ALTER TABLE `activities` ADD `route_json` text;--> statement-breakpoint
ALTER TABLE `user_settings` ADD `heat_lat` real;--> statement-breakpoint
ALTER TABLE `user_settings` ADD `heat_lng` real;--> statement-breakpoint
ALTER TABLE `user_settings` ADD `heat_radius_km` integer DEFAULT 15 NOT NULL;--> statement-breakpoint
ALTER TABLE `user_settings` ADD `heat_label` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `user_settings` ADD `heat_period` text DEFAULT 'week' NOT NULL;