ALTER TABLE `user_settings` ADD `max_hr` integer;--> statement-breakpoint
ALTER TABLE `user_settings` ADD `baseline_hrv_ms` integer;--> statement-breakpoint
ALTER TABLE `user_settings` ADD `baseline_resting_hr` integer;--> statement-breakpoint
ALTER TABLE `user_settings` ADD `baseline_sleep_hours` real;--> statement-breakpoint
ALTER TABLE `activities` ADD `hr_zone_times` text;