-- `reps`, `work_min` and `recover_min` become nullable: an interval session can
-- be planned with a zone and a total time, and the reps filled in later.
-- SQLite cannot drop a NOT NULL constraint in place, so the table is rebuilt —
-- recreate, copy, drop, rename, and put the index back. `target_reps` joins the
-- row at the same time (kilometres per rep, for `8 × 800 m`).
PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_planned_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`date` text NOT NULL,
	`mode` text NOT NULL,
	`kind` text NOT NULL,
	`title` text DEFAULT '' NOT NULL,
	`zone` integer DEFAULT 2 NOT NULL,
	`minutes` integer DEFAULT 60 NOT NULL,
	`reps` integer,
	`work_min` real,
	`recover_min` real,
	`warmup_min` real DEFAULT 15 NOT NULL,
	`cooldown_min` real DEFAULT 10 NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'planned' NOT NULL,
	`linked_activity_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	`structure_json` text,
	`target_km` real,
	`target_reps` real,
	FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON UPDATE no action ON DELETE cascade
);--> statement-breakpoint
INSERT INTO `__new_planned_sessions`("id", "user_id", "date", "mode", "kind", "title", "zone", "minutes", "reps", "work_min", "recover_min", "warmup_min", "cooldown_min", "notes", "status", "linked_activity_id", "created_at", "updated_at", "structure_json", "target_km", "target_reps")
SELECT "id", "user_id", "date", "mode", "kind", "title", "zone", "minutes", "reps", "work_min", "recover_min", "warmup_min", "cooldown_min", "notes", "status", "linked_activity_id", "created_at", "updated_at", "structure_json", "target_km", NULL FROM `planned_sessions`;--> statement-breakpoint
DROP TABLE `planned_sessions`;--> statement-breakpoint
ALTER TABLE `__new_planned_sessions` RENAME TO `planned_sessions`;--> statement-breakpoint
CREATE INDEX `planned_sessions_user_date_idx` ON `planned_sessions` (`user_id`,`date`);--> statement-breakpoint
PRAGMA foreign_keys=ON;
