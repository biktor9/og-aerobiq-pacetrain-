CREATE TABLE `sick_notes` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`date_from` text NOT NULL,
	`date_to` text NOT NULL,
	`symptoms` text DEFAULT '' NOT NULL,
	`severity` integer DEFAULT 2 NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `sick_notes_user_from_idx` ON `sick_notes` (`user_id`,`date_from`);--> statement-breakpoint
ALTER TABLE `wellness` ADD `hrv_ms` integer;--> statement-breakpoint
ALTER TABLE `wellness` ADD `sleep_quality` integer;--> statement-breakpoint
ALTER TABLE `wellness` ADD `soreness` integer;--> statement-breakpoint
ALTER TABLE `wellness` ADD `feeling` text;