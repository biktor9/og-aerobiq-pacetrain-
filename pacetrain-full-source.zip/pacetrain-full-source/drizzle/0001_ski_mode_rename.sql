-- The discipline vocabulary was widened (run, trail, orienteering, ski,
-- strength, mtb, bike) and the old "rollerski" bucket became "ski".
UPDATE `planned_sessions` SET `mode` = 'ski' WHERE `mode` = 'rollerski';
--> statement-breakpoint
UPDATE `activities` SET `mode` = 'ski' WHERE `mode` = 'rollerski';
--> statement-breakpoint
UPDATE `user_settings` SET `primary_mode` = 'ski' WHERE `primary_mode` = 'rollerski';
