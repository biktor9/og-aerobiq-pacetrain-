CREATE TABLE `page_notes` (
	`page` text PRIMARY KEY NOT NULL,
	`body` text DEFAULT '' NOT NULL,
	`updated_by` text,
	`updated_at` integer NOT NULL
);
