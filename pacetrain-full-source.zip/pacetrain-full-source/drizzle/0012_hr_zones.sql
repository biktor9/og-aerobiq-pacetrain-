-- The athlete's own heart-rate zones (the tops of Z1 … Z4 in bpm) and which
-- sports count towards them. Both are optional: without them the zones come
-- from fixed shares of the maximum heart rate and every sport is counted.
ALTER TABLE `user_settings` ADD `hr_zone_bounds` text;--> statement-breakpoint
ALTER TABLE `user_settings` ADD `hr_zone_modes` text;
