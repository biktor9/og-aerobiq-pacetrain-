ALTER TABLE `planned_sessions` ADD `warmup_km` real;--> statement-breakpoint
ALTER TABLE `planned_sessions` ADD `cooldown_km` real;--> statement-breakpoint
ALTER TABLE `user_settings` ADD `dashboard_json` text;--> statement-breakpoint
ALTER TABLE `user_settings` ADD `progress_style` text DEFAULT 'ring' NOT NULL;