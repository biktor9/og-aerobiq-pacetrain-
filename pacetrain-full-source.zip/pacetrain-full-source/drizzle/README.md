# Migrations

`src/db/schema.ts` is the source of truth; everything in this folder is generated
from it by `drizzle-kit generate`.

## Changing the schema

1. Edit `src/db/schema.ts`.
2. `npm run db:generate` — writes `NNNN_<name>.sql`, appends to `meta/_journal.json`
   and stores the new `meta/NNNN_snapshot.json`. **Commit all three.**
3. `npm run db:migrate` — `scripts/migrate.mjs` replays the SQL files that are not
   yet recorded in `__drizzle_migrations`. `npm run dev` does this automatically
   through `predev`.

`predev` only *applies* migrations. Editing `schema.ts` without generating one
leaves the database behind the code: drizzle then selects columns SQLite does not
have yet, and every affected page fails at runtime with
`SqliteError: no such column: "..."`. That is exactly how `structure_json` went
missing, so `src/db/schema.test.ts` now replays these migrations onto an in-memory
database and fails when the result does not cover the schema.

## Notes

- Migrations are applied in `_journal.json` order, so keep `idx`/`tag` sequential.
- Data-only migrations (such as `0001_ski_mode_rename`) must still register a
  snapshot; `0001_snapshot.json` is a copy of `0000_snapshot.json` with a new `id`
  and `prevId` because that step changed no DDL. Without it `db:generate` has no
  base to diff against.
- Hand-written SQL is fine, but re-run `npm run db:generate` afterwards and check
  that it reports no changes.
