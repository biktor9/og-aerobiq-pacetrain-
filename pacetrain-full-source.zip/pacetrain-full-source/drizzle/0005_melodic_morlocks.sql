ALTER TABLE `activities` ADD `rpe` integer;--> statement-breakpoint
ALTER TABLE `activities` ADD `feel` integer;--> statement-breakpoint
ALTER TABLE `activities` ADD `notes` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `activities` ADD `removed` integer DEFAULT false NOT NULL;