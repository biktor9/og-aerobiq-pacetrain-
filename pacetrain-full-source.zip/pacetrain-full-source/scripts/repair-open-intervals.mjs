/**
 * One-off repair for a database created before `0010_open_intervals.sql` was
 * rewritten: `reps`, `work_min` and `recover_min` were still NOT NULL, so an
 * interval session saved without reps failed with
 * `NOT NULL constraint failed: planned_sessions.reps`.
 *
 * SQLite cannot drop a constraint in place, so this rebuilds the table the way
 * the migration does. Every row is copied across unchanged.
 */
import Database from 'better-sqlite3';

const db = new Database('./data/pacetrain.db');
db.pragma('foreign_keys = OFF');

const before = db.prepare('select count(*) c from planned_sessions').get();
console.log(`rows before: ${before.c}`);

db.exec(`
CREATE TABLE __new_planned_sessions (
  id text PRIMARY KEY NOT NULL,
  user_id text NOT NULL,
  date text NOT NULL,
  mode text NOT NULL,
  kind text NOT NULL,
  title text DEFAULT '' NOT NULL,
  zone integer DEFAULT 2 NOT NULL,
  minutes integer DEFAULT 60 NOT NULL,
  reps integer,
  work_min real,
  recover_min real,
  warmup_min real DEFAULT 15 NOT NULL,
  cooldown_min real DEFAULT 10 NOT NULL,
  notes text DEFAULT '' NOT NULL,
  status text DEFAULT 'planned' NOT NULL,
  linked_activity_id text,
  created_at integer NOT NULL,
  updated_at integer NOT NULL,
  structure_json text,
  target_km real,
  target_reps real,
  FOREIGN KEY (user_id) REFERENCES user(id) ON UPDATE no action ON DELETE cascade
);
INSERT INTO __new_planned_sessions
SELECT id, user_id, date, mode, kind, title, zone, minutes, reps, work_min, recover_min,
       warmup_min, cooldown_min, notes, status, linked_activity_id, created_at, updated_at,
       structure_json, target_km, target_reps
FROM planned_sessions;
DROP TABLE planned_sessions;
ALTER TABLE __new_planned_sessions RENAME TO planned_sessions;
CREATE INDEX IF NOT EXISTS planned_sessions_user_date_idx ON planned_sessions (user_id, date);
`);

db.pragma('foreign_keys = ON');

const after = db.prepare('select count(*) c from planned_sessions').get();
console.log(`rows after: ${after.c}`);
for (const column of db.prepare('PRAGMA table_info(planned_sessions)').all()) {
  if (['reps', 'work_min', 'recover_min', 'target_reps'].includes(column.name)) {
    console.log(`${column.name}: notnull=${column.notnull}`);
  }
}
db.close();
