/**
 * Applies the SQL files in ./drizzle to the local SQLite database.
 *
 * Run with `npm run db:migrate`. It is also wired as `predev`, so a fresh
 * checkout only needs `npm install` and `npm run dev`.
 */
import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import { migrate } from 'drizzle-orm/better-sqlite3/migrator';

// drizzle-kit's CLI loads .env.local; plain node does not, so do it by hand.
if (fs.existsSync('.env.local')) {
  for (const line of fs.readFileSync('.env.local', 'utf8').split(/\r?\n/)) {
    const match = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
    if (match && !process.env[match[1]]) {
      process.env[match[1]] = match[2].replace(/^"(.*)"$/, '$1');
    }
  }
}

// On Cloudflare the database is D1, and wrangler owns its migrations
// (`npm run db:migrate:d1`). Nothing to do here in that mode.
if ((process.env.DATABASE_DRIVER ?? '').toLowerCase() === 'd1') {
  console.log('DATABASE_DRIVER=d1 — migrations are applied with `wrangler d1 migrations apply`.');
  process.exit(0);
}

const raw = process.env.DATABASE_URL?.trim() || './data/pacetrain.db';
const withoutScheme = raw.startsWith('file:') ? raw.slice('file:'.length) : raw;
const file = path.isAbsolute(withoutScheme) ? withoutScheme : path.join(process.cwd(), withoutScheme);

fs.mkdirSync(path.dirname(file), { recursive: true });

const sqlite = new Database(file);
sqlite.pragma('journal_mode = WAL');

try {
  migrate(drizzle(sqlite), { migrationsFolder: path.join(process.cwd(), 'drizzle') });
  const tables = sqlite
    .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    .all()
    .map((row) => row.name);
  console.log(`Database ready at ${file}`);
  console.log(`Tables: ${tables.join(', ')}`);
} finally {
  sqlite.close();
}
