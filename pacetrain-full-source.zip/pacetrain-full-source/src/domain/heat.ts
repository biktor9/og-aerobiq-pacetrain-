import { routeDistanceM, routeTouchesArea, routeBounds, centreOf, radiusOf, type Area, type LatLng } from './geo';
import { addDays } from './week';

/**
 * The heat map: every trace you have run, drawn on top of each other, limited to
 * one patch of the world and one stretch of time. The area is chosen once and
 * stays until the athlete changes it.
 */

export type HeatPeriod = 'week' | 'month' | 'year';

export const HEAT_PERIODS: { id: HeatPeriod; label: string }[] = [
  { id: 'week', label: 'This week' },
  { id: 'month', label: 'This month' },
  { id: 'year', label: 'This year' }
];

export function isHeatPeriod(value: unknown): value is HeatPeriod {
  return value === 'week' || value === 'month' || value === 'year';
}

export function heatPeriodLabel(period: HeatPeriod): string {
  return HEAT_PERIODS.find((entry) => entry.id === period)?.label ?? 'This week';
}

/** Calendar start: Monday of this week, the first of the month, the first of the year. */
export function periodStart(period: HeatPeriod, now: Date): Date {
  const day = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (period === 'week') {
    // getDay() is 0 on Sunday; the week starts on Monday here, as everywhere else.
    const weekday = (day.getDay() + 6) % 7;
    return addDays(day, -weekday);
  }
  if (period === 'month') return new Date(day.getFullYear(), day.getMonth(), 1);
  return new Date(day.getFullYear(), 0, 1);
}

export interface HeatRoute {
  id: string;
  date: string;
  name: string;
  points: LatLng[];
}

/** The traces that pass through the chosen area. */
export function routesInArea(routes: HeatRoute[], area: Area): HeatRoute[] {
  return routes.filter((route) => route.points.length > 1 && routeTouchesArea(route.points, [area.lat, area.lng], area.radiusKm));
}

export function heatTotals(routes: HeatRoute[]): { sessions: number; km: number } {
  const metres = routes.reduce((total, route) => total + routeDistanceM(route.points), 0);
  return { sessions: routes.length, km: Math.round(metres / 100) / 10 };
}

/** Where to point the map before the athlete has picked a place of their own. */
export function areaAround(points: LatLng[], radiusKm = 15, label = 'Your area'): Area | null {
  const bounds = routeBounds(points);
  if (!bounds) return null;
  const centre = centreOf(bounds);
  return {
    lat: Math.round(centre[0] * 1e5) / 1e5,
    lng: Math.round(centre[1] * 1e5) / 1e5,
    radiusKm: Math.max(2, Math.min(60, Math.round(Math.max(radiusKm, radiusOf(bounds))))),
    label
  };
}

/** Every trace from the period, newest first, capped so the page stays light. */
export function latestRoutes(routes: HeatRoute[], limit = 200): HeatRoute[] {
  return [...routes].sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, limit);
}

/** `Mon 20 Oct` — used in the heat map's list of loaded sessions. */
export function routeLabel(route: HeatRoute): string {
  const [year, month, day] = route.date.split('-').map(Number);
  const when = new Date(year, (month ?? 1) - 1, day ?? 1);
  const weekday = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][when.getDay()];
  return `${weekday} ${when.getDate()} ${when.toLocaleString('en-GB', { month: 'short' })}`;
}
