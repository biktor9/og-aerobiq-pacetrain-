import { describe, expect, it } from 'vitest';
import { baselineFor, baselineTable, cleanBaselines } from './baselines';
import type { WellnessEntry } from './wellness';

function entry(date: string, overrides: Partial<WellnessEntry> = {}): WellnessEntry {
  return {
    date,
    sleepHours: 7.5,
    sleepQuality: 3,
    hrvMs: 60,
    restingHr: 50,
    weightKg: 71,
    soreness: 3,
    mood: 3,
    stress: 3,
    feeling: null,
    notes: '',
    ...overrides
  };
}

/** Ten calm mornings at HRV 60, RHR 50 and 7.5 h of sleep. */
function history(): WellnessEntry[] {
  return Array.from({ length: 10 }, (_, index) => entry(`2026-10-${String(1 + index).padStart(2, '0')}`));
}

describe('baselineFor', () => {
  it('uses the rolling average when nothing was typed', () => {
    const view = baselineFor('hrvMs', history(), {});
    expect(view.manual).toBe(false);
    expect(view.value).toBe(60);
    expect(view.days).toBe(10);
  });

  it('lets the athlete overrule the average', () => {
    const view = baselineFor('hrvMs', history(), { hrvMs: 72 });
    expect(view.manual).toBe(true);
    expect(view.value).toBe(72);
    expect(view.days).toBe(0);
  });

  it('has nothing to average yet on a new account', () => {
    const view = baselineFor('restingHr', [], {});
    expect(view.value).toBeNull();
    expect(view.manual).toBe(false);
  });

  it('treats a cleared field as unset again', () => {
    const view = baselineFor('sleepHours', history(), { sleepHours: null });
    expect(view.manual).toBe(false);
    expect(view.value).toBe(7.5);
  });
});

describe('baselineTable', () => {
  it('lists HRV, resting heart rate and sleep in that order', () => {
    const rows = baselineTable(history(), { restingHr: 46 });
    expect(rows.map((row) => row.key)).toEqual(['hrvMs', 'restingHr', 'sleepHours']);
    expect(rows[1].manual).toBe(true);
    expect(rows[1].value).toBe(46);
  });
});

describe('cleanBaselines', () => {
  it('keeps the numbers in range and clears the rest', () => {
    expect(cleanBaselines({ hrvMs: 999, restingHr: 48, sleepHours: null })).toEqual({
      hrvMs: 300,
      restingHr: 48,
      sleepHours: null
    });
  });

  it('ignores nonsense', () => {
    expect(cleanBaselines({ hrvMs: Number.NaN, restingHr: -5 })).toEqual({
      hrvMs: null,
      restingHr: null,
      sleepHours: null
    });
  });
});
