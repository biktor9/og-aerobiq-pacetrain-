import { describe, expect, it } from 'vitest';
import {
  activityZoneMinutes,
  defaultBounds,
  observedMaxHr,
  parseZoneBounds,
  parseZoneModes,
  serializeZoneBounds,
  serializeZoneModes,
  sportsWithHeartRate,
  zoneForHrWith,
  zoneLabels,
  zoneMinutes,
  zoneRange,
  zoneSlices
} from './hr-zones';
import type { Activity } from './types';

/** The athlete's own zones: Z1 under 111, Z2 to 133, Z3 to 152, Z4 to 168. */
const BOUNDS = [110, 133, 152, 168] as [number, number, number, number];

function activity(overrides: Partial<Activity> & { id: string }): Activity {
  return {
    externalId: overrides.id,
    date: '2026-10-20',
    mode: 'run',
    name: 'Run',
    durationSec: 3600,
    distanceM: 10_000,
    avgHr: 140,
    maxHr: 150,
    load: null,
    source: 'intervals.icu',
    linkedSessionId: null,
    ...overrides
  };
}

describe('zone boundaries', () => {
  it('reads back four rising numbers', () => {
    expect(parseZoneBounds('110,133,152,168', 190)).toEqual([110, 133, 152, 168]);
  });

  it('falls back to shares of the maximum when nothing is stored', () => {
    expect(parseZoneBounds(null, 190)).toEqual(defaultBounds(190));
    expect(defaultBounds(190)).toEqual([124, 144, 160, 177]);
  });

  it('ignores a list that is short, long or out of order', () => {
    expect(parseZoneBounds('110,133,152', 190)).toEqual(defaultBounds(190));
    expect(parseZoneBounds('110,133,152,168,180', 190)).toEqual(defaultBounds(190));
    expect(parseZoneBounds('110,152,133,168', 190)).toEqual(defaultBounds(190));
    expect(parseZoneBounds('nonsense', 190)).toEqual(defaultBounds(190));
  });

  it('round-trips through the stored form', () => {
    expect(serializeZoneBounds(BOUNDS)).toBe('110,133,152,168');
  });

  it('places a heart rate in the athlete’s own zones', () => {
    expect(zoneForHrWith(100, BOUNDS)).toBe(1);
    expect(zoneForHrWith(110, BOUNDS)).toBe(1);
    expect(zoneForHrWith(120, BOUNDS)).toBe(2);
    expect(zoneForHrWith(140, BOUNDS)).toBe(3);
    expect(zoneForHrWith(160, BOUNDS)).toBe(4);
    expect(zoneForHrWith(180, BOUNDS)).toBe(5);
  });

  it('describes each zone as a range in bpm', () => {
    expect(zoneRange(1, BOUNDS)).toEqual({ from: 0, to: 110 });
    expect(zoneRange(2, BOUNDS)).toEqual({ from: 110, to: 133 });
    expect(zoneRange(5, BOUNDS)).toEqual({ from: 168, to: null });
    expect(zoneLabels(BOUNDS).map((zone) => zone.range)).toEqual([
      'under 111 bpm',
      '111–133 bpm',
      '134–152 bpm',
      '153–168 bpm',
      '169+ bpm'
    ]);
  });
});


describe('activityZoneMinutes', () => {
  it('places an easy hour mostly in Z1–Z2', () => {
    const zones = activityZoneMinutes(activity({ id: 'easy', avgHr: 118, maxHr: 126 }), BOUNDS);
    expect((zones?.[1] ?? 0) + (zones?.[2] ?? 0)).toBeGreaterThan(50);
    expect(zones?.[5] ?? 0).toBe(0);
  });

  it('places a threshold hour mostly in Z4', () => {
    const zones = activityZoneMinutes(activity({ id: 'hard', avgHr: 160, maxHr: 166 }), BOUNDS);
    expect((zones?.[4] ?? 0) + (zones?.[5] ?? 0)).toBeGreaterThan(40);
  });

  it('moves a session up a zone when the boundaries are lower', () => {
    const run = activity({ id: 'r', avgHr: 140, maxHr: 145 });
    const normal = activityZoneMinutes(run, BOUNDS);
    // Boundaries that all sit lower put the same run in a harder zone.
    const low = activityZoneMinutes(run, [100, 120, 130, 138]);
    expect((low?.[4] ?? 0) + (low?.[5] ?? 0)).toBeGreaterThan((normal?.[4] ?? 0) + (normal?.[5] ?? 0));
  });

  it('uses the zone times intervals.icu recorded when they are there', () => {
    const zones = activityZoneMinutes(activity({ id: 'zoned', hrZoneSec: [600, 1200, 300, 1200, 300] }), BOUNDS);
    expect(zones).toEqual({ 1: 10, 2: 20, 3: 5, 4: 20, 5: 5 });
  });

  it('has nothing to say about an activity without a heart rate', () => {
    expect(activityZoneMinutes(activity({ id: 'none', avgHr: null, maxHr: null }), BOUNDS)).toBeNull();
  });
});

describe('zoneMinutes', () => {
  const activities = [
    activity({ id: 'run-1', mode: 'run', durationSec: 3600 }),
    activity({ id: 'run-2', mode: 'trail', durationSec: 1800 }),
    activity({ id: 'gym', mode: 'strength', durationSec: 3600, avgHr: 150, maxHr: 165 }),
    activity({ id: 'nohr', avgHr: null, maxHr: null })
  ];

  it('counts every sport by default', () => {
    const total = zoneMinutes(activities, { bounds: BOUNDS });
    expect(total.totalMinutes).toBe(150);
    expect(total.withoutHr).toBe(1);
  });

  it('counts only the sports the athlete chose', () => {
    const total = zoneMinutes(activities, { bounds: BOUNDS, modes: ['run', 'trail'] });
    expect(total.totalMinutes).toBe(90);
  });

  it('says nothing was measured when no chosen sport has a heart rate', () => {
    const total = zoneMinutes(activities, { bounds: BOUNDS, modes: ['bike'] });
    expect(total.totalMinutes).toBe(0);
    expect(Object.values(total.zones).reduce((a, b) => a + b, 0)).toBe(0);
  });
});

describe('zone modes', () => {
  it('stores null when every sport counts', () => {
    expect(serializeZoneModes(null)).toBeNull();
    expect(serializeZoneModes([])).toBeNull();
    expect(serializeZoneModes(['run', 'trail', 'orienteering', 'ski', 'strength', 'mtb', 'bike'])).toBeNull();
  });

  it('stores a chosen subset in the planner’s order', () => {
    expect(serializeZoneModes(['bike', 'run'])).toBe('run,bike');
  });

  it('reads a subset back, ignoring anything unknown', () => {
    expect(parseZoneModes('run,bike')).toEqual(['run', 'bike']);
    expect(parseZoneModes('run,swim')).toEqual(['run']);
    expect(parseZoneModes(null)).toBeNull();
    expect(parseZoneModes('')).toBeNull();
  });

  it('lists the sports that have a heart rate', () => {
    const rows = sportsWithHeartRate([
      activity({ id: 'a', mode: 'run', durationSec: 3600 }),
      activity({ id: 'b', mode: 'bike', durationSec: 1800 }),
      activity({ id: 'c', mode: 'strength', avgHr: null, maxHr: null })
    ]);
    expect(rows.map((row) => row.mode)).toEqual(['run', 'bike']);
    expect(rows[0].minutes).toBe(60);
  });
});

describe('zoneSlices', () => {
  it('gives each zone a share of the total and drops empty ones', () => {
    const slices = zoneSlices({ 1: 30, 2: 30, 3: 0, 4: 40, 5: 0 });
    expect(slices.map((slice) => slice.id)).toEqual([1, 2, 4]);
    expect(slices.map((slice) => slice.share)).toEqual([30, 30, 40]);
  });
});

describe('observedMaxHr', () => {
  it('takes the highest peak in the activities', () => {
    expect(
      observedMaxHr([
        activity({ id: 'a', maxHr: 172 }),
        activity({ id: 'b', maxHr: 181 }),
        activity({ id: 'c', maxHr: null, avgHr: 140 })
      ])
    ).toBe(181);
  });

  it('falls back when nothing was recorded', () => {
    expect(observedMaxHr([])).toBe(190);
  });
});
