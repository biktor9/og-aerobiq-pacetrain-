/**
 * The colour of a day in the calendar, from how it went against the plan.
 *
 * The scale is a single number: the day's training as a share of what was
 * planned. Each stop has a colour and the reader is meant to travel along it —
 * so 25 % reads as a red-yellow blend rather than a hard switch, which is what
 * makes a week of half-finished sessions look different from a week of misses.
 *
 *   0 %      red       skipped: marked so, or the day ended with nothing done
 *   50 %     yellow    done, but only half of what was planned
 *   100 %    green     the plan, followed
 *   200 %+   blue      twice the plan, or more
 *
 * A day without a plan has no ratio, so it gets the plain training shade it
 * always had; that is not a judgement about the plan, just "you trained".
 *
 * A day that has not ended yet is never judged. It stays blank — no red, no
 * shade — because the run it is waiting for may still happen. Only two things
 * make a day red before it is over: the athlete marking it skipped, which is
 * their own word for it, and a day that ended with nothing done.
 */

export type DayVerdict = 'skipped' | 'short' | 'on-plan' | 'over' | 'unplanned' | 'pending';

export interface DayColour {
  verdict: DayVerdict;
  /** Training as a share of the plan; null when the day had no plan. */
  ratio: number | null;
  /** The colour to paint with. */
  color: string;
  /** A word for the tooltip. */
  label: string;
}

/** The stops, in order. The ends are the darkest and the middle is the plan. */
export const SCALE = {
  skip: '#b3392e',
  half: '#d8a325',
  plan: '#157a55',
  double: '#1f5fd0'
} as const;

/** Below this share of the plan the day counts as skipped, not merely short. */
export const SKIPPED_BELOW = 0.1;
/** Half the plan. */
export const SHORT_AT = 0.5;
/** Twice the plan is as blue as it gets. */
export const DOUBLE_AT = 2;

function hexToRgb(hex: string): [number, number, number] {
  const value = hex.replace('#', '');
  return [
    parseInt(value.slice(0, 2), 16),
    parseInt(value.slice(2, 4), 16),
    parseInt(value.slice(4, 6), 16)
  ];
}

/** Mixes two colours, `t` running from the first to the second. */
export function mixHex(from: string, to: string, t: number): string {
  const a = hexToRgb(from);
  const b = hexToRgb(to);
  const clamped = Math.min(1, Math.max(0, t));
  const channel = (index: number) => Math.round(a[index] + (b[index] - a[index]) * clamped);
  return `#${[0, 1, 2].map((index) => channel(index).toString(16).padStart(2, '0')).join('')}`;
}

/**
 * The colour for a ratio of actual to planned. Anything at or below the skip
 * threshold is pure red; between the stops the colour is interpolated, so the
 * step from red to yellow to green to blue is continuous.
 */
export function colorForRatio(ratio: number): { color: string; verdict: DayVerdict } {
  // A ratio that is not a number at all means "no idea", which reads as nothing
  // done. Infinity is different: it means far over the plan, and reads as blue.
  const value = Number.isNaN(ratio) ? 0 : ratio;

  if (value <= SKIPPED_BELOW) return { color: SCALE.skip, verdict: 'skipped' };
  if (value < SHORT_AT) {
    // Red at the threshold, yellow at half the plan.
    const t = (value - SKIPPED_BELOW) / (SHORT_AT - SKIPPED_BELOW);
    return { color: mixHex(SCALE.skip, SCALE.half, t), verdict: 'short' };
  }
  if (value < 1) {
    // Yellow at half the plan, green at the whole of it.
    const t = (value - SHORT_AT) / (1 - SHORT_AT);
    return { color: mixHex(SCALE.half, SCALE.plan, t), verdict: 'short' };
  }
  if (value <= 1.05) return { color: SCALE.plan, verdict: 'on-plan' };
  if (value < DOUBLE_AT) {
    // Green at the plan, blue at twice it.
    const t = (value - 1) / (DOUBLE_AT - 1);
    return { color: mixHex(SCALE.plan, SCALE.double, Math.min(1, t)), verdict: 'over' };
  }
  return { color: SCALE.double, verdict: 'over' };
}

/**
 * A day's colour. A day that has not happened yet is left blank: the plan is
 * still to come, so there is nothing to judge and nothing to warn about. A day
 * that has ended is red only when it was skipped — either the athlete marked it
 * skipped, or the day went by with nothing done. In between, the shade follows
 * how much of the plan was done.
 */
export function dayColour(input: {
  /** Minutes actually trained. */
  minutes: number;
  /** Minutes the plan wanted that day. */
  plannedMinutes: number;
  /** Sessions marked skipped that day. */
  skipped?: number;
  /**
   * True once the day is over. An open day is never called skipped, however
   * late it is: the athlete may still be about to run.
   */
  ended?: boolean;
}): DayColour {
  const planned = input.plannedMinutes;

  if (planned <= 0) {
    return { verdict: 'unplanned', ratio: null, color: '', label: 'no plan' };
  }

  const ended = input.ended ?? true;

  // Marked skipped: that is the athlete's own word for it, so it holds whenever
  // they say it, before the day is out or after.
  if (input.skipped && input.skipped > 0) {
    return { verdict: 'skipped', ratio: 0, color: SCALE.skip, label: 'skipped' };
  }

  // The day is still going: the plan may yet be met, so it stays unjudged and
  // wears only its dashed outline.
  if (!ended && input.minutes <= 0) {
    return { verdict: 'pending', ratio: null, color: '', label: 'still to come' };
  }

  const ratio = input.minutes / planned;
  const { color, verdict } = colorForRatio(ratio);
  return { color, verdict, ratio, label: labelFor(verdict, ratio) };
}

function labelFor(verdict: DayVerdict, ratio: number): string {
  const share = Math.round(ratio * 100);
  switch (verdict) {
    case 'skipped':
      return 'skipped';
    case 'short':
      return `${share}% of the plan`;
    case 'on-plan':
      return 'plan followed';
    case 'over':
      return `${share}% of the plan`;
    case 'pending':
      return 'still to come';
    default:
      return 'no plan';
  }
}

/** The legend's stops, in the order they read. */
export const LEGEND: { color: string; label: string }[] = [
  { color: SCALE.skip, label: 'skipped' },
  { color: SCALE.half, label: '50%' },
  { color: SCALE.plan, label: 'on plan' },
  { color: SCALE.double, label: '200%' }
];
