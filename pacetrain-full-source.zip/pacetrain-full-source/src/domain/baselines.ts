import { baselineOf, valuesOf, type WellnessEntry, type WellnessNumberKey } from './wellness';

/**
 * The athlete's own baseline numbers — HRV, resting heart rate, sleep.
 *
 * A watch's baseline is an average of whatever it managed to record, and when
 * the watch is new, worn badly or simply wrong, that average is wrong too. These
 * are the fallbacks: set one by hand and every morning is compared with it
 * instead. A value left unset keeps the rolling average.
 */

export type BaselineKey = 'hrvMs' | 'restingHr' | 'sleepHours';

export const BASELINE_FIELDS: {
  key: BaselineKey;
  label: string;
  unit: string;
  min: number;
  max: number;
  step: number;
  hint: string;
}[] = [
  {
    key: 'hrvMs',
    label: 'HRV baseline',
    unit: 'ms',
    min: 5,
    max: 300,
    step: 1,
    hint: 'rMSSD, the overnight number your watch reports'
  },
  {
    key: 'restingHr',
    label: 'Resting heart rate',
    unit: 'bpm',
    min: 25,
    max: 150,
    step: 1,
    hint: 'the calmest number of a normal night'
  },
  {
    key: 'sleepHours',
    label: 'Sleep baseline',
    unit: 'h',
    min: 3,
    max: 12,
    step: 0.25,
    hint: 'what a normal night looks like for you'
  }
];

export type ManualBaselines = Partial<Record<BaselineKey, number | null>>;

export interface BaselineView {
  key: BaselineKey;
  label: string;
  unit: string;
  /** The number that is actually used — set by hand, or averaged. */
  value: number | null;
  /** True when the athlete typed it. */
  manual: boolean;
  /** How many days the rolling average was built from. */
  days: number;
}

function round1(value: number | null): number | null {
  return value === null ? null : Math.round(value * 10) / 10;
}

/** One field: the hand-set number if there is one, the recent average otherwise. */
export function baselineFor(
  key: BaselineKey,
  entries: WellnessEntry[],
  manual: ManualBaselines
): BaselineView {
  const field = BASELINE_FIELDS.find((item) => item.key === key) ?? BASELINE_FIELDS[0];
  const typed = manual[key];
  if (typeof typed === 'number' && Number.isFinite(typed) && typed > 0) {
    return { key, label: field.label, unit: field.unit, value: typed, manual: true, days: 0 };
  }
  const rolling = baselineOf(entries, key as WellnessNumberKey, { days: 14 });
  return {
    key,
    label: field.label,
    unit: field.unit,
    value: round1(rolling.value),
    manual: false,
    days: rolling.days
  };
}

/** All three, in the order the form shows them. */
export function baselineTable(entries: WellnessEntry[], manual: ManualBaselines): BaselineView[] {
  return BASELINE_FIELDS.map((field) => baselineFor(field.key, entries, manual));
}

/** Weeks of entries, oldest first, for a sparkline next to each field. */
export function baselineSeries(entries: WellnessEntry[], key: BaselineKey): number[] {
  return valuesOf(entries, key as WellnessNumberKey);
}

/** Only the numbers that are really set, ready to be stored. */
export function cleanBaselines(raw: ManualBaselines): ManualBaselines {
  const out: ManualBaselines = {};
  for (const field of BASELINE_FIELDS) {
    const value = raw[field.key];
    if (typeof value === 'number' && Number.isFinite(value) && value > 0) {
      out[field.key] = Math.min(field.max, Math.max(field.min, value));
    } else {
      out[field.key] = null;
    }
  }
  return out;
}
