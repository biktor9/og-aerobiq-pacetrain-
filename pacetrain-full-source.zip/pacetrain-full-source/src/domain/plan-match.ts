import { isRunningMode } from './activity';
import type { Activity, ModeId, Session } from './types';

/**
 * Pairing planned sessions with the activities that fulfilled them.
 *
 * The planner and the import know nothing about each other — a session is a
 * row with a date and a discipline, an activity is a file from a watch. Left
 * unpaired, a day looks like two sessions ("I ran it, why does it say I didn't
 * do it?"). This module does the matching once, in a way the calendar, the week
 * summary and the session editor all agree on.
 *
 * An explicit link always wins. Otherwise: same day, same discipline family,
 * and a duration or distance in the same ballpark.
 */

export interface SessionActivityPair {
  session: Session;
  activity: Activity;
  /** True when the athlete made the link by hand. */
  manual: boolean;
}

export interface DayPairing {
  pairs: SessionActivityPair[];
  /** Activities that belong to no planned session. */
  leftoverActivities: Activity[];
  /** Sessions with nothing to show for them. */
  openSessions: Session[];
  /** Sessions that count as done: paired, or marked done by hand. */
  doneSessions: Session[];
}

export type DisciplineGroup = 'run' | 'bike' | 'ski' | 'strength';

/** Trail and orienteering are running; MTB is cycling. */
export function disciplineGroup(mode: ModeId): DisciplineGroup {
  if (isRunningMode(mode)) return 'run';
  if (mode === 'bike' || mode === 'mtb') return 'bike';
  if (mode === 'ski') return 'ski';
  return 'strength';
}

function minutesOf(activity: Activity): number {
  return activity.durationSec > 0 ? activity.durationSec / 60 : 0;
}

/**
 * How plausible it is that `activity` is the session that was planned.
 * `null` means "not this one": a different sport, or a wildly different size.
 */
function pairScore(session: Session, activity: Activity): number | null {
  const sessionMin = session.durationMin;
  const activityMin = minutesOf(activity);
  const durationRatio = sessionMin > 0 && activityMin > 0 ? activityMin / sessionMin : null;

  const sessionKm = session.targetKm ?? 0;
  const activityKm = activity.distanceM > 0 ? activity.distanceM / 1000 : 0;
  const kmRatio = sessionKm > 0 && activityKm > 0 ? activityKm / sessionKm : null;

  const sameMode = activity.mode === session.mode;
  const sameGroup = disciplineGroup(activity.mode) === disciplineGroup(session.mode);
  if (!sameMode && !sameGroup) return null;

  // A 20-minute shakeout should not be claimed by a 2-hour ride, even if both
  // are "training". Requiring one plausible dimension avoids that.
  const plausibleDuration = durationRatio !== null && durationRatio >= 0.45 && durationRatio <= 2.2;
  const plausibleDistance = kmRatio !== null && kmRatio >= 0.5 && kmRatio <= 2;
  if (!plausibleDuration && !plausibleDistance) return null;

  const modePenalty = sameMode ? 0 : 0.35;
  const durationPenalty = durationRatio === null ? 0.25 : Math.min(2, Math.abs(Math.log(durationRatio)));
  const distancePenalty = kmRatio === null ? 0 : Math.min(1.5, Math.abs(Math.log(kmRatio)) * 0.5);

  return modePenalty + durationPenalty + distancePenalty;
}

/** Pairs one day's sessions with one day's activities. */
export function pairDay(sessions: Session[], activities: Activity[]): DayPairing {
  const pairs: SessionActivityPair[] = [];
  const usedSessions = new Set<string>();
  const usedActivities = new Set<string>();

  // 1. Links the athlete made by hand, even across disciplines. A session they
  // marked skipped stays skipped: the activity may exist, but it is not what
  // they meant to do, and the week should say so.
  for (const session of sessions) {
    if (!session.linkedActivityId || session.status === 'skipped') continue;
    const activity = activities.find((item) => item.id === session.linkedActivityId);
    if (!activity || usedActivities.has(activity.id)) continue;
    pairs.push({ session, activity, manual: true });
    usedSessions.add(session.id);
    usedActivities.add(activity.id);
  }

  // 2. Best-scoring automatic pairs, one session and one activity each.
  const candidates: { session: Session; activity: Activity; score: number }[] = [];
  for (const session of sessions) {
    if (usedSessions.has(session.id) || session.status === 'skipped') continue;
    for (const activity of activities) {
      if (usedActivities.has(activity.id)) continue;
      const score = pairScore(session, activity);
      if (score !== null) candidates.push({ session, activity, score });
    }
  }

  for (const candidate of candidates.sort((a, b) => a.score - b.score)) {
    if (usedSessions.has(candidate.session.id) || usedActivities.has(candidate.activity.id)) continue;
    pairs.push({ session: candidate.session, activity: candidate.activity, manual: false });
    usedSessions.add(candidate.session.id);
    usedActivities.add(candidate.activity.id);
  }

  const pairedIds = new Set(pairs.map((pair) => pair.session.id));
  const doneSessions = sessions.filter(
    (session) => session.status !== 'skipped' && (pairedIds.has(session.id) || session.status === 'done')
  );

  return {
    pairs,
    leftoverActivities: activities.filter((activity) => !usedActivities.has(activity.id)),
    openSessions: sessions.filter((session) => !pairedIds.has(session.id)),
    doneSessions
  };
}

/** The same pairing across a whole week, grouped by date. */
export function pairByDate(sessions: Session[], activities: Activity[]): Map<string, DayPairing> {
  const dates = new Set([...sessions.map((session) => session.date), ...activities.map((activity) => activity.date)]);
  const out = new Map<string, DayPairing>();

  for (const date of dates) {
    out.set(
      date,
      pairDay(
        sessions.filter((session) => session.date === date),
        activities.filter((activity) => activity.date === date)
      )
    );
  }
  return out;
}

/** Session ids that have an activity behind them, for the week summary. */
export function doneSessionIds(sessions: Session[], activities: Activity[]): Set<string> {
  const out = new Set<string>();
  for (const pairing of pairByDate(sessions, activities).values()) {
    // A skipped session is not done, even if something was recorded that day.
    for (const session of pairing.doneSessions) {
      if (session.status !== 'skipped') out.add(session.id);
    }
  }
  return out;
}
