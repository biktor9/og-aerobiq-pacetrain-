import { addDays, parseISODate, toISODate } from './week';
import { baselineOf, feelingLabel, type WellnessEntry } from './wellness';

/**
 * The recovery score: overnight HRV and resting heart rate against the
 * athlete's own baseline, sleep, soreness and stress, plus what the training
 * load says and — importantly — how the athlete says they feel. An illness
 * overrides everything: no number is worth training through a fever.
 */

export type RecoveryTone = 'good' | 'ok' | 'warn' | 'bad';

export interface RecoverySignal {
  key: string;
  label: string;
  /** The reading itself, formatted for display. */
  value: string;
  verdict: RecoveryTone | 'neutral';
  /** Plain-language explanation, e.g. "9% below your 14-day normal". */
  detail: string;
}

export interface RecoveryScore {
  /** 0–100, higher is better. */
  score: number;
  label: string;
  tone: RecoveryTone;
  summary: string;
  signals: RecoverySignal[];
  /** True when an illness covers today. */
  sick: boolean;
  /** False when nothing was logged for today. */
  hasData: boolean;
}

export interface SickNote {
  id?: string;
  dateFrom: string;
  dateTo: string;
  symptoms: string;
  severity: number;
  notes: string;
}

const SLEEP_TARGET = 7.5;
const BASELINE_DAYS = 14;

export const SEVERITY_LABELS = ['Mild', 'Rough', 'Bad'];

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function pct(delta: number): string {
  const value = Math.round(delta * 100);
  return `${value > 0 ? '+' : value < 0 ? '−' : '±'}${Math.abs(value)}%`;
}

export function isSickOn(notes: SickNote[], dateISO: string): boolean {
  return notes.some((note) => note.dateFrom <= dateISO && note.dateTo >= dateISO);
}

/** Every date covered by an illness, capped so a typo cannot loop for years. */
export function sickDays(notes: SickNote[]): string[] {
  const out = new Set<string>();
  for (const note of notes) {
    let cursor = parseISODate(note.dateFrom);
    for (let guard = 0; guard < 400 && toISODate(cursor) <= note.dateTo; guard++) {
      out.add(toISODate(cursor));
      cursor = addDays(cursor, 1);
    }
  }
  return [...out];
}

export interface RecoveryInput {
  /** Today's check-in, or null when nothing has been logged. */
  today: WellnessEntry | null;
  /** Recent entries; today is excluded from the baselines automatically. */
  entries?: WellnessEntry[];
  /** Fitness/fatigue from the training history. */
  form?: { tsb: number; atl: number } | null;
  /** Illness periods. */
  sick?: SickNote[];
  todayISO?: string;
  /**
   * Baseline numbers the athlete typed themselves. A set value replaces the
   * rolling average, so a watch that reads high or a week of poor sleep does not
   * move the line the morning is measured against.
   */
  baselines?: { hrvMs?: number | null; restingHr?: number | null; sleepHours?: number | null };
}

/** The baseline to compare with: the athlete's own number, or the average. */
function baselineFor(
  key: 'hrvMs' | 'restingHr' | 'sleepHours',
  history: WellnessEntry[],
  baselines: RecoveryInput['baselines']
): { value: number | null; days: number; manual: boolean } {
  const manual = baselines?.[key];
  if (typeof manual === 'number' && Number.isFinite(manual) && manual > 0) {
    return { value: manual, days: 0, manual: true };
  }
  const rolling = baselineOf(history, key, { days: BASELINE_DAYS });
  return { ...rolling, manual: false };
}

export function recoveryScore({
  today,
  entries = [],
  form = null,
  sick = [],
  todayISO,
  baselines = {}
}: RecoveryInput): RecoveryScore {
  const date = todayISO ?? today?.date ?? toISODate(new Date());
  const sickToday = isSickOn(sick, date);
  const history = entries.filter((entry) => entry.date < date);
  const signals: RecoverySignal[] = [];
  let score = 72;
  let hasData = false;

  // 1. Overnight HRV — the strongest morning signal.
  if (today?.hrvMs) {
    hasData = true;
    const base = baselineFor('hrvMs', history, baselines);
    if (base.value && (base.manual || base.days >= 3)) {
      const delta = (today.hrvMs - base.value) / base.value;
      score += clamp(delta * 90, -20, 10);
      signals.push({
        key: 'hrv',
        label: 'Overnight HRV',
        value: `${Math.round(today.hrvMs)} ms`,
        verdict: delta >= 0.03 ? 'good' : delta >= -0.07 ? 'ok' : delta >= -0.15 ? 'warn' : 'bad',
        detail: base.manual
          ? `${pct(delta)} against your own baseline of ${Math.round(base.value)} ms`
          : `${pct(delta)} against your ${base.days}-day normal of ${Math.round(base.value)} ms`
      });
    } else {
      signals.push({
        key: 'hrv',
        label: 'Overnight HRV',
        value: `${Math.round(today.hrvMs)} ms`,
        verdict: 'neutral',
        detail: 'no baseline yet — a few more mornings and this starts counting'
      });
    }
  }

  // 2. Resting heart rate, also against the athlete's own normal.
  if (today?.restingHr) {
    hasData = true;
    const base = baselineFor('restingHr', history, baselines);
    if (base.value && (base.manual || base.days >= 3)) {
      const delta = today.restingHr - base.value;
      score -= clamp(delta * 3.5, -10, 14);
      signals.push({
        key: 'restingHr',
        label: 'Resting HR',
        value: `${Math.round(today.restingHr)} bpm`,
        verdict: delta <= -2 ? 'good' : delta <= 2 ? 'ok' : delta <= 5 ? 'warn' : 'bad',
        detail: `${delta >= 0 ? '+' : '−'}${Math.abs(Math.round(delta))} bpm against your${
          base.manual ? ' own baseline' : ' normal'
        } of ${Math.round(base.value)} bpm`
      });
    } else {
      signals.push({
        key: 'restingHr',
        label: 'Resting HR',
        value: `${Math.round(today.restingHr)} bpm`,
        verdict: 'neutral',
        detail: 'no baseline yet'
      });
    }
  }

  // 3. Sleep: how long, and how well. A typed sleep baseline wins over 7.5 h.
  if (today?.sleepHours !== null && today?.sleepHours !== undefined) {
    hasData = true;
    const sleepBase = baselineFor('sleepHours', history, baselines);
    const target = sleepBase.value ?? SLEEP_TARGET;
    const delta = today.sleepHours - target;
    score += clamp(delta * 6, -12, 8);
    const targetText = sleepBase.manual ? `${target.toFixed(1)} h baseline` : `${SLEEP_TARGET} h target`;
    signals.push({
      key: 'sleep',
      label: 'Sleep',
      value: `${today.sleepHours.toFixed(1)} h`,
      verdict: delta >= 0 ? 'good' : delta >= -0.5 ? 'ok' : delta >= -1.5 ? 'warn' : 'bad',
      detail: delta >= 0 ? `at or above the ${targetText}` : `${Math.abs(delta).toFixed(1)} h under the ${targetText}`
    });
  }

  if (today?.sleepQuality) {
    hasData = true;
    score += (today.sleepQuality - 3) * 4;
    signals.push({
      key: 'sleepQuality',
      label: 'Sleep quality',
      value: `${today.sleepQuality}/5`,
      verdict: today.sleepQuality >= 4 ? 'good' : today.sleepQuality === 3 ? 'ok' : 'warn',
      detail: 'how rested you felt waking up'
    });
  }

  // 4. Body: soreness and stress.
  if (today?.soreness) {
    hasData = true;
    score -= (today.soreness - 3) * 5;
    signals.push({
      key: 'soreness',
      label: 'Soreness',
      value: `${today.soreness}/5`,
      verdict: today.soreness <= 2 ? 'good' : today.soreness === 3 ? 'ok' : 'warn',
      detail: 'muscles and joints this morning'
    });
  }

  if (today?.stress) {
    hasData = true;
    score -= (today.stress - 3) * 4;
    signals.push({
      key: 'stress',
      label: 'Life stress',
      value: `${today.stress}/5`,
      verdict: today.stress <= 2 ? 'good' : today.stress === 3 ? 'ok' : 'warn',
      detail: 'hard training costs more when life is loud'
    });
  }


  // 5. What the training itself says.
  if (form) {
    const tsb = form.tsb;
    score += tsb < -25 ? -6 : tsb < -10 ? -2 : tsb > 15 ? 3 : 2;
    signals.push({
      key: 'load',
      label: 'Training form',
      value: `${tsb > 0 ? '+' : ''}${Math.round(tsb)}`,
      verdict: tsb < -25 ? 'warn' : tsb < -10 ? 'ok' : 'good',
      detail:
        tsb < -25
          ? 'carrying a lot of fatigue from the last week'
          : tsb < -10
            ? 'normal in a build block'
            : 'enough freshness in the tank'
    });
  }

  // 6. The athlete's own correction, which outranks a watch.
  if (today?.feeling) {
    hasData = true;
    score += today.feeling === 'better' ? 8 : today.feeling === 'worse' ? -10 : 0;
    signals.push({
      key: 'feeling',
      label: 'Your own read',
      value: feelingLabel(today.feeling),
      verdict: today.feeling === 'better' ? 'good' : today.feeling === 'worse' ? 'warn' : 'neutral',
      detail: today.feeling === 'worse' ? 'you said it feels worse than the numbers' : 'you said it matches'
    });
  }

  let rounded = Math.round(clamp(score, 0, 100));
  let label: string;
  let tone: RecoveryTone;

  if (rounded >= 80) {
    label = 'Ready to push';
    tone = 'good';
  } else if (rounded >= 65) {
    label = 'Good to train';
    tone = 'good';
  } else if (rounded >= 50) {
    label = 'Moderate';
    tone = 'ok';
  } else if (rounded >= 35) {
    label = 'Take it easy';
    tone = 'warn';
  } else {
    label = 'Rest';
    tone = 'bad';
  }

  let summary: string;
  if (sickToday) {
    rounded = Math.min(rounded, 22);
    label = 'Rest';
    tone = 'bad';
    summary = 'You are sick. Recovery comes first — training can wait a few days.';
  } else if (!hasData) {
    summary = 'No morning data yet. Log sleep, HRV and how you feel, and this becomes a real number.';
  } else if (tone === 'good') {
    summary = 'Your body is ready for the hard work.';
  } else if (tone === 'ok') {
    summary = 'Fine for training — keep the intensity honest and the easy days easy.';
  } else if (tone === 'warn') {
    summary = 'Something is off. Keep it easy, or move the quality session to tomorrow.';
  } else {
    summary = 'Recovery first: food, water, sleep. Training today would cost more than it gives.';
  }

  return { score: rounded, label, tone, summary, signals, sick: sickToday, hasData };
}

