import {
  distanceBetween,
  elevationBetween,
  firstIndexAtOrAfter,
  maxOf,
  mean,
  numbers,
  type BasicStreams
} from './streams';
import type { Segment } from './types';

/**
 * Per-interval statistics for a detected session.
 *
 * The detector only reports the metric it ran on (power, heart rate or speed).
 * This module takes the same effort windows and reads *every* stream the
 * activity has — heart rate, altitude and distance — so each interval gets a
 * complete breakdown. It is pure: streams in, numbers out.
 */

/** The parts of an activity stream the report needs. */
export type IntervalStreams = BasicStreams;

export interface IntervalRow {
  /** 1-based rep number. */
  index: number;
  startSec: number;
  durationSec: number;
  distanceM: number | null;
  paceSecPerKm: number | null;
  avgHr: number | null;
  maxHr: number | null;
  gainM: number | null;
  lossM: number | null;
  /** This interval's time minus the average interval time. */
  deltaVsAverageSec: number;
  /** Label of the group of intervals that share this one's length, e.g. `4′`. */
  sameLengthLabel: string;
  /** How many intervals are in that group (including this one). */
  sameLengthCount: number;
  /** This interval's time minus the group average. */
  deltaVsSameLengthSec: number;
  /** This interval's pace minus the group average pace (positive = slower). */
  deltaVsSameLengthPaceSec: number | null;
}

export interface IntervalGroup {
  label: string;
  count: number;
  avgDurationSec: number;
  avgPaceSecPerKm: number | null;
}

export interface IntervalTotals {
  count: number;
  timeSec: number;
  distanceM: number | null;
  avgDurationSec: number;
  paceSecPerKm: number | null;
  avgHr: number | null;
  maxHr: number | null;
  gainM: number | null;
  lossM: number | null;
}

export interface IntervalReport {
  rows: IntervalRow[];
  groups: IntervalGroup[];
  totals: IntervalTotals;
}

/** Below this a distance reads as "no movement", not as a pace. */
const MIN_DISTANCE_M = 25;
/** Reps whose length is within this share of a group's average belong to it. */
const LENGTH_TOLERANCE = 0.08;
/** Shorter efforts are only compared with themselves; noise dominates otherwise. */
const MIN_GROUP_SEC = 10;

/** `4′`, `90″`, `4′30″` — how a rep length reads in conversation. */
export function formatSpan(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  if (total < 60) return `${total}″`;
  const minutes = Math.floor(total / 60);
  const rest = total % 60;
  return rest === 0 ? `${minutes}′` : `${minutes}′${String(rest).padStart(2, '0')}″`;
}

/** Reps that share a length, in ascending length order. */
function groupByLength(rows: Pick<IntervalRow, 'durationSec'>[]): number[][] {
  const order = rows
    .map((row, index) => ({ index, duration: row.durationSec }))
    .sort((a, b) => a.duration - b.duration);

  const groups: number[][] = [];
  let current: { members: number[]; total: number } | null = null;

  for (const item of order) {
    if (item.duration < MIN_GROUP_SEC) {
      groups.push([item.index]);
      current = null;
      continue;
    }
    if (current) {
      const average = current.total / current.members.length;
      if (Math.abs(item.duration - average) <= average * LENGTH_TOLERANCE) {
        current.members.push(item.index);
        current.total += item.duration;
        continue;
      }
    }
    current = { members: [item.index], total: item.duration };
    groups.push(current.members);
  }

  return groups;
}

function weightedAverage(pairs: { value: number; weight: number }[]): number | null {
  const usable = pairs.filter((pair) => Number.isFinite(pair.value) && pair.weight > 0);
  if (!usable.length) return null;
  const totalWeight = usable.reduce((sum, pair) => sum + pair.weight, 0);
  return usable.reduce((sum, pair) => sum + pair.value * pair.weight, 0) / totalWeight;
}

/**
 * Reads every stream an effort touched and returns one row per rep, the rep
 * groups, and totals. Pure: the detector supplies the windows, the streams
 * supply the numbers.
 */
export function buildIntervalReport(work: Segment[], streams: IntervalStreams): IntervalReport {
  const time = streams.time;
  const efforts = work.filter((segment) => segment.kind === 'work');

  const rows: IntervalRow[] = efforts.map((segment, index) => {
    const rawStart = time.length ? firstIndexAtOrAfter(time, segment.startSec) : 0;
    const rawEnd = time.length
      ? Math.min(firstIndexAtOrAfter(time, segment.startSec + segment.durationSec), time.length - 1)
      : 0;
    // The window is inclusive at both ends, so a 240 s rep at 1 Hz lasts 240 s.
    const from = Math.min(rawStart, Math.max(0, time.length - 1));
    const endIndex = Math.max(from, rawEnd);
    const to = Math.max(from + 1, endIndex + 1);

    const durationSec =
      time.length && endIndex > from
        ? Math.max(1, Math.round(time[endIndex] - time[from]))
        : Math.max(1, Math.round(segment.durationSec));

    const distanceM = time.length ? distanceBetween(streams, from, to, durationSec) : null;
    const paceSecPerKm =
      distanceM !== null && distanceM >= MIN_DISTANCE_M ? durationSec / (distanceM / 1000) : null;
    const beats = numbers(streams.heartrate, from, to);
    const peak = maxOf(beats);
    const elevation = elevationBetween(streams.altitude, from, to);

    return {
      index: index + 1,
      startSec: segment.startSec,
      durationSec,
      distanceM,
      paceSecPerKm,
      avgHr: beats.length ? Math.round(mean(beats)) : null,
      maxHr: peak === null ? null : Math.round(peak),
      gainM: elevation ? Math.round(elevation.gainM) : null,
      lossM: elevation ? Math.round(elevation.lossM) : null,
      deltaVsAverageSec: 0,
      sameLengthLabel: '',
      sameLengthCount: 1,
      deltaVsSameLengthSec: 0,
      deltaVsSameLengthPaceSec: null
    };
  });

  const averageDuration = rows.length
    ? rows.reduce((sum, row) => sum + row.durationSec, 0) / rows.length
    : 0;
  for (const row of rows) row.deltaVsAverageSec = row.durationSec - averageDuration;

  const groups: IntervalGroup[] = groupByLength(rows).map((members) => {
    const totalSec = members.reduce((sum, index) => sum + rows[index].durationSec, 0);
    const avgDurationSec = totalSec / members.length;

    // Only reps that actually measured a distance can define the group's pace.
    const measured = members
      .map((index) => rows[index])
      .filter((row) => row.distanceM !== null);
    const measuredDistance = measured.reduce((sum, row) => sum + (row.distanceM ?? 0), 0);
    const measuredTime = measured.reduce((sum, row) => sum + row.durationSec, 0);
    const avgPaceSecPerKm =
      measuredDistance >= MIN_DISTANCE_M ? measuredTime / (measuredDistance / 1000) : null;

    const label = formatSpan(avgDurationSec);
    for (const index of members) {
      const row = rows[index];
      row.sameLengthLabel = label;
      row.sameLengthCount = members.length;
      row.deltaVsSameLengthSec = row.durationSec - avgDurationSec;
      row.deltaVsSameLengthPaceSec =
        row.paceSecPerKm !== null && avgPaceSecPerKm !== null ? row.paceSecPerKm - avgPaceSecPerKm : null;
    }

    return { label, count: members.length, avgDurationSec, avgPaceSecPerKm };
  });

  const timeSec = rows.reduce((sum, row) => sum + row.durationSec, 0);
  const measured = rows.filter((row) => row.distanceM !== null);
  const distanceM = measured.length ? measured.reduce((sum, row) => sum + (row.distanceM ?? 0), 0) : null;
  const climbs = rows.filter((row) => row.gainM !== null);
  const hr = weightedAverage(
    rows
      .filter((row) => row.avgHr !== null)
      .map((row) => ({ value: row.avgHr ?? 0, weight: row.durationSec }))
  );
  const peaks = rows
    .map((row) => row.maxHr)
    .filter((value): value is number => value !== null && Number.isFinite(value));

  const totals: IntervalTotals = {
    count: rows.length,
    timeSec,
    distanceM,
    avgDurationSec: averageDuration,
    paceSecPerKm: distanceM !== null && distanceM >= MIN_DISTANCE_M ? timeSec / (distanceM / 1000) : null,
    avgHr: hr === null ? null : Math.round(hr),
    maxHr: peaks.length ? Math.max(...peaks) : null,
    gainM: climbs.length ? climbs.reduce((sum, row) => sum + (row.gainM ?? 0), 0) : null,
    lossM: climbs.length ? climbs.reduce((sum, row) => sum + (row.lossM ?? 0), 0) : null
  };

  return { rows, groups, totals };
}

