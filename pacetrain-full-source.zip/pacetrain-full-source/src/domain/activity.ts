import { addDays, startOfWeek, toISODate } from './week';
import type { Activity, ModeId } from './types';

/**
 * The disciplines that count as running when the app talks about running
 * distance. Trail and orienteering are running in everything but name, so
 * their kilometres belong in the same total.
 */
export const RUNNING_MODES: ModeId[] = ['run', 'trail', 'orienteering'];

/**
 * The windows the activities screen offers. Calendar ranges ("this week",
 * "this year") sit next to rolling ones ("last 90 days"), because "this month"
 * and "last 30 days" answer different questions.
 */
export type ActivityRangeId = 'week' | 'month' | '30d' | '90d' | '365d' | 'year';

export interface ActivityRangeOption {
  id: ActivityRangeId;
  /** Chip label. */
  label: string;
  /** Sentence used in the page subtitle and the empty state. */
  title: string;
}

export const ACTIVITY_RANGES: ActivityRangeOption[] = [
  { id: 'week', label: 'Week', title: 'This week' },
  { id: 'month', label: 'Month', title: 'This month' },
  { id: '30d', label: '30 days', title: 'Last 30 days' },
  { id: '90d', label: '90 days', title: 'Last 90 days' },
  { id: '365d', label: '365 days', title: 'Last 365 days' },
  { id: 'year', label: 'Year', title: 'This year' }
];

export const DEFAULT_ACTIVITY_RANGE: ActivityRangeId = '30d';

export function isActivityRangeId(value: unknown): value is ActivityRangeId {
  return ACTIVITY_RANGES.some((range) => range.id === value);
}

export interface ActivityRangeBounds {
  id: ActivityRangeId;
  /** Inclusive `YYYY-MM-DD`, local time. */
  from: string;
  to: string;
  label: string;
}

/** Inclusive dates for a range. Unknown ids fall back to the default window. */
export function activityRangeBounds(id: string | null | undefined, today: Date = new Date()): ActivityRangeBounds {
  const range = ACTIVITY_RANGES.find((item) => item.id === id) ?? ACTIVITY_RANGES.find((item) => item.id === DEFAULT_ACTIVITY_RANGE)!;
  const to = toISODate(today);

  if (range.id === 'week') return { id: range.id, from: toISODate(startOfWeek(today)), to, label: range.title };
  if (range.id === 'month') {
    return { id: range.id, from: toISODate(new Date(today.getFullYear(), today.getMonth(), 1)), to, label: range.title };
  }
  if (range.id === 'year') {
    return { id: range.id, from: toISODate(new Date(today.getFullYear(), 0, 1)), to, label: range.title };
  }

  const days = Number(range.id.replace('d', ''));
  return { id: range.id, from: toISODate(addDays(today, -(days - 1))), to, label: range.title };
}

export function isRunningMode(id: ModeId): boolean {
  return RUNNING_MODES.includes(id);
}

export interface ModeTotals {
  count: number;
  km: number;
  minutes: number;
}

export interface ActivityTotals {
  count: number;
  km: number;
  minutes: number;
  longestKm: number;
  byMode: Record<string, ModeTotals>;
}

export function activityKm(activity: Activity): number {
  return activity.distanceM > 0 ? activity.distanceM / 1000 : 0;
}

function round1(value: number): number {
  return Math.round(value * 10) / 10;
}

function emptyTotals(): ActivityTotals {
  return { count: 0, km: 0, minutes: 0, longestKm: 0, byMode: {} };
}

/** Distance, time and a per-discipline split for any list of activities. */
export function activityTotals(activities: Activity[]): ActivityTotals {
  const totals = emptyTotals();

  for (const activity of activities) {
    const km = activityKm(activity);
    const minutes = activity.durationSec > 0 ? activity.durationSec / 60 : 0;

    totals.count += 1;
    totals.km += km;
    totals.minutes += minutes;
    totals.longestKm = Math.max(totals.longestKm, km);

    const modeTotals = totals.byMode[activity.mode] ?? { count: 0, km: 0, minutes: 0 };
    modeTotals.count += 1;
    modeTotals.km += km;
    modeTotals.minutes += minutes;
    totals.byMode[activity.mode] = modeTotals;
  }

  totals.km = round1(totals.km);
  totals.minutes = Math.round(totals.minutes);
  totals.longestKm = round1(totals.longestKm);
  for (const modeTotals of Object.values(totals.byMode)) {
    modeTotals.km = round1(modeTotals.km);
    modeTotals.minutes = Math.round(modeTotals.minutes);
  }
  return totals;
}

export interface RunningTotals extends ActivityTotals {
  /** Weighted pace across the running activities, in seconds per km. */
  avgPaceSecPerKm: number | null;
}

/** The running-only slice: run, trail and orienteering together. */
export function runningTotals(activities: Activity[]): RunningTotals {
  const running = activities.filter((activity) => isRunningMode(activity.mode));
  const totals = activityTotals(running);

  let seconds = 0;
  let metres = 0;
  for (const activity of running) {
    if (activity.distanceM < 1000 || activity.durationSec <= 0) continue;
    seconds += activity.durationSec;
    metres += activity.distanceM;
  }

  return {
    ...totals,
    avgPaceSecPerKm: metres > 0 && seconds > 0 ? Math.round(seconds / (metres / 1000)) : null
  };
}

/** Activities keyed by `YYYY-MM-DD`, newest first inside each day. */
export function activitiesByDate(activities: Activity[]): Record<string, Activity[]> {
  const byDate: Record<string, Activity[]> = {};
  for (const activity of activities) {
    (byDate[activity.date] ??= []).push(activity);
  }
  for (const list of Object.values(byDate)) {
    list.sort((a, b) => b.durationSec - a.durationSec);
  }
  return byDate;
}
