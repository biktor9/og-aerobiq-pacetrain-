import type { Activity, ModeId } from './types';
import { addDays, toISODate } from './week';

/** The disciplines the planner can express in kilometres. */
export type DistanceMode = 'run' | 'trail' | 'orienteering';

export const DISTANCE_MODES: DistanceMode[] = ['run', 'trail', 'orienteering'];

/**
 * Fallbacks for an account with nothing imported yet, in seconds per km. They
 * are deliberately conservative: easy running, easy trail, honest terrain.
 */
export const DEFAULT_PACE_SEC_PER_KM: Record<DistanceMode, number> = {
  run: 330,
  trail: 400,
  orienteering: 480
};

export type PaceTable = Record<DistanceMode, number>;

export function isDistanceMode(id: ModeId): id is DistanceMode {
  return (DISTANCE_MODES as string[]).includes(id);
}

export function paceFor(mode: ModeId, paces: PaceTable = DEFAULT_PACE_SEC_PER_KM): number {
  return isDistanceMode(mode) ? paces[mode] : paces.run;
}

export function median(values: number[]): number | null {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

/**
 * Median pace per discipline over the last `days` of imported activities. A
 * median ignores the one very slow long run that would drag a mean down.
 */
export function paceTable(activities: Activity[], now: Date = new Date(), days = 60): PaceTable {
  const from = toISODate(addDays(now, -days));
  const samples = new Map<DistanceMode, number[]>();

  for (const activity of activities) {
    if (!isDistanceMode(activity.mode)) continue;
    if (activity.date < from || activity.distanceM < 1000 || activity.durationSec <= 0) continue;
    const pace = activity.durationSec / (activity.distanceM / 1000);
    // Anything outside 2:00–30:00 per km is a data problem, not a pace.
    if (!Number.isFinite(pace) || pace < 120 || pace > 1800) continue;
    const list = samples.get(activity.mode) ?? [];
    list.push(pace);
    samples.set(activity.mode, list);
  }

  const table = { ...DEFAULT_PACE_SEC_PER_KM };
  for (const mode of DISTANCE_MODES) {
    const value = median(samples.get(mode) ?? []);
    if (value) table[mode] = Math.round(value);
  }
  return table;
}

/** Minutes needed for a distance at the athlete's own pace. */
export function minutesForDistance(km: number, mode: ModeId, paces: PaceTable = DEFAULT_PACE_SEC_PER_KM): number {
  const minutes = (Math.max(0, km) * paceFor(mode, paces)) / 60;
  return Math.max(5, Math.round(minutes));
}

/** `5:30/km` */
export function formatPace(secPerKm: number): string {
  const total = Math.max(0, Math.round(secPerKm));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}/km`;
}

/**
 * Disciplines whose sessions are naturally described in kilometres. The pace
 * table only measures the running ones; the rest fall back to a sensible speed.
 */
export const DISTANCE_SPORT_MODES: ModeId[] = ['run', 'trail', 'orienteering', 'bike', 'mtb', 'ski'];

export function isDistanceSport(id: ModeId): boolean {
  return DISTANCE_SPORT_MODES.includes(id);
}

/** Typical speeds for sports the pace table does not measure, in seconds per km. */
const SPORT_PACE_SEC_PER_KM: Partial<Record<ModeId, number>> = {
  bike: 150,
  mtb: 240,
  ski: 300
};

/** The athlete's own pace where we have one, a sensible fallback otherwise. */
export function planningPace(mode: ModeId, paces: PaceTable = DEFAULT_PACE_SEC_PER_KM): number {
  if (isDistanceMode(mode)) return paces[mode];
  return SPORT_PACE_SEC_PER_KM[mode] ?? paces.run;
}

/** Whole kilometres that roughly fill a duration at that pace. */
export function kmForMinutes(minutes: number, mode: ModeId, paces?: PaceTable): number {
  const pace = planningPace(mode, paces);
  return Math.max(1, Math.round((Math.max(1, minutes) * 60) / pace));
}

/** The pace a km/time pair implies, in seconds per km. */
export function impliedPaceSecPerKm(minutes: number, km: number): number | null {
  if (!(minutes > 0) || !(km > 0)) return null;
  return (minutes * 60) / km;
}

/**
 * How far a km/time pair sits from the athlete's usual pace, in percent. The
 * planner only warns past ten percent — both fields are stored as written.
 */
export function paceMismatchPct(minutes: number, km: number, expectedSecPerKm: number): number | null {
  const implied = impliedPaceSecPerKm(minutes, km);
  if (implied === null || !(expectedSecPerKm > 0)) return null;
  return (Math.abs(implied - expectedSecPerKm) / expectedSecPerKm) * 100;
}

/**
 * The share of an easy pace that a fast rep is run at. 0.85 is roughly what a
 * 400 m to 1 km rep costs most runners over their easy pace, and it only has to
 * be close: the athlete types the rep distance, the planner turns it into a
 * work length it can add up.
 */
export const WORK_PACE_SHARE = 0.85;

/** Minutes for one rep of `km` at a working pace, rounded to half a minute. */
export function minutesForKm(km: number, workingPaceSecPerKm: number): number {
  const minutes = (Math.max(0, km) * Math.max(60, workingPaceSecPerKm)) / 60;
  return Math.max(0.5, Math.round(minutes * 2) / 2);
}
