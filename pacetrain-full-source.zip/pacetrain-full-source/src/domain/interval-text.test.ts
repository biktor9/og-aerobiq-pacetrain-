import { describe, expect, it } from 'vitest';
import { describeBlocks, parseIntervalText, readDurations, zoneFromWords } from './interval-text';

describe('readDurations', () => {
  it('reads minutes, hours and seconds', () => {
    expect(readDurations("4x8'")).toEqual([8]);
    expect(readDurations('90 min')).toEqual([90]);
    expect(readDurations('1h 30min')).toEqual([60, 30]);
    expect(readDurations('45s')).toEqual([0.75]);
    expect(readDurations('no numbers here')).toEqual([]);
  });

  it('does not confuse metres with minutes', () => {
    expect(readDurations('1000 m')).toEqual([]);
    expect(readDurations('4x1000m')).toEqual([]);
  });
});

describe('zoneFromWords', () => {
  it('maps coaching words onto zones', () => {
    expect(zoneFromWords('threshold')).toBe(4);
    expect(zoneFromWords('max')).toBe(5);
    expect(zoneFromWords('easy')).toBe(2);
    expect(zoneFromWords('jog')).toBe(1);
    expect(zoneFromWords('z3')).toBe(3);
    expect(zoneFromWords('whatever')).toBeNull();
  });
});

describe('parseIntervalText', () => {
  it('reads the mixed session from the planner', () => {
    const parsed = parseIntervalText("20' warm-up, 4x8' threshold w/ 2' jog, 3x3' max w/ 3' easy, 10' down");

    expect(parsed.ok).toBe(true);
    expect(parsed.blocks).toEqual([
      { kind: 'warmup', minutes: 20, zone: 1 },
      { kind: 'work', minutes: 8, zone: 4 },
      { kind: 'recover', minutes: 2, zone: 1 },
      { kind: 'work', minutes: 8, zone: 4 },
      { kind: 'recover', minutes: 2, zone: 1 },
      { kind: 'work', minutes: 8, zone: 4 },
      { kind: 'recover', minutes: 2, zone: 1 },
      { kind: 'work', minutes: 8, zone: 4 },
      { kind: 'work', minutes: 3, zone: 5 },
      { kind: 'recover', minutes: 3, zone: 2 },
      { kind: 'work', minutes: 3, zone: 5 },
      { kind: 'recover', minutes: 3, zone: 2 },
      { kind: 'work', minutes: 3, zone: 5 },
      { kind: 'cooldown', minutes: 10, zone: 1 }
    ]);
    expect(parsed.totalMin).toBe(83);
    expect(parsed.warmupMin).toBe(20);
    expect(parsed.cooldownMin).toBe(10);
    expect(parsed.zone).toBe(4);
    expect(parsed.kind).toBe('intervals');
    expect(parsed.warnings).toEqual([]);
  });

  it('does not add recovery after the final repeat', () => {
    const parsed = parseIntervalText("15' warm-up, 5x3' hard w/ 1' easy, 10' cool down");
    expect(parsed.blocks.filter((block) => block.kind === 'work')).toHaveLength(5);
    expect(parsed.blocks.filter((block) => block.kind === 'recover')).toHaveLength(4);
    expect(parsed.blocks.at(-1)).toEqual({ kind: 'cooldown', minutes: 10, zone: 1 });
  });

  it('understands parenthesised sets', () => {
    const parsed = parseIntervalText("3x(4' hard + 2' easy)");
    expect(parsed.blocks).toHaveLength(6);
    expect(parsed.blocks.slice(0, 2)).toEqual([
      { kind: 'work', minutes: 4, zone: 4 },
      { kind: 'recover', minutes: 2, zone: 2 }
    ]);
    expect(parsed.totalMin).toBe(18);
  });

  it('keeps a plain steady session simple', () => {
    const parsed = parseIntervalText('60 minutes easy endurance');
    expect(parsed.kind).toBe('steady');
    expect(parsed.reps).toBe(1);
    expect(parsed.blocks).toEqual([{ kind: 'work', minutes: 60, zone: 2 }]);
  });

  it('explains what it could not read', () => {
    const empty = parseIntervalText('go hard and have fun');
    expect(empty.ok).toBe(false);
    expect(empty.blocks).toEqual([]);
    expect(empty.warnings.join(' ')).toMatch(/No duration found/);

    const metres = parseIntervalText('4x1000 m');
    expect(metres.ok).toBe(false);
    expect(metres.warnings.join(' ')).toMatch(/Distance-based reps/);
  });

  it('is deterministic', () => {
    const text = "20' easy, 4x1' max / 1' easy, 10' down";
    expect(parseIntervalText(text)).toEqual(parseIntervalText(text));
  });

  it('reads a recovery written after a comma as the between-rep jog', () => {
    const parsed = parseIntervalText('4x8 min threshold, 2 min jog');

    expect(parsed.blocks).toEqual([
      { kind: 'work', minutes: 8, zone: 4 },
      { kind: 'recover', minutes: 2, zone: 1 },
      { kind: 'work', minutes: 8, zone: 4 },
      { kind: 'recover', minutes: 2, zone: 1 },
      { kind: 'work', minutes: 8, zone: 4 },
      { kind: 'recover', minutes: 2, zone: 1 },
      { kind: 'work', minutes: 8, zone: 4 }
    ]);
    expect(parsed.totalMin).toBe(38);
    expect(parsed.reps).toBe(4);
    expect(parsed.recoverMin).toBe(2);
    expect(parsed.warnings).toEqual([]);
  });

  it('keeps the recovery out of the rep count for an easy comma step', () => {
    const parsed = parseIntervalText('3x10 min threshold, 3 min easy');
    expect(parsed.reps).toBe(3);
    expect(parsed.recoverMin).toBe(3);
    // 3 × 10′ of work with a 3′ recovery between reps.
    expect(parsed.totalMin).toBe(36);
  });

  it('reads a full comma-separated session', () => {
    const parsed = parseIntervalText('20 min warm-up, 4x8 min threshold, 2 min jog, 10 min down');
    expect(parsed.warmupMin).toBe(20);
    expect(parsed.cooldownMin).toBe(10);
    expect(parsed.reps).toBe(4);
    expect(parsed.blocks.filter((block) => block.kind === 'recover')).toHaveLength(3);
    expect(parsed.totalMin).toBe(68);
  });

  it('does not fold a cool-down into the last repeat', () => {
    const parsed = parseIntervalText('4x8 min threshold, 10 min down');
    expect(parsed.blocks.at(-1)).toEqual({ kind: 'cooldown', minutes: 10, zone: 1 });
    expect(parsed.totalMin).toBe(42);
  });

  it('warns instead of counting metres as minutes', () => {
    const parsed = parseIntervalText('8x400m 2 min rest');
    expect(parsed.ok).toBe(false);
    expect(parsed.blocks).toEqual([]);
    expect(parsed.warnings.join(' ')).toMatch(/Distance-based reps/);
  });
});

describe('describeBlocks', () => {
  it('compresses repeats into a readable line', () => {
    const parsed = parseIntervalText("20' warm-up, 4x8' threshold w/ 2' jog, 3x3' max w/ 3' easy, 10' down");
    expect(describeBlocks(parsed.blocks)).toBe(
      '20′ warm-up · 4 × 8′ @ Z4 · 2′ easy · 3 × 3′ @ Z5 · 3′ easy · 10′ cool-down'
    );
  });

  it('leaves single blocks alone', () => {
    expect(describeBlocks([{ kind: 'work', minutes: 45, zone: 2 }])).toBe('45′ @ Z2');
  });
});

describe('reading the way athletes write times', () => {
  it('reads seconds and combined minutes:seconds', () => {
    expect(readDurations('6x90"')).toEqual([1.5]);
    expect(readDurations("6x2'30\"")).toEqual([2.5]);
    expect(readDurations('45″')).toEqual([0.75]);

    const reps = parseIntervalText('8x90" hard');
    expect(reps.reps).toBe(8);
    expect(reps.blocks.every((block) => block.minutes === 1.5)).toBe(true);
  });

  it('reads clock notation as minutes:seconds', () => {
    expect(readDurations('4:30')).toEqual([4.5]);
    expect(readDurations('1:02:30')).toEqual([62.5]);

    const reps = parseIntervalText('4x4:00 @ 3:50/km');
    expect(reps.blocks.map((block) => block.minutes)).toEqual([4, 4, 4, 4]);
    expect(reps.warnings).toEqual([]);
  });

  it('turns distance reps and a pace into timed reps', () => {
    const km = parseIntervalText('4x1km @ 4:00/km');
    expect(km.blocks).toEqual([
      { kind: 'work', minutes: 4, zone: 4 },
      { kind: 'work', minutes: 4, zone: 4 },
      { kind: 'work', minutes: 4, zone: 4 },
      { kind: 'work', minutes: 4, zone: 4 }
    ]);
    expect(km.totalMin).toBe(16);

    const metres = parseIntervalText('8x400m @ 3:30/km');
    expect(metres.blocks[0]).toEqual({ kind: 'work', minutes: 1.4, zone: 4 });

    const miles = parseIntervalText('5x1 mile @ 6:30/mi');
    expect(miles.blocks[0]).toEqual({ kind: 'work', minutes: 6.5, zone: 4 });
  });

  it('keeps a recovery written after distance reps', () => {
    const parsed = parseIntervalText('6x800m @ 3:30/km, 90s rest');
    expect(parsed.reps).toBe(6);
    expect(parsed.workMin).toBe(2.8);
    expect(parsed.recoverMin).toBe(1.5);
    expect(parsed.blocks.filter((block) => block.kind === 'recover')).toHaveLength(5);
    expect(parsed.warnings).toEqual([]);
  });

  it('uses a per-rep time when that is what was written', () => {
    expect(parseIntervalText('8x400m @ 90"').blocks[0]).toEqual({ kind: 'work', minutes: 1.5, zone: 4 });
    expect(parseIntervalText('4x1000m in 4:30').blocks[0]).toEqual({ kind: 'work', minutes: 4.5, zone: 4 });
    expect(parseIntervalText('12x400m (75")').blocks[0]).toEqual({ kind: 'work', minutes: 1.25, zone: 4 });
    expect(parseIntervalText('6 x 1 km 4:10 pace').blocks[0]).toEqual({ kind: 'work', minutes: 4.17, zone: 4 });
  });

  it('does not invent a recovery from a pace target', () => {
    const parsed = parseIntervalText("4x8' @ 4:00");
    expect(parsed.blocks).toHaveLength(4);
    expect(parsed.blocks.every((block) => block.kind === 'work')).toBe(true);
    expect(parsed.totalMin).toBe(32);
  });

  it('names the phrase it could not read', () => {
    const parsed = parseIntervalText("20' warm-up, strides and drills");
    expect(parsed.blocks).toEqual([{ kind: 'warmup', minutes: 20, zone: 1 }]);
    expect(parsed.warnings.join(' ')).toMatch(/Could not read "strides"/);
  });

  it('prints half minutes as seconds', () => {
    expect(describeBlocks([{ kind: 'work', minutes: 1.5, zone: 5 }])).toBe('1′30″ @ Z5');
    expect(describeBlocks([{ kind: 'work', minutes: 0.75, zone: 5 }])).toBe('45″ @ Z5');
  });
});



describe('other ways reps get written down', () => {
  it('accepts a star as the multiplication sign', () => {
    const parsed = parseIntervalText("4*8' threshold");
    expect(parsed.reps).toBe(4);
    expect(parsed.workMin).toBe(8);
  });

  it('accepts a dot pace', () => {
    const parsed = parseIntervalText('6x1km @ 4.30/km');
    expect(parsed.blocks[0]).toEqual({ kind: 'work', minutes: 4.5, zone: 4 });
    expect(parsed.totalMin).toBe(27);
  });
});

describe('awkward but real session notes', () => {
  it('takes a recovery written in brackets', () => {
    const parsed = parseIntervalText('4x1km @ 4:00/km (2\' rest)');
    expect(parsed.reps).toBe(4);
    expect(parsed.workMin).toBe(4);
    expect(parsed.recoverMin).toBe(2);
    expect(parsed.blocks.filter((block) => block.kind === 'recover')).toHaveLength(3);
  });

  it('reads a time written before its distance as the rep', () => {
    const parsed = parseIntervalText("4x2' @ 500m");
    expect(parsed.blocks.map((block) => block.minutes)).toEqual([2, 2, 2, 2]);
    expect(parsed.totalMin).toBe(8);
  });

  it('reads a warm-up, a set with paces and a cool-down as one session', () => {
    const parsed = parseIntervalText(
      "20' warm-up, 6x800m @ 3:30/km with 90\" jog, 10' down"
    );

    expect(parsed.ok).toBe(true);
    expect(parsed.warmupMin).toBe(20);
    expect(parsed.cooldownMin).toBe(10);
    expect(parsed.reps).toBe(6);
    expect(parsed.workMin).toBe(2.8);
    expect(parsed.recoverMin).toBe(1.5);
    expect(parsed.warnings).toEqual([]);
  });
});

