import { describe, expect, it } from 'vitest';
import {
  addWidget,
  defaultDashboard,
  hiddenWidgets,
  isWidgetId,
  layoutRows,
  moveWidget,
  parseDashboard,
  parseProgressStyle,
  parseSizes,
  removeWidget,
  serializeDashboard,
  serializeSizes,
  showsStats,
  sizeOf,
  sizesFor,
  STAT_WIDGETS,
  visibleStats,
  WIDGETS,
  type WidgetId
} from './dashboard';

describe('dashboard defaults', () => {
  it('starts with the tiles and cards that were always there', () => {
    const dashboard = defaultDashboard();
    expect(dashboard.order).toHaveLength(12);
    expect(dashboard.order.slice(0, 7)).toEqual([
      'overview',
      'stat-running',
      'stat-time',
      'stat-planned',
      'stat-plan-done',
      'stat-expected',
      'stat-load'
    ]);
  });

  it('leaves the newer widgets for the athlete to add', () => {
    const order = defaultDashboard().order;
    for (const id of ['plan-done', 'week-strip', 'recovery', 'stat-streak'] as WidgetId[]) {
      expect(order).not.toContain(id);
      expect(isWidgetId(id)).toBe(true);
    }
  });

  it('has a label and a hint for every widget it offers', () => {
    for (const widget of WIDGETS) {
      expect(widget.label.length).toBeGreaterThan(0);
      expect(widget.hint.length).toBeGreaterThan(0);
    }
    // No two widgets share a name, or the bar would be ambiguous.
    expect(new Set(WIDGETS.map((widget) => widget.label)).size).toBe(WIDGETS.length);
  });

  it('knows which ids are tiles', () => {
    expect(STAT_WIDGETS.length).toBeGreaterThanOrEqual(6);
    expect(STAT_WIDGETS.every((id) => WIDGETS.some((widget) => widget.id === id))).toBe(true);
    // Every tile in the catalogue is listed, and nothing else is.
    for (const widget of WIDGETS) {
      expect(STAT_WIDGETS.includes(widget.id)).toBe(widget.kind === 'tile');
    }
  });
});

describe('parseDashboard', () => {
  it('falls back to everything when nothing is stored', () => {
    expect(parseDashboard(null).order).toHaveLength(12);
    expect(parseDashboard('').order).toHaveLength(12);
  });

  it('survives broken JSON', () => {
    expect(parseDashboard('{not json').order).toHaveLength(12);
    expect(parseDashboard('"a string"').order).toHaveLength(12);
  });

  it('drops unknown ids and duplicates, keeping the order it was given', () => {
    const stored = JSON.stringify(['board', 'nonsense', 'zones', 'board', 'mix']);
    expect(parseDashboard(stored).order).toEqual(['board', 'zones', 'mix']);
  });

  it('keeps a deliberately short list, which is how widgets are hidden', () => {
    expect(parseDashboard(JSON.stringify(['board'])).order).toEqual(['board']);
  });

  it('round-trips through the stored form', () => {
    const dashboard = { order: ['zones', 'board'] as WidgetId[] };
    expect(parseDashboard(serializeDashboard(dashboard))).toEqual(dashboard);
  });
});

describe('editing the order', () => {
  const order: WidgetId[] = ['overview', 'mix', 'zones', 'calendar'];

  it('moves a widget up and down', () => {
    expect(moveWidget(order, 'zones', -1)).toEqual(['overview', 'zones', 'mix', 'calendar']);
    expect(moveWidget(order, 'zones', 1)).toEqual(['overview', 'mix', 'calendar', 'zones']);
  });

  it('stops at the ends instead of wrapping', () => {
    expect(moveWidget(order, 'overview', -1)).toEqual(order);
    expect(moveWidget(order, 'calendar', 1)).toEqual(order);
  });

  it('removes a widget and lists it as hidden', () => {
    const next = removeWidget(order, 'mix');
    expect(next).toEqual(['overview', 'zones', 'calendar']);
    expect(hiddenWidgets(next).map((widget) => widget.id)).toContain('mix');
  });

  it('puts a widget back where it belongs, not at the bottom', () => {
    // `mix` sits between the tiles and the zones in the catalogue.
    const withoutMix = removeWidget(order, 'mix');
    expect(addWidget(withoutMix, 'mix')).toEqual(order);
  });

  it('adds a widget that was never there at the end of its catalogue neighbours', () => {
    expect(addWidget(['overview'], 'board')).toEqual(['overview', 'board']);
  });

  it('ignores adding one that is already shown', () => {
    expect(addWidget(order, 'zones')).toEqual(order);
  });

  it('returns a new array every time, so React sees the change', () => {
    expect(moveWidget(order, 'overview', 1)).not.toBe(order);
    expect(removeWidget(order, 'mix')).not.toBe(order);
    expect(addWidget(order, 'zones')).not.toBe(order);
  });
});

describe('what is shown', () => {
  it('lists only the tiles that survived', () => {
    expect(visibleStats(['overview', 'stat-load', 'zones', 'stat-time'])).toEqual(['stat-load', 'stat-time']);
  });

  it('draws no tile row when the row itself is off the page', () => {
    const withoutRow: WidgetId[] = ['mix', 'zones', 'stat-time'];
    expect(showsStats(withoutRow)).toBe(false);
  });

  it('draws no tile row when every tile was removed', () => {
    expect(showsStats(['overview', 'mix'])).toBe(false);
  });

  it('draws the row when the overview and a tile are both there', () => {
    expect(showsStats(['overview', 'stat-running'])).toBe(true);
  });
});

describe('progress style', () => {
  it('defaults to rings', () => {
    expect(parseProgressStyle(null)).toBe('ring');
    expect(parseProgressStyle('nonsense')).toBe('ring');
  });

  it('reads a stored bar', () => {
    expect(parseProgressStyle('bar')).toBe('bar');
  });
});

describe('layoutRows', () => {
  it('puts a run of tiles in one row', () => {
    const rows = layoutRows(['stat-running', 'stat-time', 'stat-load', 'mix']);
    // Two tiles to a row: the third starts a new one rather than squeezing in.
    expect(rows.map((row) => row.ids)).toEqual([
      ['stat-running', 'stat-time'],
      ['stat-load'],
      ['mix']
    ]);
    expect(rows[0].kind).toBe('tiles');
    expect(rows[2].kind).toBe('cards');
  });

  it('never puts more than two tiles in a row', () => {
    const rows = layoutRows([...STAT_WIDGETS]);
    expect(rows).toHaveLength(Math.ceil(STAT_WIDGETS.length / 2));
    expect(rows.every((row) => row.ids.length <= 2)).toBe(true);
    expect(rows.every((row) => row.kind === 'tiles')).toBe(true);
  });

  it('keeps the athlete’s order inside the pairs', () => {
    const rows = layoutRows(['stat-streak', 'stat-load', 'stat-avg-pace', 'stat-time']);
    expect(rows.map((row) => row.ids)).toEqual([
      ['stat-streak', 'stat-load'],
      ['stat-avg-pace', 'stat-time']
    ]);
  });

  it('gives every pair its own key, so a tile is not drawn twice', () => {
    const rows = layoutRows([...STAT_WIDGETS]);
    const keys = rows.map((row) => row.key);
    expect(new Set(keys).size).toBe(keys.length);
  });

  it('ends the tile row at a card, and starts a new one after it', () => {
    // The layout that was reported: a card between two tiles.
    const rows = layoutRows(['stat-running', 'mix', 'stat-time']);
    expect(rows.map((row) => row.ids)).toEqual([['stat-running'], ['mix'], ['stat-time']]);
  });

  it('keeps adjacent cards in separate rows', () => {
    const rows = layoutRows(['mix', 'zones', 'heat']);
    expect(rows).toHaveLength(3);
    expect(rows.every((row) => row.kind === 'cards')).toBe(true);
  });

  it('lets two half-width cards share a row', () => {
    const rows = layoutRows(['mix', 'zones'], { mix: 'wide', zones: 'wide' });
    expect(rows).toHaveLength(1);
    expect(rows[0].ids).toEqual(['mix', 'zones']);
  });

  it('does not let a full-width card join a row', () => {
    const rows = layoutRows(['mix', 'zones'], { mix: 'wide' });
    expect(rows).toHaveLength(2);
  });

  it('draws nothing for the old tile-row marker, and lets it break nothing', () => {
    const rows = layoutRows(['overview', 'stat-running', 'stat-time']);
    expect(rows).toHaveLength(1);
    expect(rows[0].ids).toEqual(['stat-running', 'stat-time']);
  });

  it('gives every row a key that does not collide', () => {
    const rows = layoutRows(['stat-running', 'mix', 'stat-time', 'zones']);
    expect(new Set(rows.map((row) => row.key)).size).toBe(rows.length);
  });

  it('returns nothing for an empty order', () => {
    expect(layoutRows([])).toEqual([]);
  });
});

describe('sizes', () => {
  it('offers three sizes for a tile and two for a card', () => {
    expect(sizesFor('stat-load')).toEqual(['small', 'wide', 'large']);
    expect(sizesFor('mix')).toEqual(['small', 'wide']);
  });

  it('falls back to the natural size', () => {
    expect(sizeOf({}, 'mix')).toBe('small');
    expect(sizeOf({ mix: 'wide' }, 'mix')).toBe('wide');
  });

  it('reads back what it stored', () => {
    const sizes = { mix: 'wide', 'stat-load': 'large' } as const;
    expect(parseSizes(serializeSizes(sizes))).toEqual(sizes);
  });

  it('survives broken or missing input', () => {
    expect(parseSizes(null)).toEqual({});
    expect(parseSizes('{not json')).toEqual({});
    expect(parseSizes('[]')).toEqual({});
    expect(parseSizes('"wide"')).toEqual({});
  });

  it('drops unknown widgets, unknown sizes, and sizes a widget cannot have', () => {
    const stored = JSON.stringify({
      'not-a-widget': 'wide',
      mix: 'enormous',
      zones: 'large',
      'stat-load': 'large'
    });
    expect(parseSizes(stored)).toEqual({ 'stat-load': 'large' });
  });

  it('lets a wide card be stored, since cards can be half width', () => {
    expect(parseSizes(JSON.stringify({ mix: 'wide' }))).toEqual({ mix: 'wide' });
  });
});
