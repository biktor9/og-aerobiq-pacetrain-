import { describe, expect, it } from 'vitest';
import {
  MAX_STRUCTURE_BLOCKS,
  describeSession,
  edgeMinutes,
  initialSession,
  kmToMinutes,
  normalizeSession,
  normalizeStructure,
  parseStructureJson,
  sessionBlocks,
  sessionDuration,
  sessionTitle,
  toSession
} from './plan';
import { MODE_IDS, MODES, normalizeMode, type Block, type SessionInput } from './types';

const intervals: SessionInput = {
  date: '2026-10-20',
  mode: 'run',
  kind: 'intervals',
  title: 'Threshold reps',
  zone: 4,
  minutes: 60,
  reps: 4,
  workMin: 8,
  recoverMin: 2,
  warmupMin: 15,
  cooldownMin: 10,
  notes: '',
  status: 'planned'
};

describe('session structure', () => {
  it('expands intervals into warm-up, reps and cool-down', () => {
    const blocks = sessionBlocks(intervals);
    expect(blocks.map((b) => b.kind)).toEqual([
      'warmup',
      'work',
      'recover',
      'work',
      'recover',
      'work',
      'recover',
      'work',
      'cooldown'
    ]);
    expect(blocks.filter((b) => b.kind === 'work')).toHaveLength(4);
    expect(blocks.filter((b) => b.kind === 'work').every((b) => b.zone === 4)).toBe(true);
  });

  it('does not add recovery after the final rep', () => {
    const blocks = sessionBlocks({ ...intervals, reps: 2 });
    expect(blocks.filter((b) => b.kind === 'recover')).toHaveLength(1);
    expect(sessionDuration({ ...intervals, reps: 2 })).toBe(15 + 8 + 2 + 8 + 10);
  });

  it('derives interval duration from its parts', () => {
    // 15 warm-up + 4×8 work + 3×2 recovery + 10 cool-down
    expect(sessionDuration(intervals)).toBe(63);
  });

  it('uses the minutes field for steady sessions', () => {
    const steady: SessionInput = { ...intervals, kind: 'steady', minutes: 75, reps: 6 };
    expect(sessionBlocks(steady)).toEqual([{ kind: 'work', minutes: 75, zone: 4 }]);
    expect(sessionDuration(steady)).toBe(75);
  });

  it('treats strength as a single block', () => {
    const strength: SessionInput = { ...initialSession('2026-10-20', 'strength') };
    expect(strength.kind).toBe('strength');
    expect(sessionBlocks(strength)).toHaveLength(1);
    expect(sessionDuration(strength)).toBe(45);
  });
});

describe('normalizeSession', () => {
  it('clamps values into a sane range', () => {
    const normalized = normalizeSession({
      ...intervals,
      reps: 999,
      workMin: 500,
      recoverMin: -5,
      zone: 9,
      minutes: 2
    });
    expect(normalized.reps).toBe(40);
    expect(normalized.workMin).toBe(120);
    expect(normalized.recoverMin).toBe(0);
    expect(normalized.zone).toBe(5);
    expect(normalized.minutes).toBe(5);
  });

  it('repairs unknown modes, kinds, dates and statuses', () => {
    const normalized = normalizeSession({
      date: '20/10/2026',
      // deliberately invalid values coming from a query string or an import
      mode: 'swim' as never,
      kind: 'fartlek' as never,
      status: 'postponed' as never
    });
    expect(normalized.mode).toBe('run');
    expect(normalized.kind).toBe('steady');
    expect(normalized.status).toBe('planned');
    expect(normalized.date).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });

  it('rounds fractional minutes to whole minutes', () => {
    const normalized = normalizeSession({ ...intervals, workMin: 7.4, warmupMin: 12.6 });
    expect(normalized.workMin).toBe(7);
    expect(normalized.warmupMin).toBe(13);
  });

  it('keeps an interval session open when the reps are not decided', () => {
    const normalized = normalizeSession({ ...intervals, reps: null, workMin: null, minutes: 90, targetKm: 14 });
    expect(normalized.reps).toBeNull();
    expect(normalized.workMin).toBeNull();
    // One block in the chosen zone, 90 minutes long, and the kilometres kept.
    expect(normalized.kind).toBe('intervals');
    expect(sessionDuration(normalized)).toBe(90);
    expect(normalized.targetKm).toBe(14);
    expect(describeSession(normalized)).toBe('14 km · 90′ @ Z4 · reps not set');
  });

  it('plans intervals by distance per rep', () => {
    const normalized = normalizeSession({ ...intervals, reps: 8, targetReps: 0.8, workMin: 3.5 });
    expect(normalized.targetReps).toBe(0.8);
    expect(describeSession(normalized)).toContain('8 × 0.8 km @ Z4');
  });

  it('keeps a total distance on an interval set with reps', () => {
    // 6 × 4′ plus warm-up and cool-down, planned as 14 km in total.
    const normalized = normalizeSession({ ...intervals, reps: 6, workMin: 4, targetKm: 14 });

    expect(normalized.reps).toBe(6);
    expect(normalized.targetKm).toBe(14);
    expect(describeSession(normalized)).toContain('6 × 4′ @ Z4');
    expect(describeSession(normalized)).toContain('14 km total');
    // The total does not replace the rep length.
    expect(normalized.workMin).toBe(4);
  });

  it('carries no rep numbers on a steady session', () => {
    const normalized = normalizeSession({ ...intervals, kind: 'steady', reps: 8, workMin: 3 });
    expect(normalized.reps).toBeNull();
    expect(normalized.workMin).toBeNull();
    expect(normalized.targetReps).toBeNull();
  });
});

describe('warm-up and cool-down in kilometres', () => {
  it('turns a distance into minutes at the athlete’s pace', () => {
    // 2 km at 5:30/km is 11 minutes.
    expect(kmToMinutes(2, 330)).toBe(11);
    // 1 km at 6:00/km is 6 minutes.
    expect(kmToMinutes(1, 360)).toBe(6);
  });

  it('has nothing to convert for a blank or zero distance', () => {
    expect(kmToMinutes(null)).toBeNull();
    expect(kmToMinutes(0)).toBeNull();
    expect(kmToMinutes(Number.NaN)).toBeNull();
  });

  it('falls back to a sane pace when none is given', () => {
    // The planner's default 5:30/km, in half-minute steps.
    expect(kmToMinutes(1)).toBe(5.5);
    expect(kmToMinutes(2)).toBe(11);
  });

  it('lets a kilometre value win over the minutes', () => {
    const edges = edgeMinutes({ warmupMin: 15, cooldownMin: 10, warmupKm: 2, cooldownKm: null }, 330);
    expect(edges.warmup).toBe(11);
    expect(edges.cooldown).toBe(10);
  });

  it('uses the minutes when neither edge has a distance', () => {
    expect(edgeMinutes({ warmupMin: 15, cooldownMin: 10, warmupKm: null, cooldownKm: null }, 330)).toEqual({
      warmup: 15,
      cooldown: 10
    });
  });

  it('makes the session as long as the kilometres imply', () => {
    const session = normalizeSession({
      ...intervals,
      reps: 4,
      workMin: 8,
      recoverMin: 2,
      warmupKm: 2,
      cooldownKm: 1,
      warmupMin: 0,
      cooldownMin: 0
    });

    // 2 km warm-up (11′) + 4×8′ + 3×2′ + 1 km cool-down (5.5′) = 54.5′.
    const rendered = toSession({ ...session, id: 'x', linkedActivityId: null });
    expect(session.warmupKm).toBe(2);
    expect(rendered.durationMin).toBe(54.5);
    expect(rendered.blocks[0]).toEqual({ kind: 'warmup', minutes: 11, zone: 1 });
    expect(rendered.blocks[rendered.blocks.length - 1]).toEqual({ kind: 'cooldown', minutes: 5.5, zone: 1 });
  });
});

describe('session descriptions', () => {
  it('describes intervals compactly', () => {
    expect(describeSession(intervals)).toBe('4 × 8′ @ Z4 · 2′ easy · 63′ total');
  });

  it('describes steady and strength sessions', () => {
    expect(describeSession({ ...intervals, kind: 'steady', minutes: 60, zone: 2 })).toBe('60′ @ Z2');
    expect(describeSession({ ...intervals, kind: 'strength', mode: 'strength', minutes: 45, zone: 4 })).toBe(
      '45′ · Threshold'
    );
  });

  it('falls back to a sensible title', () => {
    expect(sessionTitle({ ...intervals, title: '' })).toBe('Intervals');
    expect(sessionTitle({ ...intervals, title: '  ', kind: 'strength' })).toBe('Strength');
    expect(sessionTitle({ ...intervals, title: 'Hill reps' })).toBe('Hill reps');
  });

  it('rebuilds a rendered session from a stored row', () => {
    const session = toSession({ ...intervals, id: 'abc', linkedActivityId: 'act-1' });
    expect(session.id).toBe('abc');
    expect(session.linkedActivityId).toBe('act-1');
    expect(session.durationMin).toBe(63);
    expect(session.blocks).toHaveLength(9);
  });
});

describe('structure persistence', () => {
  // What the athlete typed: 20' warm-up, 2x8' threshold, 10' down.
  const parsed: Block[] = [
    { kind: 'warmup', minutes: 20, zone: 1 },
    { kind: 'work', minutes: 8, zone: 4 },
    { kind: 'recover', minutes: 2, zone: 1 },
    { kind: 'work', minutes: 8, zone: 4 },
    { kind: 'cooldown', minutes: 10, zone: 1 }
  ];
  // The text the `structure_json` column stores.
  const stored = JSON.stringify(parsed);

  it('round-trips a parsed structure through the JSON column', () => {
    expect(parseStructureJson(stored)).toEqual(parsed);
  });

  it('keeps the structure when a saved row is read back', () => {
    const row: SessionInput & { id: string; linkedActivityId: string | null } = {
      ...intervals,
      id: 'row-1',
      linkedActivityId: null,
      structure: parseStructureJson(stored)
    };

    expect(normalizeSession(row).structure).toEqual(parsed);

    const session = toSession(row);
    expect(session.blocks).toEqual(parsed);
    expect(session.durationMin).toBe(48);
    expect(describeSession(session)).toContain('48′ total');
    expect(describeSession(session)).toContain('2 ×');
  });

  it('ignores junk in the column and falls back to the numbers', () => {
    expect(parseStructureJson(null)).toBeNull();
    expect(parseStructureJson('')).toBeNull();
    expect(parseStructureJson('not json')).toBeNull();
    expect(parseStructureJson('{"kind":"work","minutes":10}')).toBeNull();
    expect(parseStructureJson('[]')).toBeNull();

    const fallback = normalizeSession({ ...intervals, structure: parseStructureJson('{oops') });
    expect(fallback.structure).toBeNull();
    expect(sessionBlocks(fallback).filter((b) => b.kind === 'work')).toHaveLength(4);
  });

  it('repairs block kinds, minutes and zones on the way in', () => {
    expect(parseStructureJson('[{"kind":"sprint","minutes":"12","zone":"9"}]')).toEqual([
      { kind: 'work', minutes: 12, zone: 5 }
    ]);
    expect(normalizeStructure([{ kind: 'work', minutes: 0, zone: 2 }, { kind: 'work', minutes: 3, zone: 2 }])).toEqual(
      [{ kind: 'work', minutes: 3, zone: 2 }]
    );
    expect(normalizeStructure('20 easy')).toBeNull();
  });

  it('caps the block list so a pasted plan cannot flood a row', () => {
    const many = Array.from({ length: MAX_STRUCTURE_BLOCKS + 20 }, () => ({ kind: 'work' as const, minutes: 1, zone: 2 }));
    expect(normalizeStructure(many)).toHaveLength(MAX_STRUCTURE_BLOCKS);
  });
});

describe('training modes', () => {
  it('exposes every discipline exactly once', () => {
    expect(MODE_IDS).toEqual(['run', 'trail', 'orienteering', 'ski', 'strength', 'mtb', 'bike']);
    expect(MODES.map((m) => m.id)).toEqual([...MODE_IDS]);
    expect(new Set(MODES.map((m) => m.short)).size).toBe(MODES.length);
  });

  it('normalises stored, legacy and unknown modes', () => {
    expect(normalizeMode('mtb')).toBe('mtb');
    expect(normalizeMode(' Orienteering ')).toBe('orienteering');
    // Rows written before the vocabulary was widened.
    expect(normalizeMode('rollerski')).toBe('ski');
    expect(normalizeMode('swim')).toBe('run');
    expect(normalizeMode(undefined)).toBe('run');
  });
});
