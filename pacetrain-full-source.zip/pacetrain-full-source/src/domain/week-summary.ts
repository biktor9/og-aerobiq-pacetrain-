import { isRunningMode } from './activity';
import { doneSessionIds } from './plan-match';
import type { Activity, Session } from './types';
import { addDays, addWeeks, toISODate, weekKey, weekRangeLabel, weekdayLabel } from './week';

/**
 * The week as it actually happened, next to the week as it was planned.
 *
 * `weekStats` describes the plan (minutes, load, target kilometres). This
 * module answers the other question: how much did the athlete really run, how
 * much of the plan is behind them, and how did the last four weeks look. It is
 * pure, so the calendar and the numbers can never disagree.
 */

/** Minutes trained in a day, mapped onto five shades for the calendar. */
const HEAT_STEPS = [20, 45, 75] as const;

export type HeatLevel = 0 | 1 | 2 | 3 | 4;

export interface DayStatus {
  /** `YYYY-MM-DD` */
  date: string;
  /** `Mon` */
  weekday: string;
  dayOfMonth: number;
  isToday: boolean;
  /** Later than today: no training has happened yet. */
  isFuture: boolean;
  /** Minutes of imported activity. */
  minutes: number;
  km: number;
  runningKm: number;
  activities: number;
  /** Running activities only (run, trail, orienteering). */
  runs: number;
  plannedMinutes: number;
  planned: number;
  done: number;
  skipped: number;
  level: HeatLevel;
}

export interface WeekSummary {
  /** `2026-W43` */
  key: string;
  monday: string;
  /** `19–25 Oct 2026` */
  label: string;
  days: DayStatus[];
  /** Actual minutes across every discipline. */
  minutes: number;
  km: number;
  runningKm: number;
  runs: number;
  activities: number;
  plannedMinutes: number;
  /** Planned minutes on days that have already happened. */
  plannedSoFarMinutes: number;
  /** Actual minutes on days that have already happened. */
  doneMinutes: number;
  /** `doneMinutes / plannedSoFarMinutes`, 0 when nothing was planned yet. */
  donePct: number;
  /**
   * Planned time already behind the athlete: a finished session counts as
   * planned minutes completed, a skipped one as nothing, an open one as the
   * session it turned out to be. This is "plan done so far".
   */
  donePlanMinutes: number;
  /** `donePlanMinutes / plannedSoFarMinutes`, 0 when nothing was due. */
  donePlanPct: number;
  /**
   * What the plan says the week will come to, once the skipped sessions are
   * taken out: the hours and the running kilometres still to be done plus the
   * ones already done.
   */
  forecastMinutes: number;
  forecastRunningKm: number;
  /** Planned minutes in sessions marked skipped, this week and the last. */
  skippedMinutes: number;
  /** Planned running kilometres in those sessions. */
  skippedKm: number;
  /** Running kilometres the plan wants by Sunday, skipped sessions excluded. */
  plannedRunningKm: number;
  sessions: number;
  done: number;
  skipped: number;
  trainedDays: number;
  isCurrentWeek: boolean;
}

export function heatLevel(minutes: number): HeatLevel {
  if (minutes <= 0) return 0;
  if (minutes < HEAT_STEPS[0]) return 1;
  if (minutes < HEAT_STEPS[1]) return 2;
  if (minutes < HEAT_STEPS[2]) return 3;
  return 4;
}

function round1(value: number): number {
  return Math.round(value * 10) / 10;
}

export function buildWeekSummary({
  monday,
  activities,
  sessions,
  today = new Date()
}: {
  monday: Date;
  activities: Activity[];
  sessions: Session[];
  today?: Date;
}): WeekSummary {
  const todayISO = toISODate(today);
  const key = weekKey(monday);
  const weekStart = toISODate(monday);
  const weekEnd = toISODate(addDays(monday, 6));

  // Only this week's rows. The caller may hand over a whole strip's worth of
  // activities and sessions, and anything outside Monday–Sunday belongs to a
  // neighbouring week: counting it here is how every week ended up with the
  // same planned hours and kilometres.
  const weekSessions = sessions.filter((session) => session.date >= weekStart && session.date <= weekEnd);
  const weekActivities = activities.filter((activity) => activity.date >= weekStart && activity.date <= weekEnd);

  // A session is done when there is an activity behind it, not only when the
  // athlete remembered to tick it off. This is what stops a completed week from
  // reading "0 of 5 done".
  const finished = doneSessionIds(weekSessions, weekActivities);

  const days: DayStatus[] = [];

  for (let offset = 0; offset < 7; offset++) {
    const date = addDays(monday, offset);
    const iso = toISODate(date);
    const dayActivities = weekActivities.filter((activity) => activity.date === iso);
    const daySessions = weekSessions.filter((session) => session.date === iso);

    let minutes = 0;
    let km = 0;
    let runningKm = 0;
    for (const activity of dayActivities) {
      minutes += activity.durationSec > 0 ? activity.durationSec / 60 : 0;
      const activityKilometres = activity.distanceM > 0 ? activity.distanceM / 1000 : 0;
      km += activityKilometres;
      if (isRunningMode(activity.mode)) runningKm += activityKilometres;
    }

    days.push({
      date: iso,
      weekday: weekdayLabel(date),
      dayOfMonth: date.getDate(),
      isToday: iso === todayISO,
      isFuture: iso > todayISO,
      minutes: Math.round(minutes),
      km: round1(km),
      runningKm: round1(runningKm),
      activities: dayActivities.length,
      runs: dayActivities.filter((activity) => isRunningMode(activity.mode)).length,
      plannedMinutes: daySessions.reduce((total, session) => total + session.durationMin, 0),
      planned: daySessions.length,
      done: daySessions.filter((session) => finished.has(session.id)).length,
      skipped: daySessions.filter((session) => session.status === 'skipped').length,
      level: heatLevel(minutes)
    });
  }

  const sum = (pick: (day: DayStatus) => number, allowed: (day: DayStatus) => boolean = () => true) =>
    days.filter(allowed).reduce((total, day) => total + pick(day), 0);

  const skippedDue = weekSessions.filter((session) => session.status === 'skipped' && session.date <= todayISO);
  const skippedDueMinutes = skippedDue.reduce((total, session) => total + session.durationMin, 0);
  // A skipped session is off the plan, so it is not "due" either: the share of
  // the plan done is measured against what was still expected to happen.
  const plannedSoFarMinutes = Math.max(
    0,
    Math.round(sum((day) => day.plannedMinutes, (day) => !day.isFuture)) - skippedDueMinutes
  );
  const doneMinutes = Math.round(sum((day) => day.minutes, (day) => !day.isFuture));

  // The plan's own count: sessions that happened on days already lived count
  // as the time they were planned for, skipped ones as nothing, and an open
  // interval session as whatever the athlete actually did.
  let donePlanMinutes = 0;
  for (const session of weekSessions) {
    const iso = session.date;
    const future = iso > todayISO;
    if (future || session.status === 'skipped') continue;
    if (session.status === 'done' || finished.has(session.id)) {
      donePlanMinutes += session.durationMin;
      continue;
    }
    // Not ticked off and not matched: count the time actually trained that day.
    const day = days.find((entry) => entry.date === iso);
    if (day) donePlanMinutes += Math.min(day.minutes, session.durationMin);
  }
  donePlanMinutes = Math.round(donePlanMinutes);

  // What the week will come to. A skipped session is off the plan, so it is
  // cut from the forecast — that is the difference between a plan slipping and
  // a plan that was never going to be met.
  let forecastMinutes = 0;
  let forecastRunningKm = 0;
  let skippedMinutes = 0;
  let skippedKm = 0;
  let plannedRunningKm = 0;
  for (const session of weekSessions) {
    if (session.status === 'skipped' && session.date <= todayISO) {
      skippedMinutes += session.durationMin;
      if (isRunningMode(session.mode)) skippedKm += session.targetKm ?? 0;
      continue;
    }
    forecastMinutes += session.durationMin;
    if (isRunningMode(session.mode)) {
      plannedRunningKm += session.targetKm ?? 0;
      forecastRunningKm += session.targetKm ?? 0;
    }
  }

  return {
    key,
    monday: toISODate(monday),
    label: weekRangeLabel(monday),
    days,
    minutes: Math.round(sum((day) => day.minutes)),
    km: round1(sum((day) => day.km)),
    runningKm: round1(sum((day) => day.runningKm)),
    runs: days.reduce((total, day) => total + day.runs, 0),
    activities: days.reduce((total, day) => total + day.activities, 0),
    plannedMinutes: Math.round(sum((day) => day.plannedMinutes)),
    plannedSoFarMinutes,
    doneMinutes,
    donePct: plannedSoFarMinutes > 0 ? Math.round((doneMinutes / plannedSoFarMinutes) * 100) : 0,
    donePlanMinutes,
    donePlanPct: plannedSoFarMinutes > 0 ? Math.round((donePlanMinutes / plannedSoFarMinutes) * 100) : 0,
    forecastMinutes: Math.round(forecastMinutes),
    forecastRunningKm: round1(forecastRunningKm),
    skippedMinutes: Math.round(skippedMinutes),
    skippedKm: round1(skippedKm),
    plannedRunningKm: round1(plannedRunningKm),
    sessions: days.reduce((total, day) => total + day.planned, 0),
    done: days.reduce((total, day) => total + day.done, 0),
    skipped: days.reduce((total, day) => total + day.skipped, 0),
    trainedDays: days.filter((day) => day.minutes > 0).length,
    isCurrentWeek: key === weekKey(today)
  };
}

/**
 * `weeks` weeks in a row ending with the one that starts on `monday`. A
 * negative count walks forward instead, which is how the calendar shows next
 * week beside the last three.
 */
export function buildWeekStrip({
  monday,
  weeks = 4,
  activities,
  sessions,
  today = new Date()
}: {
  monday: Date;
  weeks?: number;
  activities: Activity[];
  sessions: Session[];
  today?: Date;
}): WeekSummary[] {
  const count = Math.max(1, Math.round(Math.abs(weeks)));
  const out: WeekSummary[] = [];

  if (weeks < 0) {
    // Forward from this week: this one first, then the weeks after it.
    for (let ahead = 0; ahead < count; ahead++) {
      out.push(buildWeekSummary({ monday: addWeeks(monday, ahead), activities, sessions, today }));
    }
    return out;
  }

  for (let back = count - 1; back >= 0; back--) {
    out.push(buildWeekSummary({ monday: addWeeks(monday, -back), activities, sessions, today }));
  }
  return out;
}

/**
 * The calendar the plan page shows: the last three weeks, this week, and next
 * week — five rows, so next week's plan is visible without leaving the page.
 */
export function buildCalendarWeeks({
  monday,
  activities,
  sessions,
  today = new Date()
}: {
  /** Monday of the week being viewed. */
  monday: Date;
  activities: Activity[];
  sessions: Session[];
  today?: Date;
}): WeekSummary[] {
  return [
    // The last four weeks, ending with the one being viewed.
    ...buildWeekStrip({ monday, weeks: 4, activities, sessions, today }),
    // And the week after it, so next week's plan is on the same page.
    buildWeekSummary({ monday: addWeeks(monday, 1), activities, sessions, today })
  ];
}
