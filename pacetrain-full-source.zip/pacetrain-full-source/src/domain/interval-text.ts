import type { Block, BlockKind } from './types';

/**
 * Reads a session written in plain words ("20' warm-up, 4x8' threshold w/ 2'
 * jog, 10' down") and turns it into timed blocks.
 *
 * This is deliberately a small, deterministic parser: it runs on the server, it
 * needs no API key, and the same text always produces the same structure. When
 * a DeepSeek key is configured the API route may ask the model first, but the
 * result is validated against this shape and this parser stays the fallback.
 */

export interface ParsedIntervalText {
  blocks: Block[];
  totalMin: number;
  reps: number;
  workMin: number;
  recoverMin: number;
  warmupMin: number;
  cooldownMin: number;
  zone: number;
  kind: 'steady' | 'intervals';
  /** False when the text held no usable duration. */
  ok: boolean;
  warnings: string[];
}

const BLOCK_KINDS: BlockKind[] = ['warmup', 'work', 'recover', 'cooldown'];

const ZONE_WORDS: { zone: number; re: RegExp }[] = [
  { zone: 5, re: /\b(max|vo2|v02|sprint|all[- ]?out|neuromuscular|anaerobic)\b/ },
  { zone: 4, re: /\b(threshold|thresh|lactate|ftp|race pace|hard|tempo hard|sub[- ]?threshold)\b/ },
  { zone: 3, re: /\b(tempo|marathon|sweet ?spot|steady hard)\b/ },
  { zone: 2, re: /\b(easy|steady|aerobic|endurance|base|conversational|long)\b/ },
  { zone: 1, re: /\b(recovery|recover|rest|jog|float|spin|walk|warm|warmup|cool|cooling|down|shake)\b/ }
];

/**
 * Durations are written in every notation an athlete types: `8′`, `90″`,
 * `2′30″`, `4:30`, `1h 20`, `45 sec`. Each pattern is tried in this order at
 * every position, because `2′30″` is one duration — not 2′ followed by 30″.
 */
type DurationKind = 'minutes' | 'seconds' | 'clock';

interface DurationMatch {
  minutes: number;
  start: number;
  end: number;
  kind: DurationKind;
  /** `4:30/km` is a pace, not a duration. */
  pace: boolean;
}

const NUMBER = String.raw`\d+(?:[.,]\d+)?`;

interface DurationPattern {
  re: RegExp;
  read: (match: RegExpExecArray) => { minutes: number; kind: DurationKind };
}

const DURATION_PATTERNS: DurationPattern[] = [
  {
    // 2'30" / 2' 30" — the closing quote proves where the seconds end.
    re: new RegExp(String.raw`(${NUMBER})\s*'\s*(\d{1,2})\s*(?:"|'')`, 'y'),
    read: (match) => ({
      minutes: Number(match[1].replace(',', '.')) + Number(match[2]) / 60,
      kind: 'seconds'
    })
  },
  {
    // 2'30 — no space, so "8' 4:00" stays 8 minutes plus a 4:00 pace.
    re: new RegExp(String.raw`(${NUMBER})'(\d{1,2})(?!\d)`, 'y'),
    read: (match) => ({
      minutes: Number(match[1].replace(',', '.')) + Number(match[2]) / 60,
      kind: 'seconds'
    })
  },
  {
    // 4:30 is four minutes thirty (mm:ss); 1:02:30 carries an hour.
    re: new RegExp(String.raw`(\d{1,3}):([0-5]\d)(?::([0-5]\d))?`, 'y'),
    read: (match) => ({
      minutes: match[3]
        ? Number(match[1]) * 60 + Number(match[2]) + Number(match[3]) / 60
        : Number(match[1]) + Number(match[2]) / 60,
      kind: 'clock'
    })
  },
  {
    // 90" / 45″
    re: new RegExp(String.raw`(${NUMBER})\s*"`, 'y'),
    read: (match) => ({ minutes: Number(match[1].replace(',', '.')) / 60, kind: 'seconds' })
  },
  {
    // 8' / 8′
    re: new RegExp(String.raw`(${NUMBER})\s*'`, 'y'),
    read: (match) => ({ minutes: Number(match[1].replace(',', '.')), kind: 'minutes' })
  },
  {
    // 8 min / 90 sec / 1h
    re: new RegExp(
      String.raw`(${NUMBER})\s*(hours?|hrs?|h|minutes?|mins?|min|m|seconds?|secs?|s)(?![a-z])`,
      'iy'
    ),
    read: (match) => {
      const amount = Number(match[1].replace(',', '.'));
      const unit = match[2].toLowerCase();
      // "1000 m" is a distance, not a thousand-minute rep.
      if (unit === 'm' && amount >= 100) return { minutes: 0, kind: 'minutes' };
      const minutes = unit.startsWith('h') ? amount * 60 : unit.startsWith('s') ? amount / 60 : amount;
      return { minutes, kind: unit.startsWith('s') ? 'seconds' : 'minutes' };
    }
  }
];

/** `4:30/km`, `4'30"/km`, `4:30 per km`, `12 km/h`. */
const PACE_SUFFIX = /^\s*(?:min|mins|'|′)?\s*(?:\/|per)\s*(km|k|mi|mile|miles?|400\s*m|500\s*m|m)\b/;
const PACE_AFTER = /^\s*(?:min\s*)?(?:pace|\/\s*(?:km|k|mi|mile|miles?|400\s*m|500\s*m|m))\b/;
const PACE_BEFORE = /\bpace\s*$/;

function isPaceAt(text: string, start: number, end: number): boolean {
  const after = text.slice(end);
  return PACE_SUFFIX.test(after) || PACE_AFTER.test(after) || PACE_BEFORE.test(text.slice(0, start));
}

function normalizeText(input: string): string {
  return input
    .replace(/[′’‘`]/g, "'")
    .replace(/[″“”]/g, '"')
    .replace(/[×✕*]/g, 'x')
    .replace(/[–—]/g, '-')
    .replace(/\bw\/\s*/gi, 'with ')
    .replace(/@/g, ' ')
    .replace(/\bat\b/gi, ' ')
    .toLowerCase();
}

/** Splits on commas, semicolons, newlines, "+" and the words "and"/"then". */
function splitTopLevel(text: string): string[] {
  const parts: string[] = [];
  let depth = 0;
  let current = '';

  for (const char of text) {
    if (char === '(') depth += 1;
    if (char === ')') depth = Math.max(0, depth - 1);
    if (depth === 0 && /[,;\n+]/.test(char)) {
      parts.push(current);
      current = '';
      continue;
    }
    current += char;
  }
  parts.push(current);

  return parts
    .flatMap((part) => part.split(/\s+(?:and|then)\s+/))
    .map((part) => part.trim())
    .filter(Boolean);
}

/** Every duration in a phrase, in minutes, in the order it was written. */
export function readDurations(text: string): number[] {
  return timeMatches(normalizeText(text)).map((match) => match.minutes);
}

/**
 * A fresh set of sticky regexes per call: a shared global regex keeps
 * `lastIndex` between calls, which silently shifts every second parse.
 */
function durationMatches(text: string): DurationMatch[] {
  const out: DurationMatch[] = [];
  let index = 0;

  while (index < text.length) {
    let advanced = false;

    for (const pattern of DURATION_PATTERNS) {
      pattern.re.lastIndex = index;
      const match = pattern.re.exec(text);
      if (!match) continue;

      const { minutes, kind } = pattern.read(match);
      const end = match.index + Math.max(1, match[0].length);
      if (minutes > 0) {
        out.push({ minutes, start: match.index, end, kind, pace: isPaceAt(text, match.index, end) });
      }
      index = end;
      advanced = true;
      break;
    }

    if (!advanced) index += 1;
  }

  return out;
}

/** Durations only: a pace target is not something you can spend time doing. */
function timeMatches(text: string): DurationMatch[] {
  return durationMatches(text).filter((match) => !match.pace);
}

/** The phrase with every number that describes a time or pace removed. */
function stripDurations(text: string): string {
  let out = '';
  let cursor = 0;
  for (const match of durationMatches(text)) {
    out += `${text.slice(cursor, match.start)} `;
    cursor = match.end;
  }
  return `${out}${text.slice(cursor)}`.replace(/\s+/g, ' ').trim();
}

export function zoneFromWords(text: string): number | null {
  const explicit = /\bz\s?([1-5])\b/.exec(text);
  if (explicit) return Number(explicit[1]);
  for (const { zone, re } of ZONE_WORDS) {
    if (re.test(text)) return zone;
  }
  return null;
}

function kindFromWords(text: string): BlockKind | null {
  if (/\b(warm[- ]?up|warmup|warm up|warm)\b/.test(text)) return 'warmup';
  if (/\b(cool[- ]?down|cooldown|cool down|jog down|down)\b/.test(text)) return 'cooldown';
  if (/\b(recover|recovery|rest|jog|float|spin|walk)\b/.test(text)) return 'recover';
  return null;
}

function isWarmupText(text: string): boolean {
  return /\b(warm[- ]?up|warmup|warm up|warm)\b/.test(text);
}

function isCooldownText(text: string): boolean {
  return /\b(cool[- ]?down|cooldown|cool down|jog down|down)\b/.test(text);
}

function roundTenth(value: number): number {
  return Math.round(value * 100) / 100;
}

/**
 * Blocks are stored in minutes, because that is what the planner and the load
 * model speak. Hundredths of a minute (0.6 s) keep a 400 m rep honest: at half
 * a minute of rounding, 8 × 400 m becomes a different session.
 */
function block(kind: BlockKind, minutes: number, zone: number): Block {
  return { kind, minutes: Math.min(600, Math.max(0.1, roundTenth(minutes))), zone };
}

/** A plain timed step: "20' easy", "3' max", "10' cool-down". */
function parseStep(text: string, fallbackZone: number): Block | null {
  const durations = timeMatches(text);
  if (!durations.length) return null;

  const minutes = durations[0].minutes;
  const words = stripDurations(text);
  const kind = kindFromWords(words) ?? 'work';
  const zone = zoneFromWords(words) ?? (kind === 'work' ? fallbackZone : 1);
  return block(kind, minutes, zone);
}

/** "3x(4' hard + 2' easy)" — the parenthesised set, repeated. */
function parseGroup(reps: number, inner: string, trailing: string, warnings: string[]): Block[] {
  const steps = splitTopLevel(inner)
    .map((step) => parseStep(step, 4))
    .filter((step): step is Block => Boolean(step));

  if (!steps.length) {
    warnings.push(`Could not read the set "${inner.trim()}".`);
    return [];
  }

  const tailZone = zoneFromWords(trailing);
  const blocks: Block[] = [];
  for (let rep = 0; rep < reps; rep++) {
    steps.forEach((step, stepIndex) => {
      // Inside a set, everything after the first step is the easy part of it.
      const kind = stepIndex > 0 && step.kind === 'work' && step.zone <= 2 ? 'recover' : step.kind;
      blocks.push({ ...step, kind, zone: tailZone && rep === 0 ? tailZone : step.zone });
    });
  }
  return blocks;
}

/** Words that mark the easy part between reps ("with 2' jog", "90s rest"). */
const RECOVERY_WORDS = /\b(easy|recover|recovery|jog|float|walk|rest|spin|off|between|with)\b/;

/** "4x8' threshold with 2' jog". */
function parseRepeats(reps: number, rest: string, warnings: string[]): Block[] {
  const durations = timeMatches(rest);
  if (!durations.length) {
    warnings.push(`"${rest.trim()}" has reps but no work duration.`);
    return [];
  }

  const work = durations[0];
  // A second duration is the recovery only when the phrase says so. Without
  // that guard "4x8' @ 4:00" would invent a 4′ jog between the reps.
  const recovery = RECOVERY_WORDS.test(rest) ? durations[1] : undefined;
  const between = rest.slice(work.end, recovery?.start ?? rest.length);

  const workZone = zoneFromWords(between) ?? zoneFromWords(rest.slice(0, work.start)) ?? 4;
  const recoverZone = recovery ? zoneFromWords(rest.slice(recovery.end)) ?? 1 : 1;

  const blocks: Block[] = [];
  for (let rep = 0; rep < reps; rep++) {
    blocks.push(block('work', work.minutes, workZone));
    if (recovery && rep < reps - 1) blocks.push(block('recover', recovery.minutes, recoverZone));
  }
  return blocks;
}

/** How many metres one unit is worth, for rep distances. */
const DISTANCE_UNITS: Record<string, number> = {
  km: 1000,
  k: 1000,
  mi: 1609.344,
  mile: 1609.344,
  miles: 1609.344,
  m: 1
};

interface RepDistance {
  metres: number;
  start: number;
  end: number;
}

/** `400m`, `1km`, `1 mile`, `5x1000` — how far one repeat goes. */
function readRepDistance(text: string): RepDistance | null {
  const match = /(\d+(?:[.,]\d+)?)\s*(km|k|mi|miles?|m)\b/.exec(text);
  if (match) {
    const amount = Number(match[1].replace(',', '.'));
    const unit = match[2].toLowerCase();
    // "8m" is eight minutes; "800m" is eight hundred metres.
    if (unit === 'm' && amount < 100) return null;
    return {
      metres: amount * (DISTANCE_UNITS[unit] ?? 1),
      start: match.index,
      end: match.index + match[0].length
    };
  }

  // "5x1000 @ 4:10" — a bare number this large can only be metres.
  const bare = /^\s*(\d{3,4})(?![\d.,])/.exec(text);
  if (bare) {
    const metres = Number(bare[1]);
    const start = bare.index + bare[0].indexOf(bare[1]);
    if (metres >= 200) return { metres, start, end: start + bare[1].length };
  }
  return null;
}

/** True when a repeat is described by distance rather than by time. */
function hasDistanceRep(text: string): boolean {
  return readRepDistance(text) !== null;
}

interface PaceMatch {
  secPerKm: number;
  start: number;
  end: number;
}

function unitMetres(unit: string): number {
  const clean = unit.toLowerCase().replace(/\s+/g, '');
  if (clean === '400m') return 400;
  if (clean === '500m') return 500;
  return DISTANCE_UNITS[clean] ?? 1000;
}

/** Seconds per kilometre for a pace (or speed) written anywhere in a phrase. */
function paceMatches(text: string): PaceMatch[] {
  const out: PaceMatch[] = [];
  const patterns: { re: RegExp; read: (match: RegExpExecArray) => number | null }[] = [
    {
      // 4:30/km · 1:02:30 per mile · 90"/400m
      re: /(\d{1,3}):([0-5]\d)(?::([0-5]\d))?\s*(?:min)?\s*(?:\/|per)\s*(km|k|mi|miles?|400\s*m|500\s*m|m)\b/g,
      read: (match) => {
        // 4:30 is mm:ss; 1:02:30 is h:mm:ss.
        const seconds = match[3]
          ? Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3])
          : Number(match[1]) * 60 + Number(match[2]);
        return (seconds / unitMetres(match[4])) * 1000;
      }
    },
    {
      // 4.30/km — the Scandinavian way of writing 4:30
      re: /(\d{1,2})[.,](\d{2})\s*(?:\/|per)\s*(km|k|mi|miles?)\b/g,
      read: (match) => ((Number(match[1]) + Number(match[2]) / 60) * 60 * 1000) / unitMetres(match[3])
    },
    {
      // 4'30"/km · 4 min per km
      re: /(\d+(?:[.,]\d+)?)\s*(?:min|mins|'|′)\s*(?:\/|per)\s*(km|k|mi|miles?)\b/g,
      read: (match) => (Number(match[1].replace(',', '.')) * 60 * 1000) / unitMetres(match[2])
    },
    {
      // 4:30 pace
      re: /(\d{1,3}):([0-5]\d)\s*(?:min\s*)?pace\b/g,
      read: (match) => Number(match[1]) * 60 + Number(match[2])
    },
    {
      // 12 km/h
      re: /(\d+(?:[.,]\d+)?)\s*km\s*(?:\/|per)\s*(?:h|hr|hour)\b/g,
      read: (match) => {
        const speed = Number(match[1].replace(',', '.'));
        return speed > 0 ? 3600 / speed : null;
      }
    }
  ];

  for (const { re, read } of patterns) {
    let match = re.exec(text);
    while (match) {
      const secPerKm = read(match);
      if (secPerKm && Number.isFinite(secPerKm)) {
        out.push({ secPerKm, start: match.index, end: match.index + match[0].length });
      }
      match = re.exec(text);
    }
  }
  return out.sort((a, b) => a.start - b.start);
}

/**
 * Splits "800m @ 3:30/km with 90s rest" into the rep and the recovery. A
 * duration written just before the word ("90s rest") belongs to the recovery.
 */
function splitRecovery(text: string): { work: string; recovery: string } {
  const match = RECOVERY_WORDS.exec(text);
  if (!match) return { work: text, recovery: '' };

  const before = text.slice(0, match.index);
  const after = text.slice(match.index);
  const last = durationMatches(before).at(-1);
  // "(2' rest)" leaves a bracket behind the duration; strip it with the split.
  if (last && before.slice(last.end).replace(/[()]/g, '').trim() === '') {
    return {
      work: before.slice(0, last.start).replace(/[()\s]+$/, ''),
      recovery: before.slice(last.start) + after
    };
  }
  return { work: before, recovery: after };
}

/** How long one repeat takes, from a pace, a per-rep time or a distance+pace pair. */
function repSeconds(work: string, distance: RepDistance, pace: PaceMatch | undefined): number | null {
  if (pace) return (distance.metres / 1000) * pace.secPerKm;

  const last = timeMatches(work).at(-1);
  if (!last) return null;

  const before = work.slice(Math.max(0, last.start - 8), last.start);
  const after = work.slice(last.end, last.end + 8);
  const perRep = /\b(in|for|each)\s*$/.test(before) || /\bpace\b/.test(after);

  // A time written after the distance ("400m @ 4:10") is a pace; one written
  // before it ("2' @ 500m") is the rep. A seconds tick ("90″") is the rep, and
  // so is anything at about a kilometre or more.
  if (last.kind === 'seconds' || perRep || last.start < distance.start || distance.metres >= 900) {
    return last.minutes * 60;
  }
  return (distance.metres / 1000) * last.minutes * 60;
}

/** "6x1km @ 4:00/km", "8x400m in 90″", "5x1 mile @ 6:30/mi". */
function parseDistanceRepeats(reps: number, rest: string, warnings: string[]): Block[] {
  const { work, recovery } = splitRecovery(rest);
  const distance = readRepDistance(work);
  const seconds = distance ? repSeconds(work, distance, paceMatches(work)[0]) : null;

  if (!distance || !seconds || seconds <= 0) {
    warnings.push(
      'Distance-based reps need a time — add a pace (8x400m @ 3:30/km) or a time per rep (8x400m in 90″).'
    );
    return [];
  }

  const recoveryMinutes = timeMatches(recovery)[0]?.minutes ?? 0;
  const zone = zoneFromWords(stripDurations(work)) ?? 4;
  const recoverZone = zoneFromWords(recovery) ?? 1;

  const blocks: Block[] = [];
  for (let rep = 0; rep < reps; rep++) {
    blocks.push(block('work', seconds / 60, zone));
    if (recoveryMinutes > 0 && rep < reps - 1) blocks.push(block('recover', recoveryMinutes, recoverZone));
  }
  return blocks;
}

/** Recomputes the scalar summary for any block list (also used for AI output). */
export function summariseBlocks(blocks: Block[], warnings: string[] = []): ParsedIntervalText {
  const totalMin = blocks.reduce((total, item) => total + item.minutes, 0);
  const workBlocks = blocks.filter((item) => item.kind === 'work');
  const recoverBlocks = blocks.filter((item) => item.kind === 'recover');

  let warmupMin = 0;
  let index = 0;
  while (index < blocks.length && blocks[index].kind === 'warmup') warmupMin += blocks[index++].minutes;

  let cooldownMin = 0;
  let back = blocks.length - 1;
  while (back >= 0 && blocks[back].kind === 'cooldown') cooldownMin += blocks[back--].minutes;

  // The most repeated duration is what the athlete means by "the work".
  const pick = (items: Block[], fallback: number) => {
    const counts = new Map<number, number>();
    for (const item of items) counts.set(item.minutes, (counts.get(item.minutes) ?? 0) + 1);
    let best = fallback;
    let bestCount = 0;
    for (const [minutes, count] of counts) {
      if (count > bestCount) {
        best = minutes;
        bestCount = count;
      }
    }
    return best;
  };

  const zoneMinutes = new Map<number, number>();
  for (const item of workBlocks) zoneMinutes.set(item.zone, (zoneMinutes.get(item.zone) ?? 0) + item.minutes);
  let zone = 2;
  let zoneBest = 0;
  for (const [id, minutes] of zoneMinutes) {
    if (minutes > zoneBest) {
      zone = id;
      zoneBest = minutes;
    }
  }

  return {
    blocks,
    totalMin: roundTenth(totalMin),
    reps: Math.max(1, workBlocks.length),
    workMin: pick(workBlocks, 8),
    recoverMin: recoverBlocks.length ? pick(recoverBlocks, 0) : 0,
    warmupMin,
    cooldownMin,
    zone,
    kind: workBlocks.length > 1 || recoverBlocks.length > 0 ? 'intervals' : 'steady',
    ok: blocks.length > 0,
    warnings
  };
}

/** Turns one top-level phrase into blocks. */
function parseChunk(chunk: string, position: { index: number; count: number }, warnings: string[]): Block[] {
  const repeat = /(\d+)\s*x\s*(.+)$/.exec(chunk);
  if (repeat) {
    const reps = Math.min(40, Math.max(1, Number(repeat[1])));
    const rest = repeat[2].trim();
    const group = /^\((.*)\)\s*([^()]*)$/.exec(rest);
    if (group) return parseGroup(reps, group[1], group[2], warnings);
    if (hasDistanceRep(rest)) return parseDistanceRepeats(reps, rest, warnings);
    return parseRepeats(reps, rest, warnings);
  }

  const blocks: Block[] = [];
  for (const part of splitTopLevel(chunk)) {
    const step = parseStep(part, 2);
    if (!step) continue;

    if (step.kind === 'work' && position.index > 0 && position.index < position.count - 1 && step.zone <= 2) {
      // A bare "easy" phrase in the middle of the session is recovery.
      blocks.push({ ...step, kind: 'recover' });
      continue;
    }
    if (step.kind === 'work' && isWarmupText(part)) {
      blocks.push({ ...step, kind: 'warmup', zone: 1 });
      continue;
    }
    if (step.kind === 'work' && isCooldownText(part)) {
      blocks.push({ ...step, kind: 'cooldown', zone: 1 });
      continue;
    }
    blocks.push(step);
  }
  return blocks;
}

/**
 * Athletes write "4x8 min threshold, 2 min jog" and the comma splits the
 * recovery off the repeat. Fold a short easy step back into the repeat it
 * follows so it becomes the between-rep recovery instead of a trailing block.
 */
function mergeRecoveries(chunks: string[]): string[] {
  const merged: string[] = [];

  for (let index = 0; index < chunks.length; index++) {
    const chunk = chunks[index];
    const next = chunks[index + 1];
    if (next && /\d+\s*x/.test(chunk) && isTrailingRecovery(next)) {
      merged.push(`${chunk} with ${next}`);
      index += 1;
      continue;
    }
    merged.push(chunk);
  }

  return merged;
}

/** A short easy step, not a warm-up, a cool-down or another set. */
function isTrailingRecovery(text: string): boolean {
  if (/\d+\s*x/.test(text)) return false;
  if (isWarmupText(text) || isCooldownText(text)) return false;
  const step = parseStep(text, 2);
  if (!step) return false;
  // Long easy blocks are sessions of their own, not recoveries between reps.
  if (step.minutes > 10) return false;
  return step.kind === 'recover' || (step.kind === 'work' && step.zone <= 2);
}

export function parseIntervalText(input: string): ParsedIntervalText {
  const text = normalizeText(input ?? '');
  const warnings: string[] = [];
  const chunks = mergeRecoveries(splitTopLevel(text));
  const blocks: Block[] = [];

  chunks.forEach((chunk, index) => {
    const warningsBefore = warnings.length;
    const parsed = parseChunk(chunk, { index, count: chunks.length }, warnings);
    blocks.push(...parsed);

    // Say which phrase was dropped instead of silently losing it.
    if (!parsed.length && warnings.length === warningsBefore && chunk.trim()) {
      warnings.push(`Could not read "${chunk.trim()}" — add a duration like 8′ or a pace like 4:30/km.`);
    }
  });

  if (!blocks.length) {
    warnings.push('No duration found. Try something like "20\' warm-up, 4x8\' threshold, 10\' down".');
  }

  return summariseBlocks(blocks, warnings);
}

/** "4 × 8′ @ Z4 · 2′ easy · 10′ cool-down" */
export function describeBlocks(blocks: Block[]): string {
  const parts: string[] = [];
  let index = 0;

  while (index < blocks.length) {
    const current = blocks[index];
    if (current.kind !== 'work') {
      parts.push(`${trim(current.minutes)} ${label(current.kind)}`);
      index += 1;
      continue;
    }

    const recover = blocks[index + 1]?.kind === 'recover' ? blocks[index + 1] : null;
    const stride = recover ? 2 : 1;
    let reps = 1;
    let cursor = index;

    while (true) {
      const nextIndex = cursor + stride;
      const next = blocks[nextIndex];
      if (!next || next.kind !== 'work' || next.minutes !== current.minutes || next.zone !== current.zone) break;
      const nextRecover = blocks[nextIndex + 1];
      // The last rep of a set has nothing after it, so a missing recovery is fine.
      if (recover && nextRecover && nextRecover.kind === 'recover' && nextRecover.minutes !== recover.minutes) break;
      reps += 1;
      cursor = nextIndex;
    }

    parts.push(
      reps > 1
        ? `${reps} × ${trim(current.minutes)} @ Z${current.zone}`
        : `${trim(current.minutes)} @ Z${current.zone}`
    );
    if (recover) parts.push(`${trim(recover.minutes)} easy`);

    // Skip past the set, including the recovery after its final rep.
    index = blocks[cursor + 1]?.kind === 'recover' ? cursor + 2 : cursor + 1;
  }

  return parts.join(' · ');
}

function label(kind: BlockKind): string {
  if (kind === 'warmup') return 'warm-up';
  if (kind === 'cooldown') return 'cool-down';
  if (kind === 'recover') return 'easy';
  return 'work';
}

function trim(value: number): string {
  if (Number.isInteger(value)) return `${value}′`;
  const seconds = Math.round(value * 60);
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  if (!minutes) return `${rest}″`;
  return rest ? `${minutes}′${String(rest).padStart(2, '0')}″` : `${minutes}′`;
}

/** Only used by the API layer: is this block array usable as a session? */
export function isBlockList(value: unknown): value is Block[] {
  return (
    Array.isArray(value) &&
    value.length > 0 &&
    value.every(
      (item) =>
        Boolean(item) &&
        typeof item === 'object' &&
        BLOCK_KINDS.includes((item as Block).kind) &&
        Number.isFinite(Number((item as Block).minutes)) &&
        Number((item as Block).minutes) > 0
    )
  );
}
