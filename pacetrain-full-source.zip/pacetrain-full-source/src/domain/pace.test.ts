import { describe, expect, it } from 'vitest';
import { DEFAULT_PACE_SEC_PER_KM, formatPace, isDistanceMode, median, minutesForDistance, paceFor, paceTable } from './pace';
import type { Activity } from './types';

function activity(overrides: Partial<Activity> & { id: string; date: string }): Activity {
  return {
    externalId: overrides.id,
    mode: 'run',
    name: 'Run',
    durationSec: 1800,
    distanceM: 6000,
    avgHr: null,
    maxHr: null,
    load: null,
    source: 'intervals.icu',
    linkedSessionId: null,
    ...overrides
  };
}

const now = new Date(2026, 9, 24); // 24 Oct 2026

describe('median', () => {
  it('takes the middle value, averaging the pair for an even list', () => {
    expect(median([300, 320, 400])).toBe(320);
    expect(median([300, 320, 400, 420])).toBe(360);
    expect(median([])).toBeNull();
  });
});

describe('paceTable', () => {
  it('uses the median pace per discipline over the last 60 days', () => {
    const table = paceTable(
      [
        activity({ id: 'a', date: '2026-10-20', durationSec: 1800, distanceM: 6000 }), // 5:00/km
        activity({ id: 'b', date: '2026-10-22', durationSec: 1740, distanceM: 6000 }), // 4:50/km
        activity({ id: 'c', date: '2026-10-23', durationSec: 4200, distanceM: 6000 }), // 11:40 — an outlier
        activity({ id: 'd', date: '2026-10-21', mode: 'trail', durationSec: 2400, distanceM: 6000 }) // 6:40/km
      ],
      now
    );

    expect(table.run).toBe(300); // median of 300, 290, 700 — one slow run cannot move it
    expect(table.trail).toBe(400);
    expect(table.orienteering).toBe(DEFAULT_PACE_SEC_PER_KM.orienteering);
  });

  it('ignores old, short and non-running activities', () => {
    const table = paceTable(
      [
        activity({ id: 'old', date: '2026-06-01', durationSec: 1200, distanceM: 6000 }),
        activity({ id: 'short', date: '2026-10-20', durationSec: 240, distanceM: 800 }),
        activity({ id: 'bike', date: '2026-10-21', mode: 'bike', durationSec: 3600, distanceM: 30_000 })
      ],
      now
    );

    expect(table).toEqual(DEFAULT_PACE_SEC_PER_KM);
  });

  it('ignores impossible paces', () => {
    const table = paceTable([activity({ id: 'a', date: '2026-10-20', durationSec: 60, distanceM: 30_000 })], now);
    expect(table.run).toBe(DEFAULT_PACE_SEC_PER_KM.run);
  });
});

describe('minutesForDistance', () => {
  it('derives the minutes from the distance and pace', () => {
    expect(minutesForDistance(10, 'run')).toBe(55); // 10 × 5:30
    expect(minutesForDistance(12, 'trail')).toBe(80); // 12 × 6:40
    expect(minutesForDistance(15, 'run', { run: 240, trail: 300, orienteering: 420 })).toBe(60);
  });

  it('never returns less than five minutes', () => {
    expect(minutesForDistance(0.2, 'run')).toBe(5);
  });
});

describe('formatPace and isDistanceMode', () => {
  it('prints a pace per kilometre', () => {
    expect(formatPace(330)).toBe('5:30/km');
    expect(formatPace(400)).toBe('6:40/km');
    expect(formatPace(65)).toBe('1:05/km');
  });

  it('knows which disciplines are measured in kilometres', () => {
    expect(isDistanceMode('run')).toBe(true);
    expect(isDistanceMode('orienteering')).toBe(true);
    expect(isDistanceMode('ski')).toBe(false);
    expect(paceFor('ski')).toBe(DEFAULT_PACE_SEC_PER_KM.run);
  });
});
