import { describe, expect, it } from 'vitest';
import {
  addDays,
  addWeeks,
  dayLabel,
  fmtClock,
  fmtDuration,
  isWeekKey,
  mondayOfWeekKey,
  parseISODate,
  startOfWeek,
  toISODate,
  weekDays,
  weekKey,
  weekRangeLabel,
  weekdayLabel
} from './week';

describe('ISO date helpers', () => {
  it('round-trips an ISO date through local time', () => {
    const date = parseISODate('2026-10-23');
    expect(date.getFullYear()).toBe(2026);
    expect(date.getMonth()).toBe(9);
    expect(date.getDate()).toBe(23);
    expect(toISODate(date)).toBe('2026-10-23');
  });

  it('falls back to today for garbage input instead of throwing', () => {
    expect(toISODate(parseISODate('not-a-date'))).toBe(toISODate(new Date()));
  });

  it('adds days across a month boundary', () => {
    expect(toISODate(addDays(parseISODate('2026-10-31'), 1))).toBe('2026-11-01');
    expect(toISODate(addDays(parseISODate('2026-03-01'), -1))).toBe('2026-02-28');
  });

  it('starts weeks on Monday', () => {
    expect(toISODate(startOfWeek(parseISODate('2026-10-23')))).toBe('2026-10-19');
    expect(toISODate(startOfWeek(parseISODate('2026-10-19')))).toBe('2026-10-19');
    // Sunday belongs to the week that started six days earlier.
    expect(toISODate(startOfWeek(parseISODate('2026-10-25')))).toBe('2026-10-19');
  });

  it('labels the ISO week', () => {
    expect(weekKey(parseISODate('2026-10-23'))).toBe('2026-W43');
    expect(weekKey(parseISODate('2026-01-01'))).toBe('2026-W01');
    expect(weekKey(parseISODate('2027-01-01'))).toBe('2026-W53');
  });

  it('validates week keys', () => {
    expect(isWeekKey('2026-W43')).toBe(true);
    expect(isWeekKey('2026-43')).toBe(false);
    expect(isWeekKey(null)).toBe(false);
  });

  it('resolves a week key back to its Monday', () => {
    expect(toISODate(mondayOfWeekKey('2026-W43'))).toBe('2026-10-19');
    expect(toISODate(mondayOfWeekKey('2026-W01'))).toBe('2025-12-29');
    expect(toISODate(mondayOfWeekKey('bogus'))).toBe(toISODate(startOfWeek(new Date())));
  });

  it('moves whole weeks', () => {
    expect(toISODate(addWeeks(parseISODate('2026-10-19'), 2))).toBe('2026-11-02');
    expect(toISODate(addWeeks(parseISODate('2026-10-19'), -1))).toBe('2026-10-12');
  });

  it('returns seven consecutive days', () => {
    const days = weekDays(parseISODate('2026-10-19')).map(toISODate);
    expect(days).toHaveLength(7);
    expect(days[0]).toBe('2026-10-19');
    expect(days[6]).toBe('2026-10-25');
  });

  it('formats labels', () => {
    const friday = parseISODate('2026-10-23');
    expect(weekdayLabel(friday)).toBe('Fri');
    expect(dayLabel(friday)).toBe('Fri 23');
    expect(weekRangeLabel(parseISODate('2026-10-19'))).toBe('19–25 Oct 2026');
    expect(weekRangeLabel(parseISODate('2026-10-26'))).toBe('26 Oct – 1 Nov 2026');
  });

  it('formats durations and clocks', () => {
    expect(fmtDuration(0)).toBe('0m');
    expect(fmtDuration(45)).toBe('45m');
    expect(fmtDuration(65)).toBe('1h 05m');
    expect(fmtDuration(120)).toBe('2h 00m');
    expect(fmtClock(45)).toBe('0:45');
    expect(fmtClock(3725)).toBe('1:02:05');
  });
});
