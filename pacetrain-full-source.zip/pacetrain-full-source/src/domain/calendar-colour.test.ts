import { describe, expect, it } from 'vitest';
import { colorForRatio, dayColour, mixHex, SCALE } from './calendar-colour';

/** Reads a hex colour back as [r, g, b], for the blend assertions. */
function rgb(hex: string): [number, number, number] {
  const value = hex.replace('#', '');
  return [0, 2, 4].map((index) => parseInt(value.slice(index, index + 2), 16)) as [number, number, number];
}

describe('mixHex', () => {
  it('returns the ends exactly', () => {
    expect(mixHex('#000000', '#ffffff', 0)).toBe('#000000');
    expect(mixHex('#000000', '#ffffff', 1)).toBe('#ffffff');
  });

  it('meets in the middle', () => {
    expect(mixHex('#000000', '#ffffff', 0.5)).toBe('#808080');
  });

  it('clamps outside the range', () => {
    expect(mixHex('#000000', '#ffffff', -2)).toBe('#000000');
    expect(mixHex('#000000', '#ffffff', 5)).toBe('#ffffff');
  });
});

describe('colorForRatio', () => {
  it('is pure red when nothing was done', () => {
    expect(colorForRatio(0).color).toBe(SCALE.skip);
    expect(colorForRatio(0).verdict).toBe('skipped');
  });

  it('is pure yellow at exactly half the plan', () => {
    expect(colorForRatio(0.5).color).toBe(SCALE.half);
  });

  it('is pure green at exactly the plan', () => {
    expect(colorForRatio(1).color).toBe(SCALE.plan);
    expect(colorForRatio(1).verdict).toBe('on-plan');
  });

  it('is as blue as it gets at twice the plan, and no bluer beyond', () => {
    expect(colorForRatio(2).color).toBe(SCALE.double);
    expect(colorForRatio(5).color).toBe(SCALE.double);
    expect(colorForRatio(2).verdict).toBe('over');
  });

  it('blends red towards yellow between nothing and half the plan', () => {
    // A quarter of the plan sits between the skip threshold and the half stop.
    const [r, g, b] = rgb(colorForRatio(0.3).color);
    // Between red (179, 57, 46) and yellow (216, 163, 37): more red than blue,
    // and greener than pure red.
    expect(r).toBeGreaterThan(179);
    expect(g).toBeGreaterThan(57);
    expect(g).toBeLessThan(163);
    expect(b).toBeLessThan(46);
  });

  it('blends yellow towards green between half and the whole plan', () => {
    const [r, g, b] = rgb(colorForRatio(0.75).color);
    // Between yellow (216, 163, 37) and green (21, 122, 85).
    expect(r).toBeLessThan(216);
    expect(r).toBeGreaterThan(21);
    expect(g).toBeLessThan(163);
    expect(g).toBeGreaterThan(122);
  });

  it('blends green towards blue above the plan', () => {
    const [r, , b] = rgb(colorForRatio(1.5).color);
    // Between green (21, 122, 85) and blue (31, 95, 208): less red, more blue.
    expect(r).toBeLessThanOrEqual(31);
    expect(b).toBeGreaterThan(85);
  });

  it('treats a damaged ratio as nothing done', () => {
    expect(colorForRatio(Number.NaN).verdict).toBe('skipped');
    expect(colorForRatio(Number.POSITIVE_INFINITY).color).toBe(SCALE.double);
  });
});

describe('dayColour', () => {
  it('leaves a day with no plan alone', () => {
    const colour = dayColour({ minutes: 60, plannedMinutes: 0 });
    expect(colour.verdict).toBe('unplanned');
    expect(colour.ratio).toBeNull();
    expect(colour.color).toBe('');
  });

  it('leaves a rest day with no plan alone too', () => {
    expect(dayColour({ minutes: 0, plannedMinutes: 0 }).verdict).toBe('unplanned');
  });

  it('calls an ended day with nothing done skipped', () => {
    const colour = dayColour({ minutes: 0, plannedMinutes: 60, ended: true });
    expect(colour.verdict).toBe('skipped');
    expect(colour.color).toBe(SCALE.skip);
    expect(colour.label).toBe('skipped');
  });

  it('calls an explicitly skipped session skipped', () => {
    const colour = dayColour({ minutes: 0, plannedMinutes: 60, skipped: 1, ended: true });
    expect(colour.verdict).toBe('skipped');
  });

  it('leaves a day that has not ended unjudged, so no red before its time', () => {
    // A planned session later today: nothing done yet, but the day is not over.
    const colour = dayColour({ minutes: 0, plannedMinutes: 60, ended: false });
    expect(colour.verdict).toBe('pending');
    expect(colour.ratio).toBeNull();
    expect(colour.color).toBe('');
    expect(colour.label).toBe('still to come');
  });

  it('still turns red before the day ends when the athlete marked it skipped', () => {
    const colour = dayColour({ minutes: 0, plannedMinutes: 60, skipped: 1, ended: false });
    expect(colour.verdict).toBe('skipped');
    expect(colour.color).toBe(SCALE.skip);
  });

  it('judges an open day once some training is in', () => {
    const colour = dayColour({ minutes: 30, plannedMinutes: 60, ended: false });
    expect(colour.verdict).toBe('short');
    expect(colour.ratio).toBe(0.5);
  });

  it('measures the rest against the plan', () => {
    const half = dayColour({ minutes: 30, plannedMinutes: 60, ended: true });
    expect(half.ratio).toBe(0.5);
    expect(half.color).toBe(SCALE.half);
    expect(half.label).toBe('50% of the plan');
  });

  it('calls a full session on plan', () => {
    const full = dayColour({ minutes: 60, plannedMinutes: 60, ended: true });
    expect(full.verdict).toBe('on-plan');
    expect(full.label).toBe('plan followed');
  });

  it('counts anything well over the plan as over', () => {
    expect(dayColour({ minutes: 150, plannedMinutes: 60, ended: true }).verdict).toBe('over');
    expect(dayColour({ minutes: 150, plannedMinutes: 60, ended: true }).label).toBe('250% of the plan');
  });

  it('keeps the ratio exact for the tooltip', () => {
    expect(dayColour({ minutes: 45, plannedMinutes: 60, ended: true }).ratio).toBe(0.75);
  });
});
