import { describe, expect, it } from 'vitest';
import { eventCountdown, nextEvent, sortEvents, type RaceEvent } from './events';

const TODAY = new Date(2026, 9, 24); // Fri 24 Oct 2026

function race(overrides: Partial<RaceEvent> = {}): RaceEvent {
  return {
    id: 'e1',
    name: 'Autumn half',
    date: '2026-10-24',
    mode: 'run',
    priority: 'A',
    distanceKm: 21.1,
    targetTimeSec: 5400,
    notes: '',
    ...overrides
  };
}

describe('eventCountdown', () => {
  it('counts the days and names race day', () => {
    expect(eventCountdown({ date: '2026-10-24', priority: 'A' }, TODAY).label).toBe('Today');
    expect(eventCountdown({ date: '2026-10-25', priority: 'A' }, TODAY).label).toBe('Tomorrow');
    expect(eventCountdown({ date: '2026-11-21', priority: 'A' }, TODAY).label).toBe('4 weeks to go');
    expect(eventCountdown({ date: '2026-11-21', priority: 'A' }, TODAY).days).toBe(28);
  });

  it('moves through base, build, peak and taper', () => {
    expect(eventCountdown({ date: '2027-03-01', priority: 'A' }, TODAY).phase).toBe('base');
    expect(eventCountdown({ date: '2026-12-20', priority: 'A' }, TODAY).phase).toBe('build');
    expect(eventCountdown({ date: '2026-11-15', priority: 'A' }, TODAY).phase).toBe('peak');
    expect(eventCountdown({ date: '2026-11-02', priority: 'A' }, TODAY).phase).toBe('taper');
  });

  it('tapers a shorter time for a smaller race', () => {
    // Three weeks out: still peak for an A race, already tapering for a B race.
    expect(eventCountdown({ date: '2026-11-14', priority: 'A' }, TODAY).phase).toBe('peak');
    expect(eventCountdown({ date: '2026-10-31', priority: 'B' }, TODAY).phase).toBe('taper');
    expect(eventCountdown({ date: '2026-10-31', priority: 'C' }, TODAY).phase).toBe('peak');
  });

  it('closes out a race that has happened', () => {
    const past = eventCountdown({ date: '2026-10-10', priority: 'A' }, TODAY);
    expect(past.phase).toBe('done');
    expect(past.label).toBe('14 days ago');
    expect(past.days).toBe(-14);
  });
});

describe('nextEvent', () => {
  it('picks the soonest race that has not happened yet', () => {
    const events = [
      race({ id: 'past', date: '2026-09-01' }),
      race({ id: 'next', date: '2026-11-01' }),
      race({ id: 'later', date: '2027-04-01' })
    ];

    expect(nextEvent(events, TODAY)?.id).toBe('next');
    expect(nextEvent([race({ id: 'past', date: '2026-09-01' })], TODAY)).toBeNull();
  });
});

describe('sortEvents', () => {
  it('puts upcoming races first, then the recent past', () => {
    const sorted = sortEvents(
      [
        race({ id: 'later', date: '2027-04-01' }),
        race({ id: 'old', date: '2026-08-01' }),
        race({ id: 'next', date: '2026-11-01' }),
        race({ id: 'recent', date: '2026-10-01' })
      ],
      TODAY
    );

    expect(sorted.map((event) => event.id)).toEqual(['next', 'later', 'recent', 'old']);
  });
});
