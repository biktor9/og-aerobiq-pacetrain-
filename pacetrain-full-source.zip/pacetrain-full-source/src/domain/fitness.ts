import { sessionLoad } from './load';
import type { Activity, Session } from './types';
import { addDays, toISODate } from './week';

/**
 * Fitness, fatigue and form — the Performance Management Chart that
 * intervals.icu is built around, in three numbers.
 *
 * Fitness (CTL) is a 42-day average of daily load, fatigue (ATL) a 7-day
 * average, and form (TSB) is the difference: how much freshness is left.
 * Load comes from the activity when intervals.icu measured it, otherwise from
 * duration adjusted by heart rate. Everything is deterministic and pure.
 */

export interface FitnessPoint {
  date: string;
  /** Load scored on the day. */
  load: number;
  /** Chronic training load: slow-moving fitness. */
  ctl: number;
  /** Acute training load: what the body is currently handling. */
  atl: number;
  /** Form: positive means fresh, negative means carrying fatigue. */
  tsb: number;
  /** Future day: the load comes from the plan, not from an activity. */
  projected: boolean;
}

export interface FormZone {
  label: string;
  tone: 'good' | 'ok' | 'warn' | 'bad';
  advice: string;
}

export interface FitnessSummary {
  /** The most recent day that has happened. */
  today: FitnessPoint;
  form: FormZone;
  /** Change in fitness over the last seven days, in percent. */
  rampPct: number;
  /** Load actually completed in the last seven days. */
  weekLoad: number;
  /** Load planned for the next seven days. */
  plannedLoad: number;
}

const CTL_DAYS = 42;
const ATL_DAYS = 7;
/**
 * The averages are seeded by computing 12 weeks before the visible window, so
 * the first point on the chart is a real number instead of a line crawling up
 * from zero.
 */
const WARMUP_DAYS = 84;

function round1(value: number): number {
  return Math.round(value * 10) / 10;
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

/**
 * The load of one activity. intervals.icu supplies a TSS-like number on
 * import; without it, minutes scaled by heart rate give a close enough score
 * for the shape of a fitness curve.
 */
export function estimatedLoad(activity: Activity): number {
  if (typeof activity.load === 'number' && Number.isFinite(activity.load) && activity.load > 0) {
    return Math.round(activity.load);
  }
  const minutes = activity.durationSec > 0 ? activity.durationSec / 60 : 0;
  if (!minutes) return 0;
  const factor = activity.avgHr ? clamp((activity.avgHr - 75) / 100, 0.35, 1.15) : 0.7;
  return Math.round(minutes * factor);
}

/** Where a given form sits, in words an athlete can act on. */
export function formZone(tsb: number): FormZone {
  if (tsb >= 20) {
    return {
      label: 'Very fresh',
      tone: 'ok',
      advice: 'Fresh enough to race — but fitness is starting to slip, so use it or lose it.'
    };
  }
  if (tsb >= 5) {
    return { label: 'Fresh', tone: 'good', advice: 'Race-ready: sharp, rested, and still fit. This is the taper working.' };
  }
  if (tsb >= -10) {
    return { label: 'Neutral', tone: 'good', advice: 'Balanced. The normal place to sit while training steadily.' };
  }
  if (tsb >= -30) {
    return { label: 'Productive', tone: 'ok', advice: 'Fitness is ahead of recovery. Normal in a build block — keep easy days easy.' };
  }
  return { label: 'Overreaching', tone: 'bad', advice: 'Too much fatigue. Back off before it turns into an injury or a cold.' };
}

/**
 * One point per day, oldest first, ending a little beyond today so the plan's
 * effect on form is visible.
 */
export function fitnessSeries({
  activities,
  sessions = [],
  days = 90,
  projectedDays = 14,
  today = new Date()
}: {
  activities: Activity[];
  sessions?: Session[];
  days?: number;
  projectedDays?: number;
  today?: Date;
}): FitnessPoint[] {
  const todayISO = toISODate(today);
  const start = addDays(today, -(Math.max(7, days) - 1));
  const end = addDays(today, Math.max(0, projectedDays));

  const actual = new Map<string, number>();
  for (const activity of activities) {
    if (activity.date > todayISO) continue;
    actual.set(activity.date, (actual.get(activity.date) ?? 0) + estimatedLoad(activity));
  }

  const planned = new Map<string, number>();
  for (const session of sessions) {
    if (session.date <= todayISO) continue;
    planned.set(session.date, (planned.get(session.date) ?? 0) + sessionLoad(session));
  }

  let ctl = 0;
  let atl = 0;
  const points: FitnessPoint[] = [];
  const burnIn = addDays(start, -WARMUP_DAYS);

  for (let date = burnIn; toISODate(date) <= toISODate(end); date = addDays(date, 1)) {
    const iso = toISODate(date);
    const projected = iso > todayISO;
    const load = projected ? (planned.get(iso) ?? 0) : (actual.get(iso) ?? 0);

    ctl += (load - ctl) / CTL_DAYS;
    atl += (load - atl) / ATL_DAYS;

    if (date < start) continue;
    points.push({ date: iso, load: Math.round(load), ctl: round1(ctl), atl: round1(atl), tsb: round1(ctl - atl), projected });
  }

  return points;
}

/** Reads the headline numbers off a series produced by `fitnessSeries`. */
export function fitnessSummary(series: FitnessPoint[]): FitnessSummary | null {
  if (!series.length) return null;

  let index = series.length - 1;
  while (index > 0 && series[index].projected) index -= 1;

  const today = series[index];
  const weekAgo = series[Math.max(0, index - 7)];
  const weekLoad = series.slice(Math.max(0, index - 6), index + 1).reduce((sum, point) => sum + point.load, 0);
  const plannedLoad = series
    .slice(index + 1, index + 8)
    .filter((point) => point.projected)
    .reduce((sum, point) => sum + point.load, 0);

  return {
    today,
    form: formZone(today.tsb),
    rampPct: weekAgo.ctl > 0 ? Math.round(((today.ctl - weekAgo.ctl) / weekAgo.ctl) * 100) : 0,
    weekLoad,
    plannedLoad
  };
}
