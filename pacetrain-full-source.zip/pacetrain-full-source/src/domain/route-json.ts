import { isLatLng, roundRoute, simplifyRoute, type LatLng } from './geo';

/**
 * How a GPS trace is kept between two page loads: thinned, rounded and stored as
 * JSON in the activity row. `null` means "not read yet", `'[]'` means "read, and
 * this activity had no GPS", so nothing is asked for twice.
 */

/** Points kept per activity: street-level enough, and a couple of kB in the row. */
export const ROUTE_POINTS = 150;

export function parseRoute(json: string | null | undefined): LatLng[] {
  if (!json) return [];
  try {
    const parsed: unknown = JSON.parse(json);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((point) => isLatLng(point)) as LatLng[];
  } catch {
    return [];
  }
}

export function serialiseRoute(points: LatLng[]): string {
  return JSON.stringify(roundRoute(simplifyRoute(points, ROUTE_POINTS)));
}
