import { describe, expect, it } from 'vitest';
import { compareToIntent } from './compare';
import type { Block, DetectionResult } from './types';

const intent: Block[] = [
  { kind: 'warmup', minutes: 20, zone: 1 },
  { kind: 'work', minutes: 8, zone: 4 },
  { kind: 'recover', minutes: 2, zone: 1 },
  { kind: 'work', minutes: 8, zone: 4 },
  { kind: 'cooldown', minutes: 10, zone: 1 }
];

function detection(overrides: Partial<DetectionResult> = {}): DetectionResult {
  return {
    metric: 'power',
    metricLabel: 'Power',
    unit: 'W',
    threshold: 250,
    reps: 2,
    segments: [],
    work: [],
    recover: [],
    durationSec: 2900,
    workTimeSec: 956,
    recoverTimeSec: 122,
    avgWorkSec: 478,
    avgRecoverSec: 122,
    consistency: 2,
    driftPct: -1,
    ...overrides
  };
}

describe('compareToIntent', () => {
  it('has nothing to compare against without work blocks', () => {
    expect(compareToIntent(detection(), null)).toBeNull();
    expect(compareToIntent(detection(), [{ kind: 'warmup', minutes: 20, zone: 1 }])).toBeNull();
  });

  it('lines the planned blocks up against the detected ones', () => {
    const comparison = compareToIntent(detection(), intent);
    expect(comparison).not.toBeNull();
    if (!comparison) return;

    expect(comparison.expectedReps).toBe(2);
    expect(comparison.actualReps).toBe(2);
    expect(comparison.onTarget).toBe(true);
    expect(comparison.rows.map((row) => row.label)).toEqual([
      'Reps',
      'Work per rep',
      'Recovery',
      'Work time',
      'Total time'
    ]);
    expect(comparison.rows[0]).toEqual({ label: 'Reps', target: '2', actual: '2', delta: 'on target' });
    expect(comparison.rows[1]).toMatchObject({ target: '8:00', actual: '7:58', delta: '−0:02' });
    expect(comparison.rows[2]).toMatchObject({ target: '2:00', actual: '2:02', delta: '+0:02' });
    expect(comparison.rows[4]).toMatchObject({ target: '48:00', actual: '48:20', delta: '+0:20' });
    expect(comparison.verdict).toContain('2 of 2 reps');
    expect(comparison.verdict).toContain('recovery');
  });

  it('calls out a rep that never happened', () => {
    const comparison = compareToIntent(detection({ reps: 1, workTimeSec: 478, durationSec: 1500 }), intent);
    expect(comparison?.onTarget).toBe(false);
    expect(comparison?.rows[0]).toEqual({ label: 'Reps', target: '2', actual: '1', delta: '−1' });
    expect(comparison?.verdict.startsWith('1 of 2 reps')).toBe(true);
  });

  it('leaves the recovery row out when the plan has none', () => {
    const comparison = compareToIntent(
      detection({ avgRecoverSec: 0, reps: 1, workTimeSec: 480 }),
      [{ kind: 'work', minutes: 8, zone: 4 }]
    );
    expect(comparison?.rows.map((row) => row.label)).toEqual(['Reps', 'Work per rep', 'Work time', 'Total time']);
    expect(comparison?.verdict).not.toContain('recovery');
  });

  it('is deterministic', () => {
    expect(compareToIntent(detection(), intent)).toEqual(compareToIntent(detection(), intent));
  });
});
