/**
 * The note an admin can pin to the top of a tab.
 *
 * Every tab that is part of the app carries one BETA banner, and underneath it
 * an admin can write whatever the people using the site should know that week.
 * The note belongs to the tab, not to the person reading it: one box, written
 * once, seen by everyone. Which tabs have a box is decided here rather than by
 * each page, so a page can never be missed by accident.
 */

/** The tabs that carry a banner and a note. Order is the order of the nav. */
export type PageKey =
  | 'plan'
  | 'recovery'
  | 'progress'
  | 'activities'
  | 'analysis'
  | 'coach'
  | 'settings'
  | 'admin';

export interface PageInfo {
  key: PageKey;
  /** The path the tab lives at, which is also how the note is stored. */
  path: string;
  label: string;
}

export const PAGES: PageInfo[] = [
  { key: 'plan', path: '/plan', label: 'Plan' },
  { key: 'recovery', path: '/recovery', label: 'Recovery' },
  { key: 'progress', path: '/progress', label: 'Progress' },
  { key: 'activities', path: '/activities', label: 'Activities' },
  { key: 'analysis', path: '/analysis', label: 'Analysis' },
  { key: 'coach', path: '/coach', label: 'Coach' },
  { key: 'settings', path: '/settings', label: 'Settings' },
  { key: 'admin', path: '/admin', label: 'Admin' }
];

/** What the banner says. Kept here so every tab says exactly the same thing. */
export const BETA_LABEL = 'Beta';
export const BETA_TEXT = 'This is a beta version of PaceTrain. Some things will change and some may break.';

/** Longest note we store, in characters. */
export const NOTE_MAX_LENGTH = 2000;

export const PAGE_KEYS: PageKey[] = PAGES.map((page) => page.key);

export function isPageKey(value: unknown): value is PageKey {
  return typeof value === 'string' && (PAGE_KEYS as string[]).includes(value);
}

export function pageInfo(key: PageKey): PageInfo {
  const info = PAGES.find((page) => page.key === key);
  if (!info) throw new Error(`Unknown page: ${key}`);
  return info;
}

/**
 * The path a key is stored under. `/activities/42` is the Activities tab, so
 * the detail page carries the tab's note rather than none.
 */
export function pageKeyForPath(pathname: string): PageKey | null {
  const clean = pathname.split('?')[0].split('#')[0];
  const match = PAGES.find((page) => clean === page.path || clean.startsWith(`${page.path}/`));
  return match ? match.key : null;
}

/**
 * Tidies what was typed: line endings normalised, trailing spaces dropped from
 * each line and blank lines trimmed from either end. A note made entirely of
 * blank lines is empty, which is how a note is removed.
 */
export function normalizeNote(text: string): string {
  const lines = text.replace(/\r\n?/g, '\n').split('\n').map((line) => line.replace(/[ \t]+$/, ''));
  return lines.join('\n').trim();
}

export function isBlankNote(text: string): boolean {
  return normalizeNote(text).length === 0;
}

/** Whether a public viewer is shown the note at all. */
export function showNote(text: string | null | undefined): boolean {
  return !!text && !isBlankNote(text);
}
