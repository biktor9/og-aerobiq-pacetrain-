import { describe, expect, it } from 'vitest';
import { ramp, sessionLoad, weekStats, zoneDistribution } from './load';
import { toSession } from './plan';
import type { SessionInput } from './types';

function make(overrides: Partial<SessionInput> & { id: string; date: string }): ReturnType<typeof toSession> {
  const base: SessionInput = {
    date: overrides.date,
    mode: 'run',
    kind: 'steady',
    title: '',
    zone: 2,
    minutes: 60,
    reps: 4,
    workMin: 8,
    recoverMin: 2,
    warmupMin: 15,
    cooldownMin: 10,
    notes: '',
    status: 'planned'
  };
  return toSession({ ...base, ...overrides, linkedActivityId: null, id: overrides.id });
}

describe('sessionLoad', () => {
  it('is minutes × zone factor', () => {
    expect(sessionLoad({ ...make({ id: 'a', date: '2026-10-19' }), minutes: 60, zone: 2 })).toBe(41);
    expect(sessionLoad({ ...make({ id: 'a', date: '2026-10-19' }), minutes: 60, zone: 1 })).toBe(33);
  });

  it('counts every block of an interval session', () => {
    const session = make({ id: 'b', date: '2026-10-20', kind: 'intervals', zone: 4 });
    // 15' Z1 + 4×8' Z4 + 3×2' Z1 + 10' Z1 = 46.49 → 46
    expect(sessionLoad(session)).toBe(46);
  });

  it('discounts strength work slightly', () => {
    const strength = make({ id: 'c', date: '2026-10-21', mode: 'strength', kind: 'strength', minutes: 60, zone: 2 });
    expect(sessionLoad(strength)).toBe(33);
  });
});

describe('weekStats', () => {
  const week = [
    make({ id: '1', date: '2026-10-19', minutes: 45, zone: 1 }),
    make({ id: '2', date: '2026-10-20', kind: 'intervals', zone: 4, title: 'Threshold' }),
    make({ id: '3', date: '2026-10-22', minutes: 90, zone: 2, status: 'done' }),
    make({ id: '4', date: '2026-10-22', mode: 'strength', kind: 'strength', minutes: 40, zone: 3 }),
    make({ id: '5', date: '2026-10-24', minutes: 30, zone: 1, status: 'skipped' })
  ];

  it('aggregates volume, load, hard days and completion', () => {
    const stats = weekStats(week);
    expect(stats.count).toBe(5);
    expect(stats.minutes).toBe(45 + 63 + 90 + 40 + 30);
    expect(stats.hardCount).toBe(1);
    expect(stats.doneCount).toBe(1);
    expect(stats.skippedCount).toBe(1);
    expect(stats.longestMin).toBe(90);
  });

  it('splits volume by mode and by day', () => {
    const stats = weekStats(week);
    expect(stats.byMode.run.count).toBe(4);
    expect(stats.byMode.strength.count).toBe(1);
    expect(stats.byMode.trail).toEqual({ count: 0, minutes: 0, load: 0, km: 0 });
    expect(stats.byDay['2026-10-22']).toMatchObject({ count: 2, minutes: 130 });
  });

  it('totals running kilometres and leaves the other disciplines out', () => {
    const stats = weekStats([
      make({ id: 'r', date: '2026-10-19', minutes: 50, targetKm: 10 }),
      make({ id: 't', date: '2026-10-20', mode: 'trail', minutes: 90, targetKm: 16 }),
      make({ id: 'o', date: '2026-10-21', mode: 'orienteering', minutes: 40, targetKm: 5 }),
      make({ id: 'b', date: '2026-10-22', mode: 'bike', minutes: 60, targetKm: 30 })
    ]);

    // run + trail + orienteering, not the bike ride.
    expect(stats.runningKm).toBe(31);
    expect(stats.byMode.trail.km).toBe(16);
    expect(stats.byMode.bike.km).toBe(30);
  });

  it('ignores a session without a distance target', () => {
    expect(weekStats([make({ id: 'a', date: '2026-10-19', minutes: 45 })]).runningKm).toBe(0);
  });

  it('handles an empty week', () => {
    const stats = weekStats([]);
    expect(stats).toMatchObject({ count: 0, minutes: 0, load: 0, hardCount: 0, longestMin: 0 });
  });

  it('counts interval time in the zone distribution', () => {
    const dist = zoneDistribution(week);
    expect(dist[4]).toBe(32); // 4 × 8' of threshold work
    expect(dist[2]).toBe(90); // the long easy run
    expect(dist[1]).toBe(45 + 31 + 30); // easy run + warm-up/recovery/cool-down + skipped easy
  });
});

describe('ramp', () => {
  it('reports the first week without a comparison', () => {
    expect(ramp(300, 0)).toMatchObject({ pct: null, tone: 'new' });
  });

  it('treats small changes as flat', () => {
    expect(ramp(302, 300)).toMatchObject({ pct: 1, tone: 'flat' });
  });

  it('flags big jumps up and down', () => {
    expect(ramp(360, 300)).toMatchObject({ pct: 20, tone: 'up', label: '+20% vs last week' });
    expect(ramp(210, 300)).toMatchObject({ pct: -30, tone: 'down', label: '-30% vs last week' });
  });
});
