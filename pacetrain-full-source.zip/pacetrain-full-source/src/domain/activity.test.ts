import { describe, expect, it } from 'vitest';
import {
  ACTIVITY_RANGES,
  activityRangeBounds,
  activitiesByDate,
  activityTotals,
  isActivityRangeId,
  isRunningMode,
  runningTotals
} from './activity';
import type { Activity } from './types';

function activity(overrides: Partial<Activity> & { id: string; date: string }): Activity {
  return {
    externalId: overrides.id,
    mode: 'run',
    name: 'Run',
    durationSec: 3600,
    distanceM: 10_000,
    avgHr: null,
    maxHr: null,
    load: null,
    source: 'intervals.icu',
    linkedSessionId: null,
    ...overrides
  };
}

describe('isRunningMode', () => {
  it('counts run, trail and orienteering', () => {
    expect(isRunningMode('run')).toBe(true);
    expect(isRunningMode('trail')).toBe(true);
    expect(isRunningMode('orienteering')).toBe(true);
    expect(isRunningMode('bike')).toBe(false);
    expect(isRunningMode('strength')).toBe(false);
  });
});

describe('activityTotals', () => {
  it('adds distance, time and a per-mode split', () => {
    const totals = activityTotals([
      activity({ id: 'a', date: '2026-10-20', durationSec: 3600, distanceM: 10_000 }),
      activity({ id: 'b', date: '2026-10-21', mode: 'ski', durationSec: 5400, distanceM: 18_000 }),
      activity({ id: 'c', date: '2026-10-22', durationSec: 1800, distanceM: 5000 })
    ]);

    expect(totals.count).toBe(3);
    expect(totals.km).toBe(33);
    expect(totals.minutes).toBe(180);
    expect(totals.longestKm).toBe(18);
    expect(totals.byMode.run).toEqual({ count: 2, km: 15, minutes: 90 });
    expect(totals.byMode.ski).toEqual({ count: 1, km: 18, minutes: 90 });
  });

  it('copes with an empty list and a missing distance', () => {
    expect(activityTotals([])).toEqual({ count: 0, km: 0, minutes: 0, longestKm: 0, byMode: {} });
    expect(activityTotals([activity({ id: 'a', date: '2026-10-20', distanceM: 0 })])).toMatchObject({
      km: 0,
      count: 1
    });
  });
});

describe('runningTotals', () => {
  it('averages pace over the running modes only', () => {
    const totals = runningTotals([
      activity({ id: 'a', date: '2026-10-20', durationSec: 1800, distanceM: 6000 }), // 5:00/km
      activity({ id: 'b', date: '2026-10-21', mode: 'trail', durationSec: 2400, distanceM: 6000 }), // 6:40/km
      activity({ id: 'c', date: '2026-10-22', mode: 'bike', durationSec: 3600, distanceM: 30_000 })
    ]);

    expect(totals.count).toBe(2);
    expect(totals.km).toBe(12);
    expect(totals.avgPaceSecPerKm).toBe(350); // 4200s over 12 km
  });

  it('has no pace when only unmeasured activities are left', () => {
    const totals = runningTotals([activity({ id: 'a', date: '2026-10-20', distanceM: 400 })]);
    expect(totals.avgPaceSecPerKm).toBeNull();
    expect(totals.count).toBe(1);
  });
});

describe('activitiesByDate', () => {
  it('groups by day, longest first', () => {
    const byDate = activitiesByDate([
      activity({ id: 'short', date: '2026-10-20', durationSec: 1800 }),
      activity({ id: 'long', date: '2026-10-20', durationSec: 5400 }),
      activity({ id: 'other', date: '2026-10-21' })
    ]);

    expect(Object.keys(byDate)).toEqual(['2026-10-20', '2026-10-21']);
    expect(byDate['2026-10-20'].map((item) => item.id)).toEqual(['long', 'short']);
  });
});

describe('activity ranges', () => {
  const TODAY = new Date(2026, 9, 24); // Sat 24 Oct 2026

  function spanDays(from: string, to: string): number {
    const start = new Date(`${from}T00:00:00Z`).getTime();
    const end = new Date(`${to}T00:00:00Z`).getTime();
    return Math.round((end - start) / 86_400_000);
  }

  it('offers calendar and rolling windows side by side', () => {
    expect(ACTIVITY_RANGES.map((range) => range.id)).toEqual(['week', 'month', '30d', '90d', '365d', 'year']);
    expect(isActivityRangeId('year')).toBe(true);
    expect(isActivityRangeId('7d')).toBe(false);
  });

  it('starts the week on Monday and ends today', () => {
    const bounds = activityRangeBounds('week', TODAY);
    expect(bounds).toMatchObject({ id: 'week', from: '2026-10-19', to: '2026-10-24', label: 'This week' });
    expect(spanDays(bounds.from, bounds.to)).toBe(5);
  });

  it('starts the month and the year on their first day', () => {
    const month = activityRangeBounds('month', TODAY);
    const year = activityRangeBounds('year', TODAY);
    expect(month.from).toBe('2026-10-01');
    expect(month.to).toBe('2026-10-24');
    expect(year.from).toBe('2026-01-01');
    expect(year.label).toBe('This year');
  });

  it('counts rolling windows back from today, today included', () => {
    expect(spanDays(activityRangeBounds('30d', TODAY).from, activityRangeBounds('30d', TODAY).to)).toBe(29);
    expect(spanDays(activityRangeBounds('90d', TODAY).from, activityRangeBounds('90d', TODAY).to)).toBe(89);
    expect(spanDays(activityRangeBounds('365d', TODAY).from, activityRangeBounds('365d', TODAY).to)).toBe(364);
  });

  it('falls back to the last 30 days for anything unknown', () => {
    expect(activityRangeBounds('nonsense', TODAY)).toMatchObject({ id: '30d', from: '2026-09-25', to: '2026-10-24' });
    expect(activityRangeBounds(null, TODAY).id).toBe('30d');
  });

  it('handles a Monday as the whole week so far', () => {
    const monday = new Date(2026, 9, 19);
    const bounds = activityRangeBounds('week', monday);
    expect(bounds.from).toBe(bounds.to);
  });
});

