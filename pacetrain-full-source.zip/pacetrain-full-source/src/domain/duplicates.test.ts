import { describe, expect, it } from 'vitest';
import { duplicateGroups, duplicatesById } from './duplicates';
import type { Activity } from './types';

function activity(overrides: Partial<Activity> & { id: string; date: string }): Activity {
  return {
    externalId: overrides.id,
    mode: 'run',
    name: 'Run',
    durationSec: 3600,
    distanceM: 10_000,
    avgHr: 145,
    maxHr: 170,
    load: 70,
    source: 'intervals.icu',
    linkedSessionId: null,
    ...overrides
  };
}

describe('duplicateGroups', () => {
  it('flags the same run imported twice', () => {
    const groups = duplicateGroups([
      activity({ id: 'a', date: '2026-10-20', durationSec: 3600, distanceM: 10_000 }),
      activity({ id: 'b', date: '2026-10-20', durationSec: 3610, distanceM: 10_050 })
    ]);

    expect(groups).toHaveLength(1);
    expect(groups[0].map((item) => item.id).sort()).toEqual(['a', 'b']);
  });

  it('keeps a double day apart', () => {
    const groups = duplicateGroups([
      activity({ id: 'am', date: '2026-10-20', durationSec: 3600, distanceM: 10_000 }),
      activity({ id: 'pm', date: '2026-10-20', durationSec: 2400, distanceM: 6000 })
    ]);

    expect(groups).toEqual([]);
  });

  it('ignores a different day or a different sport', () => {
    expect(
      duplicateGroups([
        activity({ id: 'a', date: '2026-10-20' }),
        activity({ id: 'b', date: '2026-10-21' })
      ])
    ).toEqual([]);

    expect(
      duplicateGroups([
        activity({ id: 'a', date: '2026-10-20' }),
        activity({ id: 'b', date: '2026-10-20', mode: 'bike' })
      ])
    ).toEqual([]);
  });

  it('still matches when only one of the two has a distance', () => {
    const groups = duplicateGroups([
      activity({ id: 'a', date: '2026-10-20', distanceM: 0 }),
      activity({ id: 'b', date: '2026-10-20', distanceM: 10_000 })
    ]);
    expect(groups).toHaveLength(1);
  });

  it('maps each activity to its look-alikes', () => {
    const map = duplicatesById([
      activity({ id: 'a', date: '2026-10-20' }),
      activity({ id: 'b', date: '2026-10-20', durationSec: 3550 }),
      activity({ id: 'c', date: '2026-10-18' })
    ]);

    expect(map.get('a')?.map((item) => item.id)).toEqual(['b']);
    expect(map.get('b')?.map((item) => item.id)).toEqual(['a']);
    expect(map.has('c')).toBe(false);
  });
});
