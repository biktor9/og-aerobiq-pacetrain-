import { describe, expect, it } from 'vitest';
import { bestEfforts, RUN_EFFORTS } from './best-efforts';
import type { BasicStreams } from './streams';

/** A steady run at `metresPerSecond` for `seconds`. */
function steady(metresPerSecond: number, seconds: number): BasicStreams {
  const time = Array.from({ length: seconds + 1 }, (_, index) => index);
  const distance = time.map((value) => value * metresPerSecond);
  return { time, distance, velocity: time.map(() => metresPerSecond) };
}

describe('bestEfforts', () => {
  it('finds the fastest window over each distance', () => {
    const efforts = bestEfforts(steady(3, 3600));
    const km = efforts.find((effort) => effort.label === '1 km');
    const km400 = efforts.find((effort) => effort.label === '400 m');

    expect(km).toBeDefined();
    expect(km!.seconds).toBeGreaterThanOrEqual(333);
    expect(km!.seconds).toBeLessThanOrEqual(335);
    expect(km!.paceSecPerKm).toBe(km!.seconds);
    expect(km400!.seconds).toBeGreaterThanOrEqual(133);
    expect(km400!.seconds).toBeLessThanOrEqual(135);
  });

  it('prefers the fast part of a run over the whole average', () => {
    // 5 minutes at 5 m/s, then 20 minutes at 2.5 m/s.
    const time = Array.from({ length: 1501 }, (_, index) => index);
    const distance = time.map((seconds) => (seconds <= 300 ? seconds * 5 : 1500 + (seconds - 300) * 2.5));
    const efforts = bestEfforts({ time, distance }, [{ label: '1 km', metres: 1000 }]);

    expect(efforts).toHaveLength(1);
    expect(efforts[0].seconds).toBeGreaterThanOrEqual(200);
    expect(efforts[0].seconds).toBeLessThanOrEqual(201);
    expect(efforts[0].startSec).toBe(0);
  });

  it('skips distances the activity never reached', () => {
    const efforts = bestEfforts(steady(3, 900), RUN_EFFORTS);
    const labels = efforts.map((effort) => effort.label);

    expect(labels).toContain('400 m');
    expect(labels).toContain('1 km');
    expect(labels).not.toContain('5 km');
    expect(labels).not.toContain('10 km');
  });

  it('works from speed when the activity has no distance stream', () => {
    const streams: BasicStreams = { time: Array.from({ length: 601 }, (_, index) => index), velocity: Array(601).fill(4) };
    const efforts = bestEfforts(streams, [{ label: '1 km', metres: 1000 }]);

    expect(efforts[0].seconds).toBeGreaterThanOrEqual(250);
    expect(efforts[0].seconds).toBeLessThanOrEqual(251);
  });

  it('returns nothing when there is no movement to measure', () => {
    expect(bestEfforts({ time: [0, 1, 2] })).toEqual([]);
    expect(bestEfforts({ time: [] })).toEqual([]);
  });
});
