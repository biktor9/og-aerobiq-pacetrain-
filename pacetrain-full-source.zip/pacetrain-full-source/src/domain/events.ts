import type { ModeId } from './types';
import { parseISODate, startOfDay, toISODate } from './week';

/**
 * Races and goals. intervals.icu keeps a full season planner; the useful part
 * for one athlete is smaller: which race is next, how long is left, and what
 * the training should look like between now and then.
 */

export type EventPriority = 'A' | 'B' | 'C';

export interface RaceEvent {
  id: string;
  name: string;
  date: string;
  mode: ModeId;
  priority: EventPriority;
  distanceKm: number | null;
  targetTimeSec: number | null;
  notes: string;
}

export type EventPhase = 'base' | 'build' | 'peak' | 'taper' | 'race' | 'done';

export interface EventCountdown {
  /** Days until the event; 0 on race day, negative once it has passed. */
  days: number;
  weeks: number;
  phase: EventPhase;
  /** `24 days to go`, `Today`, `3 weeks ago`. */
  label: string;
  advice: string;
  tone: 'good' | 'ok' | 'warn' | 'neutral';
}

export const PRIORITY_LABELS: Record<EventPriority, string> = {
  A: 'A race',
  B: 'B race',
  C: 'C race'
};

export const PHASE_LABELS: Record<EventPhase, string> = {
  base: 'Base',
  build: 'Build',
  peak: 'Peak',
  taper: 'Taper',
  race: 'Race week',
  done: 'Done'
};

export function isPriority(value: unknown): value is EventPriority {
  return value === 'A' || value === 'B' || value === 'C';
}

function daysBetween(fromISO: string, toISO: string): number {
  const from = parseISODate(fromISO).getTime();
  const to = parseISODate(toISO).getTime();
  return Math.round((to - from) / 86_400_000);
}

/** How far out the taper starts, by how much the race matters. */
function taperWeeks(priority: EventPriority): number {
  if (priority === 'A') return 2;
  if (priority === 'B') return 1;
  return 0;
}

function phaseFor(weeks: number, priority: EventPriority): EventPhase {
  if (weeks <= taperWeeks(priority)) return 'taper';
  if (weeks <= 5) return 'peak';
  if (weeks <= 12) return 'build';
  return 'base';
}

const ADVICE: Record<EventPhase, string> = {
  base: 'Base: steady aerobic volume, consistent frequency, and a little strength. Nothing heroic.',
  build: 'Build: grow the long session and the threshold work. Keep the easy days genuinely easy.',
  peak: 'Peak: race-specific sessions, one hard effort every 72 hours. Volume starts to come down.',
  taper: 'Taper: cut volume, keep short sharp touches. Sleep is training now.',
  race: 'Race week: easy, short, confident. Practise the start, fuel like it is race day.',
  done: 'This one is history. Log how it went, then pick the next target.'
};

export function eventCountdown(
  event: Pick<RaceEvent, 'date' | 'priority'>,
  today: Date = new Date()
): EventCountdown {
  const days = daysBetween(toISODate(startOfDay(today)), event.date);
  const weeks = Math.ceil(days / 7);

  if (days < 0) {
    const ago = Math.abs(days);
    return {
      days,
      weeks,
      phase: 'done',
      label: ago === 1 ? 'Yesterday' : `${ago} days ago`,
      advice: ADVICE.done,
      tone: 'neutral'
    };
  }

  if (days === 0) {
    return { days, weeks: 0, phase: 'race', label: 'Today', advice: ADVICE.race, tone: 'good' };
  }

  const phase = phaseFor(weeks, event.priority);
  return {
    days,
    weeks,
    phase,
    label: days === 1 ? 'Tomorrow' : days < 7 ? `${days} days to go` : `${weeks} weeks to go`,
    advice: ADVICE[phase],
    tone: phase === 'taper' || phase === 'peak' ? 'warn' : phase === 'race' ? 'good' : 'ok'
  };
}

/** The next race that has not happened yet, or null. */
export function nextEvent(events: RaceEvent[], today: Date = new Date()): RaceEvent | null {
  const todayISO = toISODate(startOfDay(today));
  return (
    [...events]
      .filter((event) => event.date >= todayISO)
      .sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0))[0] ?? null
  );
}

/** Upcoming first by date, then everything that has already happened. */
export function sortEvents(events: RaceEvent[], today: Date = new Date()): RaceEvent[] {
  const todayISO = toISODate(startOfDay(today));
  return [...events].sort((a, b) => {
    const aPast = a.date < todayISO;
    const bPast = b.date < todayISO;
    if (aPast !== bPast) return aPast ? 1 : -1;
    if (a.date !== b.date) return aPast ? (a.date < b.date ? 1 : -1) : a.date < b.date ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
}
