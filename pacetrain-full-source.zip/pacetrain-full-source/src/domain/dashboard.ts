/**
 * Which widgets the plan page shows, and in what order.
 *
 * The page is a stack of blocks — the week's numbers, the sport mix, the zones,
 * the calendar, the week itself and the heat map. Every one of them can be
 * removed, and the ones that were removed can be added back, so the order is
 * stored as one JSON value in `user_settings`. The catalogue lives here so the
 * page, the editor and the tests all agree on what exists.
 */

export type WidgetId =
  | 'overview'
  | 'stat-running'
  | 'stat-time'
  | 'stat-planned'
  | 'stat-plan-done'
  | 'stat-expected'
  | 'stat-load'
  | 'stat-expected-time'
  | 'stat-remaining-time'
  | 'stat-sessions-done'
  | 'stat-streak'
  | 'stat-avg-pace'
  | 'mix'
  | 'zones'
  | 'calendar'
  | 'board'
  | 'heat'
  | 'plan-done'
  | 'plan-left'
  | 'load-ramp'
  | 'week-strip'
  | 'recovery';

export interface WidgetInfo {
  id: WidgetId;
  label: string;
  /** One line for the editor, saying what it holds. */
  hint: string;
  /** Tiles share a row; the rest are full-width cards. */
  kind: 'tile' | 'card' | 'group';
}

export const WIDGETS: WidgetInfo[] = [
  { id: 'overview', label: 'Tile row', hint: 'the whole row of numbers below', kind: 'group' },
  { id: 'stat-running', label: 'Running km', hint: 'distance actually run this week', kind: 'tile' },
  { id: 'stat-time', label: 'Time trained', hint: 'hours from your activities', kind: 'tile' },
  { id: 'stat-planned', label: 'Planned time', hint: 'what the week’s plan adds up to', kind: 'tile' },
  { id: 'stat-plan-done', label: 'Plan done so far', hint: 'percent of the plan behind you', kind: 'tile' },
  { id: 'stat-expected', label: 'Expected distance', hint: 'running km the plan still wants', kind: 'tile' },
  { id: 'stat-expected-time', label: 'Expected time', hint: 'how long the week’s plan should take', kind: 'tile' },
  { id: 'stat-remaining-time', label: 'Still to do', hint: 'planned time left in the week', kind: 'tile' },
  { id: 'stat-sessions-done', label: 'Sessions done', hint: 'how many sessions are behind you', kind: 'tile' },
  { id: 'stat-load', label: 'Load', hint: 'training load against last week', kind: 'tile' },
  { id: 'stat-streak', label: 'Streak', hint: 'days in a row with something done', kind: 'tile' },
  { id: 'stat-avg-pace', label: 'Average pace', hint: 'your pace over the week’s runs', kind: 'tile' },
  { id: 'plan-done', label: 'Plan progress', hint: 'a big ring or bar for the week so far', kind: 'card' },
  { id: 'plan-left', label: 'Sessions left', hint: 'what is still ahead, day by day', kind: 'card' },
  { id: 'load-ramp', label: 'Load ramp', hint: 'this week against the last four', kind: 'card' },
  { id: 'mix', label: 'Sports', hint: 'the bar split by discipline', kind: 'card' },
  { id: 'zones', label: 'Heart-rate zones', hint: 'time in Z1–Z5 with your own boundaries', kind: 'card' },
  { id: 'week-strip', label: 'Week numbers', hint: 'four weeks at a glance, side by side', kind: 'card' },
  { id: 'recovery', label: 'Recovery', hint: 'the morning score and what shaped it', kind: 'card' },
  { id: 'calendar', label: 'Calendar', hint: 'last three weeks, this week and next', kind: 'card' },
  { id: 'board', label: 'Week board', hint: 'the seven days and their sessions', kind: 'card' },
  { id: 'heat', label: 'Heat map', hint: 'every trace inside your area', kind: 'card' }
];

/** The tiles inside the overview row, in their own order. */
export const STAT_WIDGETS: WidgetId[] = WIDGETS.filter((widget) => widget.kind === 'tile').map(
  (widget) => widget.id
);

export interface Dashboard {
  /** In the order they are shown; anything missing from here is hidden. */
  order: WidgetId[];
}

const ALL_IDS: WidgetId[] = WIDGETS.map((widget) => widget.id);

/** What a new account starts with: the tiles and the cards that were always there. */
export function defaultDashboard(): Dashboard {
  return { order: [...DEFAULT_IDS] };
}

const DEFAULT_IDS: WidgetId[] = [
  'overview',
  'stat-running',
  'stat-time',
  'stat-planned',
  'stat-plan-done',
  'stat-expected',
  'stat-load',
  'mix',
  'zones',
  'calendar',
  'board',
  'heat'
];

export function isWidgetId(value: unknown): value is WidgetId {
  return typeof value === 'string' && (ALL_IDS as string[]).includes(value);
}

/**
 * Reads the stored JSON back into a dashboard. Unknown ids are dropped, a
 * missing id is simply not shown, and a duplicate is ignored — so a renamed or
 * removed widget can never break the page.
 */
export function parseDashboard(value: string | null | undefined): Dashboard {
  if (!value) return defaultDashboard();
  let raw: unknown;
  try {
    raw = JSON.parse(value);
  } catch {
    return defaultDashboard();
  }
  if (!Array.isArray(raw)) return defaultDashboard();

  const seen = new Set<WidgetId>();
  const order: WidgetId[] = [];
  for (const item of raw) {
    const id = typeof item === 'string' ? item : (item as { id?: unknown })?.id;
    if (!isWidgetId(id) || seen.has(id)) continue;
    seen.add(id);
    order.push(id);
  }
  return { order };
}

export function serializeDashboard(dashboard: Dashboard): string {
  return JSON.stringify(dashboard.order);
}

/** Moves one widget up or down, keeping everything else in place. */
export function moveWidget(order: WidgetId[], id: WidgetId, direction: -1 | 1): WidgetId[] {
  const index = order.indexOf(id);
  if (index < 0) return [...order];
  const target = index + direction;
  if (target < 0 || target >= order.length) return [...order];
  const next = [...order];
  [next[index], next[target]] = [next[target], next[index]];
  return next;
}

/** Takes a widget off the page. */
export function removeWidget(order: WidgetId[], id: WidgetId): WidgetId[] {
  return order.filter((entry) => entry !== id);
}

/**
 * Puts a widget back. It goes after the last widget that precedes it in the
 * catalogue, so a restored widget lands near where it lived originally rather
 * than at the bottom of the page.
 */
export function addWidget(order: WidgetId[], id: WidgetId): WidgetId[] {
  if (order.includes(id)) return [...order];
  const target = ALL_IDS.indexOf(id);
  // The last widget shown that comes before this one in the catalogue.
  let insertAt = 0;
  for (let index = 0; index < order.length; index++) {
    if (ALL_IDS.indexOf(order[index]) < target) insertAt = index + 1;
  }
  const next = [...order];
  next.splice(insertAt, 0, id);
  return next;
}

/** The widgets that are not on the page, in catalogue order. */
export function hiddenWidgets(order: WidgetId[]): WidgetInfo[] {
  return WIDGETS.filter((widget) => !order.includes(widget.id));
}

/** The tiles to show, in order. */
export function visibleStats(order: WidgetId[]): WidgetId[] {
  return order.filter((id) => STAT_WIDGETS.includes(id));
}

/**
 * A tile is hidden either by being removed itself or by having the whole
 * overview row taken off the page.
 */
export function showsStats(order: WidgetId[]): boolean {
  return order.includes('overview') && visibleStats(order).length > 0;
}

export function showsWidget(order: WidgetId[], id: WidgetId): boolean {
  return order.includes(id);
}

/** How a percentage is drawn: a filling bar, or a ring that closes. */
export type ProgressStyle = 'bar' | 'ring';

export function isProgressStyle(value: unknown): value is ProgressStyle {
  return value === 'bar' || value === 'ring';
}

export function parseProgressStyle(value: string | null | undefined): ProgressStyle {
  return isProgressStyle(value) ? value : 'ring';
}

/**
 * How big a widget is drawn. Sizes are per widget, because "wide" means
 * different things for a tile and a card: a tile grows within its row, a card
 * grows from a full-width block into half of one, so two cards can sit side by
 * side.
 */
export type WidgetSize = 'small' | 'wide' | 'large';

/** The sizes each kind of widget can be given, in the order they read. */
export const SIZES_FOR: Record<'tile' | 'card', WidgetSize[]> = {
  tile: ['small', 'wide', 'large'],
  card: ['small', 'wide']
};

/** What each size is called in the editor. */
export const SIZE_LABEL: Record<WidgetSize, { tile: string; card: string }> = {
  small: { tile: 'Small', card: 'Full width' },
  wide: { tile: 'Wide', card: 'Half width' },
  large: { tile: 'Large', card: 'Full width' }
};

/** Every size, with the note that explains what it does. */
export function sizesFor(id: WidgetId): WidgetSize[] {
  const info = WIDGETS.find((widget) => widget.id === id);
  return info && info.kind === 'tile' ? SIZES_FOR.tile : SIZES_FOR.card;
}

export function isWidgetSize(value: unknown): value is WidgetSize {
  return value === 'small' || value === 'wide' || value === 'large';
}

/**
 * The stored sizes. Anything unknown is dropped, so a removed size name cannot
 * break the page; a widget with no entry keeps its natural size.
 */
export type Sizes = Partial<Record<WidgetId, WidgetSize>>;

export function parseSizes(value: string | null | undefined): Sizes {
  if (!value) return {};
  let raw: unknown;
  try {
    raw = JSON.parse(value);
  } catch {
    return {};
  }
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};

  const sizes: Sizes = {};
  for (const [id, size] of Object.entries(raw as Record<string, unknown>)) {
    if (!isWidgetId(id) || !isWidgetSize(size)) continue;
    // A size the widget cannot have is ignored rather than forced.
    if (!sizesFor(id).includes(size)) continue;
    sizes[id] = size;
  }
  return sizes;
}

export function serializeSizes(sizes: Sizes): string {
  return JSON.stringify(sizes);
}

/** The size a widget is drawn at, falling back to its natural one. */
export function sizeOf(sizes: Sizes, id: WidgetId): WidgetSize {
  return sizes[id] ?? 'small';
}

/**
 * Groups the order into what a row looks like: a run of tiles sits side by
 * side, and a card breaks the run. So `tile, tile, card, tile` becomes a row of
 * two tiles, the card, then a row of one — which is both what the start page
 * looked like and where the athlete actually put things.
 *
 * A card marked `wide` joins the run of its neighbours instead of breaking it,
 * so two wide cards can share a row.
 */
export interface BlockRow {
  /** Position in the order, so React can key on something stable. */
  key: string;
  kind: 'tiles' | 'cards';
  ids: WidgetId[];
}

/**
 * How many tiles sit in one row. Two is the widest a tile can be drawn before
 * its number stops being readable at a glance, and it is the shape the tiles
 * are written for: a wide tile pair, one under the other. A third and fourth
 * tile therefore start a new row rather than squeezing in beside the first two.
 */
export const TILES_PER_ROW = 2;

export function layoutRows(order: WidgetId[], sizes: Sizes = {}): BlockRow[] {
  const rows: BlockRow[] = [];
  let run: WidgetId[] = [];
  let runKind: 'tiles' | 'cards' | null = null;
  /** True when the card run so far is made of half-width cards. */
  let runIsWide = false;
  let runIndex = 0;

  const flush = () => {
    if (run.length && runKind) {
      rows.push({ key: `${runKind}-${runIndex}`, kind: runKind, ids: run });
      runIndex += 1;
    }
    run = [];
    runKind = null;
    runIsWide = false;
  };

  for (const id of order) {
    // The old tile-row marker draws nothing, so it neither joins nor breaks a run.
    if (id === 'overview') continue;

    const isTile = STAT_WIDGETS.includes(id);
    const wide = sizeOf(sizes, id) === 'wide';

    // Tiles share a row with the tiles before them, up to a pair: once the row
    // holds as many as it may, the next tile starts a fresh one. A card only
    // joins a run of half-width cards, so two wide cards sit side by side.
    const joins = isTile
      ? runKind === 'tiles' && run.length < TILES_PER_ROW
      : runKind === 'cards' && wide && runIsWide;

    if (!joins) {
      flush();
      runKind = isTile ? 'tiles' : 'cards';
      runIsWide = !isTile && wide;
    }
    run.push(id);
  }
  flush();

  return rows;
}
