import { describe, expect, it } from 'vitest';
import { toSession } from './plan';
import { sportMix } from './sport-mix';
import type { Activity, ModeId, Session } from './types';

function activity(id: string, mode: ModeId, minutes: number, km = 0): Activity {
  return {
    id,
    externalId: id,
    date: '2026-10-20',
    mode,
    name: 'Session',
    durationSec: Math.round(minutes * 60),
    distanceM: Math.round(km * 1000),
    avgHr: null,
    maxHr: null,
    load: null,
    source: 'intervals.icu',
    linkedSessionId: null
  };
}

function session(id: string, mode: ModeId, minutes: number, km: number | null = null): Session {
  return toSession({
    id,
    date: '2026-10-20',
    mode,
    kind: 'steady',
    title: 'Session',
    zone: 2,
    minutes,
    targetKm: km,
    reps: 1,
    workMin: minutes,
    recoverMin: 0,
    warmupMin: 0,
    cooldownMin: 0,
    notes: '',
    status: 'planned',
    structure: null,
    linkedActivityId: null
  });
}

describe('sportMix', () => {
  it('splits the week by how long each sport was trained', () => {
    const mix = sportMix({
      activities: [activity('1', 'run', 60, 12), activity('2', 'run', 30, 6), activity('3', 'bike', 90, 40), activity('4', 'ski', 60, 15)]
    });

    expect(mix.source).toBe('actual');
    expect(mix.totalMinutes).toBe(240);
    expect(mix.slices.map((slice) => slice.mode)).toEqual(['bike', 'run', 'ski']);
    expect(mix.slices[0]).toMatchObject({ mode: 'bike', minutes: 90, km: 40, count: 1, share: 38 });
    expect(mix.slices[1]).toMatchObject({ mode: 'run', minutes: 90, km: 18, count: 2, share: 37 });
    expect(mix.slices.reduce((sum, slice) => sum + slice.share, 0)).toBe(100);
  });

  it('falls back to the plan when nothing has been imported', () => {
    const mix = sportMix({ sessions: [session('1', 'run', 60, 10), session('2', 'strength', 40)] });

    expect(mix.source).toBe('planned');
    expect(mix.totalMinutes).toBe(100);
    expect(mix.slices.map((slice) => ({ mode: slice.mode, share: slice.share }))).toEqual([
      { mode: 'run', share: 60 },
      { mode: 'strength', share: 40 }
    ]);
  });

  it('always adds up to one hundred percent', () => {
    const mix = sportMix({
      activities: [activity('1', 'run', 1), activity('2', 'bike', 1), activity('3', 'ski', 1)]
    });

    expect(mix.slices.map((slice) => slice.share)).toEqual([34, 33, 33]);
  });

  it('has nothing to show for an empty week', () => {
    expect(sportMix({})).toEqual({ slices: [], totalMinutes: 0, source: 'none' });
  });

  it('ignores activities without a duration', () => {
    const mix = sportMix({ activities: [activity('1', 'run', 0), activity('2', 'bike', 30, 15)] });
    expect(mix.slices).toHaveLength(1);
    expect(mix.slices[0].mode).toBe('bike');
  });
});
