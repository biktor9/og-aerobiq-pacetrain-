﻿import { describe, expect, it } from 'vitest';
import {
  autoThreshold,
  detectionFromLaps,
  detectIntervals,
  lapThreshold,
  percentile,
  smoothSeries,
  summariseDetection
} from './intervals';

interface WorkoutOptions {
  reps?: number;
  workSec?: number;
  recoverSec?: number;
  warmupSec?: number;
  cooldownSec?: number;
  easy?: number;
  hard?: number | ((rep: number, t: number) => number);
  dt?: number;
}

function workout(options: WorkoutOptions = {}) {
  const { reps = 4, workSec = 240, recoverSec = 120, warmupSec = 300, cooldownSec = 300, dt = 1 } = options;
  const time: number[] = [];
  const values: number[] = [];
  let t = 0;

  const push = (seconds: number, value: number | ((t: number) => number)) => {
    for (let elapsed = 0; elapsed < seconds; elapsed += dt) {
      time.push(t);
      values.push(typeof value === 'function' ? value(t) : value);
      t += dt;
    }
  };

  push(warmupSec, options.easy ?? 140);
  for (let rep = 0; rep < reps; rep++) {
    push(workSec, typeof options.hard === 'function' ? options.hard(rep, t) : (options.hard ?? 320));
    if (rep < reps - 1) push(recoverSec, options.easy ?? 140);
  }
  push(cooldownSec, options.easy ?? 140);

  return { time, values };
}

describe('percentile', () => {
  it('interpolates between neighbours', () => {
    expect(percentile([0, 10], 50)).toBe(5);
    expect(percentile([1, 2, 3, 4, 5], 0)).toBe(1);
    expect(percentile([1, 2, 3, 4, 5], 100)).toBe(5);
    expect(percentile([], 50)).toBe(0);
  });

  it('puts the auto threshold between the easy baseline and the peak', () => {
    const values = [...Array(80).fill(140), ...Array(20).fill(320)];
    const threshold = autoThreshold(values, 60);
    expect(threshold).toBeGreaterThan(140);
    expect(threshold).toBeLessThan(320);
    expect(threshold).toBeCloseTo(248, 0);
  });
});

describe('smoothSeries', () => {
  it('is a no-op for a window of one', () => {
    expect(smoothSeries([1, 2, 3], 1)).toEqual([1, 2, 3]);
  });

  it('averages with a trailing window', () => {
    expect(smoothSeries([10, 10, 10, 100], 3)).toEqual([10, 10, 10, 40]);
  });
});

describe('detectIntervals', () => {
  it('finds four threshold reps with a manual threshold', () => {
    const { time, values } = workout();
    const result = detectIntervals(time, values, { threshold: 250, minWorkSec: 30, smoothingSec: 10 });

    expect(result.reps).toBe(4);
    expect(result.work).toHaveLength(4);
    expect(result.recover).toHaveLength(3);
    expect(result.threshold).toBe(250);
    expect(result.metric).toBe('power');
    expect(result.unit).toBe('W');
    // The trailing average trims a few seconds from each edge, never more.
    for (const segment of result.work) {
      expect(segment.durationSec).toBeGreaterThan(225);
      expect(segment.durationSec).toBeLessThanOrEqual(240);
      expect(segment.avg).toBeGreaterThan(280);
      expect(segment.max).toBe(320);
      expect(segment.min).toBeGreaterThanOrEqual(140);
    }
    expect(result.durationSec).toBe(1919);
    expect(result.workTimeSec).toBeGreaterThan(900);
    expect(result.consistency).toBeLessThan(3);
  });

  it('works out its own threshold', () => {
    const { time, values } = workout({ easy: 150, hard: 330 });
    const result = detectIntervals(time, values, { threshold: 0, thresholdPct: 60 });
    expect(result.reps).toBe(4);
    expect(result.threshold).toBeGreaterThan(150);
    expect(result.threshold).toBeLessThan(330);
  });

  it('reports nothing for a steady stream', () => {
    const time = Array.from({ length: 600 }, (_, i) => i);
    const values = Array.from({ length: 600 }, () => 210);
    const result = detectIntervals(time, values);
    expect(result.reps).toBe(0);
    expect(result.work).toEqual([]);
    expect(summariseDetection(result)).toContain('No intervals');
  });

  it('ignores spikes that are too short to be an effort', () => {
    const { time, values } = workout({ reps: 2, workSec: 180, recoverSec: 120 });
    // A 5s sprint at 900W in the middle of the warm-up.
    for (let i = 60; i < 65; i++) values[i] = 900;
    const result = detectIntervals(time, values, { threshold: 250, minWorkSec: 30 });
    expect(result.reps).toBe(2);
  });

  it('bridges short dropouts inside one effort', () => {
    const { time, values } = workout({ reps: 2, workSec: 240, recoverSec: 120 });
    // Simulate a 5s power dropout in the middle of the first rep.
    for (let i = 400; i < 405; i++) values[i] = 0;
    const result = detectIntervals(time, values, { threshold: 250, minWorkSec: 30, minGapSec: 15 });
    expect(result.reps).toBe(2);
    expect(result.work[0].durationSec).toBeGreaterThan(225);
  });

  it('survives null samples from the API', () => {
    const { time, values } = workout({ reps: 3 });
    const withNulls = values.map((value, i) => (i % 37 === 0 ? null : value));
    const result = detectIntervals(time, withNulls, { threshold: 250, minWorkSec: 30 });
    expect(result.reps).toBe(3);
  });

  it('smooths away noise', () => {
    const { time, values } = workout({
      reps: 4,
      hard: (rep, t) => 300 + (rep + 1) * 10 + Math.sin(t) * 35
    });
    const noisy = values.map((value) => value + (Math.random() - 0.5) * 20);
    const result = detectIntervals(time, noisy, { threshold: 250, minWorkSec: 30, smoothingSec: 15 });
    expect(result.reps).toBe(4);
  });

  it('measures fade across the session', () => {
    const { time, values } = workout({ reps: 4, hard: (rep) => [340, 320, 300, 280][rep] });
    const result = detectIntervals(time, values, { threshold: 250, minWorkSec: 30 });
    expect(result.driftPct).toBeLessThan(-10);
    expect(summariseDetection(result)).toContain('falling');
  });

  it('flags uneven rep lengths', () => {
    const time: number[] = [];
    const values: number[] = [];
    let t = 0;
    const push = (seconds: number, value: number) => {
      for (let i = 0; i < seconds; i++) {
        time.push(t++);
        values.push(value);
      }
    };
    push(120, 140);
    for (const length of [60, 120, 180, 240]) {
      push(length, 300);
      push(90, 140);
    }
    push(120, 140);
    const result = detectIntervals(time, values, { threshold: 250, minWorkSec: 30 });
    expect(result.reps).toBe(4);
    expect(result.consistency).toBeGreaterThan(30);
    expect(summariseDetection(result)).toContain('uneven');
  });

  it('handles empty and tiny inputs', () => {
    expect(detectIntervals([], []).reps).toBe(0);
    expect(detectIntervals([0, 1, 2], [1, 2, 3]).reps).toBe(0);
    expect(detectIntervals([0, 1], [null, null]).reps).toBe(0);
  });

  it('normalises nonsensical parameters', () => {
    const { time, values } = workout();
    const result = detectIntervals(time, values, {
      minWorkSec: -10,
      minGapSec: -5,
      smoothingSec: -1,
      thresholdPct: 500
    });
    expect(result.reps).toBeGreaterThan(0);
  });
});

/** A lap as intervals.icu sends it, converted to seconds per km for a run. */
function lap(durationSec: number, distanceM: number, paceSecPerKm: number) {
  return {
    index: 0,
    startSec: 0,
    durationSec,
    distanceM,
    avg: paceSecPerKm,
    max: paceSecPerKm,
    min: paceSecPerKm
  };
}

describe('detectionFromLaps', () => {
  it('finds the cut-off a real interval session needs', () => {
    const result = lapThreshold([238, 240, 241, 244, 350, 375, 420, 420, 425]);
    expect(result.split).toBe(true);
    // The line lands on the easy side of the slowest rep (4:00/km), so the four
    // reps are work and the warm-up and cool-down are not.
    expect(result.threshold).toBeGreaterThan(244);
    expect(result.threshold).toBeLessThan(350);
  });

  it('finds no cut-off in a run where every kilometre is alike', () => {
    const steady = [318, 320, 321, 322, 319, 323, 320, 321];
    expect(lapThreshold(steady).split).toBe(false);
  });

  it('takes the watch’s laps as they are instead of guessing', () => {
    // Warm-up, four 800 m reps at 4:00/km with 2 min jogs, cool-down.
    const laps = [
      { ...lap(600, 1600, 375), name: 'Warm-up' },
      { ...lap(192, 800, 240), name: '800 m' },
      { ...lap(120, 300, 420), name: 'Recovery' },
      { ...lap(190, 800, 238), name: '800 m' },
      { ...lap(120, 300, 425), name: 'Recovery' },
      { ...lap(195, 800, 244), name: '800 m' },
      { ...lap(120, 300, 420), name: 'Recovery' },
      { ...lap(193, 800, 241), name: '800 m' },
      { ...lap(480, 1400, 350), name: 'Cool-down' }
    ];

    const result = detectionFromLaps(laps, 'pace');

    expect(result.reps).toBe(4);
    expect(result.work.map((segment) => Math.round(segment.avg))).toEqual([240, 238, 244, 241]);
    // Warm-up, three jogs and the cool-down are all recovery, never reps.
    expect(result.recover).toHaveLength(5);
    expect(result.workTimeSec).toBe(192 + 190 + 195 + 193);
    expect(result.consistency).toBeLessThan(5);
  });

  it('keeps the labels the laps came with', () => {
    const result = detectionFromLaps(
      [
        { ...lap(200, 800, 250), name: '800m' },
        { ...lap(120, 300, 400), name: 'Recovery' },
        { ...lap(200, 800, 252), name: '800m' }
      ],
      'pace'
    );

    expect(result.work[0].label).toBe('800m');
    expect(result.work).toHaveLength(2);
  });

  it('lets the athlete decide which laps are work', () => {
    const laps = [lap(300, 1000, 300), lap(300, 1000, 305), lap(300, 1000, 310)].map((entry, index) => ({
      ...entry,
      index: index + 1,
      kind: index === 1 ? ('work' as const) : ('recover' as const)
    }));

    const result = detectionFromLaps(laps, 'pace');

    expect(result.reps).toBe(1);
    expect(result.work[0].durationSec).toBe(300);
  });

  it('finds nothing in a steady session where every lap was the same', () => {
    const laps = Array.from({ length: 10 }, (_, index) => ({
      ...lap(300, 1000, 330 + (index % 2)),
      name: `Km ${index + 1}`
    }));
    expect(detectionFromLaps(laps, 'pace').reps).toBe(0);
  });

  it('ignores a set of 15-second strides', () => {
    const laps = [
      { ...lap(600, 1500, 400), name: 'km' },
      { ...lap(15, 70, 210), name: 'Stride' },
      { ...lap(60, 200, 420), name: '2' },
      { ...lap(15, 70, 212), name: 'Stride' },
      { ...lap(600, 1500, 400), name: 'km' }
    ];
    expect(detectionFromLaps(laps, 'pace').reps).toBe(0);
  });

  it('needs at least two laps', () => {
    expect(detectionFromLaps([lap(600, 2000, 300)], 'pace').reps).toBe(0);
    expect(detectionFromLaps([], 'pace').reps).toBe(0);
  });
});
