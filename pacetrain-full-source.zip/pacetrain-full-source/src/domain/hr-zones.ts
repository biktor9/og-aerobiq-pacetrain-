import { MODES, zone, zoneHrShare, type Activity, type ModeId, type ZoneId, ZONE_IDS } from './types';

/**
 * Time in heart-rate zones.
 *
 * Zones are not recorded — beats are. Every imported activity arrives with an
 * average and a peak heart rate, sometimes with the time it spent in zones
 * (intervals.icu sends `hr_zone_times`), and this module turns that into the
 * hours each zone got. It is a model, not the watch's own log, and it says so:
 * the estimate is spread around the session's average with the peak pulling the
 * hard end up, so a threshold run lands in Z4 while an easy run stays in Z2.
 *
 * The boundaries are the athlete's own: `ZoneBounds` holds the top of Z1 … Z4 in
 * bpm, and anything above the last one is Z5. Without them the zones fall back
 * to fixed shares of the maximum heart rate.
 */

export type ZoneBounds = [number, number, number, number];

/** Where each zone ends, as a share of maximum heart rate, when nothing is typed. */
const DEFAULT_BOUNDS_SHARE = [0.65, 0.76, 0.84, 0.93] as const;

/** The default boundaries for a maximum heart rate, in bpm. */
export function defaultBounds(maxHr: number): ZoneBounds {
  const safe = Math.max(120, Math.round(maxHr));
  return DEFAULT_BOUNDS_SHARE.map((share) => Math.round(safe * share)) as ZoneBounds;
}

/**
 * Reads the stored `"110,133,152,168"` back into four numbers. Anything that is
 * not four ascending values is ignored, so a half-typed row never breaks a page.
 */
export function parseZoneBounds(value: string | null | undefined, maxHr: number): ZoneBounds {
  const fallback = defaultBounds(maxHr);
  if (!value) return fallback;
  const parts = value
    .split(',')
    .map((part) => Number(part.trim()))
    .filter((part) => Number.isFinite(part) && part > 0);
  if (parts.length !== 4) return fallback;
  // The boundaries have to rise: a mistyped pair would put two zones in one place.
  for (let index = 1; index < parts.length; index++) {
    if (!(parts[index] > parts[index - 1])) return fallback;
  }
  return parts as ZoneBounds;
}

export function serializeZoneBounds(bounds: ZoneBounds): string {
  return bounds.join(',');
}

/** The zone a heart rate falls in, using the athlete's own boundaries. */
export function zoneForHrWith(hr: number, bounds: ZoneBounds): ZoneId {
  if (hr <= bounds[0]) return 1;
  if (hr <= bounds[1]) return 2;
  if (hr <= bounds[2]) return 3;
  if (hr <= bounds[3]) return 4;
  return 5;
}

/** `{ from, to }` in bpm — `to` is null for Z5, which has no ceiling. */
export function zoneRange(id: ZoneId, bounds: ZoneBounds): { from: number; to: number | null } {
  const from = id === 1 ? 0 : bounds[id - 2];
  const to = id === 5 ? null : bounds[id - 1];
  return { from, to };
}

/** The zones as the settings screen lists them, with their bpm ranges. */
export function zoneLabels(bounds: ZoneBounds): { id: ZoneId; label: string; range: string }[] {
  return ZONE_IDS.map((id) => {
    const { from, to } = zoneRange(id, bounds);
    const range = to === null ? `${from + 1}+ bpm` : from === 0 ? `under ${to + 1} bpm` : `${from + 1}–${to} bpm`;
    return { id, label: zone(id).label, range };
  });
}


export interface ZoneMinutes {
  /** Minutes in each zone, Z1 … Z5. */
  zones: Record<ZoneId, number>;
  /** Total minutes the estimate covers (activities that had a heart rate). */
  totalMinutes: number;
  /** Activities that carried no heart rate and could not be placed. */
  withoutHr: number;
}

export function emptyZoneMinutes(): Record<ZoneId, number> {
  return { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
}

/**
 * The mode's share of maximum heart rate, which is what decides whether two
 * sports can be compared. Strength runs hot on little load; a ride sits lower
 * for the same effort. The estimate is shifted by this before zoning.
 */
const MODE_HR_SHIFT: Record<ModeId, number> = {
  run: 0,
  trail: 0,
  orienteering: 0,
  ski: 0.02,
  bike: 0.02,
  mtb: 0.02,
  strength: 0.04
};

/**
 * The weight each zone gets for a session at a given average heart rate.
 *
 * The average decides most of it, and the gap between the average and the peak
 * is what the hard end of the session gets: an interval set with a big gap puts
 * a good share in the zone above, an even threshold run sits in one zone for the
 * whole hour.
 */
function weightsFor(avgHr: number, peakHr: number, bounds: ZoneBounds): Record<ZoneId, number> {
  const weights = emptyZoneMinutes();
  const centre = zoneForHrWith(avgHr, bounds);
  const above = Math.min(5, centre + 1) as ZoneId;
  const below = Math.max(1, centre - 1) as ZoneId;
  // How much of this zone's width the peak travelled past the average.
  const { from, to } = zoneRange(centre, bounds);
  const width = to === null ? Math.max(1, bounds[3] - from) : Math.max(1, to - from);
  const hardShare = Math.min(0.4, Math.max(0, (peakHr - avgHr) / width) * 0.5);

  weights[centre] = 1 - hardShare;
  if (hardShare > 0) weights[above] = hardShare;
  // A long warm-up pulls the average down, so the zone below keeps a small share.
  if (centre > 1) weights[below] += 0.08;
  return weights;
}

/** One activity's minutes, spread over the zones it touched. */
export function activityZoneMinutes(
  activity: Activity,
  bounds: ZoneBounds,
  maxHr = bounds[3]
): Record<ZoneId, number> | null {
  // The platform's own zone times beat any estimate: they came from the watch.
  if (activity.hrZoneSec?.length) {
    const out = emptyZoneMinutes();
    let any = false;
    for (const id of ZONE_IDS) {
      const seconds = activity.hrZoneSec[id - 1];
      if (typeof seconds === 'number' && Number.isFinite(seconds) && seconds > 0) {
        out[id] = seconds / 60;
        any = true;
      }
    }
    return any ? out : null;
  }

  if (!activity.avgHr || !(activity.durationSec > 0)) return null;
  // A different sport reads a little higher or lower for the same effort.
  const shift = (MODE_HR_SHIFT[activity.mode] ?? 0) * Math.max(120, maxHr);
  const avgHr = activity.avgHr + shift;
  const peakHr = Math.max(avgHr, (activity.maxHr ?? activity.avgHr) + shift);
  const weights = weightsFor(avgHr, peakHr, bounds);
  const sum = ZONE_IDS.reduce((total, id) => total + weights[id], 0) || 1;
  const minutes = activity.durationSec / 60;
  const out = emptyZoneMinutes();
  for (const id of ZONE_IDS) out[id] = (weights[id] / sum) * minutes;
  return out;
}

/** A maximum heart rate from the athlete's own activities, or a sane default. */
export function observedMaxHr(activities: Activity[], fallback = 190): number {
  const peaks = activities
    .map((activity) => activity.maxHr ?? activity.avgHr ?? 0)
    .filter((value) => Number.isFinite(value) && value > 100);
  if (!peaks.length) return fallback;
  return Math.round(peaks.reduce((best, value) => Math.max(best, value), 0));
}

/** Adds every activity up, keeping only the sports the athlete chose. */
export function zoneMinutes(
  activities: Activity[],
  { bounds, modes }: { bounds: ZoneBounds; modes?: ModeId[] | null }
): ZoneMinutes {
  const totals = emptyZoneMinutes();
  let totalMinutes = 0;
  let withoutHr = 0;
  const maxHr = bounds[3];

  for (const activity of activities) {
    if (modes && modes.length && !modes.includes(activity.mode)) continue;
    const spread = activityZoneMinutes(activity, bounds, maxHr);
    if (!spread) {
      if (activity.durationSec > 0) withoutHr += 1;
      continue;
    }
    for (const id of ZONE_IDS) totals[id] += spread[id];
    totalMinutes += activity.durationSec / 60;
  }

  for (const id of ZONE_IDS) totals[id] = Math.round(totals[id]);
  return { zones: totals, totalMinutes: Math.round(totalMinutes), withoutHr };
}

export interface ZoneSlice {
  id: ZoneId;
  label: string;
  color: string;
  minutes: number;
  /** Percent of the period's measured time. */
  share: number;
}

/** The bar's segments, with empty zones dropped. */
export function zoneSlices(totals: Record<ZoneId, number>): ZoneSlice[] {
  const sum = ZONE_IDS.reduce((total, id) => total + Math.max(0, totals[id]), 0);
  return ZONE_IDS.filter((id) => totals[id] > 0).map((id) => ({
    id,
    label: zone(id).label,
    color: zone(id).color,
    minutes: Math.round(totals[id]),
    share: sum > 0 ? Math.round((Math.max(0, totals[id]) / sum) * 100) : 0
  }));
}

/**
 * Which sports the athlete wants counted. Null or an empty list means "all of
 * them", so a fresh account sees everything without choosing anything.
 */
export function parseZoneModes(value: string | null | undefined): ModeId[] | null {
  if (!value) return null;
  const ids = value
    .split(',')
    .map((part) => part.trim())
    .filter((part) => MODES.some((mode) => mode.id === part)) as ModeId[];
  return ids.length ? ids : null;
}

/** Stores the choice, or null when every sport is counted. */
export function serializeZoneModes(modes: ModeId[] | null | undefined): string | null {
  if (!modes || !modes.length) return null;
  const ordered = MODES.map((mode) => mode.id).filter((id) => modes.includes(id));
  return ordered.length === MODES.length ? null : ordered.join(',');
}

/** Which sports have a heart rate to count, with how many sessions each has. */
export function sportsWithHeartRate(activities: Activity[]): { mode: ModeId; activities: number; minutes: number }[] {
  return MODES.map((mode) => {
    const own = activities.filter((activity) => activity.mode === mode.id && activity.avgHr);
    return {
      mode: mode.id,
      activities: own.length,
      minutes: Math.round(own.reduce((total, activity) => total + activity.durationSec / 60, 0))
    };
  }).filter((row) => row.activities > 0);
}

/** The heart-rate anchors of a zone, for the tooltip: `Z2 ≈ 133 bpm`. */
export function zoneAnchorHr(id: ZoneId, maxHr: number, bounds?: ZoneBounds): number {
  if (bounds) {
    const { from, to } = zoneRange(id, bounds);
    return to === null ? from + 1 : Math.round((from + to) / 2);
  }
  return Math.round(zoneHrShare(id) * Math.max(120, maxHr));
}
