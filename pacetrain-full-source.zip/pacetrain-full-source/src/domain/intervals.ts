﻿import { METRICS, type DetectionResult, type MetricId, type Segment } from './types';

export interface DetectParams {
  metric: MetricId;
  /** 0 means "work it out from the data". */
  threshold: number;
  /** Where the automatic threshold sits between the easy baseline and the peak. */
  thresholdPct: number;
  minWorkSec: number;
  minGapSec: number;
  smoothingSec: number;
}

export const DEFAULT_DETECT: DetectParams = {
  metric: 'power',
  threshold: 0,
  thresholdPct: 60,
  minWorkSec: 30,
  minGapSec: 15,
  smoothingSec: 10
};

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function normalizeDetectParams(raw: Partial<DetectParams> | null | undefined): DetectParams {
  const p = { ...DEFAULT_DETECT, ...(raw ?? {}) };
  const metric = METRICS.some((m) => m.id === p.metric) ? p.metric : DEFAULT_DETECT.metric;
  return {
    metric,
    threshold: clamp(Number(p.threshold) || 0, 0, 100_000),
    thresholdPct: clamp(Number(p.thresholdPct) || 60, 20, 90),
    minWorkSec: clamp(Number(p.minWorkSec) || 30, 5, 900),
    minGapSec: clamp(Number(p.minGapSec) || 0, 0, 600),
    smoothingSec: clamp(Number(p.smoothingSec) || 0, 0, 120)
  };
}

function median(values: number[]): number {
  if (!values.length) return 1;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

/** Linear-interpolated percentile, p between 0 and 100. */
export function percentile(values: number[], p: number): number {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const rank = (clamp(p, 0, 100) / 100) * (sorted.length - 1);
  const low = Math.floor(rank);
  const high = Math.ceil(rank);
  if (low === high) return sorted[low];
  return sorted[low] + (sorted[high] - sorted[low]) * (rank - low);
}

/**
 * Automatic threshold: a fraction of the way from the easy baseline (20th
 * percentile) to the hard ceiling (95th percentile). 60% sits just under
 * threshold power/pace for most workouts.
 */
export function autoThreshold(values: number[], pct: number): number {
  if (!values.length) return 0;
  const baseline = percentile(values, 20);
  const peak = percentile(values, 95);
  if (!Number.isFinite(baseline) || !Number.isFinite(peak) || peak <= baseline) return peak || 0;
  return baseline + (peak - baseline) * (clamp(pct, 0, 100) / 100);
}

/** Trailing moving average with a window measured in samples. */
export function smoothSeries(values: number[], windowSamples: number): number[] {
  const window = Math.max(1, Math.round(windowSamples));
  if (window === 1) return [...values];
  const out: number[] = new Array(values.length);
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= window) sum -= values[i - window];
    out[i] = sum / Math.min(i + 1, window);
  }
  return out;
}

interface Run {
  startIdx: number;
  endIdx: number;
}

function sampleStep(time: number[]): number {
  const diffs: number[] = [];
  for (let i = 1; i < time.length && diffs.length < 200; i++) {
    const d = time[i] - time[i - 1];
    if (d > 0 && d < 60) diffs.push(d);
  }
  return diffs.length ? median(diffs) : 1;
}

function round(value: number): number {
  return Math.round(value * 10) / 10;
}

function segmentStats(
  values: number[],
  time: number[],
  run: Run,
  kind: Segment['kind'],
  index: number
): Segment {
  let sum = 0;
  let max = -Infinity;
  let min = Infinity;
  let count = 0;
  for (let i = run.startIdx; i <= run.endIdx; i++) {
    const v = values[i];
    if (!Number.isFinite(v)) continue;
    sum += v;
    if (v > max) max = v;
    if (v < min) min = v;
    count += 1;
  }
  const startSec = time[run.startIdx];
  const endSec = time[run.endIdx];
  return {
    index,
    kind,
    startSec,
    endSec,
    durationSec: Math.max(0, endSec - startSec),
    avg: count ? sum / count : 0,
    max: count ? max : 0,
    min: count ? min : 0
  };
}

/**
 * Finds work/recovery intervals in a stream where **higher values mean harder**.
 * Pace streams must be converted to speed before they get here.
 */
export function detectIntervals(
  time: number[],
  rawValues: (number | null)[],
  params: Partial<DetectParams> = {}
): DetectionResult {
  const p = normalizeDetectParams(params);
  const meta = METRICS.find((m) => m.id === p.metric) ?? METRICS[0];

  const empty: DetectionResult = {
    metric: p.metric,
    metricLabel: meta.label,
    unit: meta.unit,
    threshold: 0,
    reps: 0,
    segments: [],
    work: [],
    recover: [],
    durationSec: 0,
    workTimeSec: 0,
    recoverTimeSec: 0,
    avgWorkSec: 0,
    avgRecoverSec: 0,
    consistency: 0,
    driftPct: 0
  };

  // Keep only usable samples, preserving their timestamps.
  const t: number[] = [];
  const v: number[] = [];
  for (let i = 0; i < rawValues.length; i++) {
    const value = rawValues[i];
    if (value === null || value === undefined || !Number.isFinite(value)) continue;
    const stamp = Number(time[i]);
    if (!Number.isFinite(stamp)) continue;
    t.push(stamp);
    v.push(Number(value));
  }
  if (v.length < 10) return empty;

  const step = sampleStep(t);
  const windowSamples = p.smoothingSec > 0 ? Math.max(1, Math.round(p.smoothingSec / step)) : 1;
  const smoothed = smoothSeries(v, windowSamples);
  const baseline = percentile(smoothed, 20);
  const peak = percentile(smoothed, 95);
  const threshold = p.threshold > 0 ? p.threshold : autoThreshold(smoothed, p.thresholdPct);

  // A flat stream has no intervals to find, even though every sample is "above"
  // its own 95th percentile.
  if (peak - baseline <= Math.max(1, peak * 0.02)) {
    return { ...empty, threshold: round(threshold) };
  }

  // 1. Find every run above the threshold.
  const runs: Run[] = [];
  let start = -1;
  for (let i = 0; i < smoothed.length; i++) {
    const above = smoothed[i] >= threshold;
    if (above && start === -1) start = i;
    if (!above && start !== -1) {
      runs.push({ startIdx: start, endIdx: i - 1 });
      start = -1;
    }
  }
  if (start !== -1) runs.push({ startIdx: start, endIdx: smoothed.length - 1 });

  // 2. Merge runs separated by a gap shorter than minGapSec (a dropped sample
  //    or a short dip inside one effort).
  const merged: Run[] = [];
  for (const run of runs) {
    const previous = merged[merged.length - 1];
    if (previous && t[run.startIdx] - t[previous.endIdx] <= p.minGapSec) {
      previous.endIdx = run.endIdx;
      continue;
    }
    merged.push({ ...run });
  }

  // 3. Drop efforts that are too short to be a real interval.
  const workRuns = merged.filter((run) => t[run.endIdx] - t[run.startIdx] >= p.minWorkSec);
  if (!workRuns.length) return { ...empty, threshold: round(threshold) };

  const work = workRuns.map((run, i) => segmentStats(v, t, run, 'work', i + 1));

  // 4. Everything between two efforts is recovery.
  const recover: Segment[] = [];
  for (let i = 0; i < workRuns.length - 1; i++) {
    const gapStart = workRuns[i].endIdx;
    const gapEnd = workRuns[i + 1].startIdx;
    if (gapEnd <= gapStart) continue;
    recover.push(segmentStats(v, t, { startIdx: gapStart, endIdx: gapEnd }, 'recover', i + 1));
  }

  const durationSec = Math.max(0, t[t.length - 1] - t[0]);
  const workTimeSec = work.reduce((sum, s) => sum + s.durationSec, 0);
  const recoverTimeSec = recover.reduce((sum, s) => sum + s.durationSec, 0);
  const durations = work.map((s) => s.durationSec);
  const mean = durations.reduce((a, b) => a + b, 0) / durations.length;
  const variance = durations.reduce((sum, d) => sum + (d - mean) ** 2, 0) / durations.length;
  const consistency = mean > 0 ? (Math.sqrt(variance) / mean) * 100 : 0;
  const driftPct =
    work.length >= 2 && work[0].avg > 0 ? ((work[work.length - 1].avg - work[0].avg) / work[0].avg) * 100 : 0;

  const segments = [...work, ...recover].sort((a, b) => a.startSec - b.startSec);

  return {
    metric: p.metric,
    metricLabel: meta.label,
    unit: meta.unit,
    threshold: round(threshold),
    reps: work.length,
    segments,
    work,
    recover,
    durationSec,
    workTimeSec,
    recoverTimeSec,
    avgWorkSec: Math.round(workTimeSec / work.length),
    avgRecoverSec: recover.length ? Math.round(recoverTimeSec / recover.length) : 0,
    consistency: Math.round(consistency * 10) / 10,
    driftPct: Math.round(driftPct * 10) / 10
  };
}

/** A lap, optionally already marked as work or recovery by the athlete. */
export interface LoggedLap {
  /** 1-based, in recording order. Ignored on the way in: order decides it. */
  index: number
  startSec: number
  durationSec: number
  /** Average in the detected metric's unit — km/h for speed, seconds per km for pace. */
  avg: number
  max: number
  min: number
  /** Optional label from the recording (`800m`, `1 km`, `Lap 3`). */
  name?: string
  /** Set by the athlete on the analysis page; absent means "decide for me". */
  kind?: 'work' | 'recover'
}

/** `16′`, `90″`, `4′30″` — the same shape the interval report uses. */
function describeRep(durationSec: number): string {
  const total = Math.max(0, Math.round(durationSec))
  if (total < 60) return `${total}″`
  const minutes = Math.floor(total / 60)
  const rest = total % 60
  return rest === 0 ? `${minutes}′` : `${minutes}′${String(rest).padStart(2, '0')}″`
}

function lapLabel(lap: LoggedLap): string {
  const named = lap.name?.trim()
  return named && named.length <= 10 ? named : describeRep(lap.durationSec)
}

function emptyResult(metric: MetricId): DetectionResult {
  const meta = METRICS.find((m) => m.id === metric) ?? METRICS[0]
  return {
    metric,
    metricLabel: meta.label,
    unit: meta.unit,
    threshold: 0,
    reps: 0,
    segments: [],
    work: [],
    recover: [],
    durationSec: 0,
    workTimeSec: 0,
    recoverTimeSec: 0,
    avgWorkSec: 0,
    avgRecoverSec: 0,
    consistency: 0,
    driftPct: 0
  }
}

/**
 * A short, human read of a detection result — used by the coach and the UI. */
export function summariseDetection(result: DetectionResult): string {
  if (!result.reps) {
    return 'No intervals were found above the threshold. Lower the threshold or raise the smoothing window.';
  }
  const bits: string[] = [
    `${result.reps} × ${Math.round(result.avgWorkSec / 60)}′ efforts around ${Math.round(result.threshold)} ${result.unit}`
  ];
  if (result.consistency <= 5) bits.push('very even pacing');
  else if (result.consistency <= 12) bits.push('reasonably even pacing');
  else bits.push(`uneven efforts (${Math.round(result.consistency)}% spread)`);

  if (result.recover.length && result.avgRecoverSec) {
    bits.push(`${Math.round(result.avgRecoverSec)}′ recovery on average`);
  }
  if (Math.abs(result.driftPct) >= 5) {
    bits.push(
      `${result.driftPct > 0 ? 'rising' : 'falling'} by ${Math.abs(Math.round(result.driftPct))}% from first to last effort`
    );
  }
  return `${bits.join(', ')}.`;
}

/**
 * Where the reps start in a list of laps.
 *
 * Both parts of the session are there once something divides the laps in two:
 * a group of laps much harder than the rest, and enough easy laps to be the
 * rest of the run. Every cut is tried, and the one that leaves the most laps
 * on both sides wins — a warm-up, four reps and three jogs give a five/four
 * split, not a one/eight one.
 *
 * `harderIsHigher` is false for pace, where a smaller number is the harder lap,
 * and true for km/h, watts and heart rate. Either way, the two sides have to be
 * at least 8 % apart: that is what makes this a session with intervals rather
 * than a steady run whose kilometres all sit within a few seconds of each other.
 */
export function lapThreshold(
  averages: number[],
  { harderIsHigher = false }: { harderIsHigher?: boolean } = {}
): { threshold: number; split: boolean } {
  const sorted = averages.slice().sort((a, b) => (harderIsHigher ? a - b : b - a));
  let best: { threshold: number; score: number } | null = null;

  for (let cut = 1; cut < sorted.length; cut++) {
    const reps = sorted.slice(0, cut);
    const rest = sorted.slice(cut);
    const repMean = reps.reduce((sum, value) => sum + value, 0) / reps.length;
    const restMean = rest.reduce((sum, value) => sum + value, 0) / rest.length;
    // How much harder the reps are. The list is sorted hardest-first, so the
    // reps carry the larger number whether that is more watts or a slower pace,
    // and the ratio is above 1. The two sides must be 8 % apart for this to be a
    // session with intervals rather than a steady run.
    const ratio = repMean / Math.max(1, restMean);
    if (ratio < 1.08) continue;

    // The most even split wins; among equals the one whose reps stand furthest
    // clear of the rest, which is the line nearest the reps rather than the
    // middle of a long warm-up.
    const balance = Math.min(reps.length, rest.length) / Math.max(reps.length, rest.length);
    const score = balance * 10 + (ratio - 1) * 4;
    if (!best || score > best.score) {
      // The line sits halfway between the slowest rep and the easiest lap.
      best = { threshold: (sorted[cut - 1] + sorted[cut]) / 2, score };
    }
  }

  if (!best) return { threshold: 0, split: false };
  return { threshold: best.threshold, split: true };
}

/**
 * Reads a session from the laps the athlete (or intervals.icu) recorded instead
 * of guessing from the stream.
 *
 * `laps` must already be in the detected metric's unit (km/h for speed, seconds
 * per km for pace, watts and bpm as they are). Deciding which lap is work is
 * done without asking: a lap clearly harder than the easy part of the session is
 * work, and a lap much shorter than the efforts around it is a jog between reps.
 * Laps the athlete marked by hand (`kind`) always win.
 */
export function detectionFromLaps(laps: LoggedLap[], metric: MetricId): DetectionResult {
  const clean = laps
    .filter((lap) => Number.isFinite(lap.avg) && lap.avg > 0 && lap.durationSec > 0)
    .map((lap, position) => ({ ...lap, index: position + 1 }));

  const empty = emptyResult(metric);
  if (clean.length < 2) return empty;

  const averages = clean.map((lap) => lap.avg);
  // Pace is the one metric where a smaller number is the harder lap.
  const { threshold, split } = lapThreshold(averages, { harderIsHigher: metric !== 'pace' });
  const labels = clean.map((lap) => lap.name?.trim().toLowerCase() ?? '');
  const anyPicked = clean.some((lap) => lap.kind);

  // A session with one effort spread over every lap has no intervals to find —
  // unless the athlete marked the laps themselves, which always decides.
  if (!split && !anyPicked) return { ...empty, threshold: round(threshold) };

  // A recovery label is the one kind of lap that must never count as work — a
  // jog between reps can be long enough to pass the threshold. The rest is
  // decided by intensity, which is where the reps really stand apart. Pace is
  // the metric where a lap below the line is the harder one.
  const recoveryLabelled = labels.some((name) => /recover|rest|easy|jog/.test(name));
  const isWork = (lap: LoggedLap) => (metric === 'pace' ? lap.avg < threshold : lap.avg > threshold);
  const picked = clean.filter((lap, index) => {
    if (recoveryLabelled && /recover|rest|easy|jog/.test(labels[index])) return false;
    return lap.kind ? lap.kind === 'work' : isWork(lap);
  });
  if (!picked.length) return { ...empty, threshold: round(threshold) };

  // Four 15-second strides are pickups, not a set of intervals.
  const longest = Math.max(...picked.map((lap) => lap.durationSec));
  if (longest < 60) return { ...empty, threshold: round(threshold) };

  const chosen = new Set(picked.map((lap) => lap.index));
  if (!clean.some((lap) => lap.kind)) {
    // A lap between two efforts that is shorter and easier than the typical rep
    // is a jog between reps, so it is drawn as recovery. A 2:00 jog at 7:00/km
    // between 16′ blocks passes the threshold on length alone — it must not
    // count as work.
    const firstWork = clean.findIndex((lap) => chosen.has(lap.index));
    const lastWork = clean.reduce((last, lap, index) => (chosen.has(lap.index) ? index : last), 0);
    const typical = median(picked.map((lap) => lap.durationSec));
    const easyMark = median(clean.map((lap) => lap.avg));
    clean.forEach((lap, index) => {
      if (index <= firstWork || index >= lastWork) return;
      const shorter = lap.durationSec < typical * 0.6;
      const easier = metric === 'pace' ? lap.avg > easyMark : lap.avg < easyMark;
      if (shorter || easier) chosen.delete(lap.index);
    });
  }

  const kinds = clean.map((lap) => (chosen.has(lap.index) ? ('work' as const) : ('recover' as const)));
  return reportFromLaps(clean, kinds, metric, threshold);
}

/** Builds the detection result and the statistics around a set of laps. */
export function reportFromLaps(
  laps: LoggedLap[],
  kinds: ('work' | 'recover')[],
  metric: MetricId,
  threshold = 0
): DetectionResult {
  const segments: Segment[] = laps.map((lap, index) => ({
    index: lap.index,
    kind: kinds[index] ?? 'recover',
    startSec: lap.startSec,
    endSec: lap.startSec + lap.durationSec,
    durationSec: lap.durationSec,
    avg: lap.avg,
    max: lap.max,
    min: lap.min,
    label: lapLabel(lap)
  }));

  const worked = segments.filter((segment) => segment.kind === 'work');
  const rested = segments.filter((segment) => segment.kind === 'recover');
  const workTimeSec = worked.reduce((sum, segment) => sum + segment.durationSec, 0);
  const recoverTimeSec = rested.reduce((sum, segment) => sum + segment.durationSec, 0);
  const durations = worked.map((segment) => segment.durationSec);
  const mean = durations.length ? durations.reduce((a, b) => a + b, 0) / durations.length : 0;
  const variance = durations.reduce((sum, duration) => sum + (duration - mean) ** 2, 0) / Math.max(1, durations.length);
  const consistency = mean > 0 ? (Math.sqrt(variance) / mean) * 100 : 0;
  const driftPct =
    worked.length >= 2 && worked[0].avg > 0
      ? ((worked[worked.length - 1].avg - worked[0].avg) / worked[0].avg) * 100
      : 0;
  const meta = METRICS.find((m) => m.id === metric) ?? METRICS[0];

  return {
    metric,
    metricLabel: meta.label,
    unit: meta.unit,
    threshold: round(threshold),
    reps: worked.length,
    segments,
    work: worked,
    recover: rested,
    durationSec: segments.reduce((sum, segment) => sum + segment.durationSec, 0),
    workTimeSec,
    recoverTimeSec,
    avgWorkSec: worked.length ? Math.round(workTimeSec / worked.length) : 0,
    avgRecoverSec: rested.length ? Math.round(recoverTimeSec / rested.length) : 0,
    consistency: Math.round(consistency * 10) / 10,
    driftPct: Math.round(driftPct * 10) / 10
  };
}

