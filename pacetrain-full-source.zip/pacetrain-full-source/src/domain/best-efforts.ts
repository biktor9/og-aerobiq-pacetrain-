import { cumulativeDistance, type BasicStreams } from './streams';

/**
 * Best efforts: the fastest window over a set of distances inside one activity.
 * This is the small, honest slice of intervals.icu's power/pace curve — no
 * modelling, no smoothing, just the best stretch of road the athlete produced.
 */

export interface BestEffort {
  label: string;
  distanceM: number;
  seconds: number;
  /** Where the effort started, in seconds from the activity start. */
  startSec: number;
  endSec: number;
  paceSecPerKm: number;
}

export interface EffortTarget {
  label: string;
  metres: number;
}

export const RUN_EFFORTS: EffortTarget[] = [
  { label: '400 m', metres: 400 },
  { label: '1 km', metres: 1000 },
  { label: '1 mile', metres: 1609.344 },
  { label: '5 km', metres: 5000 },
  { label: '10 km', metres: 10_000 }
];

export const RIDE_EFFORTS: EffortTarget[] = [
  { label: '1 km', metres: 1000 },
  { label: '5 km', metres: 5000 },
  { label: '10 km', metres: 10_000 },
  { label: '20 km', metres: 20_000 }
];

/**
 * Slides a window over the cumulative distance trace and keeps the shortest
 * time that covers each target. Targets longer than the activity are skipped.
 */
export function bestEfforts(streams: BasicStreams, targets: EffortTarget[] = RUN_EFFORTS): BestEffort[] {
  const { time } = streams;
  if (time.length < 2) return [];

  const distance = cumulativeDistance(streams);
  const total = distance[distance.length - 1];
  const out: BestEffort[] = [];

  for (const target of targets) {
    if (total < target.metres) continue;

    let best = Infinity;
    let bestStart = 0;
    let bestEnd = 0;
    let start = 0;

    for (let end = 1; end < time.length; end++) {
      // Pull the start forward while the window still covers the distance.
      while (start < end && distance[end] - distance[start + 1] >= target.metres) start += 1;
      if (distance[end] - distance[start] < target.metres) continue;

      const seconds = time[end] - time[start];
      if (seconds > 0 && seconds < best) {
        best = seconds;
        bestStart = start;
        bestEnd = end;
      }
    }

    if (!Number.isFinite(best)) continue;
    out.push({
      label: target.label,
      distanceM: target.metres,
      seconds: Math.round(best),
      startSec: time[bestStart],
      endSec: time[bestEnd],
      paceSecPerKm: Math.round(best / (target.metres / 1000))
    });
  }

  return out;
}
