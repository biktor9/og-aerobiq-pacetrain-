import { describe, expect, it } from 'vitest';
import { addDays, toISODate } from './week';
import { baselineOf, feelingLabel, isFeeling, wellnessDays, wellnessSummary, type WellnessEntry } from './wellness';

const TODAY = new Date(2026, 9, 24); // Fri 24 Oct 2026

function entry(offsetDays: number, overrides: Partial<WellnessEntry> = {}): WellnessEntry {
  return {
    date: toISODate(addDays(TODAY, offsetDays)),
    sleepHours: 7.8,
    sleepQuality: 4,
    hrvMs: 62,
    restingHr: 48,
    weightKg: 71.4,
    soreness: 2,
    mood: 4,
    stress: 2,
    feeling: null,
    notes: '',
    ...overrides
  };
}

describe('feelings', () => {
  it('recognises the three answers and labels them', () => {
    expect(isFeeling('worse')).toBe(true);
    expect(isFeeling('meh')).toBe(false);
    expect(feelingLabel('better')).toBe('Better than usual');
    expect(feelingLabel(null)).toBe('Not given');
  });
});

describe('wellnessSummary', () => {
  it('averages the week and compares it with the week before', () => {
    const entries = [
      ...Array.from({ length: 7 }, (_, index) => entry(-13 + index, { sleepHours: 7, hrvMs: 55, restingHr: 50 })),
      ...Array.from({ length: 7 }, (_, index) => entry(-6 + index, { sleepHours: 8, hrvMs: 65, restingHr: 47 }))
    ];
    const summary = wellnessSummary(entries, { today: TODAY });

    expect(summary.filled).toBe(7);
    expect(summary.sleepAvg).toBe(8);
    expect(summary.sleepDelta).toBe(1);
    expect(summary.hrvAvg).toBe(65);
    expect(summary.hrvDelta).toBe(10);
    expect(summary.restingHrAvg).toBe(47);
    expect(summary.restingHrDelta).toBe(-3);
    expect(summary.weightKg).toBe(71.4);
    expect(summary.latest?.date).toBe(toISODate(TODAY));
  });

  it('leaves deltas empty when there is no earlier week', () => {
    const summary = wellnessSummary([entry(0)], { today: TODAY });

    expect(summary.filled).toBe(1);
    expect(summary.sleepDelta).toBeNull();
    expect(summary.hrvDelta).toBeNull();
    expect(summary.restingHrDelta).toBeNull();
  });

  it('takes weight from the most recent entry that has one', () => {
    const summary = wellnessSummary(
      [entry(-3, { weightKg: 70.2 }), entry(-1, { weightKg: null }), entry(0, { weightKg: null })],
      { today: TODAY }
    );
    expect(summary.weightKg).toBe(70.2);
  });
});

describe('baselineOf', () => {
  it('averages the days before today', () => {
    const entries = [entry(-1, { hrvMs: 60 }), entry(-2, { hrvMs: 64 }), entry(0, { hrvMs: 90 })];
    const baseline = baselineOf(entries, 'hrvMs', { today: TODAY, days: 14 });

    expect(baseline.value).toBe(62);
    expect(baseline.days).toBe(2);
  });

  it('ignores days outside the window', () => {
    const entries = [entry(-30, { hrvMs: 40 }), entry(-2, { hrvMs: 60 })];
    expect(baselineOf(entries, 'hrvMs', { today: TODAY, days: 14 }).days).toBe(1);
  });
});

describe('wellnessDays', () => {
  it('keeps a slot for every day, filled or not', () => {
    const days = wellnessDays([entry(0), entry(-2)], { today: TODAY, days: 5 });

    expect(days).toHaveLength(5);
    expect(days[4].date).toBe(toISODate(TODAY));
    expect(days[4].entry).not.toBeNull();
    expect(days[3].entry).toBeNull();
    expect(days[2].entry).not.toBeNull();
  });
});
