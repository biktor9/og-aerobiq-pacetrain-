/**
 * The paywall: four prepaid periods, sold by hand.
 *
 * There is no checkout on the site. The prices are shown, the athlete emails
 * the developer, and the period is switched on from /billing once the payment
 * has arrived (Swish, bank transfer, whatever suits). Access is still a date
 * range — nothing renews by itself and there is nothing to cancel.
 */

export type PlanId = 'trial' | 'quarter' | 'halfYear' | 'year';

export interface BillingPlan {
  id: PlanId;
  name: string;
  /** One-off price in whole kronor. */
  priceSek: number;
  days: number;
  tagline: string;
  perks: string[];
  /** Nothing else can be bought first: this is the cheap look around. */
  trialOnly: boolean;
}

export const PLANS: BillingPlan[] = [
  {
    id: 'trial',
    name: 'Test period',
    priceSek: 10,
    days: 7,
    tagline: 'One week to look around. Once per account.',
    perks: ['The whole site for a week', 'No auto-renew', 'Upgrade any time — days add up'],
    trialOnly: true
  },
  {
    id: 'quarter',
    name: '3 months',
    priceSek: 50,
    days: 91,
    tagline: 'About 3.8 kr a week — one coffee for a build block.',
    perks: ['A full build block', 'Fitness, fatigue and form history', 'Race countdowns and taper phases'],
    trialOnly: false
  },
  {
    id: 'halfYear',
    name: '6 months',
    priceSek: 90,
    days: 182,
    tagline: 'Half a year of training for 90 kr.',
    perks: ['Two build blocks and a taper', 'Season-long trend lines', 'Every new feature we ship'],
    trialOnly: false
  },
  {
    id: 'year',
    name: '12 months',
    priceSek: 140,
    days: 365,
    tagline: 'Best value: a full season for 2.7 kr a week.',
    perks: ['A whole season of training', 'The lowest price per week', 'Every new feature we ship'],
    trialOnly: false
  }
];

export const ACCESS_MESSAGE =
  'All money goes to pay for AI, keep the site running and improving new features.';

export type SubscriptionSource = 'manual' | 'grant' | 'demo';
export type SubscriptionStatus = 'active' | 'canceled';

export interface SubscriptionRecord {
  id: string;
  plan: PlanId;
  status: SubscriptionStatus;
  source: SubscriptionSource;
  amountSek: number;
  reference: string;
  note: string;
  /** ISO timestamps. */
  startedAt: string;
  expiresAt: string;
}

export type AccessReason = 'active' | 'none' | 'expired';

export interface Access {
  active: boolean;
  plan: PlanId | null;
  /** Whole days left, rounded up; 0 once it has run out. */
  daysLeft: number;
  reason: AccessReason;
  expiresAt: string | null;
}

const DAY_MS = 86_400_000;

export function planById(id: string): BillingPlan | null {
  return PLANS.find((plan) => plan.id === id) ?? null;
}

export function isPlanId(value: unknown): value is PlanId {
  return value === 'trial' || value === 'quarter' || value === 'halfYear' || value === 'year';
}

export function isSubscriptionSource(value: unknown): value is SubscriptionSource {
  return value === 'manual' || value === 'grant' || value === 'demo';
}

export function formatSek(amount: number): string {
  return `${Math.round(amount)} kr`;
}

/** Price per week, for the "what does this really cost" line. */
export function perWeek(plan: BillingPlan): number {
  return Math.round((plan.priceSek / (plan.days / 7)) * 10) / 10;
}

/** Is the paid access still valid at `now`? */
export function accessFor(subscription: SubscriptionRecord | null, now: Date = new Date()): Access {
  if (!subscription) {
    return { active: false, plan: null, daysLeft: 0, reason: 'none', expiresAt: null };
  }

  const expires = new Date(subscription.expiresAt);
  const remaining = expires.getTime() - now.getTime();
  const active = Number.isFinite(remaining) && remaining > 0;

  return {
    active,
    plan: subscription.plan,
    daysLeft: active ? Math.ceil(remaining / DAY_MS) : 0,
    reason: active ? 'active' : 'expired',
    expiresAt: subscription.expiresAt
  };
}

/** The 25 kr week can only be bought once. */
export function trialUsed(history: Pick<SubscriptionRecord, 'plan'>[]): boolean {
  return history.some((entry) => entry.plan === 'trial');
}

/**
 * When a new plan would end. Buying while still active adds the days to the
 * end of the current period, so nobody loses paid time by renewing early.
 */
export function periodEnd(
  plan: BillingPlan,
  { subscription = null, now = new Date() }: { subscription?: SubscriptionRecord | null; now?: Date } = {}
): Date {
  const currentEnd = subscription ? new Date(subscription.expiresAt) : null;
  const start = currentEnd && currentEnd.getTime() > now.getTime() ? currentEnd : now;
  return new Date(start.getTime() + plan.days * DAY_MS);
}

/** `2026-10-31` — the date an athlete actually cares about. */
export function expiryLabel(iso: string): string {
  const date = new Date(iso);
  if (!Number.isFinite(date.getTime())) return '';
  return date.toISOString().slice(0, 10);
}

export function planLabel(id: PlanId | null): string {
  if (!id) return 'No plan';
  return planById(id)?.name ?? id;
}
