import { describe, expect, it } from 'vitest';
import { areaAround, heatTotals, isHeatPeriod, latestRoutes, periodStart, routesInArea, type HeatRoute } from '@/domain/heat';
import { toISODate } from '@/domain/week';

const STOCKHOLM: [number, number] = [59.33, 18.06];

function route(id: string, date: string, lat = STOCKHOLM[0], lng = STOCKHOLM[1], spread = 0.01): HeatRoute {
  return {
    id,
    date,
    name: id,
    points: [
      [lat, lng],
      [lat + spread, lng + spread]
    ]
  };
}

describe('periodStart', () => {
  const friday = new Date(2026, 9, 23, 15, 30); // Friday 23 October 2026

  it('starts the week on Monday', () => {
    expect(toISODate(periodStart('week', friday))).toBe('2026-10-19');
  });

  it('starts the month on the first', () => {
    expect(toISODate(periodStart('month', friday))).toBe('2026-10-01');
  });

  it('starts the year in January', () => {
    expect(toISODate(periodStart('year', friday))).toBe('2026-01-01');
  });

  it('handles a Sunday, which belongs to the week that started six days earlier', () => {
    expect(toISODate(periodStart('week', new Date(2026, 9, 25)))).toBe('2026-10-19');
  });
});

describe('isHeatPeriod', () => {
  it('only accepts the three windows', () => {
    expect(isHeatPeriod('week')).toBe(true);
    expect(isHeatPeriod('month')).toBe(true);
    expect(isHeatPeriod('year')).toBe(true);
    expect(isHeatPeriod('decade')).toBe(false);
    expect(isHeatPeriod(null)).toBe(false);
  });
});

describe('routesInArea', () => {
  const area = { lat: STOCKHOLM[0], lng: STOCKHOLM[1], radiusKm: 10, label: 'Stockholm' };

  it('keeps the runs near the centre and drops the ones away from it', () => {
    const kept = routesInArea([route('a', '2026-10-20'), route('b', '2026-10-21', 57.7, 11.97)], area);
    expect(kept.map((entry) => entry.id)).toEqual(['a']);
  });

  it('ignores traces with no points', () => {
    const empty: HeatRoute = { id: 'c', date: '2026-10-22', name: 'c', points: [] };
    expect(routesInArea([empty], area)).toEqual([]);
  });
});

describe('heatTotals', () => {
  it('adds up the kilometres of what is on the map', () => {
    const totals = heatTotals([route('a', '2026-10-20'), route('b', '2026-10-21')]);
    // 0.01 degrees in both directions is about 1.34 km per trace.
    expect(totals.sessions).toBe(2);
    expect(totals.km).toBeCloseTo(2.7, 0);
  });

  it('reports nothing when the map is empty', () => {
    expect(heatTotals([])).toEqual({ sessions: 0, km: 0 });
  });
});

describe('areaAround', () => {
  it('centres the default area on the traces', () => {
    const area = areaAround([route('a', '2026-10-20').points[0], route('a', '2026-10-20').points[1]]);
    expect(area?.lat).toBeCloseTo(59.335, 4);
    expect(area?.radiusKm).toBeGreaterThanOrEqual(2);
    expect(area?.label).toBe('Your area');
  });

  it('has nothing to centre on without points', () => {
    expect(areaAround([])).toBeNull();
  });
});

describe('latestRoutes', () => {
  it('puts the newest first and respects the cap', () => {
    const routes = [route('old', '2026-10-01'), route('new', '2026-10-22'), route('mid', '2026-10-10')];
    expect(latestRoutes(routes).map((entry) => entry.id)).toEqual(['new', 'mid', 'old']);
    expect(latestRoutes(routes, 2)).toHaveLength(2);
  });
});
