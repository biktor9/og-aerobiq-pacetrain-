import { describe, expect, it } from 'vitest';
import { parseRoute, ROUTE_POINTS, serialiseRoute } from '@/domain/route-json';
import type { LatLng } from '@/domain/geo';

describe('route storage', () => {
  it('round-trips a trace', () => {
    const points: LatLng[] = [
      [59.3293456, 18.0684512],
      [59.3299, 18.0689]
    ];
    expect(parseRoute(serialiseRoute(points))).toEqual([
      [59.32935, 18.06845],
      [59.3299, 18.0689]
    ]);
  });

  it('reads a missing or broken value as no route', () => {
    expect(parseRoute(null)).toEqual([]);
    expect(parseRoute('')).toEqual([]);
    expect(parseRoute('not json')).toEqual([]);
    expect(parseRoute('{"lat":59}')).toEqual([]);
    expect(parseRoute('[1,2,3]')).toEqual([]);
  });

  it('drops impossible points rather than drawing them', () => {
    expect(parseRoute(JSON.stringify([[59.33, 18.06], [0, 0], [91, 18]]))).toEqual([[59.33, 18.06]]);
  });

  it('thins a long trace before it is stored', () => {
    const long: LatLng[] = Array.from({ length: 2000 }, (_, index) => [59.3 + index * 1e-5, 18.0]);
    const stored = parseRoute(serialiseRoute(long));

    expect(stored.length).toBeLessThanOrEqual(ROUTE_POINTS + 1);
    expect(stored[stored.length - 1]).toEqual([59.3 + 1999 * 1e-5, 18]);
  });

  it('keeps a run without GPS as an empty trace, not as nothing', () => {
    expect(serialiseRoute([])).toBe('[]');
    expect(parseRoute('[]')).toEqual([]);
  });
});
