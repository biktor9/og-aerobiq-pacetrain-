import type { Block, DetectionResult } from './types';
import { fmtClock } from './week';

/**
 * Planned-versus-actual, computed from the athlete's own words and the detected
 * efforts. Everything here is deterministic: no model call, no cost, and the
 * same session always produces the same verdict.
 */

export interface CompareRow {
  label: string;
  target: string;
  actual: string;
  delta: string;
}

export interface IntentComparison {
  /** Work blocks the athlete described. */
  expectedReps: number;
  actualReps: number;
  rows: CompareRow[];
  /** One line, written to be read as-is. */
  verdict: string;
  /** True when reps match and the work time is within 10%. */
  onTarget: boolean;
}

const TOLERANCE_PCT = 10;

function median(values: number[]): number {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function deltaSeconds(actual: number, target: number): string {
  if (!target) return '—';
  const diff = Math.round(actual - target);
  if (Math.abs(diff) <= 1) return 'on target';
  return `${diff > 0 ? '+' : '−'}${fmtClock(Math.abs(diff))}`;
}

function deltaReps(actual: number, target: number): string {
  const diff = actual - target;
  return diff === 0 ? 'on target' : `${diff > 0 ? '+' : '−'}${Math.abs(diff)}`;
}

function within(actual: number, target: number, pct = TOLERANCE_PCT): boolean {
  if (!target) return false;
  return Math.abs(actual - target) <= (target * pct) / 100;
}

function signedPct(actual: number, target: number): string {
  if (!target) return '0%';
  const pct = Math.round(((actual - target) / target) * 100);
  return `${pct > 0 ? '+' : ''}${pct}%`;
}

/**
 * Compares a detection result with the session as written. Returns `null` when
 * the intent has no work block, because there is nothing to compare against.
 */
export function compareToIntent(
  result: DetectionResult,
  blocks: Block[] | null | undefined
): IntentComparison | null {
  const list = blocks ?? [];
  const work = list.filter((block) => block.kind === 'work');
  if (!work.length) return null;

  const recover = list.filter((block) => block.kind === 'recover');
  const targetWorkSec = median(work.map((block) => block.minutes)) * 60;
  const targetRecoverSec = recover.length ? median(recover.map((block) => block.minutes)) * 60 : 0;
  const targetWorkTimeSec = work.reduce((total, block) => total + block.minutes, 0) * 60;
  const targetTotalSec = list.reduce((total, block) => total + block.minutes, 0) * 60;

  const rows: CompareRow[] = [
    {
      label: 'Reps',
      target: String(work.length),
      actual: String(result.reps),
      delta: deltaReps(result.reps, work.length)
    },
    {
      label: 'Work per rep',
      target: fmtClock(targetWorkSec),
      actual: fmtClock(result.avgWorkSec),
      delta: deltaSeconds(result.avgWorkSec, targetWorkSec)
    }
  ];

  if (targetRecoverSec) {
    rows.push({
      label: 'Recovery',
      target: fmtClock(targetRecoverSec),
      actual: fmtClock(result.avgRecoverSec),
      delta: deltaSeconds(result.avgRecoverSec, targetRecoverSec)
    });
  }

  rows.push(
    {
      label: 'Work time',
      target: fmtClock(targetWorkTimeSec),
      actual: fmtClock(result.workTimeSec),
      delta: deltaSeconds(result.workTimeSec, targetWorkTimeSec)
    },
    {
      label: 'Total time',
      target: fmtClock(targetTotalSec),
      actual: fmtClock(result.durationSec),
      delta: deltaSeconds(result.durationSec, targetTotalSec)
    }
  );

  const parts = [`${result.reps} of ${work.length} reps`];
  if (result.reps > 0) {
    parts.push(
      `avg work ${fmtClock(result.avgWorkSec)} vs ${fmtClock(targetWorkSec)} (${signedPct(result.avgWorkSec, targetWorkSec)})`
    );
  }
  if (targetRecoverSec && result.avgRecoverSec > 0) {
    parts.push(`recovery ${fmtClock(result.avgRecoverSec)} vs ${fmtClock(targetRecoverSec)}`);
  }

  return {
    expectedReps: work.length,
    actualReps: result.reps,
    rows,
    verdict: parts.join(' · '),
    onTarget: result.reps === work.length && within(result.workTimeSec, targetWorkTimeSec)
  };
}
