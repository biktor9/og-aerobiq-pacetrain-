import { describe, expect, it } from 'vitest';
import {
  BETA_TEXT,
  isBlankNote,
  isPageKey,
  normalizeNote,
  pageInfo,
  pageKeyForPath,
  PAGES,
  showNote
} from './page-notes';

describe('the tabs that carry a note', () => {
  it('covers every tab in the nav', () => {
    expect(PAGES.map((page) => page.key)).toEqual([
      'plan',
      'recovery',
      'progress',
      'activities',
      'analysis',
      'coach',
      'settings',
      'admin'
    ]);
  });

  it('says the same beta line everywhere', () => {
    expect(BETA_TEXT).toContain('beta');
  });

  it('gives each tab a path of its own, so one note cannot land on another', () => {
    const paths = PAGES.map((page) => page.path);
    expect(new Set(paths).size).toBe(paths.length);
  });
});

describe('pageKeyForPath', () => {
  it('matches a tab', () => {
    expect(pageKeyForPath('/plan')).toBe('plan');
    expect(pageKeyForPath('/settings')).toBe('settings');
  });

  it('keeps a detail page on its tab', () => {
    expect(pageKeyForPath('/activities/abc-123')).toBe('activities');
    expect(pageKeyForPath('/activities/abc-123?day=2026-10-12')).toBe('activities');
  });

  it('ignores a trailing slash', () => {
    expect(pageKeyForPath('/plan/')).toBe('plan');
  });

  it('has nothing to say about pages outside the app', () => {
    expect(pageKeyForPath('/pricing')).toBeNull();
    expect(pageKeyForPath('/sign-in')).toBeNull();
    expect(pageKeyForPath('/')).toBeNull();
  });

  it('does not confuse a prefix with a tab', () => {
    // `/planner` is not the Plan tab.
    expect(pageKeyForPath('/planner')).toBeNull();
  });
});

describe('normalizeNote', () => {
  it('keeps the line breaks the admin typed', () => {
    expect(normalizeNote('first\nsecond')).toBe('first\nsecond');
  });

  it('normalises Windows line endings', () => {
    expect(normalizeNote('a\r\nb\rc')).toBe('a\nb\nc');
  });

  it('drops trailing spaces and blank lines at either end', () => {
    expect(normalizeNote('\n\n  fixed the calendar   \n\nadded zones\n\n')).toBe('fixed the calendar\n\nadded zones');
  });
});

describe('an empty note', () => {
  it('is how a note is taken down', () => {
    expect(isBlankNote('')).toBe(true);
    expect(isBlankNote('   \n\n \t ')).toBe(true);
    expect(isBlankNote('something')).toBe(false);
  });

  it('is never drawn, even for a viewer', () => {
    expect(showNote('')).toBe(false);
    expect(showNote(null)).toBe(false);
    expect(showNote(undefined)).toBe(false);
    expect(showNote('  \n ')).toBe(false);
    expect(showNote('a change')).toBe(true);
  });
});

describe('pageInfo and isPageKey', () => {
  it('knows a real tab', () => {
    expect(isPageKey('coach')).toBe(true);
    expect(pageInfo('coach')).toEqual({ key: 'coach', path: '/coach', label: 'Coach' });
  });

  it('rejects anything else', () => {
    expect(isPageKey('planner')).toBe(false);
    expect(isPageKey(null)).toBe(false);
    expect(() => pageInfo('nope' as never)).toThrow();
  });
});
