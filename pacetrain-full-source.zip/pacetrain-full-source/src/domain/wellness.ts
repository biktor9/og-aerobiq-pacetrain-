import { addDays, toISODate } from './week';

/**
 * The morning check-in: sleep, overnight HRV, resting heart rate, soreness and
 * how the athlete feels. Averaged here; turned into a recovery score in
 * `domain/recovery.ts`.
 */

export type Feeling = 'better' | 'as-expected' | 'worse';

export interface WellnessEntry {
  date: string;
  sleepHours: number | null;
  /** 1 = terrible … 5 = great */
  sleepQuality: number | null;
  /** Overnight HRV in ms (rMSSD). */
  hrvMs: number | null;
  restingHr: number | null;
  weightKg: number | null;
  /** 1 = fresh … 5 = very sore */
  soreness: number | null;
  /** 1 = drained … 5 = great */
  mood: number | null;
  /** 1 = calm … 5 = very stressed */
  stress: number | null;
  /** The athlete's own correction to the numbers. */
  feeling: Feeling | null;
  /** Free text: "more tired than it says", "hectic week at work". */
  notes: string;
}

export interface WellnessSummary {
  /** Days with an entry inside the window. */
  filled: number;
  sleepAvg: number | null;
  sleepDelta: number | null;
  hrvAvg: number | null;
  hrvDelta: number | null;
  restingHrAvg: number | null;
  restingHrDelta: number | null;
  weightKg: number | null;
  moodAvg: number | null;
  stressAvg: number | null;
  /** The most recent entry, whatever day it was. */
  latest: WellnessEntry | null;
}

export const FEELINGS: { id: Feeling; label: string }[] = [
  { id: 'better', label: 'Better than usual' },
  { id: 'as-expected', label: 'As expected' },
  { id: 'worse', label: 'Worse than usual' }
];

export function isFeeling(value: unknown): value is Feeling {
  return value === 'better' || value === 'as-expected' || value === 'worse';
}

export function feelingLabel(feeling: Feeling | null | undefined): string {
  return FEELINGS.find((item) => item.id === feeling)?.label ?? 'Not given';
}

function average(values: number[]): number | null {
  if (!values.length) return null;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function round1(value: number | null): number | null {
  return value === null ? null : Math.round(value * 10) / 10;
}

function within(entries: WellnessEntry[], from: string, to: string): WellnessEntry[] {
  return entries.filter((entry) => entry.date >= from && entry.date <= to);
}

export type WellnessNumberKey =
  | 'sleepHours'
  | 'sleepQuality'
  | 'hrvMs'
  | 'restingHr'
  | 'soreness'
  | 'mood'
  | 'stress';

/** The finite values of one field. */
export function valuesOf(entries: WellnessEntry[], key: WellnessNumberKey): number[] {
  return entries
    .map((entry) => entry[key])
    .filter((value): value is number => typeof value === 'number' && Number.isFinite(value));
}

/**
 * A personal baseline for one field: the average of the days before today, so
 * this morning's reading is compared with normal, not with itself.
 */
export function baselineOf(
  entries: WellnessEntry[],
  key: WellnessNumberKey,
  { today, days = 14 }: { today?: Date; days?: number } = {}
): { value: number | null; days: number } {
  const start = today ? toISODate(addDays(today, -days)) : null;
  const end = today ? toISODate(addDays(today, -1)) : null;
  const window = entries.filter((entry) => !start || !end || (entry.date >= start && entry.date <= end));
  const values = valuesOf(window, key);
  return { value: average(values), days: values.length };
}

/** Averages over the recent window, with the change against the window before. */
export function wellnessSummary(
  entries: WellnessEntry[],
  { today = new Date(), days = 7 }: { today?: Date; days?: number } = {}
): WellnessSummary {
  const todayISO = toISODate(today);
  const windowStart = toISODate(addDays(today, -(days - 1)));
  const previousStart = toISODate(addDays(today, -(days * 2 - 1)));
  const previousEnd = toISODate(addDays(today, -days));

  const current = within(entries, windowStart, todayISO);
  const previous = within(entries, previousStart, previousEnd);

  const sleepAvg = average(valuesOf(current, 'sleepHours'));
  const sleepBefore = average(valuesOf(previous, 'sleepHours'));
  const hrvAvg = average(valuesOf(current, 'hrvMs'));
  const hrvBefore = average(valuesOf(previous, 'hrvMs'));
  const restingHrAvg = average(valuesOf(current, 'restingHr'));
  const restingHrBefore = average(valuesOf(previous, 'restingHr'));

  const sorted = [...entries].sort((a, b) => (a.date < b.date ? 1 : -1));
  const latestWithWeight = sorted.find((entry) => typeof entry.weightKg === 'number' && entry.weightKg > 0) ?? null;

  return {
    filled: current.length,
    sleepAvg: round1(sleepAvg),
    sleepDelta: sleepAvg !== null && sleepBefore !== null ? round1(sleepAvg - sleepBefore) : null,
    hrvAvg: hrvAvg === null ? null : Math.round(hrvAvg),
    hrvDelta: hrvAvg !== null && hrvBefore !== null ? Math.round(hrvAvg - hrvBefore) : null,
    restingHrAvg: round1(restingHrAvg),
    restingHrDelta: restingHrAvg !== null && restingHrBefore !== null ? round1(restingHrAvg - restingHrBefore) : null,
    weightKg: round1(latestWithWeight?.weightKg ?? null),
    moodAvg: round1(average(valuesOf(current, 'mood'))),
    stressAvg: round1(average(valuesOf(current, 'stress'))),
    latest: sorted[0] ?? null
  };
}

/** The last `days` days, oldest first, with gaps kept so the strip stays aligned. */
export function wellnessDays(
  entries: WellnessEntry[],
  { today = new Date(), days = 14 }: { today?: Date; days?: number } = {}
): { date: string; entry: WellnessEntry | null }[] {
  const byDate = new Map(entries.map((entry) => [entry.date, entry]));
  return Array.from({ length: days }, (_, index) => {
    const date = toISODate(addDays(today, -(days - 1) + index));
    return { date, entry: byDate.get(date) ?? null };
  });
}

