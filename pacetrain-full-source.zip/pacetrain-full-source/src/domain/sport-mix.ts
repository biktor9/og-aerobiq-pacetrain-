import type { Activity, ModeId, Session } from './types';

/**
 * How the week was split across disciplines — the honest replacement for a
 * zone chart that only ever showed the plan. Activities decide the mix when
 * anything has been imported; otherwise the planned sessions do, and the UI
 * says which.
 */

export interface SportSlice {
  mode: ModeId;
  minutes: number;
  km: number;
  count: number;
  /** Whole percent, distributed so the slices add up to exactly 100. */
  share: number;
}

export interface SportMix {
  slices: SportSlice[];
  totalMinutes: number;
  source: 'actual' | 'planned' | 'none';
}

function round1(value: number): number {
  return Math.round(value * 10) / 10;
}

export function sportMix({
  activities = [],
  sessions = []
}: {
  activities?: Activity[];
  /** Used only when nothing has been imported this week. */
  sessions?: Session[];
}): SportMix {
  const byMode = new Map<ModeId, { minutes: number; km: number; count: number }>();

  const add = (mode: ModeId, minutes: number, km: number) => {
    if (!(minutes > 0)) return;
    const row = byMode.get(mode) ?? { minutes: 0, km: 0, count: 0 };
    row.minutes += minutes;
    row.km += km > 0 ? km : 0;
    row.count += 1;
    byMode.set(mode, row);
  };

  for (const activity of activities) {
    add(activity.mode, activity.durationSec > 0 ? activity.durationSec / 60 : 0, activity.distanceM > 0 ? activity.distanceM / 1000 : 0);
  }
  let source: SportMix['source'] = byMode.size ? 'actual' : 'none';

  if (!byMode.size) {
    for (const session of sessions) add(session.mode, session.durationMin, session.targetKm ?? 0);
    if (byMode.size) source = 'planned';
  }

  const slices: SportSlice[] = [...byMode.entries()]
    .map(([mode, row]) => ({
      mode,
      minutes: Math.round(row.minutes),
      km: round1(row.km),
      count: row.count,
      share: 0
    }))
    .filter((slice) => slice.minutes > 0)
    .sort((a, b) => b.minutes - a.minutes || b.km - a.km);

  const totalMinutes = slices.reduce((sum, slice) => sum + slice.minutes, 0);
  if (!totalMinutes) return { slices: [], totalMinutes: 0, source: 'none' };

  // Largest-remainder rounding, so the bar always adds up to 100%.
  const raw = slices.map((slice) => (slice.minutes / totalMinutes) * 100);
  const whole = raw.map(Math.floor);
  let remainder = 100 - whole.reduce((sum, value) => sum + value, 0);
  const order = raw
    .map((value, index) => ({ index, fraction: value - Math.floor(value) }))
    .sort((a, b) => b.fraction - a.fraction);

  for (const item of order) {
    if (remainder <= 0) break;
    whole[item.index] += 1;
    remainder -= 1;
  }

  slices.forEach((slice, index) => {
    slice.share = whole[index];
  });

  return { slices, totalMinutes, source };
}
