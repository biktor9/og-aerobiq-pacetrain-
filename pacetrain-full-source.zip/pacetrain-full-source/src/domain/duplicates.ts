import { disciplineGroup } from './plan-match';
import type { Activity } from './types';

/**
 * Two imports of the same run are the other reason a day looks like it has
 * "double sessions". This finds activities that are almost certainly the same
 * workout: same day, same discipline family, and nearly the same time and
 * distance. It only suggests — nothing is deleted automatically.
 */

export interface DuplicateOptions {
  durationPct: number;
  minSeconds: number;
  distancePct: number;
  minMetres: number;
}

const DEFAULTS: DuplicateOptions = {
  durationPct: 0.05,
  minSeconds: 120,
  distancePct: 0.08,
  minMetres: 300
};

function within(a: number, b: number, pct: number, minimum: number): boolean {
  const diff = Math.abs(a - b);
  return diff <= Math.max(minimum, Math.max(a, b) * pct);
}

function looksLikeTheSameWorkout(a: Activity, b: Activity, options: DuplicateOptions): boolean {
  if (a.date !== b.date) return false;
  if (disciplineGroup(a.mode) !== disciplineGroup(b.mode)) return false;
  if (!within(a.durationSec, b.durationSec, options.durationPct, options.minSeconds)) return false;

  const bothMeasured = a.distanceM > 0 && b.distanceM > 0;
  if (bothMeasured && !within(a.distanceM, b.distanceM, options.distancePct, options.minMetres)) return false;
  return true;
}

/** Groups of activities that look like re-imports of the same workout. */
export function duplicateGroups(activities: Activity[], overrides: Partial<DuplicateOptions> = {}): Activity[][] {
  const options = { ...DEFAULTS, ...overrides };
  const groups: Activity[][] = [];
  const taken = new Set<string>();

  for (let i = 0; i < activities.length; i++) {
    if (taken.has(activities[i].id)) continue;
    const group = [activities[i]];
    for (let j = i + 1; j < activities.length; j++) {
      if (taken.has(activities[j].id)) continue;
      if (looksLikeTheSameWorkout(activities[i], activities[j], options)) {
        group.push(activities[j]);
        taken.add(activities[j].id);
      }
    }
    if (group.length > 1) {
      taken.add(activities[i].id);
      groups.push(group);
    }
  }

  return groups;
}

/** The other activities that look like the same workout, keyed by activity id. */
export function duplicatesById(activities: Activity[], overrides: Partial<DuplicateOptions> = {}): Map<string, Activity[]> {
  const out = new Map<string, Activity[]>();
  for (const group of duplicateGroups(activities, overrides)) {
    for (const activity of group) {
      out.set(
        activity.id,
        group.filter((other) => other.id !== activity.id)
      );
    }
  }
  return out;
}
