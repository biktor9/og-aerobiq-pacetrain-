import { describe, expect, it } from 'vitest';
import { buildSplits, lapsFromIcu, splitsFromLaps } from '@/domain/splits';

const FIVE_MINUTE_PACE = 1000 / 300;

/** Even effort at 1 Hz, with a cumulative distance stream. */
function stream(seconds: number, speed = FIVE_MINUTE_PACE, hr = 150) {
  const time: number[] = [];
  const velocity: number[] = [];
  const heartrate: number[] = [];
  const distance: (number | null)[] = [];

  for (let i = 0; i <= seconds; i++) {
    time.push(i);
    velocity.push(speed);
    heartrate.push(hr);
    distance.push(Math.round(i * speed * 100) / 100);
  }

  return { time, velocity, heartrate, distance };
}

/** A session built from explicit speed blocks, then sampled at 1 Hz. */
function piecewise(segments: { seconds: number; speed: number }[], hr = 150) {
  const time: number[] = [];
  const velocity: number[] = [];
  const heartrate: number[] = [];
  const distance: (number | null)[] = [];

  let second = 0;
  let metres = 0;
  for (const segment of segments) {
    for (let i = 0; i < segment.seconds; i++) {
      time.push(second);
      velocity.push(segment.speed);
      heartrate.push(hr);
      distance.push(Math.round(metres * 100) / 100);
      metres += segment.speed;
      second += 1;
    }
  }
  time.push(second);
  velocity.push(0);
  heartrate.push(hr);
  distance.push(Math.round(metres * 100) / 100);

  return { time, velocity, heartrate, distance };
}

describe('buildSplits', () => {
  it('cuts a steady effort into kilometres', () => {
    const splits = buildSplits(stream(1500));

    expect(splits.rows).toHaveLength(5);
    expect(splits.totalM).toBeCloseTo(5000, 0);
    expect(splits.totalSec).toBe(1500);
    expect(splits.avgPaceSecPerKm).toBeCloseTo(300, 0);
    for (const row of splits.rows) {
      expect(row.durationSec).toBe(300);
      expect(row.distanceM).toBe(1000);
      expect(row.paceSecPerKm).toBeCloseTo(300, 0);
      expect(row.partial).toBe(false);
    }
  });

  it('folds a short tail into the last kilometre', () => {
    const splits = buildSplits(stream(945)); // 3150 m

    expect(splits.rows).toHaveLength(3);
    const last = splits.rows[2];
    expect(last.partial).toBe(false);
    expect(last.distanceM).toBeCloseTo(1150, 0);
    expect(last.durationSec).toBeCloseTo(345, 0);
  });

  it('keeps a long tail as its own partial split', () => {
    const splits = buildSplits(stream(1020)); // 3400 m

    expect(splits.rows).toHaveLength(4);
    const last = splits.rows[3];
    expect(last.partial).toBe(true);
    expect(last.distanceM).toBeCloseTo(400, 0);
    expect(last.durationSec).toBeCloseTo(120, 0);
    expect(last.paceSecPerKm).toBeCloseTo(300, 0);
  });

  it('finds the fastest and slowest kilometre and the pace deltas', () => {
    const splits = buildSplits(
      piecewise([
        { seconds: 250, speed: 4 }, // 1 km at 4:10/km
        { seconds: 700, speed: 1000 / 350 } // 2 km at 5:50/km
      ])
    );

    expect(splits.rows).toHaveLength(3);
    expect(splits.rows[0].paceSecPerKm).toBeCloseTo(250, 0);
    expect(splits.fastest?.index).toBe(1);
    expect(splits.slowest?.index).toBeGreaterThan(1);
    expect(splits.rows[0].deltaVsAveragePaceSec).toBeLessThan(0);
    expect(splits.rows[1].deltaVsAveragePaceSec).toBeGreaterThan(0);
  });

  it('adds up climbing per kilometre', () => {
    const flat = stream(700);
    const altitude = flat.time.map((second) => 100 + second / 2);
    const splits = buildSplits({ ...flat, altitude });

    expect(splits.rows[0].gainM).toBeCloseTo(150, 0);
    expect(splits.rows[0].lossM).toBe(0);
    expect(splits.biggestClimb?.index).toBe(1);
  });

  it('reads heart rate across each split', () => {
    const splits = buildSplits(stream(600, FIVE_MINUTE_PACE, 155));
    expect(splits.rows[0].avgHr).toBe(155);
    expect(splits.rows[0].maxHr).toBe(155);
  });

  it('integrates speed when the distance stream is missing', () => {
    const { distance: _distance, ...withoutDistance } = stream(1500);
    const splits = buildSplits(withoutDistance);

    expect(splits.rows).toHaveLength(5);
    expect(splits.totalM).toBeCloseTo(5000, 0);
  });

  it('returns nothing to split when the activity never moved', () => {
    const idle = stream(300, 0);
    const splits = buildSplits(idle);

    expect(splits.rows).toHaveLength(0);
    expect(splits.avgPaceSecPerKm).toBeNull();
    expect(splits.fastest).toBeNull();
    expect(splits.biggestClimb).toBeNull();
  });
});

describe('buildSplits against the device totals', () => {
  it('scales the trace to the distance the device recorded', () => {
    // The trace lost a tenth of its distance; the watch still says 5 km.
    const streams = stream(1500);
    const short = {
      ...streams,
      distance: streams.distance.map((value) => (value === null ? null : value * 0.9))
    };

    const splits = buildSplits(short, 1000, { distanceM: 5000 });

    expect(splits.totalM).toBeCloseTo(5000, 0);
    expect(splits.rows).toHaveLength(5);
    // 25:00 over 5 km is 5:00/km, whatever the trace claims.
    expect(splits.avgPaceSecPerKm).toBeCloseTo(300, 0);
  });

  it('scales the clock when the stream is short of the session time', () => {
    const splits = buildSplits(stream(1350), 1000, { distanceM: 4500, durationSec: 1500 });

    expect(splits.totalSec).toBe(1500);
    expect(splits.avgPaceSecPerKm).toBeCloseTo(1500 / 4.5, 0);
  });

  it('leaves a one percent drift alone', () => {
    const splits = buildSplits(stream(1500), 1000, { distanceM: 5050, durationSec: 1512 });

    expect(splits.totalM).toBeCloseTo(5000, 0);
    expect(splits.totalSec).toBe(1500);
  });
});

describe('splitsFromLaps', () => {
  /** Ten kilometres run as laps, the eighth one with a stop in it. */
  function kilometreLaps() {
    return [
      { durationSec: 300, distanceM: 1000, avgHr: 148, maxHr: 155 },
      { durationSec: 298, distanceM: 1000, avgHr: 150, maxHr: 156 },
      { durationSec: 302, distanceM: 1000, avgHr: 151, maxHr: 158 },
      { durationSec: 299, distanceM: 1000, avgHr: 152, maxHr: 159 },
      { durationSec: 301, distanceM: 1000, avgHr: 153, maxHr: 160 },
      { durationSec: 303, distanceM: 1000, avgHr: 154, maxHr: 161 },
      { durationSec: 300, distanceM: 1000, avgHr: 156, maxHr: 163 },
      // A red light: the watch counted 340 s over the same kilometre.
      { durationSec: 340, distanceM: 1000, avgHr: 150, maxHr: 168 },
      { durationSec: 297, distanceM: 1000, avgHr: 160, maxHr: 170 },
      { durationSec: 295, distanceM: 1000, avgHr: 162, maxHr: 172 }
    ];
  }

  it('takes the watch’s split times as they are, stop and all', () => {
    const report = splitsFromLaps(kilometreLaps());

    expect(report.source).toBe('laps');
    expect(report.rows).toHaveLength(10);
    expect(report.rows[0].paceSecPerKm).toBe(300);
    // The kilometre with the red light stays a 5:40, exactly as recorded.
    expect(Math.round(report.rows[7].paceSecPerKm ?? 0)).toBe(340);
    expect(report.slowest?.index).toBe(8);
    expect(report.fastest?.index).toBe(10);
    expect(report.totalM).toBe(10_000);
    expect(report.totalSec).toBe(300 + 298 + 302 + 299 + 301 + 303 + 300 + 340 + 297 + 295);
  });

  it('leaves a short warm-up lap and a recovery jog out of the table', () => {
    const report = splitsFromLaps([
      { durationSec: 60, distanceM: 180 },
      { durationSec: 120, distanceM: 300, intensity: 60 },
      { durationSec: 300, distanceM: 1000 },
      { durationSec: 290, distanceM: 1000 },
      { durationSec: 60, distanceM: 150 }
    ]);

    expect(report.rows.map((row) => row.distanceM)).toEqual([1000, 1000]);
    expect(report.rows.every((row) => !row.partial)).toBe(true);
  });
});

describe('lapsFromIcu', () => {
  it('reads moving time, distance, heart rate and the start of each lap', () => {
    const { laps, totalM, totalSec } = lapsFromIcu(
      [
        { moving_time: 300, distance: 1000, average_heartrate: 150.4, max_heartrate: 155.6, start_index: 0 },
        { moving_time: 290, distance: 1000, average_heartrate: 152, max_heartrate: 160, start_index: 300 }
      ],
      { movingTimeSec: 590 }
    );

    expect(laps).toHaveLength(2);
    expect(laps[0]).toMatchObject({ startSec: 0, durationSec: 300, distanceM: 1000, avgHr: 150, maxHr: 156 });
    expect(laps[1].startSec).toBe(300);
    expect(totalM).toBe(2000);
    expect(totalSec).toBe(590);
  });

  it('marks recovery laps when the watch labelled them', () => {
    const { laps } = lapsFromIcu(
      [
        { moving_time: 960, distance: 4000, label: 'Work' },
        { moving_time: 120, distance: 300, label: 'Recovery' },
        { moving_time: 960, distance: 4000, label: 'Work' }
      ],
      { movingTimeSec: 2040 }
    );

    expect(laps.map((lap) => lap.recovery)).toEqual([false, true, false]);
  });

  it('says nothing when the athlete only lapped part of the run', () => {
    const result = lapsFromIcu([{ moving_time: 300, distance: 1000 }], { movingTimeSec: 3600 });
    expect(result.laps).toHaveLength(0);
  });
});

