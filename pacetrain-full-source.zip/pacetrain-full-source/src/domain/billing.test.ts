import { describe, expect, it } from 'vitest';
import {
  PLANS,
  accessFor,
  expiryLabel,
  formatSek,
  perWeek,
  periodEnd,
  planById,
  planLabel,
  trialUsed,
  type SubscriptionRecord
} from './billing';

const NOW = new Date('2026-10-24T09:00:00.000Z');

function subscription(overrides: Partial<SubscriptionRecord> = {}): SubscriptionRecord {
  return {
    id: 'sub-1',
    plan: 'halfYear',
    status: 'active',
    source: 'grant',
    amountSek: 80,
    reference: '',
    note: '',
    startedAt: '2026-10-01T00:00:00.000Z',
    expiresAt: '2027-04-01T00:00:00.000Z',
    ...overrides
  };
}

describe('the plans', () => {
  it('prices a test week at 10 kr, 3 months at 50, 6 months at 90 and a year at 140', () => {
    expect(planById('trial')).toMatchObject({ priceSek: 10, days: 7, trialOnly: true });
    expect(planById('quarter')).toMatchObject({ priceSek: 50, days: 91, trialOnly: false });
    expect(planById('halfYear')).toMatchObject({ priceSek: 90, days: 182, trialOnly: false });
    expect(planById('year')).toMatchObject({ priceSek: 140, days: 365, trialOnly: false });
    expect(PLANS).toHaveLength(4);
  });

  it('works out what a period costs per week', () => {
    expect(perWeek(planById('trial')!)).toBe(10);
    expect(perWeek(planById('quarter')!)).toBe(3.8);
    expect(perWeek(planById('halfYear')!)).toBe(3.5);
    expect(perWeek(planById('year')!)).toBe(2.7);
  });

  it('formats kronor and labels a period', () => {
    expect(formatSek(90)).toBe('90 kr');
    expect(planLabel('year')).toBe('12 months');
    expect(planLabel('quarter')).toBe('3 months');
    expect(planLabel(null)).toBe('No plan');
  });
});

describe('accessFor', () => {
  it('is active while the paid period has not run out', () => {
    const access = accessFor(subscription(), NOW);

    expect(access.active).toBe(true);
    expect(access.reason).toBe('active');
    expect(access.plan).toBe('halfYear');
    expect(access.daysLeft).toBe(159);
    expect(access.expiresAt).toBe('2027-04-01T00:00:00.000Z');
  });

  it('expires the moment the period ends', () => {
    const access = accessFor(subscription({ expiresAt: '2026-10-20T00:00:00.000Z' }), NOW);

    expect(access.active).toBe(false);
    expect(access.reason).toBe('expired');
    expect(access.daysLeft).toBe(0);
    expect(access.plan).toBe('halfYear');
  });

  it('keeps a cancelled period usable until it ends', () => {
    const access = accessFor(subscription({ status: 'canceled' }), NOW);
    expect(access.active).toBe(true);
  });

  it('treats a missing subscription as no access', () => {
    expect(accessFor(null, NOW)).toMatchObject({ active: false, reason: 'none', daysLeft: 0, plan: null });
  });

  it('rounds partial days up', () => {
    const access = accessFor(subscription({ expiresAt: '2026-10-25T08:00:00.000Z' }), NOW);
    expect(access.daysLeft).toBe(1);
  });
});

describe('trialUsed', () => {
  it('allows one trial per account', () => {
    expect(trialUsed([])).toBe(false);
    expect(trialUsed([{ plan: 'trial' }])).toBe(true);
    expect(trialUsed([{ plan: 'halfYear' }])).toBe(false);
  });
});

describe('periodEnd', () => {
  it('runs from today when nothing is active', () => {
    const end = periodEnd(planById('halfYear')!, { now: NOW });
    expect(expiryLabel(end.toISOString())).toBe('2027-04-24');
  });

  it('adds to the end of the current period when renewing early', () => {
    const end = periodEnd(planById('year')!, { subscription: subscription(), now: NOW });
    // 2027-04-01 plus 365 days lands on 2028-03-31 because 2028 is a leap year.
    expect(expiryLabel(end.toISOString())).toBe('2028-03-31');
  });

  it('starts a fresh period when the old one already ended', () => {
    const end = periodEnd(planById('trial')!, {
      subscription: subscription({ expiresAt: '2026-10-01T00:00:00.000Z' }),
      now: NOW
    });
    expect(expiryLabel(end.toISOString())).toBe('2026-10-31');
  });
});
