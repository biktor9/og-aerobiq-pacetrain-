import {
  cumulativeDistance,
  elevationBetween,
  maxOf,
  mean,
  numbers,
  type BasicStreams
} from './streams';

/**
 * Kilometre splits — the table every runner looks at first.
 *
 * Two ways to cut the same table, in order of trust:
 *
 * 1. **From the laps the watch recorded.** intervals.icu keeps every lap, and its
 *    own splits are those laps with the pauses taken out. Re-deriving the
 *    kilometres from GPS used to drift away from them: a stop at a light, a
 *    tunnel, a watch that auto-pauses more eagerly all moved a boundary, and the
 *    table showed a 4:12 eighth kilometre next to intervals.icu's 4:35.
 * 2. **From the trace**, when there are no laps at all. Splits are cut at the
 *    moment the cumulative distance passes each kilometre, interpolated between
 *    samples, and the total is matched to the device's own distance and time.
 *
 * Recovery laps (a 2:00 jog between reps) and the short warm-up lap a watch
 * writes by itself are not kilometre splits, so they are left out.
 */

export interface SplitRow {
  /** 1-based kilometre number. */
  index: number;
  startSec: number;
  endSec: number;
  durationSec: number;
  distanceM: number;
  paceSecPerKm: number | null;
  avgHr: number | null;
  maxHr: number | null;
  gainM: number | null;
  lossM: number | null;
  /** This kilometre's pace minus the session average (positive = slower). */
  deltaVsAveragePaceSec: number | null;
  /** True for a short final split that was too long to fold into the last km. */
  partial: boolean;
}

export interface SplitsReport {
  rows: SplitRow[];
  unitM: number;
  totalM: number;
  totalSec: number;
  avgPaceSecPerKm: number | null;
  fastest: SplitRow | null;
  slowest: SplitRow | null;
  biggestClimb: SplitRow | null;
  /** Where the rows came from: the watch's own laps, or the trace. */
  source: 'laps' | 'trace';
}

/** A lap as intervals.icu records it. */
export interface LapSplitInput {
  durationSec: number;
  distanceM: number;
  avgHr?: number | null;
  maxHr?: number | null;
  /** Seconds from the start of the activity. */
  startSec?: number;
  /** intervals.icu's shared intensity, when it sent one. */
  intensity?: number | null;
  /** True for a recovery/recovery-style lap, which is never a split. */
  recovery?: boolean;
}

/** The device's own totals, used to match the trace to what the athlete was told. */
export interface SplitTotals {
  distanceM?: number | null;
  durationSec?: number | null;
}

/**
 * How far the trace has to be nudged to agree with the device. GPS distance
 * drifts by a percent or two, which is left alone; a larger gap means a missing
 * or broken stream, and matching the device beats printing an impossible pace.
 */
function scaleFactor(measured: number, expected: number | null | undefined): number {
  if (!expected || !(measured > 0) || !(expected > 0)) return 1;
  const ratio = expected / measured;
  if (Math.abs(ratio - 1) <= 0.02 || ratio < 0.5 || ratio > 2) return 1;
  return ratio;
}

/** A tail shorter than this folds into the last full split instead of its own row. */
const MIN_REMAINDER_M = 200;
/** Below this a split has no meaningful pace. */
const MIN_DISTANCE_M = 25;

interface Boundary {
  sec: number;
  /** First sample that belongs to the next split. */
  index: number;
  metres: number;
}

function makeRow(
  streams: BasicStreams,
  index: number,
  from: Boundary,
  to: Boundary,
  distanceM: number,
  partial: boolean
): SplitRow {
  const durationSec = Math.max(1, Math.round(to.sec - from.sec));
  const paceSecPerKm = distanceM >= MIN_DISTANCE_M ? durationSec / (distanceM / 1000) : null;

  const beats = numbers(streams.heartrate, from.index, to.index);
  const peak = maxOf(beats);
  const elevation = elevationBetween(streams.altitude, from.index, to.index);

  return {
    index,
    startSec: from.sec,
    endSec: to.sec,
    durationSec,
    distanceM,
    paceSecPerKm,
    avgHr: beats.length ? Math.round(mean(beats)) : null,
    maxHr: peak === null ? null : Math.round(peak),
    gainM: elevation ? Math.round(elevation.gainM) : null,
    lossM: elevation ? Math.round(elevation.lossM) : null,
    deltaVsAveragePaceSec: null,
    partial
  };
}

function paceOf(row: SplitRow): number {
  return row.paceSecPerKm ?? Number.POSITIVE_INFINITY;
}

/** Splits for one activity. Pure: streams in, table out. */
export function buildSplits(streams: BasicStreams, unitM = 1000, totals: SplitTotals = {}): SplitsReport {
  const empty: SplitsReport = {
    rows: [],
    unitM,
    totalM: 0,
    totalSec: 0,
    avgPaceSecPerKm: null,
    fastest: null,
    slowest: null,
    biggestClimb: null,
    source: 'trace'
  };
  if (streams.time.length < 2) return empty;

  const raw = cumulativeDistance(streams);
  // The device's own totals win when the trace disagrees with them, so the
  // splits add up to the distance and time printed at the top of the page.
  const measuredM = raw.length ? raw[raw.length - 1] : 0;
  const distanceScale = scaleFactor(measuredM, totals.distanceM);

  const firstSec = streams.time[0];
  const spanSec = streams.time[streams.time.length - 1] - firstSec;
  const timeScale = scaleFactor(spanSec, totals.durationSec);
  const time =
    timeScale === 1 ? streams.time : streams.time.map((sec) => firstSec + (sec - firstSec) * timeScale);
  const source: BasicStreams = timeScale === 1 ? streams : { ...streams, time };

  const cumulative = distanceScale === 1 ? raw : raw.map((metres) => metres * distanceScale);
  const totalM = cumulative[cumulative.length - 1];
  const startSec = time[0];
  const endSec = time[time.length - 1];
  const totalSec = Math.max(0, Math.round(endSec - startSec));
  if (!(totalM > 0) || totalSec <= 0) return { ...empty, totalSec };

  const boundaries: Boundary[] = [{ sec: startSec, index: 0, metres: 0 }];
  let cursor = 1;
  for (let km = 1; km * unitM <= totalM; km++) {
    const target = km * unitM;
    while (cursor < cumulative.length - 1 && cumulative[cursor] < target) cursor++;
    if (cumulative[cursor] < target) break;

    const before = Math.max(0, cursor - 1);
    const span = cumulative[cursor] - cumulative[before];
    const ratio = span > 0 ? (target - cumulative[before]) / span : 0;
    const sec = time[before] + ratio * (time[cursor] - time[before]);
    boundaries.push({ sec, index: cursor, metres: target });
  }

  const rows: SplitRow[] = [];
  for (let i = 1; i < boundaries.length; i++) {
    rows.push(makeRow(source, i, boundaries[i - 1], boundaries[i], unitM, false));
  }

  const finish: Boundary = { sec: endSec, index: time.length, metres: totalM };
  const lastBoundary = boundaries[boundaries.length - 1];
  const remainderM = totalM - lastBoundary.metres;

  if (remainderM > 0 && endSec > lastBoundary.sec) {
    const beforeLast = boundaries[boundaries.length - 2];
    if (remainderM < MIN_REMAINDER_M && rows.length && beforeLast) {
      // A 60 m kick to the line is not a split — fold it into the last kilometre.
      rows[rows.length - 1] = makeRow(source, rows.length, beforeLast, finish, unitM + remainderM, false);
    } else {
      rows.push(makeRow(source, rows.length + 1, lastBoundary, finish, remainderM, true));
    }
  }

  const avgPaceSecPerKm = totalM >= MIN_DISTANCE_M ? totalSec / (totalM / 1000) : null;
  for (const row of rows) {
    row.deltaVsAveragePaceSec =
      row.paceSecPerKm !== null && avgPaceSecPerKm !== null ? row.paceSecPerKm - avgPaceSecPerKm : null;
  }

  return summarise(rows, unitM, totalM, totalSec, avgPaceSecPerKm, 'trace');
}

/** Fastest, slowest and the biggest climb, plus the totals. */
function summarise(
  rows: SplitRow[],
  unitM: number,
  totalM: number,
  totalSec: number,
  avgPaceSecPerKm: number | null,
  source: SplitsReport['source']
): SplitsReport {
  const paced = rows.filter((row) => row.paceSecPerKm !== null);
  const comparable = paced.filter((row) => !row.partial);
  const pool = comparable.length ? comparable : paced;
  const fastest = pool.length ? pool.reduce((best, row) => (paceOf(row) < paceOf(best) ? row : best)) : null;
  const slowest = pool.length ? pool.reduce((best, row) => (paceOf(row) > paceOf(best) ? row : best)) : null;
  const climbs = rows.filter((row) => row.gainM !== null);
  const biggestClimb = climbs.length
    ? climbs.reduce((best, row) => ((row.gainM ?? 0) > (best.gainM ?? 0) ? row : best))
    : null;

  return { rows, unitM, totalM, totalSec, avgPaceSecPerKm, fastest, slowest, biggestClimb, source };
}

/** A first or last lap shorter than this is warm-up or cool-down, not a split. */
const EDGE_LAP_M = 250;

/**
 * Splits from the laps the watch recorded — the same laps intervals.icu shows.
 *
 * These are the athlete's own kilometres, so nothing is recalculated: distance,
 * time and heart rate are taken as recorded. Laps that are not kilometres are
 * dropped — a recovery jog between reps, and the short lap a watch writes when
 * Start is pressed before the first full kilometre — because a 0.12 km "split"
 * at 3:10/km is how the table got strange in the first place.
 */
export function splitsFromLaps(laps: LapSplitInput[], unitM = 1000): SplitsReport {
  const usable = laps
    .filter((lap) => Number.isFinite(lap.durationSec) && lap.durationSec > 0)
    .filter((lap) => Number.isFinite(lap.distanceM) && lap.distanceM > 0)
    .filter((lap) => !lap.recovery);

  const hadLaps = usable.length > 0;
  const rows: SplitRow[] = [];
  let elapsed = 0;

  for (let index = 0; index < usable.length; index++) {
    const lap = usable[index];
    const startSec = lap.startSec ?? elapsed;
    const durationSec = Math.round(lap.durationSec);
    elapsed = startSec + durationSec;

    const isEdge = index === 0 || index === usable.length - 1;
    const tooShort = lap.distanceM < EDGE_LAP_M;
    // A short lap in the middle is a surge or a jog; on an interval session it
    // is the recovery. Neither belongs in a kilometre table.
    const midRunShort = !isEdge && lap.distanceM < unitM * 0.6;
    const easyLabel = !isEdge && lap.intensity != null && lap.intensity < 85;
    if ((isEdge && tooShort) || midRunShort || easyLabel) continue;

    rows.push({
      index: rows.length + 1,
      startSec,
      endSec: startSec + durationSec,
      durationSec,
      distanceM: Math.round(lap.distanceM),
      paceSecPerKm: lap.distanceM >= MIN_DISTANCE_M ? durationSec / (lap.distanceM / 1000) : null,
      avgHr: lap.avgHr ?? null,
      maxHr: lap.maxHr ?? null,
      gainM: null,
      lossM: null,
      deltaVsAveragePaceSec: null,
      partial: lap.distanceM < unitM * 0.95
    });
  }

  if (!rows.length) return summarise([], unitM, 0, 0, null, hadLaps ? 'laps' : 'trace');

  const totalM = rows.reduce((sum, row) => sum + row.distanceM, 0);
  const totalSec = rows.reduce((sum, row) => sum + row.durationSec, 0);
  const avgPaceSecPerKm = totalM >= MIN_DISTANCE_M ? totalSec / (totalM / 1000) : null;
  for (const row of rows) {
    row.deltaVsAveragePaceSec =
      row.paceSecPerKm !== null && avgPaceSecPerKm !== null ? row.paceSecPerKm - avgPaceSecPerKm : null;
  }

  return summarise(rows, unitM, totalM, totalSec, avgPaceSecPerKm, 'laps');
}

/**
 * Reads the lap list intervals.icu returns for one activity into something the
 * splits table can use. `movingTimeSec` is the activity's own moving time: when
 * the laps cover less than that, the athlete only lapped part of the run, and
 * the trace is the better source for the kilometres they did not lap.
 */
export function lapsFromIcu(
  raw: {
    moving_time?: number;
    elapsed_time?: number;
    distance?: number;
    average_heartrate?: number | null;
    max_heartrate?: number | null;
    start_index?: number;
    type?: string;
    label?: string | null;
  }[],
  { movingTimeSec }: { movingTimeSec?: number | null } = {}
): { laps: LapSplitInput[]; totalM: number; totalSec: number } {
  // Some watches label every lap; a recovery is then recognisable by name.
  const labelled = raw.some((lap) => /recover|rest|warm ?up|cool ?down|easy/i.test(lap.label ?? lap.type ?? ''));
  const laps: LapSplitInput[] = [];
  let cursor = 0;

  for (const lap of raw) {
    const duration = lap.moving_time ?? lap.elapsed_time ?? 0;
    const distance = lap.distance ?? 0;
    if (!(duration > 0)) continue;
    const start = lap.start_index ?? cursor;
    cursor = start + duration;
    const label = `${lap.label ?? ''} ${lap.type ?? ''}`.toLowerCase();
    laps.push({
      startSec: start,
      durationSec: duration,
      distanceM: distance,
      avgHr: lap.average_heartrate ? Math.round(lap.average_heartrate) : null,
      maxHr: lap.max_heartrate ? Math.round(lap.max_heartrate) : null,
      recovery: labelled && /recover|rest|cool ?down|easy/.test(label)
    });
  }

  const totalM = laps.reduce((sum, lap) => sum + lap.distanceM, 0);
  const totalSec = laps.reduce((sum, lap) => sum + lap.durationSec, 0);
  if (movingTimeSec && totalSec < movingTimeSec * 0.9) {
    return { laps: [], totalM: 0, totalSec: 0 };
  }
  return { laps, totalM, totalSec };
}

