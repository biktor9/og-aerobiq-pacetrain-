import { describe, expect, it } from 'vitest';
import { isSickOn, recoveryScore, sickDays, type SickNote } from './recovery';
import type { WellnessEntry } from './wellness';

const TODAY = '2026-10-24';

function entry(date: string, overrides: Partial<WellnessEntry> = {}): WellnessEntry {
  return {
    date,
    sleepHours: 7.5,
    sleepQuality: 3,
    hrvMs: 60,
    restingHr: 50,
    weightKg: 71,
    soreness: 3,
    mood: 3,
    stress: 3,
    feeling: null,
    notes: '',
    ...overrides
  };
}

/** Fourteen calm days before today, so today can be compared with something. */
function history(): WellnessEntry[] {
  return Array.from({ length: 14 }, (_, index) => {
    const day = String(10 + index).padStart(2, '0');
    return entry(`2026-10-${day}`);
  });
}

function sick(overrides: Partial<SickNote> = {}): SickNote {
  return { dateFrom: TODAY, dateTo: TODAY, symptoms: 'Sore throat', severity: 2, notes: '', ...overrides };
}

describe('recoveryScore', () => {
  it('says the body is ready when HRV is up and sleep was long', () => {
    const result = recoveryScore({
      today: entry(TODAY, { hrvMs: 68, restingHr: 47, sleepHours: 8.2, sleepQuality: 5, soreness: 1, stress: 1, feeling: 'better' }),
      entries: history(),
      form: { tsb: 5, atl: 40 },
      todayISO: TODAY
    });

    expect(result.score).toBeGreaterThanOrEqual(85);
    expect(result.tone).toBe('good');
    expect(result.label).toBe('Ready to push');
    expect(result.signals.find((signal) => signal.key === 'hrv')?.detail).toMatch(/against your 14-day normal/);
  });

  it('drops hard when HRV is suppressed, the heart rate is up and sleep is short', () => {
    const result = recoveryScore({
      today: entry(TODAY, { hrvMs: 44, restingHr: 58, sleepHours: 5.2, sleepQuality: 2, soreness: 5, stress: 5, feeling: 'worse' }),
      entries: history(),
      form: { tsb: -30, atl: 70 },
      todayISO: TODAY
    });

    expect(result.score).toBeLessThan(30);
    expect(result.tone).toBe('bad');
    expect(result.label).toBe('Rest');
    expect(result.signals.map((signal) => signal.key)).toEqual(
      expect.arrayContaining(['hrv', 'restingHr', 'sleep', 'sleepQuality', 'soreness', 'stress', 'load', 'feeling'])
    );
  });

  it('lets the athlete overrule the numbers', () => {
    const base = recoveryScore({ today: entry(TODAY), entries: history(), todayISO: TODAY });
    const worse = recoveryScore({ today: entry(TODAY, { feeling: 'worse' }), entries: history(), todayISO: TODAY });
    const better = recoveryScore({ today: entry(TODAY, { feeling: 'better' }), entries: history(), todayISO: TODAY });

    expect(worse.score).toBeLessThan(base.score);
    expect(better.score).toBeGreaterThan(base.score);
    expect(worse.signals.find((signal) => signal.key === 'feeling')?.detail).toMatch(/worse/);
  });

  it('overrides everything when the athlete is sick', () => {
    const result = recoveryScore({
      today: entry(TODAY, { hrvMs: 70, sleepHours: 9 }),
      entries: history(),
      sick: [sick()],
      todayISO: TODAY
    });

    expect(result.sick).toBe(true);
    expect(result.score).toBeLessThanOrEqual(22);
    expect(result.label).toBe('Rest');
    expect(result.summary).toMatch(/sick/i);
  });

  it('is honest when nothing has been logged', () => {
    const result = recoveryScore({ today: null, entries: [], todayISO: TODAY });

    expect(result.hasData).toBe(false);
    expect(result.score).toBe(72);
    expect(result.summary).toMatch(/No morning data yet/);
  });

  it('marks a young baseline as not ready yet', () => {
    const result = recoveryScore({ today: entry(TODAY), entries: [entry('2026-10-23')], todayISO: TODAY });
    expect(result.signals.find((signal) => signal.key === 'hrv')?.verdict).toBe('neutral');
  });
});

describe('sick days', () => {
  it('knows which days an illness covers', () => {
    const notes = [sick({ dateFrom: '2026-10-22', dateTo: '2026-10-25' })];
    expect(isSickOn(notes, '2026-10-21')).toBe(false);
    expect(isSickOn(notes, '2026-10-23')).toBe(true);
    expect(sickDays(notes)).toEqual(['2026-10-22', '2026-10-23', '2026-10-24', '2026-10-25']);
  });

  it('handles a single day and several periods', () => {
    const notes = [sick(), sick({ dateFrom: '2026-11-01', dateTo: '2026-11-02' })];
    expect(sickDays(notes)).toEqual(['2026-10-24', '2026-11-01', '2026-11-02']);
  });
});

describe('recoveryScore with manual baselines', () => {
  it('measures the morning against the number the athlete typed', () => {
    const today = entry(TODAY, { hrvMs: 70 });

    // Ten calm nights at 60 ms: an HRV of 70 is 17 % up, so the average says good.
    const rolling = recoveryScore({ today, entries: history(), todayISO: TODAY });
    // Typed at 70 ms, the same morning is exactly normal.
    const manual = recoveryScore({
      today,
      entries: history(),
      todayISO: TODAY,
      baselines: { hrvMs: 70 }
    });

    expect(rolling.score).toBeGreaterThan(manual.score);
    expect(manual.signals.find((signal) => signal.key === 'hrv')?.detail).toContain('your own baseline of 70 ms');
  });

  it('counts a resting heart rate against the typed resting heart rate', () => {
    const today = entry(TODAY, { restingHr: 56 });
    const result = recoveryScore({
      today,
      entries: history(),
      todayISO: TODAY,
      baselines: { restingHr: 55 }
    });

    const signal = result.signals.find((entry) => entry.key === 'restingHr');
    expect(signal?.detail).toContain('own baseline of 55 bpm');
    expect(signal?.verdict).toBe('ok');
  });

  it('uses a typed sleep baseline instead of the 7.5 h target', () => {
    const today = entry(TODAY, { sleepHours: 7 });
    const result = recoveryScore({
      today,
      entries: history(),
      todayISO: TODAY,
      baselines: { sleepHours: 7 }
    });

    const signal = result.signals.find((entry) => entry.key === 'sleep');
    expect(signal?.detail).toContain('7.0 h baseline');
    expect(signal?.verdict).toBe('good');
  });

  it('falls back to the average for a field left empty', () => {
    const today = entry(TODAY);
    const result = recoveryScore({
      today,
      entries: history(),
      todayISO: TODAY,
      baselines: { hrvMs: null, restingHr: 55 }
    });

    expect(result.signals.find((signal) => signal.key === 'hrv')?.detail).toContain('14-day normal');
  });
});

