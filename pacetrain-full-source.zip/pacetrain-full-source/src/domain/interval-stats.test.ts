import { describe, expect, it } from 'vitest';
import { buildIntervalReport, formatSpan } from '@/domain/interval-stats';
import type { Segment } from '@/domain/types';

function work(index: number, startSec: number, durationSec: number): Segment {
  return {
    index,
    kind: 'work',
    startSec,
    endSec: startSec + durationSec,
    durationSec,
    avg: 300,
    max: 320,
    min: 280
  };
}

function rest(index: number, startSec: number, durationSec: number): Segment {
  return { ...work(index, startSec, durationSec), kind: 'recover' };
}

/** A flat, even effort sampled at 1 Hz. */
function stream(seconds: number, speed: number, hr = 160) {
  const time: number[] = [];
  const velocity: number[] = [];
  const heartrate: number[] = [];
  const distance: (number | null)[] = [];
  const altitude: (number | null)[] = [];

  for (let i = 0; i <= seconds; i++) {
    time.push(i);
    velocity.push(speed);
    heartrate.push(hr);
    distance.push(Math.round(i * speed * 100) / 100);
    altitude.push(50);
  }

  return { time, velocity, heartrate, distance, altitude };
}

/** 5:00/km — 200 m every 60 s. */
const FIVE_MINUTE_PACE = 1000 / 300;

describe('buildIntervalReport', () => {
  it('gives every rep its distance, pace and heart rate', () => {
    const segments = [work(1, 60, 240), work(2, 420, 240), work(3, 780, 240), work(4, 1140, 240)];
    const report = buildIntervalReport(segments, stream(1500, FIVE_MINUTE_PACE));

    expect(report.rows).toHaveLength(4);
    const first = report.rows[0];
    expect(first.durationSec).toBe(240);
    expect(first.distanceM).toBeCloseTo(800, 0);
    expect(first.paceSecPerKm).toBeCloseTo(300, 0);
    expect(first.avgHr).toBe(160);
    expect(first.maxHr).toBe(160);
    expect(first.gainM).toBe(0);
    expect(first.lossM).toBe(0);
  });

  it('totals the work and averages it by time', () => {
    const segments = [work(1, 60, 240), work(2, 420, 240), work(3, 780, 240), work(4, 1140, 240)];
    const report = buildIntervalReport(segments, stream(1500, FIVE_MINUTE_PACE));

    expect(report.totals.count).toBe(4);
    expect(report.totals.timeSec).toBe(960);
    expect(report.totals.distanceM).toBeCloseTo(3200, 0);
    expect(report.totals.avgDurationSec).toBe(240);
    expect(report.totals.paceSecPerKm).toBeCloseTo(300, 0);
    expect(report.totals.avgHr).toBe(160);
    expect(report.totals.maxHr).toBe(160);
  });

  it('groups reps of the same length and leaves a different set alone', () => {
    const segments = [work(1, 0, 240), work(2, 300, 240), work(3, 600, 180), work(4, 900, 180)];
    const report = buildIntervalReport(segments, stream(1200, FIVE_MINUTE_PACE));

    expect(report.groups.map((group) => group.count)).toEqual([2, 2]);
    expect(report.groups.map((group) => group.label)).toEqual(['3′', '4′']);
    expect(report.rows[0].sameLengthLabel).toBe('4′');
    expect(report.rows[0].sameLengthCount).toBe(2);
    expect(report.rows[2].sameLengthCount).toBe(2);
  });

  it('keeps lengths within eight percent in one group and splits past it', () => {
    const close = buildIntervalReport(
      [work(1, 0, 240), work(2, 300, 255), work(3, 600, 258)],
      stream(1000, FIVE_MINUTE_PACE)
    );
    expect(close.groups).toHaveLength(1);
    expect(close.groups[0].count).toBe(3);

    const far = buildIntervalReport([work(1, 0, 240), work(2, 300, 300)], stream(1000, FIVE_MINUTE_PACE));
    expect(far.groups).toHaveLength(2);
  });

  it('compares each rep with the average of its own set', () => {
    const segments = [work(1, 0, 240), work(2, 300, 240), work(3, 600, 250)];
    const report = buildIntervalReport(segments, stream(1000, FIVE_MINUTE_PACE));

    expect(report.groups).toHaveLength(1);
    expect(report.rows[0].deltaVsAverageSec).toBeCloseTo(-3.3, 0);
    expect(report.rows[0].deltaVsSameLengthSec).toBeCloseTo(-3.3, 0);
    expect(report.rows[2].deltaVsSameLengthSec).toBeCloseTo(6.7, 0);
    expect(report.rows[0].deltaVsSameLengthPaceSec).toBeCloseTo(0, 3);
  });

  it('ignores recoveries when reporting work', () => {
    const report = buildIntervalReport([work(1, 0, 240), rest(2, 240, 120), work(3, 360, 240)], stream(700, FIVE_MINUTE_PACE));
    expect(report.rows).toHaveLength(2);
    expect(report.rows.map((row) => row.index)).toEqual([1, 2]);
  });

  it('integrates speed when the activity has no distance stream', () => {
    const { distance: _distance, ...withoutDistance } = stream(1500, FIVE_MINUTE_PACE);
    const report = buildIntervalReport([work(1, 60, 240)], withoutDistance);

    expect(report.rows[0].distanceM).toBeCloseTo(800, 0);
    expect(report.rows[0].paceSecPerKm).toBeCloseTo(300, 0);
  });

  it('adds up climbing from the altitude stream', () => {
    const flat = stream(700, FIVE_MINUTE_PACE);
    const altitude = flat.time.map((second) => 50 + second / 2);
    const report = buildIntervalReport([work(1, 0, 240)], { ...flat, altitude });

    expect(report.rows[0].gainM).toBeCloseTo(120, 0);
    expect(report.rows[0].lossM).toBe(0);
    expect(report.totals.gainM).toBeCloseTo(120, 0);
  });

  it('falls back to the detected durations when a stream is missing', () => {
    const report = buildIntervalReport([work(1, 60, 240)], { time: [] });

    expect(report.rows[0].durationSec).toBe(240);
    expect(report.rows[0].distanceM).toBeNull();
    expect(report.rows[0].paceSecPerKm).toBeNull();
    expect(report.rows[0].avgHr).toBeNull();
    expect(report.totals.distanceM).toBeNull();
    expect(report.totals.avgHr).toBeNull();
  });

  it('formats rep lengths the way a coach says them', () => {
    expect(formatSpan(45)).toBe('45″');
    expect(formatSpan(240)).toBe('4′');
    expect(formatSpan(270)).toBe('4′30″');
  });
});
