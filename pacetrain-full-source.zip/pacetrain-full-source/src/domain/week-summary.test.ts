import { describe, expect, it } from 'vitest';
import { toSession } from './plan';
import type { Activity, ModeId, Session, SessionStatus } from './types';
import { addWeeks, startOfWeek, weekKey } from './week';
import { buildCalendarWeeks, buildWeekStrip, buildWeekSummary, heatLevel } from './week-summary';

function activity(overrides: Partial<Activity> & { id: string; date: string }): Activity {
  return {
    externalId: overrides.id,
    mode: 'run',
    name: 'Run',
    durationSec: 3600,
    distanceM: 10_000,
    avgHr: null,
    maxHr: null,
    load: null,
    source: 'intervals.icu',
    linkedSessionId: null,
    ...overrides
  };
}

function session(
  date: string,
  minutes: number,
  status: SessionStatus = 'planned',
  mode: ModeId = 'run',
  targetKm: number | null = null
): Session {
  return toSession({
    id: `s-${date}-${minutes}-${status}-${mode}`,
    date,
    mode,
    kind: 'steady',
    title: 'Session',
    zone: 2,
    minutes,
    targetKm,
    reps: 1,
    workMin: minutes,
    recoverMin: 0,
    warmupMin: 0,
    cooldownMin: 0,
    notes: '',
    status,
    structure: null,
    linkedActivityId: null
  });
}

const MONDAY = new Date(2026, 9, 19); // Mon 19 Oct 2026
const TODAY = new Date(2026, 9, 21); // Wed 21 Oct 2026

describe('heatLevel', () => {
  it('maps minutes onto five shades', () => {
    expect(heatLevel(0)).toBe(0);
    expect(heatLevel(10)).toBe(1);
    expect(heatLevel(30)).toBe(2);
    expect(heatLevel(60)).toBe(3);
    expect(heatLevel(120)).toBe(4);
  });
});

describe('buildWeekSummary', () => {
  const activities = [
    activity({ id: 'a', date: '2026-10-19', durationSec: 3600, distanceM: 10_000 }),
    activity({ id: 'b', date: '2026-10-20', durationSec: 1800, distanceM: 5000 }),
    activity({ id: 'c', date: '2026-10-21', mode: 'bike', durationSec: 2700, distanceM: 8000 })
  ];
  const sessions = [
    session('2026-10-19', 60, 'done'),
    session('2026-10-20', 30),
    session('2026-10-21', 45),
    session('2026-10-22', 50),
    session('2026-10-23', 40)
  ];

  it('adds up what actually happened, running and everything else', () => {
    const week = buildWeekSummary({ monday: MONDAY, activities, sessions, today: TODAY });

    expect(week.key).toBe(weekKey(MONDAY));
    expect(week.label).toBe('19–25 Oct 2026');
    expect(week.days).toHaveLength(7);
    expect(week.activities).toBe(3);
    expect(week.runs).toBe(2);
    expect(week.km).toBe(23);
    expect(week.runningKm).toBe(15);
    expect(week.minutes).toBe(135);
    expect(week.trainedDays).toBe(3);
    expect(week.sessions).toBe(5);
    expect(week.done).toBe(2);
  });

  it('measures the plan against the days that have already happened', () => {
    const week = buildWeekSummary({ monday: MONDAY, activities, sessions, today: TODAY });

    expect(week.plannedMinutes).toBe(225);
    expect(week.plannedSoFarMinutes).toBe(135);
    expect(week.doneMinutes).toBe(135);
    expect(week.donePct).toBe(100);
  });

  it('counts a missed day against the athlete', () => {
    const week = buildWeekSummary({ monday: MONDAY, activities: activities.slice(0, 2), sessions, today: TODAY });

    expect(week.doneMinutes).toBe(90);
    expect(week.donePct).toBe(67);
  });

  it('marks today and the days still to come', () => {
    const week = buildWeekSummary({ monday: MONDAY, activities, sessions, today: TODAY });
    const [monday, , wednesday, thursday] = week.days;

    expect(monday.isToday).toBe(false);
    expect(monday.isFuture).toBe(false);
    expect(wednesday.isToday).toBe(true);
    expect(thursday.isFuture).toBe(true);
    expect(monday.level).toBe(3);
    expect(thursday.level).toBe(0);
    expect(monday.planned).toBe(1);
  });

  it('treats a finished week as fully due', () => {
    const week = buildWeekSummary({ monday: MONDAY, activities, sessions, today: new Date(2026, 9, 26) });

    expect(week.plannedSoFarMinutes).toBe(225);
    expect(week.donePct).toBe(60);
    expect(week.isCurrentWeek).toBe(false);
  });

  it('survives an empty week', () => {
    const week = buildWeekSummary({ monday: MONDAY, activities: [], sessions: [], today: TODAY });

    expect(week.minutes).toBe(0);
    expect(week.donePct).toBe(0);
    expect(week.trainedDays).toBe(0);
    expect(week.days.every((day) => day.level === 0)).toBe(true);
  });

  it('counts a session as done when an activity is behind it', () => {
    const week = buildWeekSummary({
      monday: MONDAY,
      activities: [activity({ id: 'a', date: '2026-10-19', durationSec: 3600, distanceM: 10_000 })],
      sessions: [session('2026-10-19', 60), session('2026-10-20', 30)],
      today: new Date(2026, 9, 26)
    });

    expect(week.done).toBe(1);
    expect(week.days[0].done).toBe(1);
    expect(week.days[1].done).toBe(0);
  });

  it('keeps a session marked done by hand even without an activity', () => {
    const week = buildWeekSummary({
      monday: MONDAY,
      activities: [],
      sessions: [session('2026-10-19', 60, 'done')],
      today: new Date(2026, 9, 26)
    });

    expect(week.done).toBe(1);
    expect(week.minutes).toBe(0);
  });
});

describe('buildWeekStrip', () => {
  it('returns four weeks, oldest first, ending with the given Monday', () => {
    const strip = buildWeekStrip({
      monday: MONDAY,
      weeks: 4,
      activities: [activity({ id: 'a', date: '2026-10-01' })],
      sessions: [session('2026-10-19', 60)],
      today: TODAY
    });

    expect(strip).toHaveLength(4);
    expect(strip[3].key).toBe(weekKey(MONDAY));
    expect(strip[0].key).toBe(weekKey(addWeeks(MONDAY, -3)));
    expect(strip.map((week) => week.monday)).toEqual([
      '2026-09-28',
      '2026-10-05',
      '2026-10-12',
      '2026-10-19'
    ]);
    expect(strip[0].km).toBe(10);
    expect(strip[3].plannedMinutes).toBe(60);
    expect(strip[3].isCurrentWeek).toBe(true);
    expect(strip[0].isCurrentWeek).toBe(false);
  });
});

describe('plan done so far and the forecast', () => {
  // Monday and Tuesday done, Wednesday skipped, Thursday still to come.
  const sessions = [
    session('2026-10-19', 60, 'planned', 'run', 10),
    session('2026-10-20', 40, 'planned', 'run', 7),
    session('2026-10-21', 45, 'skipped', 'run', 8),
    session('2026-10-22', 50, 'planned', 'run', 9)
  ];
  const activities = [
    activity({ id: 'a', date: '2026-10-19', durationSec: 3600, distanceM: 10_000 }),
    activity({ id: 'b', date: '2026-10-20', durationSec: 2340, distanceM: 7000 })
  ];
  const week = buildWeekSummary({ monday: MONDAY, activities, sessions, today: TODAY });

  it('counts finished sessions as their planned time', () => {
    // 60′ and 40′ of plan are behind the athlete; the 45′ skip is off the plan,
    // so 100′ are due and all of them happened.
    expect(week.plannedSoFarMinutes).toBe(100);
    expect(week.donePlanMinutes).toBe(100);
    expect(week.donePlanPct).toBe(100);
  });

  it('leaves the skipped session out of the forecast, hours and kilometres alike', () => {
    // 60 + 40 + 45 skipped + 50: what the plan holds once the skip is dropped.
    expect(week.forecastMinutes).toBe(150);
    expect(week.plannedRunningKm).toBe(26);
    // 34 km planned in total; the 8 km skipped session is not going to happen.
    expect(week.forecastRunningKm).toBe(26);
    expect(week.skippedMinutes).toBe(45);
    expect(week.skippedKm).toBe(8);
  });

  it('keeps a session marked done by hand in the plan', () => {
    const done = buildWeekSummary({
      monday: MONDAY,
      activities: [],
      sessions: [session('2026-10-19', 60, 'done', 'run', 10), session('2026-10-20', 30, 'skipped')],
      today: new Date(2026, 9, 26)
    });

    expect(done.donePlanMinutes).toBe(60);
    expect(done.donePlanPct).toBe(100);
    expect(done.skippedMinutes).toBe(30);
  });

  it('counts the time actually trained for a session left unticked', () => {
    const partDone = buildWeekSummary({
      monday: MONDAY,
      activities: [activity({ id: 'a', date: '2026-10-19', durationSec: 1800, distanceM: 5000, mode: 'bike' })],
      sessions: [session('2026-10-19', 60)],
      today: new Date(2026, 9, 26)
    });

    // Half an hour of riding against an hour of plan.
    expect(partDone.donePlanMinutes).toBe(30);
    expect(partDone.donePlanPct).toBe(50);
  });
});


describe('a week only counts its own days', () => {
  // This is the bug that made every week show the same plan: the strip hands
  // each week the whole window's rows, and a week must ignore what is outside it.
  const sessions = [
    session('2026-10-12', 60, 'planned', 'run', 12),
    session('2026-10-19', 60, 'planned', 'run', 10),
    session('2026-10-20', 40, 'planned', 'run', 7),
    session('2026-10-26', 50, 'planned', 'run', 9)
  ];
  const activities = [
    activity({ id: 'a', date: '2026-10-19', durationSec: 3600, distanceM: 10_000 }),
    activity({ id: 'b', date: '2026-10-27', durationSec: 1800, distanceM: 5000 })
  ];

  it('leaves out the plan of the weeks either side', () => {
    const week = buildWeekSummary({ monday: MONDAY, activities, sessions, today: new Date(2026, 9, 26) });

    expect(week.plannedMinutes).toBe(100);
    expect(week.plannedRunningKm).toBe(17);
    expect(week.sessions).toBe(2);
    expect(week.runningKm).toBe(10);
  });

  it('gives a week with nothing in it nothing', () => {
    const empty = buildWeekSummary({
      monday: addWeeks(MONDAY, 1),
      activities,
      sessions,
      today: new Date(2026, 9, 26)
    });

    // Only Tuesday's half hour belongs to the week after.
    expect(empty.plannedMinutes).toBe(50);
    expect(empty.runningKm).toBe(5);
    expect(empty.donePlanMinutes).toBe(0);
  });

  it('counts the same figures for a strip as for a single week', () => {
    const strip = buildWeekStrip({ monday: MONDAY, weeks: 3, activities, sessions, today: new Date(2026, 9, 26) });
    const single = buildWeekSummary({ monday: MONDAY, activities, sessions, today: new Date(2026, 9, 26) });

    const fromStrip = strip[strip.length - 1];
    expect(fromStrip.plannedMinutes).toBe(single.plannedMinutes);
    expect(fromStrip.plannedRunningKm).toBe(single.plannedRunningKm);
    expect(fromStrip.runningKm).toBe(single.runningKm);
  });
});

describe('buildCalendarWeeks', () => {
  it('shows the last three weeks, this week, then next week', () => {
    const today = new Date(2026, 9, 28); // Wed 28 Oct 2026
    const weeks = buildCalendarWeeks({ monday: startOfWeek(today), activities: [], sessions: [], today });

    expect(weeks).toHaveLength(5);
    expect(weeks.map((week) => week.monday)).toEqual([
      '2026-10-05',
      '2026-10-12',
      '2026-10-19',
      '2026-10-26',
      '2026-11-02'
    ]);
    // Only the second-to-last row is the current week; the last is next week.
    expect(weeks.filter((week) => week.isCurrentWeek)).toHaveLength(1);
    expect(weeks[3].isCurrentWeek).toBe(true);
    expect(weeks[4].key).toBe('2026-W45');
  });
});

describe('a skipped session', () => {
  it('is not done, even when the watch recorded something that day', () => {
    const week = buildWeekSummary({
      monday: MONDAY,
      activities: [activity({ id: 'a', date: '2026-10-19', durationSec: 3600, distanceM: 10_000 })],
      sessions: [session('2026-10-19', 60, 'skipped')],
      today: new Date(2026, 9, 25)
    });

    expect(week.done).toBe(0);
    expect(week.skipped).toBe(1);
    expect(week.donePlanMinutes).toBe(0);
    expect(week.plannedSoFarMinutes).toBe(0);
  });
});

