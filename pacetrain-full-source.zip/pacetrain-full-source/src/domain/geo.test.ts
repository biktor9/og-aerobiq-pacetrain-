import { describe, expect, it } from 'vitest';
import {
  centreOf,
  clampZoom,
  haversineM,
  isLatLng,
  project,
  radiusOf,
  roundRoute,
  routeBounds,
  routeDistanceM,
  routeTouchesArea,
  simplifyRoute,
  tileRange,
  unproject,
  withinRadius,
  zoomForRadius,
  type LatLng
} from '@/domain/geo';

describe('isLatLng', () => {
  it('rejects impossible coordinates', () => {
    expect(isLatLng([91, 18])).toBe(false);
    expect(isLatLng([59, 181])).toBe(false);
    expect(isLatLng([Number.NaN, 18])).toBe(false);
    expect(isLatLng([59.33, 18.06])).toBe(true);
  });
});

describe('distance', () => {
  it('measures Stockholm to Uppsala', () => {
    // 59.3293, 18.0686 → 59.8586, 17.6389 is about 64 km.
    const km = haversineM([59.3293, 18.0686], [59.8586, 17.6389]) / 1000;
    expect(km).toBeGreaterThan(60);
    expect(km).toBeLessThan(70);
  });

  it('knows what is inside the area', () => {
    expect(withinRadius([59.34, 18.07], [59.33, 18.06], 5)).toBe(true);
    expect(withinRadius([59.86, 17.64], [59.33, 18.06], 5)).toBe(false);
  });

  it('adds up a trace', () => {
    const line: LatLng[] = [
      [59.33, 18.06],
      [59.34, 18.06],
      [59.35, 18.06]
    ];
    // 0.02 degrees of latitude is about 2.2 km.
    expect(routeDistanceM(line) / 1000).toBeCloseTo(2.22, 1);
  });

  it('sees a route that only passes through the area', () => {
    const line: LatLng[] = [
      [59.2, 18.06],
      [59.33, 18.06],
      [59.46, 18.06]
    ];
    expect(routeTouchesArea(line, [59.33, 18.06], 1)).toBe(true);
    expect(routeTouchesArea(line, [60.5, 18.06], 1)).toBe(false);
  });
});

describe('route shape', () => {
  it('boxes a trace and finds its centre', () => {
    const bounds = routeBounds([
      [59.3, 18.0],
      [59.4, 18.2]
    ]);
    expect(bounds).not.toBeNull();
    const centre = centreOf(bounds!);
    expect(centre[0]).toBeCloseTo(59.35, 6);
    expect(centre[1]).toBeCloseTo(18.1, 6);
    expect(radiusOf(bounds!)).toBeGreaterThan(6);
  });

  it('thins a long trace and keeps the finish', () => {
    const points: LatLng[] = Array.from({ length: 1001 }, (_, index) => [59.3 + index * 1e-4, 18.0]);
    const thin = simplifyRoute(points, 100);

    expect(thin.length).toBeLessThanOrEqual(101);
    expect(thin[thin.length - 1]).toEqual(points[points.length - 1]);
  });

  it('drops samples that did not move', () => {
    const still: LatLng[] = [
      [59.33, 18.06],
      [59.33, 18.06],
      [59.331, 18.061]
    ];
    expect(simplifyRoute(still)).toEqual([
      [59.33, 18.06],
      [59.331, 18.061]
    ]);
  });

  it('rounds to about a metre', () => {
    expect(roundRoute([[59.32934567, 18.06845123]])).toEqual([[59.32935, 18.06845]]);
  });
});

describe('Web Mercator', () => {
  it('projects and unprojects back', () => {
    const pixel = project(59.33, 18.06, 12);
    const [lat, lng] = unproject(pixel.x, pixel.y, 12);
    expect(lat).toBeCloseTo(59.33, 6);
    expect(lng).toBeCloseTo(18.06, 6);
  });

  it('puts the equator and Greenwich at the middle of the world', () => {
    const middle = project(0, 0, 1);
    expect(middle.x).toBeCloseTo(256, 5);
    expect(middle.y).toBeCloseTo(256, 5);
  });

  it('clamps the zoom to what tile servers hold', () => {
    expect(clampZoom(40)).toBe(18);
    expect(clampZoom(-2)).toBe(3);
  });

  it('picks a zoom that fits the area', () => {
    const tight = zoomForRadius(2, 800, 400);
    const wide = zoomForRadius(40, 800, 400);
    expect(tight).toBeGreaterThan(wide);
    expect(wide).toBeGreaterThanOrEqual(3);
  });

  it('covers the viewport with tiles', () => {
    const tiles = tileRange([59.33, 18.06], 12, 640, 320);
    // Two rows and a few columns, never more than one spare tile each way.
    expect(tiles.length).toBeGreaterThanOrEqual(6);
    expect(tiles.every((tile) => tile.y >= 0 && tile.x >= 0)).toBe(true);
    // The tile under the centre sits in the middle of the view.
    const centred = tiles.find((tile) => tile.left <= 320 && tile.left + 256 > 320);
    expect(centred).toBeDefined();
  });
});
