/**
 * Core training vocabulary. Everything here is plain data so it can be shared by
 * the planner, the interval detector, the data import and the coach.
 */

/** The training disciplines the planner knows about. */
export const MODE_ID_VALUES = ['run', 'trail', 'orienteering', 'ski', 'strength', 'mtb', 'bike'] as const;

export type ModeId = (typeof MODE_ID_VALUES)[number];

export interface ModeInfo {
  id: ModeId;
  label: string;
  short: string;
  color: string;
}

export const MODES: ModeInfo[] = [
  { id: 'run', label: 'Running', short: 'RUN', color: '#2f6fed' },
  { id: 'trail', label: 'Trail', short: 'TRL', color: '#1f9d6d' },
  { id: 'orienteering', label: 'Orienteering', short: 'ORI', color: '#0f9488' },
  { id: 'ski', label: 'Ski', short: 'SKI', color: '#7c5cd6' },
  { id: 'strength', label: 'Strength', short: 'STR', color: '#b7791f' },
  { id: 'mtb', label: 'MTB', short: 'MTB', color: '#c2410c' },
  { id: 'bike', label: 'Bike', short: 'BIK', color: '#0891b2' }
];

export const MODE_IDS: readonly ModeId[] = MODE_ID_VALUES;

/** Modes that existed before the vocabulary was widened, and what they became. */
export const LEGACY_MODE_ALIASES: Record<string, ModeId> = {
  rollerski: 'ski'
};

export function isModeId(value: unknown): value is ModeId {
  return typeof value === 'string' && (MODE_IDS as readonly string[]).includes(value);
}

/**
 * Accepts stored values, form input and legacy names. Anything unknown falls
 * back to running, which is what the app has always done.
 */
export function normalizeMode(value: unknown): ModeId {
  if (isModeId(value)) return value;
  if (typeof value === 'string') {
    const key = value.trim().toLowerCase();
    if (isModeId(key)) return key;
    const alias = LEGACY_MODE_ALIASES[key];
    if (alias) return alias;
  }
  return 'run';
}

export function mode(id: ModeId) {
  return MODES.find((m) => m.id === id) ?? MODES[0];
}

export const ZONES = [
  { id: 1, label: 'Z1', name: 'Recovery', short: 'easy', factor: 0.55, color: '#8fb3f2' },
  { id: 2, label: 'Z2', name: 'Aerobic', short: 'steady', factor: 0.68, color: '#4c9be8' },
  { id: 3, label: 'Z3', name: 'Tempo', short: 'tempo', factor: 0.82, color: '#d9a521' },
  { id: 4, label: 'Z4', name: 'Threshold', short: 'hard', factor: 0.92, color: '#e2703a' },
  { id: 5, label: 'Z5', name: 'VO2max', short: 'max', factor: 1.05, color: '#d1495b' }
] as const;

export type ZoneId = 1 | 2 | 3 | 4 | 5;
export const ZONE_IDS = [1, 2, 3, 4, 5] as ZoneId[];

/**
 * The share of maximum heart rate each zone is usually anchored at, so a
 * session planned in zones can be read as time in heart-rate zones. The watch
 * never records zones, it records beats — this is the bridge between them.
 */
const ZONE_HR_SHARE: Record<ZoneId, number> = { 1: 0.6, 2: 0.7, 3: 0.8, 4: 0.88, 5: 0.95 };

export function zoneHrShare(zoneId: number): number {
  return ZONE_HR_SHARE[(zoneId as ZoneId) in ZONE_HR_SHARE ? (zoneId as ZoneId) : 2];
}

/** The zone a heart rate falls in, given the athlete's maximum. */
export function zoneForHr(hr: number, maxHr: number): ZoneId {
  const share = hr / Math.max(120, maxHr);
  if (share >= 0.93) return 5;
  if (share >= 0.84) return 4;
  if (share >= 0.76) return 3;
  if (share >= 0.65) return 2;
  return 1;
}

export function zone(id: number) {
  return ZONES.find((z) => z.id === id) ?? ZONES[0];
}

/** Strength sessions use effort bands rather than endurance zones. */
const STRENGTH_ZONES = ['Technique', 'Base', 'Build', 'Heavy', 'Max'];

export function zoneName(modeId: ModeId, zoneId: number): string {
  if (modeId === 'strength') return STRENGTH_ZONES[zoneId - 1] ?? STRENGTH_ZONES[0];
  return zone(zoneId).name;
}

export type SessionKind = 'steady' | 'intervals' | 'strength';
export type BlockKind = 'warmup' | 'work' | 'recover' | 'cooldown';
export type SessionStatus = 'planned' | 'done' | 'skipped';

export interface Block {
  kind: BlockKind;
  minutes: number;
  zone: number;
}

/**
 * Durations that may be left blank. An interval session can be planned with its
 * zone and total time only — the reps are written down once the athlete knows
 * them — so "not chosen yet" is a real state and is stored as `null`.
 */
export interface SessionInput {
  date: string; // YYYY-MM-DD
  mode: ModeId;
  kind: SessionKind;
  title: string;
  zone: number;
  /** Duration of a steady or strength session, in minutes. Ignored for intervals. */
  minutes: number;
  /**
   * Distance target in kilometres, for sessions planned by distance. Optional:
   * `minutes` stays the load driver and this is what the athlete committed to.
   * For an interval set with reps this is the session's **total** distance
   * (warm-up, reps and cool-down included), not the length of one rep.
   */
  targetKm?: number | null;
  /** `null` while the interval session has no rep count yet. */
  reps: number | null;
  /** `null` while the work length is not decided. */
  workMin: number | null;
  /** Recovery between reps. `null` means "not chosen yet", `0` means none. */
  recoverMin: number | null;
  warmupMin: number;
  cooldownMin: number;
  /**
   * Warm-up and cool-down written in kilometres. A set value wins over the
   * minutes, which are then derived from the athlete's own easy pace.
   */
  warmupKm?: number | null;
  cooldownKm?: number | null;
  /** Kilometres per rep, for interval sessions planned by distance (`8×800 m`). */
  targetReps?: number | null;
  notes: string;
  status: SessionStatus;
  /**
   * An explicit block list, usually parsed from the athlete's own words. When
   * present it replaces the scalar fields above as the session's structure.
   */
  structure?: Block[] | null;
}

/** A session with its derived structure, as rendered by the app. */
export interface Session extends SessionInput {
  id: string;
  linkedActivityId: string | null;
  blocks: Block[];
  durationMin: number;
}

export interface Activity {
  id: string;
  externalId: string;
  date: string;
  mode: ModeId;
  name: string;
  durationSec: number;
  distanceM: number;
  avgHr: number | null;
  maxHr: number | null;
  load: number | null;
  /** intervals.icu's average moving speed in m/s, when the import carried it. */
  avgSpeedMs?: number | null;
  /**
   * Seconds in heart-rate zones Z1 … Z5, exactly as intervals.icu computed them.
   * When present these replace the estimate made from average and peak heart rate.
   */
  hrZoneSec?: number[] | null;
  source: 'intervals.icu' | 'demo' | 'manual';
  linkedSessionId: string | null;
  /** 1–10 perceived effort, when the athlete rated it. */
  rpe?: number | null;
  /** 1–5 how the session felt, when rated. */
  feel?: number | null;
  notes?: string;
  /** Soft-deleted: hidden everywhere, kept so a re-import cannot bring it back. */
  removed?: boolean;
}

export interface Segment {
  index: number;
  kind: 'work' | 'recover';
  startSec: number;
  endSec: number;
  durationSec: number;
  avg: number;
  max: number;
  min: number;
  /**
   * How the rep is written when it came from a lap: `800m`, `16′`, `90″`.
   * Absent for segments found in the stream, which are labelled by duration.
   */
  label?: string;
}

export interface DetectionResult {
  metric: 'power' | 'hr' | 'pace' | 'speed';
  metricLabel: string;
  unit: string;
  threshold: number;
  reps: number;
  segments: Segment[];
  work: Segment[];
  recover: Segment[];
  durationSec: number;
  workTimeSec: number;
  recoverTimeSec: number;
  avgWorkSec: number;
  avgRecoverSec: number;
  /** Coefficient of variation of work durations, in percent. */
  consistency: number;
  /** Change from the first work segment average to the last, in percent. */
  driftPct: number;
}

export const METRICS = [
  { id: 'power', label: 'Power', unit: 'W' },
  { id: 'hr', label: 'Heart rate', unit: 'bpm' },
  { id: 'pace', label: 'Pace', unit: '/km' },
  { id: 'speed', label: 'Speed', unit: 'km/h' }
] as const;

export type MetricId = (typeof METRICS)[number]['id'];
