import { describe, expect, it } from 'vitest';
import { disciplineGroup, doneSessionIds, pairByDate, pairDay } from './plan-match';
import { toSession } from './plan';
import type { Activity, ModeId, Session, SessionStatus } from './types';

function session(
  id: string,
  date: string,
  overrides: { mode?: ModeId; minutes?: number; status?: SessionStatus; linkedActivityId?: string | null } = {}
): Session {
  const minutes = overrides.minutes ?? 60;
  return toSession({
    id,
    date,
    mode: overrides.mode ?? 'run',
    kind: 'steady',
    title: 'Session',
    zone: 2,
    minutes,
    targetKm: null,
    reps: 1,
    workMin: minutes,
    recoverMin: 0,
    warmupMin: 0,
    cooldownMin: 0,
    notes: '',
    status: overrides.status ?? 'planned',
    structure: null,
    linkedActivityId: overrides.linkedActivityId ?? null
  });
}

function activity(
  id: string,
  date: string,
  overrides: { mode?: ModeId; minutes?: number; km?: number } = {}
): Activity {
  return {
    id,
    externalId: id,
    date,
    mode: overrides.mode ?? 'run',
    name: 'Run',
    durationSec: Math.round((overrides.minutes ?? 60) * 60),
    distanceM: (overrides.km ?? 10) * 1000,
    avgHr: 145,
    maxHr: 170,
    load: 70,
    source: 'intervals.icu',
    linkedSessionId: null
  };
}

describe('disciplineGroup', () => {
  it('treats trail and orienteering as running, MTB as cycling', () => {
    expect(disciplineGroup('trail')).toBe('run');
    expect(disciplineGroup('orienteering')).toBe('run');
    expect(disciplineGroup('mtb')).toBe('bike');
    expect(disciplineGroup('strength')).toBe('strength');
  });
});

describe('pairDay', () => {
  it('pairs a planned run with the run that got done', () => {
    const pairing = pairDay([session('s1', '2026-10-20')], [activity('a1', '2026-10-20')]);

    expect(pairing.pairs).toHaveLength(1);
    expect(pairing.pairs[0].manual).toBe(false);
    expect(pairing.doneSessions.map((item) => item.id)).toEqual(['s1']);
    expect(pairing.leftoverActivities).toEqual([]);
    expect(pairing.openSessions).toEqual([]);
  });

  it('pairs a planned run with a trail run', () => {
    const pairing = pairDay([session('s1', '2026-10-20')], [activity('a1', '2026-10-20', { mode: 'trail' })]);
    expect(pairing.pairs[0].activity.id).toBe('a1');
  });

  it('refuses to call a 20 minute jog the 2 hour session', () => {
    const pairing = pairDay(
      [session('s1', '2026-10-20', { minutes: 120 })],
      [activity('a1', '2026-10-20', { minutes: 20, km: 3 })]
    );

    expect(pairing.pairs).toEqual([]);
    expect(pairing.openSessions.map((item) => item.id)).toEqual(['s1']);
    expect(pairing.leftoverActivities.map((item) => item.id)).toEqual(['a1']);
  });

  it('never pairs across disciplines', () => {
    const pairing = pairDay([session('s1', '2026-10-20')], [activity('a1', '2026-10-20', { mode: 'bike' })]);
    expect(pairing.pairs).toEqual([]);
  });

  it('honours a link the athlete made by hand, even across disciplines', () => {
    const pairing = pairDay(
      [session('s1', '2026-10-20', { linkedActivityId: 'a1' })],
      [activity('a1', '2026-10-20', { mode: 'bike', minutes: 60, km: 30 })]
    );

    expect(pairing.pairs[0]).toMatchObject({ manual: true });
    expect(pairing.doneSessions).toHaveLength(1);
  });

  it('gives each session one activity and each activity one session', () => {
    const pairing = pairDay(
      [session('s1', '2026-10-20', { minutes: 60 }), session('s2', '2026-10-20', { minutes: 30 })],
      [activity('a1', '2026-10-20', { minutes: 58, km: 10 }), activity('a2', '2026-10-20', { minutes: 31, km: 5 })]
    );

    expect(pairing.pairs).toHaveLength(2);
    const bySession = new Map(pairing.pairs.map((pair) => [pair.session.id, pair.activity.id]));
    expect(bySession.get('s1')).toBe('a1');
    expect(bySession.get('s2')).toBe('a2');
  });

  it('leaves extra activities over when the athlete trained twice', () => {
    const pairing = pairDay(
      [session('s1', '2026-10-20', { minutes: 60 })],
      [activity('a1', '2026-10-20', { minutes: 60 }), activity('a2', '2026-10-20', { minutes: 25, km: 4 })]
    );

    expect(pairing.pairs.map((pair) => pair.activity.id)).toEqual(['a1']);
    expect(pairing.leftoverActivities.map((item) => item.id)).toEqual(['a2']);
  });

  it('does not pair a session that was skipped', () => {
    const pairing = pairDay(
      [session('s1', '2026-10-20', { status: 'skipped' })],
      [activity('a1', '2026-10-20')]
    );

    expect(pairing.pairs).toEqual([]);
    expect(pairing.leftoverActivities.map((item) => item.id)).toEqual(['a1']);
  });

  it('counts a hand-marked done session without an activity', () => {
    const pairing = pairDay([session('s1', '2026-10-20', { status: 'done' })], []);
    expect(pairing.doneSessions.map((item) => item.id)).toEqual(['s1']);
  });
});

describe('pairByDate', () => {
  it('keeps each day separate', () => {
    const map = pairByDate(
      [session('s1', '2026-10-20'), session('s2', '2026-10-21')],
      [activity('a1', '2026-10-20')]
    );

    expect(map.get('2026-10-20')?.pairs).toHaveLength(1);
    expect(map.get('2026-10-21')?.pairs).toHaveLength(0);
    expect(doneSessionIds([session('s1', '2026-10-20'), session('s2', '2026-10-21')], [activity('a1', '2026-10-20')])).toEqual(
      new Set(['s1'])
    );
  });
});

describe('a session the athlete marked skipped', () => {
  it('stays skipped even though it has a manual link to an activity', () => {
    const planned = session('s1', '2026-10-19', { linkedActivityId: 'a1' });
    const skipped = { ...planned, status: 'skipped' as SessionStatus };
    const run = activity('a1', '2026-10-19');

    const pairing = pairDay([skipped], [run]);

    expect(pairing.pairs).toHaveLength(0);
    expect(pairing.doneSessions).toHaveLength(0);
    expect(pairing.leftoverActivities.map((item) => item.id)).toEqual(['a1']);
  });

  it('is not matched automatically either', () => {
    const skipped = session('s1', '2026-10-19', { status: 'skipped' });
    const pairing = pairDay([skipped], [activity('a1', '2026-10-19')]);

    expect(pairing.pairs).toHaveLength(0);
    expect(pairing.openSessions.map((item) => item.id)).toEqual(['s1']);
  });

  it('is left out of the done ids', () => {
    const skipped = session('s1', '2026-10-19', { status: 'skipped', linkedActivityId: 'a1' });
    const done = session('s2', '2026-10-19');

    const ids = doneSessionIds([skipped, done], [activity('a1', '2026-10-19')]);

    expect(ids.has('s1')).toBe(false);
    expect(ids.has('s2')).toBe(true);
  });

  it('still pairs a normal session with a manual link', () => {
    const linked = session('s1', '2026-10-19', { linkedActivityId: 'a1' });
    const pairing = pairDay([linked], [activity('a1', '2026-10-19')]);

    expect(pairing.pairs).toHaveLength(1);
    expect(pairing.pairs[0].manual).toBe(true);
  });
});

