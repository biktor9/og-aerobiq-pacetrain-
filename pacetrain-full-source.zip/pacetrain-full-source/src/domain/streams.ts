/**
 * Small, pure helpers for reading an activity stream.
 *
 * The interval report and the kilometre splits walk exactly the same arrays, so
 * the window maths lives here once: find a sample by time, average a window,
 * integrate distance, add up climbing.
 */

export interface BasicStreams {
  /** Seconds, one entry per sample, ascending. */
  time: number[];
  /** Beats per minute. */
  heartrate?: (number | null)[] | null;
  /** Metres per second. */
  velocity?: (number | null)[] | null;
  /** Cumulative metres. */
  distance?: (number | null)[] | null;
  /** Metres above sea level. */
  altitude?: (number | null)[] | null;
}

/** Elevation changes smaller than this are treated as GPS noise. */
export const ELEVATION_NOISE_M = 0.5;

/** Index of the first sample at or after `seconds`; `time.length` past the end. */
export function firstIndexAtOrAfter(time: number[], seconds: number): number {
  let low = 0;
  let high = time.length;
  while (low < high) {
    const mid = (low + high) >> 1;
    if (time[mid] < seconds) low = mid + 1;
    else high = mid;
  }
  return low;
}

/** The finite samples of `window[from, to)`. */
export function numbers(
  window: (number | null)[] | null | undefined,
  from: number,
  to: number
): number[] {
  if (!window || from >= to) return [];
  const out: number[] = [];
  for (let i = Math.max(0, from); i < Math.min(window.length, to); i++) {
    const value = window[i];
    if (value !== null && value !== undefined && Number.isFinite(value)) out.push(value);
  }
  return out;
}

export function mean(values: number[]): number {
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
}

export function maxOf(values: number[]): number | null {
  return values.length ? Math.max(...values) : null;
}

/** Metres covered between two sample indices, integrating speed when needed. */
export function distanceBetween(
  streams: BasicStreams,
  from: number,
  to: number,
  durationSec: number
): number | null {
  const cumulative = streams.distance;
  if (cumulative && cumulative.length > to && from < to) {
    const start = cumulative[from];
    const end = cumulative[to - 1] ?? cumulative[from];
    if (
      typeof start === 'number' &&
      Number.isFinite(start) &&
      typeof end === 'number' &&
      Number.isFinite(end)
    ) {
      return Math.max(0, end - start);
    }
  }

  const velocity = streams.velocity;
  if (!velocity || velocity.length <= from) return null;

  let metres = 0;
  let sawSample = false;
  for (let i = Math.max(1, from + 1); i < Math.min(velocity.length, to); i++) {
    const speed = velocity[i];
    const step = streams.time[i] - streams.time[i - 1];
    if (typeof speed !== 'number' || !Number.isFinite(speed) || !(step > 0)) continue;
    metres += speed * step;
    sawSample = true;
  }
  if (sawSample) return metres;

  const average = mean(numbers(velocity, from, to));
  return average > 0 && durationSec > 0 ? average * durationSec : null;
}

/** Climbing and descending between two sample indices, ignoring GPS noise. */
export function elevationBetween(
  altitude: (number | null)[] | null | undefined,
  from: number,
  to: number
): { gainM: number; lossM: number } | null {
  if (!altitude || altitude.length <= from) return null;
  let gain = 0;
  let loss = 0;
  let sawSample = false;

  for (let i = Math.max(1, from + 1); i < Math.min(altitude.length, to); i++) {
    const now = altitude[i];
    const before = altitude[i - 1];
    if (typeof now !== 'number' || typeof before !== 'number') continue;
    if (!Number.isFinite(now) || !Number.isFinite(before)) continue;
    sawSample = true;
    const diff = now - before;
    if (diff >= ELEVATION_NOISE_M) gain += diff;
    else if (diff <= -ELEVATION_NOISE_M) loss -= diff;
  }

  return sawSample ? { gainM: gain, lossM: loss } : null;
}

/**
 * Cumulative metres, one entry per time sample. Uses the recorded distance
 * stream when the activity has one and otherwise integrates speed.
 */
export function cumulativeDistance(streams: BasicStreams): number[] {
  const { time, distance, velocity } = streams;
  const out: number[] = new Array(time.length).fill(0);
  if (!time.length) return out;

  const hasDistance = distance?.some((value) => typeof value === 'number' && Number.isFinite(value));
  if (hasDistance && distance) {
    let last = 0;
    for (let i = 0; i < time.length; i++) {
      const value = distance[i];
      if (typeof value === 'number' && Number.isFinite(value)) last = value;
      out[i] = last;
    }
  } else if (velocity?.length) {
    for (let i = 1; i < time.length; i++) {
      const step = time[i] - time[i - 1];
      const speed = velocity[i] ?? velocity[i - 1] ?? 0;
      const metres = typeof speed === 'number' && Number.isFinite(speed) && step > 0 ? speed * step : 0;
      out[i] = out[i - 1] + metres;
    }
  }

  // A GPS dropout must never make the distance run backwards.
  for (let i = 1; i < out.length; i++) {
    if (out[i] < out[i - 1]) out[i] = out[i - 1];
  }
  return out;
}
