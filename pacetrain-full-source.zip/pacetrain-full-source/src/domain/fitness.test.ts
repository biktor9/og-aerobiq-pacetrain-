import { describe, expect, it } from 'vitest';
import { estimatedLoad, fitnessSeries, fitnessSummary, formZone } from './fitness';
import { addDays, toISODate } from './week';
import type { Activity, Session } from './types';
import { toSession } from './plan';

const TODAY = new Date(2026, 9, 24); // Fri 24 Oct 2026

function activity(date: string, overrides: Partial<Activity> = {}): Activity {
  return {
    id: `a-${date}-${overrides.durationSec ?? 3600}`,
    externalId: `a-${date}`,
    date,
    mode: 'run',
    name: 'Run',
    durationSec: 3600,
    distanceM: 10_000,
    avgHr: 140,
    maxHr: 180,
    load: 50,
    source: 'intervals.icu',
    linkedSessionId: null,
    ...overrides
  };
}

function session(date: string, minutes: number): Session {
  return toSession({
    id: `s-${date}`,
    date,
    mode: 'run',
    kind: 'steady',
    title: 'Run',
    zone: 3,
    minutes,
    targetKm: null,
    reps: 1,
    workMin: minutes,
    recoverMin: 0,
    warmupMin: 0,
    cooldownMin: 0,
    notes: '',
    status: 'planned',
    structure: null,
    linkedActivityId: null
  });
}

function dailyLoad(days: number, load: number): Activity[] {
  return Array.from({ length: days }, (_, index) => activity(toISODate(addDays(TODAY, -index)), { load }));
}

describe('estimatedLoad', () => {
  it('uses a measured load when intervals.icu supplied one', () => {
    expect(estimatedLoad(activity('2026-10-20', { load: 92 }))).toBe(92);
  });

  it('estimates from duration and heart rate otherwise', () => {
    const easy = estimatedLoad(activity('2026-10-20', { load: null, durationSec: 3600, avgHr: 125 }));
    const hard = estimatedLoad(activity('2026-10-20', { load: null, durationSec: 3600, avgHr: 165 }));
    expect(easy).toBeGreaterThan(20);
    expect(hard).toBeGreaterThan(easy);
    expect(estimatedLoad(activity('2026-10-20', { load: null, durationSec: 0 }))).toBe(0);
  });
});

describe('formZone', () => {
  it('names each band of form', () => {
    expect(formZone(25).label).toBe('Very fresh');
    expect(formZone(12).label).toBe('Fresh');
    expect(formZone(0).label).toBe('Neutral');
    expect(formZone(-20).label).toBe('Productive');
    expect(formZone(-40).label).toBe('Overreaching');
    expect(formZone(-40).tone).toBe('bad');
  });
});

describe('fitnessSeries', () => {
  it('settles at the daily load when training is constant', () => {
    const series = fitnessSeries({ activities: dailyLoad(200, 50), days: 90, today: TODAY });
    const today = [...series].reverse().find((point) => !point.projected);

    expect(series).toHaveLength(104);
    expect(series[series.length - 1].projected).toBe(true);
    expect(Math.abs((today?.ctl ?? 0) - 50)).toBeLessThan(1.5);
    expect(Math.abs(today?.tsb ?? 0)).toBeLessThan(1.5);
  });

  it('loses fitness and gains freshness when training stops', () => {
    const trained = fitnessSeries({ activities: dailyLoad(200, 50), days: 90, today: TODAY });
    const rested = fitnessSeries({
      activities: dailyLoad(200, 50).filter((item) => item.date < toISODate(addDays(TODAY, -14))),
      days: 90,
      today: TODAY
    });

    const trainedToday = [...trained].reverse().find((point) => !point.projected);
    const restedToday = [...rested].reverse().find((point) => !point.projected);

    expect(restedToday!.ctl).toBeLessThan(trainedToday!.ctl - 5);
    expect(restedToday!.tsb).toBeGreaterThan(10);
  });

  it('projects the plan onto the empty days ahead', () => {
    const series = fitnessSeries({
      activities: dailyLoad(200, 50),
      sessions: [session(toISODate(addDays(TODAY, 1)), 90), session(toISODate(addDays(TODAY, 3)), 60)],
      days: 30,
      projectedDays: 14,
      today: TODAY
    });

    const tomorrow = series.find((point) => point.date === toISODate(addDays(TODAY, 1)));
    expect(tomorrow?.projected).toBe(true);
    expect(tomorrow?.load).toBeGreaterThan(0);
    expect(series.filter((point) => point.projected)).toHaveLength(14);
  });

  it('keeps the visible window to the requested length', () => {
    const series = fitnessSeries({ activities: dailyLoad(120, 40), days: 30, projectedDays: 0, today: TODAY });
    expect(series).toHaveLength(30);
    expect(series[series.length - 1].date).toBe(toISODate(TODAY));
    expect(series[0].date).toBe(toISODate(addDays(TODAY, -29)));
  });
});

describe('fitnessSummary', () => {
  it('reports today, form and the week around it', () => {
    const series = fitnessSeries({
      activities: dailyLoad(200, 50),
      sessions: [session(toISODate(addDays(TODAY, 2)), 60)],
      days: 90,
      today: TODAY
    });
    const summary = fitnessSummary(series);

    expect(summary).not.toBeNull();
    expect(summary?.today.projected).toBe(false);
    expect(summary?.form.label).toBe('Neutral');
    expect(summary?.weekLoad).toBe(350);
    expect(summary?.plannedLoad).toBeGreaterThan(0);
    expect(summary?.rampPct).toBe(0);
  });

  it('returns null for an empty series', () => {
    expect(fitnessSummary([])).toBeNull();
  });
});
