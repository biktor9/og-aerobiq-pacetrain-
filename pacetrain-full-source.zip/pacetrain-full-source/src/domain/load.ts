import { isRunningMode } from './activity';
import { MODES, type ModeId, type Session, type SessionInput, zone } from './types';
import { sessionBlocks } from './plan';

/**
 * A cheap training-load proxy: minutes × zone factor. It is not TSS, but it is
 * consistent, so week-over-week comparisons are meaningful.
 */
export function sessionLoad(session: SessionInput): number {
  const factor = session.mode === 'strength' ? 0.8 : 1;
  const load = sessionBlocks(session).reduce((total, block) => total + block.minutes * zone(block.zone).factor, 0);
  return Math.round(load * factor);
}

export function isHard(session: SessionInput): boolean {
  if (session.kind === 'intervals') return session.zone >= 4;
  return session.zone >= 4;
}

export interface WeekStats {
  count: number;
  minutes: number;
  load: number;
  /** Planned kilometres across run, trail and orienteering. */
  runningKm: number;
  hardCount: number;
  doneCount: number;
  skippedCount: number;
  longestMin: number;
  byMode: Record<ModeId, { count: number; minutes: number; load: number; km: number }>;
  byDay: Record<string, { count: number; minutes: number; load: number }>;
}

export function emptyModeTotals() {
  return Object.fromEntries(MODES.map((m) => [m.id, { count: 0, minutes: 0, load: 0, km: 0 }])) as WeekStats['byMode'];
}

export function weekStats(sessions: Session[]): WeekStats {
  const stats: WeekStats = {
    count: sessions.length,
    minutes: 0,
    load: 0,
    runningKm: 0,
    hardCount: 0,
    doneCount: 0,
    skippedCount: 0,
    longestMin: 0,
    byMode: emptyModeTotals(),
    byDay: {}
  };

  for (const session of sessions) {
    const load = sessionLoad(session);
    const minutes = session.durationMin;
    const km = session.targetKm ?? 0;
    stats.minutes += minutes;
    stats.load += load;
    stats.longestMin = Math.max(stats.longestMin, minutes);
    if (isRunningMode(session.mode)) stats.runningKm += km;
    if (isHard(session)) stats.hardCount += 1;
    if (session.status === 'done') stats.doneCount += 1;
    if (session.status === 'skipped') stats.skippedCount += 1;

    const modeTotals = stats.byMode[session.mode] ?? { count: 0, minutes: 0, load: 0, km: 0 };
    modeTotals.count += 1;
    modeTotals.minutes += minutes;
    modeTotals.load += load;
    modeTotals.km += km;
    stats.byMode[session.mode] = modeTotals;

    const day = stats.byDay[session.date] ?? { count: 0, minutes: 0, load: 0 };
    day.count += 1;
    day.minutes += minutes;
    day.load += load;
    stats.byDay[session.date] = day;
  }

  stats.runningKm = Math.round(stats.runningKm * 10) / 10;
  return stats;
}

export interface Ramp {
  delta: number;
  /** Percentage change, or null when there is no previous week to compare with. */
  pct: number | null;
  label: string;
  tone: 'up' | 'down' | 'flat' | 'new';
}

export function ramp(current: number, previous: number): Ramp {
  if (!previous) {
    return { delta: current, pct: null, label: 'first week', tone: 'new' };
  }
  const delta = current - previous;
  const pct = Math.round((delta / previous) * 100);
  const tone: Ramp['tone'] = Math.abs(pct) < 5 ? 'flat' : pct > 0 ? 'up' : 'down';
  const label = `${pct > 0 ? '+' : ''}${pct}% vs last week`;
  return { delta, pct, label, tone };
}

/** Minutes spent in each zone, for the distribution bar. */
export function zoneDistribution(sessions: Session[]): Record<number, number> {
  const totals: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  for (const session of sessions) {
    for (const block of sessionBlocks(session)) {
      totals[block.zone] = (totals[block.zone] ?? 0) + block.minutes;
    }
  }
  return totals;
}

export function modeLabel(id: ModeId): string {
  return MODES.find((m) => m.id === id)?.label ?? id;
}
