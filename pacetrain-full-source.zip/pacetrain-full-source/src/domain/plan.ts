import {
  type Block,
  type BlockKind,
  type ModeId,
  type Session,
  type SessionInput,
  type SessionKind,
  normalizeMode,
  zone as zoneInfo
} from './types';
import { describeBlocks } from './interval-text';
import { parseISODate, toISODate } from './week';

export const SESSION_LIMITS = {
  minutes: { min: 5, max: 600 },
  reps: { min: 1, max: 40 },
  workMin: { min: 0.5, max: 120 },
  recoverMin: { min: 0, max: 60 },
  warmupMin: { min: 0, max: 120 },
  cooldownMin: { min: 0, max: 120 },
  targetKm: { min: 0, max: 300 },
  /** Kilometres per rep: 200 m strides up to a 20 km tempo block. */
  targetReps: { min: 0.1, max: 20 }
} as const;

function clamp(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, value));
}

function round(value: number, step = 1): number {
  return Math.round(value / step) * step;
}

/** A number from a form or a row, or `null` when it was left blank. */
function optionalNumber(value: unknown): number | null {
  if (value === null || value === undefined || value === '') return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/**
 * Turns a warm-up or cool-down written in kilometres into the minutes the rest
 * of the planner works in. `paceSecPerKm` is the athlete's easy pace; left out,
 * the planner's default running pace is used, which is close enough for a
 * warm-up.
 */
export function kmToMinutes(km: number | null | undefined, paceSecPerKm?: number): number | null {
  if (km === null || km === undefined || !Number.isFinite(km) || km <= 0) return null;
  const pace = paceSecPerKm && paceSecPerKm > 0 ? paceSecPerKm : 330;
  return Math.round((km * pace) / 60 / 0.5) * 0.5;
}

/**
 * The warm-up and cool-down in minutes, whichever way they were written. A
 * kilometre value wins, because it is what the athlete typed.
 */
export function edgeMinutes(
  session: Pick<SessionInput, 'warmupMin' | 'cooldownMin' | 'warmupKm' | 'cooldownKm'>,
  paceSecPerKm?: number
): { warmup: number; cooldown: number } {
  return {
    warmup: kmToMinutes(session.warmupKm, paceSecPerKm) ?? session.warmupMin ?? 0,
    cooldown: kmToMinutes(session.cooldownKm, paceSecPerKm) ?? session.cooldownMin ?? 0
  };
}

/**
 * How long the interval session runs. Without reps or a work length the
 * warm-up and cool-down are all there is; the athlete's total time (or the
 * kilometres planned) covers the rest. Warm-up and cool-down written in
 * kilometres have already been turned into minutes by `normalizeSession`.
 */
export function intervalDuration(session: SessionInput): number {
  const { warmup, cooldown } = edgeMinutes(session);
  const reps = session.reps ?? null;
  const workMin = session.workMin ?? null;
  if (!reps || !workMin) {
    const estimated = session.minutes && session.minutes > 0 ? session.minutes : 0;
    return Math.max(estimated, warmup + cooldown);
  }
  const recoverMin = session.recoverMin ?? 0;
  return warmup + reps * workMin + Math.max(0, reps - 1) * recoverMin + cooldown;
}

/** True when the athlete has not decided the reps yet. */
export function isOpenInterval(session: SessionInput): boolean {
  return session.kind === 'intervals' && (!session.reps || !session.workMin);
}

/**
 * Expands a session into its timed blocks. Intervals are the only kind with a
 * derived duration, which keeps the plan and the load calculation in sync.
 * A structure parsed from the athlete's own words always wins.
 */
export function sessionBlocks(session: SessionInput): Block[] {
  if (session.structure && session.structure.length) {
    return session.structure.map((block) => ({ ...block }));
  }

  if (session.kind === 'intervals') {
    if (isOpenInterval(session)) {
      // Zone and total time only: one block, so the load and the week's
      // time-in-zone still know what was meant.
      const minutes = Math.max(5, intervalDuration(session));
      return [{ kind: 'work', minutes, zone: session.zone }];
    }
    const blocks: Block[] = [];
    const reps = session.reps ?? 0;
    const workMin = session.workMin ?? 0;
    const recoverMin = session.recoverMin ?? 0;
    const { warmup, cooldown } = edgeMinutes(session);
    if (warmup > 0) blocks.push({ kind: 'warmup', minutes: warmup, zone: 1 });
    for (let rep = 0; rep < reps; rep++) {
      blocks.push({ kind: 'work', minutes: workMin, zone: session.zone });
      if (recoverMin > 0 && rep < reps - 1) {
        blocks.push({ kind: 'recover', minutes: recoverMin, zone: 1 });
      }
    }
    if (cooldown > 0) blocks.push({ kind: 'cooldown', minutes: cooldown, zone: 1 });
    return blocks;
  }

  return [{ kind: 'work', minutes: session.minutes, zone: session.zone }];
}

export function sessionDuration(session: SessionInput): number {
  return sessionBlocks(session).reduce((total, block) => total + block.minutes, 0);
}

export function initialSession(date: string, modeId: ModeId = 'run'): SessionInput {
  const isStrength = modeId === 'strength';
  return {
    date,
    mode: modeId,
    kind: isStrength ? 'strength' : 'steady',
    title: '',
    zone: 2,
    minutes: isStrength ? 45 : 60,
    targetKm: null,
    reps: 4,
    workMin: 8,
    recoverMin: 2,
    warmupMin: 15,
    cooldownMin: 10,
    warmupKm: null,
    cooldownKm: null,
    targetReps: null,
    notes: '',
    status: 'planned',
    structure: null
  };
}

export const MAX_STRUCTURE_BLOCKS = 80;

const BLOCK_KIND_IDS: BlockKind[] = ['warmup', 'work', 'recover', 'cooldown'];

/**
 * Sanitises a hand- or AI-written structure. Anything unusable becomes `null`,
 * which makes the session fall back to the scalar fields.
 */
export function normalizeStructure(value: unknown): Block[] | null {
  if (!Array.isArray(value)) return null;

  const blocks: Block[] = [];
  for (const item of value.slice(0, MAX_STRUCTURE_BLOCKS)) {
    if (!item || typeof item !== 'object') continue;
    const candidate = item as Partial<Block>;
    const minutes = Number(candidate.minutes);
    if (!Number.isFinite(minutes) || minutes <= 0) continue;
    blocks.push({
      kind: BLOCK_KIND_IDS.includes(candidate.kind as BlockKind) ? (candidate.kind as BlockKind) : 'work',
      minutes: round(clamp(minutes, 0.5, 600), 0.5),
      zone: Math.round(clamp(Number(candidate.zone) || 2, 1, 5))
    });
  }

  return blocks.length ? blocks : null;
}

/** Reads the JSON column. Bad data never breaks the planner. */
export function parseStructureJson(value: string | null | undefined): Block[] | null {
  if (!value) return null;
  try {
    return normalizeStructure(JSON.parse(value));
  } catch {
    return null;
  }
}

/** Coerces anything that came from a form, a URL or the database into a valid session. */
export function normalizeSession(raw: Partial<SessionInput> & { date?: string }): SessionInput {
  const kind: SessionKind =
    raw.kind === 'intervals' || raw.kind === 'strength' || raw.kind === 'steady' ? raw.kind : 'steady';
  const modeId: ModeId = normalizeMode(raw.mode);
  const zoneValue = clamp(Math.round(Number(raw.zone) || 2), 1, 5);
  const date = raw.date && /^\d{4}-\d{2}-\d{2}$/.test(raw.date) ? raw.date : toISODate(new Date());
  // Distances are optional and only meaningful when they are real numbers.
  const targetKmRaw = Number(raw.targetKm);

  // The rep numbers belong to interval sessions. Any other kind carries none,
  // so switching an easy run over to intervals starts from a clean slate.
  const interval = kind === 'intervals';
  const reps = interval ? optionalNumber(raw.reps) : null;
  const workMin = interval ? optionalNumber(raw.workMin) : null;
  const recoverMin = interval ? optionalNumber(raw.recoverMin) : null;
  const targetReps = interval ? optionalNumber(raw.targetReps) : null;

  return {
    date,
    mode: modeId,
    kind,
    title: String(raw.title ?? '').slice(0, 80),
    zone: zoneValue,
    minutes: round(clamp(Number(raw.minutes) || 60, SESSION_LIMITS.minutes.min, SESSION_LIMITS.minutes.max)),
    targetKm:
      raw.targetKm == null || !Number.isFinite(targetKmRaw) || targetKmRaw <= 0
        ? null
        : Math.round(clamp(targetKmRaw, SESSION_LIMITS.targetKm.min, SESSION_LIMITS.targetKm.max) * 10) / 10,
    reps:
      reps === null
        ? null
        : Math.round(clamp(reps, SESSION_LIMITS.reps.min, SESSION_LIMITS.reps.max)),
    workMin:
      workMin === null
        ? null
        : round(clamp(workMin, SESSION_LIMITS.workMin.min, SESSION_LIMITS.workMin.max)),
    recoverMin:
      recoverMin === null
        ? null
        : round(clamp(recoverMin, SESSION_LIMITS.recoverMin.min, SESSION_LIMITS.recoverMin.max)),
    warmupMin: round(
      clamp(Number(raw.warmupMin) || 0, SESSION_LIMITS.warmupMin.min, SESSION_LIMITS.warmupMin.max)
    ),
    cooldownMin: round(
      clamp(Number(raw.cooldownMin) || 0, SESSION_LIMITS.cooldownMin.min, SESSION_LIMITS.cooldownMin.max)
    ),
    warmupKm: optionalNumber(raw.warmupKm),
    cooldownKm: optionalNumber(raw.cooldownKm),
    targetReps:
      targetReps === null
        ? null
        : Math.round(clamp(targetReps, SESSION_LIMITS.targetReps.min, SESSION_LIMITS.targetReps.max) * 100) / 100,
    notes: String(raw.notes ?? '').slice(0, 400),
    status: raw.status === 'done' || raw.status === 'skipped' ? raw.status : 'planned',
    structure: normalizeStructure(raw.structure)
  };
}

/** "4 × 8′ @ Z4 · 2′ easy", "8×800 m @ Z4", "4 × 8′ @ Z4 · 14 km total", "60′ @ Z2" */
export function describeSession(session: SessionInput): string {
  if (session.structure && session.structure.length) {
    const description = describeBlocks(session.structure);
    if (description) return `${description} · ${Math.round(sessionDuration(session))}′ total`;
  }

  const z = `Z${session.zone}`;
  if (session.kind === 'intervals') {
    const total = sessionDuration(session);
    if (isOpenInterval(session)) {
      // Only a zone and a time were chosen; say so instead of inventing reps.
      const km = session.targetKm ? `${kmText(session.targetKm)} km · ` : '';
      return `${km}${Math.round(total)}′ @ ${z} · reps not set`;
    }
    const work = session.targetReps
      ? `${kmText(session.targetReps)} km`
      : `${trimMinutes(session.workMin ?? 0)}′`;
    const parts = [`${session.reps} × ${work} @ ${z}`];
    const recoverMin = session.recoverMin ?? 0;
    if (recoverMin > 0) parts.push(`${trimMinutes(recoverMin)}′ easy`);
    // A distance the athlete committed to for the whole session, when it is not
    // simply what the reps add up to.
    if (session.targetKm) parts.push(`${kmText(session.targetKm)} km total`);
    parts.push(`${Math.round(total)}′ total`);
    return parts.join(' · ');
  }
  if (session.targetKm) {
    return `${trimMinutes(session.targetKm)} km · ${Math.round(session.minutes)}′ @ ${z}`;
  }
  if (session.kind === 'strength') {
    return `${Math.round(session.minutes)}′ · ${zoneInfo(session.zone).name}`;
  }
  return `${Math.round(session.minutes)}′ @ ${z}`;
}

/** `16`, `0.8`, `1.25` — a distance without trailing zeros. */
export function kmText(km: number): string {
  if (Number.isInteger(km)) return String(km);
  return String(Math.round(km * 100) / 100);
}

export function sessionTitle(session: SessionInput): string {
  if (session.title.trim()) return session.title.trim();
  if (session.kind === 'intervals') return 'Intervals';
  if (session.kind === 'strength') return 'Strength';
  return 'Easy session';
}

function trimMinutes(value: number): string {
  return Number.isInteger(value) ? String(value) : value.toFixed(1);
}

/** Rebuilds the rendered session (with blocks and duration) from stored columns. */
export function toSession(row: SessionInput & { id: string; linkedActivityId: string | null }): Session {
  const input = normalizeSession(row);
  return {
    ...input,
    id: row.id,
    linkedActivityId: row.linkedActivityId,
    blocks: sessionBlocks(input),
    durationMin: sessionDuration(input)
  };
}

export function sessionsOnDate(sessions: Session[], date: string): Session[] {
  return sessions.filter((session) => session.date === date);
}

export function sortSessions(sessions: Session[]): Session[] {
  return [...sessions].sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1;
    return a.id < b.id ? -1 : 1;
  });
}

export function dateOf(date: string) {
  return parseISODate(date);
}
