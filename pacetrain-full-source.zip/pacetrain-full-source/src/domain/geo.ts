/**
 * Coordinates, Web Mercator and route shapes.
 *
 * The maps are slippy maps built from 256 px tiles, so every helper here works
 * in Mercator world pixels: a latitude becomes a pixel, a pixel becomes a
 * latitude, and the tile grid falls out of the zoom level.
 */

/** `[lat, lng]`, the order intervals.icu and GeoJSON-ish streams use. */
export type LatLng = [number, number];

export interface Bounds {
  minLat: number;
  maxLat: number;
  minLng: number;
  maxLng: number;
}

/** The patch of the world a heat map is about. */
export interface Area {
  lat: number;
  lng: number;
  radiusKm: number;
  label: string;
}

export const TILE_SIZE = 256;
/** Edge of the Mercator projection; beyond this the maths folds over. */
export const MAX_LATITUDE = 85.05112878;
export const MIN_ZOOM = 3;
export const MAX_ZOOM = 18;

/** Satellite imagery, no key required. Tile URL order is Esri's: z/y/x. */
export const SATELLITE_ATTRIBUTION = 'Imagery © Esri, Maxar, Earthstar Geographics';
export function satelliteTileUrl(zoom: number, x: number, y: number): string {
  return `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${zoom}/${y}/${x}`;
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value);
}

export function isLatLng(value: unknown): value is LatLng {
  return (
    Array.isArray(value) &&
    value.length >= 2 &&
    isFiniteNumber(value[0]) &&
    isFiniteNumber(value[1]) &&
    Math.abs(value[0]) <= 90 &&
    Math.abs(value[1]) <= 180 &&
    // 0/0 is what a device writes when it has no fix.
    !(value[0] === 0 && value[1] === 0)
  );
}

/** Metres between two points on the sphere. */
export function haversineM(a: LatLng, b: LatLng): number {
  const radius = 6371008.8;
  const toRad = (degrees: number) => (degrees * Math.PI) / 180;
  const dLat = toRad(b[0] - a[0]);
  const dLng = toRad(b[1] - a[1]);
  const lat1 = toRad(a[0]);
  const lat2 = toRad(b[0]);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * radius * Math.asin(Math.min(1, Math.sqrt(h)));
}

export function withinRadius(point: LatLng, centre: LatLng, radiusKm: number): boolean {
  return haversineM(point, centre) <= Math.max(0.1, radiusKm) * 1000;
}

export function routeBounds(points: LatLng[]): Bounds | null {
  if (!points.length) return null;
  let minLat = points[0][0];
  let maxLat = points[0][0];
  let minLng = points[0][1];
  let maxLng = points[0][1];
  for (const [lat, lng] of points) {
    if (lat < minLat) minLat = lat;
    if (lat > maxLat) maxLat = lat;
    if (lng < minLng) minLng = lng;
    if (lng > maxLng) maxLng = lng;
  }
  return { minLat, maxLat, minLng, maxLng };
}

export function centreOf(bounds: Bounds): LatLng {
  return [(bounds.minLat + bounds.maxLat) / 2, (bounds.minLng + bounds.maxLng) / 2];
}

/** Kilometres from the centre of the box to its corner. */
export function radiusOf(bounds: Bounds): number {
  return haversineM(centreOf(bounds), [bounds.maxLat, bounds.maxLng]) / 1000;
}

export function routeDistanceM(points: LatLng[]): number {
  let metres = 0;
  for (let i = 1; i < points.length; i++) metres += haversineM(points[i - 1], points[i]);
  return metres;
}

/** True when any part of the trace lands inside the area. */
export function routeTouchesArea(points: LatLng[], centre: LatLng, radiusKm: number): boolean {
  if (!points.length) return false;
  if (points.some((point) => withinRadius(point, centre, radiusKm))) return true;
  // A long straight stretch can jump over a small area: check the midpoints too.
  for (let i = 1; i < points.length; i++) {
    const mid: LatLng = [(points[i - 1][0] + points[i][0]) / 2, (points[i - 1][1] + points[i][1]) / 2];
    if (withinRadius(mid, centre, radiusKm)) return true;
  }
  return false;
}

/**
 * Thins a trace to at most `maxPoints`, dropping samples that did not move and
 * always keeping the finish. Enough for a map, small enough for a database row.
 */
export function simplifyRoute(points: LatLng[], maxPoints = 150): LatLng[] {
  const clean: LatLng[] = [];
  for (const point of points) {
    if (!isLatLng(point)) continue;
    const last = clean[clean.length - 1];
    if (last && Math.abs(last[0] - point[0]) < 1e-5 && Math.abs(last[1] - point[1]) < 1e-5) continue;
    clean.push([point[0], point[1]]);
  }
  if (clean.length <= maxPoints) return clean;

  const stride = Math.ceil(clean.length / maxPoints);
  const thinned = clean.filter((_, index) => index % stride === 0);
  const finish = clean[clean.length - 1];
  const last = thinned[thinned.length - 1];
  if (!last || last[0] !== finish[0] || last[1] !== finish[1]) thinned.push(finish);
  return thinned;
}

/** Five decimals is about a metre — plenty for a line on a satellite photo. */
export function roundRoute(points: LatLng[]): LatLng[] {
  return points.map(([lat, lng]) => [Math.round(lat * 1e5) / 1e5, Math.round(lng * 1e5) / 1e5]);
}

/** Web Mercator world pixel at `zoom`. */
export function project(lat: number, lng: number, zoom: number): { x: number; y: number } {
  const size = TILE_SIZE * 2 ** zoom;
  const clamped = Math.max(-MAX_LATITUDE, Math.min(MAX_LATITUDE, lat));
  const sin = Math.sin((clamped * Math.PI) / 180);
  return {
    x: ((lng + 180) / 360) * size,
    y: (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * size
  };
}

export function unproject(x: number, y: number, zoom: number): LatLng {
  const size = TILE_SIZE * 2 ** zoom;
  const lng = (x / size) * 360 - 180;
  const n = Math.PI - (2 * Math.PI * y) / size;
  return [(180 / Math.PI) * Math.atan(Math.sinh(n)), lng];
}

export function clampZoom(zoom: number): number {
  return Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, Math.round(zoom)));
}

/**
 * The tightest whole zoom at which a circle of `radiusKm` fits in the viewport.
 * Whole steps keep the raster tiles pixel-aligned.
 */
export function zoomForRadius(radiusKm: number, width: number, height: number, padding = 0.85): number {
  const usable = Math.max(120, Math.min(width, height) * padding);
  const metresPerPixel = (Math.max(0.05, radiusKm) * 2000) / usable;
  // 156543.03392 m per pixel at zoom 0 on the equator.
  return clampZoom(Math.floor(Math.log2(156543.03392 / metresPerPixel)));
}

export interface MapTile {
  x: number;
  y: number;
  /** Offset of the tile inside the viewport, in pixels. */
  left: number;
  top: number;
  zoom: number;
}

/** The tiles that cover a viewport, wrapped at the antimeridian. */
export function tileRange(centre: LatLng, zoom: number, width: number, height: number): MapTile[] {
  const centrePx = project(centre[0], centre[1], zoom);
  const left = centrePx.x - width / 2;
  const top = centrePx.y - height / 2;
  const count = 2 ** zoom;
  const firstX = Math.floor(left / TILE_SIZE);
  const lastX = Math.floor((left + width) / TILE_SIZE);
  const firstY = Math.max(0, Math.floor(top / TILE_SIZE));
  const lastY = Math.min(count - 1, Math.floor((top + height) / TILE_SIZE));

  const tiles: MapTile[] = [];
  for (let x = firstX; x <= lastX; x++) {
    for (let y = firstY; y <= lastY; y++) {
      tiles.push({
        x: ((x % count) + count) % count,
        y,
        left: x * TILE_SIZE - left,
        top: y * TILE_SIZE - top,
        zoom
      });
    }
  }
  return tiles;
}
