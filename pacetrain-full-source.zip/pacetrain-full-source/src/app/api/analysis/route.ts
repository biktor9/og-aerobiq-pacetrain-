import { z } from 'zod';
import { AnalysisError, analyseActivity } from '@/lib/analysis';
import { auth } from '@/lib/auth';
import { blockedByPaywall, paywallResponse } from '@/lib/guard';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const bodySchema = z.object({
  activityId: z.string().min(1),
  /** Optional override; the server picks pace for runners and power otherwise. */
  metric: z.enum(['power', 'hr', 'pace', 'speed']).optional(),
  threshold: z.number().min(0).max(100_000).optional(),
  thresholdPct: z.number().min(20).max(90).optional(),
  minWorkSec: z.number().min(5).max(900).optional(),
  minGapSec: z.number().min(0).max(600).optional(),
  smoothingSec: z.number().min(0).max(120).optional(),
  /**
   * The laps to analyse, 1-based in recording order. Omitted means every lap the
   * watch recorded; an empty array means "read the stream instead".
   */
  laps: z.array(z.number().int().min(1).max(500)).max(500).optional(),
  /** Read the stream even though the activity has laps. */
  ignoreLaps: z.boolean().optional()
});

export async function POST(request: Request) {
  const session = await auth.api.getSession({ headers: request.headers });
  if (!session?.user) return Response.json({ error: 'Sign in first.' }, { status: 401 });
  if (await blockedByPaywall(session.user)) return paywallResponse();

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: 'Send a JSON body.' }, { status: 400 });
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? 'Invalid parameters.' }, { status: 400 });
  }

  try {
    const result = await analyseActivity(session.user.id, parsed.data.activityId, {
      metric: parsed.data.metric,
      threshold: parsed.data.threshold,
      thresholdPct: parsed.data.thresholdPct,
      minWorkSec: parsed.data.minWorkSec,
      minGapSec: parsed.data.minGapSec,
      smoothingSec: parsed.data.smoothingSec,
      laps: parsed.data.laps,
      ignoreLaps: parsed.data.ignoreLaps
    });
    return Response.json(result);
  } catch (error) {
    if (error instanceof AnalysisError) {
      return Response.json({ error: error.message }, { status: error.status });
    }
    console.error('[analysis] failed:', error);
    return Response.json({ error: 'The analysis failed. Try again.' }, { status: 500 });
  }
}
