import { z } from 'zod';
import { db, schema } from '@/db';
import { eventCountdown, nextEvent } from '@/domain/events';
import { fitnessSeries, fitnessSummary } from '@/domain/fitness';
import { weekStats } from '@/domain/load';
import { isSickOn, recoveryScore } from '@/domain/recovery';
import { addDays, startOfWeek, toISODate, weekKey, weekRangeLabel } from '@/domain/week';
import { auth } from '@/lib/auth';
import { buildCoachMessages, offlineAnswer, type CoachInput, type CoachSettings } from '@/lib/coach-context';
import { decryptSecret, randomId } from '@/lib/crypto';
import {
  activitiesBetween,
  activitiesSince,
  chatHistory,
  getActivity,
  getSettings,
  latestAnalyses,
  listEvents,
  previousWeekLoad,
  recentWellness,
  listSickNotes,
  weekSessions
} from '@/lib/data';
import { streamDeepSeek } from '@/lib/deepseek';
import { appConfig } from '@/lib/env';
import { blockedByPaywall, paywallResponse } from '@/lib/guard';
import { checkQuota, recordUsage } from '@/lib/usage';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const bodySchema = z.object({
  question: z.string().trim().min(2, 'Ask a question first.').max(1500, 'That question is too long.')
});

function jsonError(status: number, error: string, extra: Record<string, unknown> = {}) {
  return Response.json({ error, ...extra }, { status });
}

/** Splits the offline answer into a few frames so the UI streams like the real thing. */
function chunks(text: string, size = 180): string[] {
  const out: string[] = [];
  for (let i = 0; i < text.length; i += size) out.push(text.slice(i, i + size));
  return out.length ? out : [''];
}

export async function POST(request: Request) {
  const session = await auth.api.getSession({ headers: request.headers });
  if (!session?.user) return jsonError(401, 'Sign in to talk to the coach.');
  if (await blockedByPaywall(session.user)) return paywallResponse();

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError(400, 'Send a JSON body.');
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) return jsonError(400, parsed.error.issues[0]?.message ?? 'Invalid request.');
  const question = parsed.data.question;

  const config = appConfig();
  const user = session.user;
  const settings = await getSettings(user.id);
  const ownKey = settings.deepseekKeyEnc ? decryptSecret(settings.deepseekKeyEnc) : '';
  const apiKey = ownKey || config.deepseek.apiKey;

  const { decision } = await checkQuota(
    { id: user.id, createdAt: new Date(user.createdAt) },
    { hasOwnKey: Boolean(ownKey), dailyTokenBudget: config.deepseek.dailyTokenBudget }
  );
  if (!decision.allowed) {
    return jsonError(429, decision.message, { reason: decision.reason, quota: decision });
  }

  const monday = startOfWeek(new Date());
  const [sessions, previousLoad, activities, recentAnalyses, history, fitnessActivities, wellness, races, sickNotes] =
    await Promise.all([
      weekSessions(user.id, monday),
      previousWeekLoad(user.id, monday),
      activitiesSince(user.id, toISODate(addDays(new Date(), -14))),
      latestAnalyses(user.id, 1),
      chatHistory(user.id, 12),
      // Fitness needs a long look-back; the coach only ever sees the summary.
      activitiesBetween(user.id, toISODate(addDays(new Date(), -174)), toISODate(new Date()), 3000),
      recentWellness(user.id, 14),
      listEvents(user.id),
      listSickNotes(user.id, 3)
    ]);

  const fitness = fitnessSummary(fitnessSeries({ activities: fitnessActivities, days: 90 }));
  const todayISO = toISODate(new Date());
  const todayEntry = wellness.find((entry) => entry.date === todayISO) ?? null;
  const recovery = recoveryScore({
    today: todayEntry,
    entries: wellness,
    form: fitness ? { tsb: fitness.today.tsb, atl: fitness.today.atl } : null,
    sick: sickNotes,
    todayISO
  });
  const illness = sickNotes.find((note) => isSickOn([note], todayISO)) ?? null;
  const race = nextEvent(races);
  const countdown = race ? eventCountdown(race) : null;

  let latestAnalysis: CoachInput['latestAnalysis'] = null;
  const latest = recentAnalyses[0];
  if (latest) {
    const activity = await getActivity(user.id, latest.activityId);
    latestAnalysis = {
      activityName: activity?.name || 'Imported activity',
      result: latest.result,
      summary: latest.summary
    };
  }

  const coachSettings: CoachSettings = {
    goalText: settings.goalText,
    eventDate: settings.eventDate,
    weeklyMinutesTarget: settings.weeklyMinutesTarget,
    weeklyLoadTarget: settings.weeklyLoadTarget,
    primaryMode: settings.primaryMode,
    coachTone: settings.coachTone,
    athleteNotes: settings.athleteNotes
  };

  const input: CoachInput = {
    userName: user.name ?? '',
    settings: coachSettings,
    weekKey: weekKey(monday),
    weekRange: weekRangeLabel(monday),
    sessions,
    stats: weekStats(sessions),
    previousLoad,
    activities,
    latestAnalysis,
    fitness: fitness
      ? { ctl: fitness.today.ctl, atl: fitness.today.atl, tsb: fitness.today.tsb, label: fitness.form.label }
      : null,
    recovery: {
      score: recovery.score,
      label: recovery.label,
      summary: recovery.summary,
      sick: recovery.sick,
      signals: recovery.signals.map((signal) => `${signal.label} ${signal.value} (${signal.detail})`)
    },
    recoveryNote: todayEntry?.notes?.trim() ? todayEntry.notes.trim() : null,
    illness: illness
      ? {
          from: illness.dateFrom,
          to: illness.dateTo,
          symptoms: illness.symptoms,
          severity: illness.severity
        }
      : null,
    nextRace: race && countdown ? { name: race.name, days: countdown.days, phase: countdown.phase } : null
  };

  const messages = buildCoachMessages(input, history, question);

  await db.insert(schema.chatMessages).values({
    id: randomId(),
    userId: user.id,
    role: 'user',
    content: question,
    createdAt: new Date()
  });

  const mode = !apiKey ? 'offline' : ownKey ? 'own-key' : 'shared';
  const encoder = new TextEncoder();

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (event: string, data: unknown) => {
        controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
      };

      send('meta', {
        mode,
        model: apiKey ? config.deepseek.model : 'rule-engine',
        remainingHour: Number.isFinite(decision.remainingHour) ? decision.remainingHour : null,
        remainingDay: Number.isFinite(decision.remainingDay) ? decision.remainingDay : null,
        limits: decision.limits
      });

      let answer = '';
      let usage = { promptTokens: 0, completionTokens: 0 };
      let failed = false;

      try {
        if (!apiKey) {
          for (const chunk of chunks(offlineAnswer(input, question))) {
            answer += chunk;
            send('delta', { text: chunk });
          }
          send('done', { usage, offline: true });
        } else {
          for await (const event of streamDeepSeek({
            apiKey,
            baseUrl: config.deepseek.baseUrl,
            model: config.deepseek.model,
            messages,
            maxTokens: config.deepseek.maxTokens,
            temperature: config.deepseek.temperature,
            signal: request.signal
          })) {
            if (event.type === 'delta') {
              answer += event.text;
              send('delta', { text: event.text });
            } else if (event.type === 'error') {
              failed = true;
              send('error', { message: event.message });
            } else {
              usage = event.usage;
              send('done', { usage });
            }
          }
        }
      } catch (error) {
        failed = true;
        send('error', { message: error instanceof Error ? error.message : 'The coach stopped unexpectedly.' });
      } finally {
        try {
          if (answer.trim()) {
            await db.insert(schema.chatMessages).values({
              id: randomId(),
              userId: user.id,
              role: 'assistant',
              content: answer,
              tokensIn: usage.promptTokens,
              tokensOut: usage.completionTokens,
              createdAt: new Date()
            });
          }
          if (apiKey && !failed) {
            await recordUsage({
              userId: user.id,
              promptTokens: usage.promptTokens,
              completionTokens: usage.completionTokens,
              byok: Boolean(ownKey)
            });
          }
        } catch (error) {
          console.error('[coach] could not persist the exchange:', error);
        }
        controller.close();
      }
    }
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no'
    }
  });
}
