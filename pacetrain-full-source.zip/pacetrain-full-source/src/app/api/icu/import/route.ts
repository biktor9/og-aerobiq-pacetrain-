import { auth } from '@/lib/auth';
import { blockedByPaywall, paywallResponse } from '@/lib/guard';
import { importActivities } from '@/lib/icu-sync';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** Imports the last N days from intervals.icu using the stored, encrypted key. */
export async function POST(request: Request) {
  const session = await auth.api.getSession({ headers: request.headers });
  if (!session?.user) return Response.json({ error: 'Sign in first.' }, { status: 401 });
  if (await blockedByPaywall(session.user)) return paywallResponse();

  const body = (await request.json().catch(() => ({}))) as { days?: unknown };
  const days = Number(body.days ?? 30);

  try {
    const result = await importActivities(session.user.id, Number.isFinite(days) ? days : 30);
    return Response.json({ ok: true, ...result });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : 'The import failed.' },
      { status: 400 }
    );
  }
}
