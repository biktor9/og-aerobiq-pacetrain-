import { z } from 'zod';
import { auth } from '@/lib/auth';
import { testConnection } from '@/lib/icu';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const bodySchema = z.object({
  athleteId: z.string().trim().min(1),
  apiKey: z.string().trim().min(10)
});

/** Credentials are used for this one request and never stored by this route. */
export async function POST(request: Request) {
  const session = await auth.api.getSession({ headers: request.headers });
  if (!session?.user) return Response.json({ error: 'Sign in first.' }, { status: 401 });

  const parsed = bodySchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return Response.json({ error: 'Athlete ID and API key are required.' }, { status: 400 });
  }

  try {
    const athlete = await testConnection(parsed.data);
    return Response.json({ ok: true, athlete });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : 'Could not reach intervals.icu.' },
      { status: 400 }
    );
  }
}
