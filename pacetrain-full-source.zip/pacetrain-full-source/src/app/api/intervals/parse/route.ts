import { z } from 'zod';
import { parseIntervalText, summariseBlocks } from '@/domain/interval-text';
import { auth } from '@/lib/auth';
import { decryptSecret } from '@/lib/crypto';
import { getSettings } from '@/lib/data';
import { appConfig } from '@/lib/env';
import { blockedByPaywall, paywallResponse } from '@/lib/guard';
import { parseIntervalsWithAi } from '@/lib/interval-ai';
import { checkQuota, recordUsage } from '@/lib/usage';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const bodySchema = z.object({
  text: z.string().trim().min(3, 'Write the session first.').max(600, 'That is more text than the parser can hold.')
});

export async function POST(request: Request) {
  const session = await auth.api.getSession({ headers: request.headers });
  if (!session?.user) return Response.json({ error: 'Sign in first.' }, { status: 401 });
  if (await blockedByPaywall(session.user)) return paywallResponse();

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: 'Send a JSON body.' }, { status: 400 });
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? 'Invalid request.' }, { status: 400 });
  }

  const text = parsed.data.text;
  const local = parseIntervalText(text);

  const config = appConfig();
  const user = session.user;
  const settings = await getSettings(user.id);
  const ownKey = settings.deepseekKeyEnc ? decryptSecret(settings.deepseekKeyEnc) : '';
  const apiKey = ownKey || config.deepseek.apiKey;
  if (!apiKey) return Response.json({ source: 'local', parsed: local });

  const { decision } = await checkQuota(
    { id: user.id, createdAt: new Date(user.createdAt) },
    { hasOwnKey: Boolean(ownKey), dailyTokenBudget: config.deepseek.dailyTokenBudget }
  );
  if (!decision.allowed) {
    return Response.json({ source: 'local', parsed: local, note: decision.message });
  }

  try {
    const ai = await parseIntervalsWithAi(text, {
      apiKey,
      baseUrl: config.deepseek.baseUrl,
      model: config.deepseek.model,
      signal: request.signal
    });
    if (ai) {
      if (ai.promptTokens || ai.completionTokens) {
        await recordUsage({
          userId: user.id,
          promptTokens: ai.promptTokens,
          completionTokens: ai.completionTokens,
          byok: Boolean(ownKey)
        });
      }
      // The deterministic parser still supplies the warnings (metres, no
      // duration) and the scalar summary the planner stores alongside.
      return Response.json({
        source: 'ai',
        parsed: summariseBlocks(ai.blocks, local.blocks.length ? [] : local.warnings)
      });
    }
  } catch (error) {
    console.error('[intervals] AI parse failed, using the local parser:', error);
  }

  return Response.json({ source: 'local', parsed: local });
}
