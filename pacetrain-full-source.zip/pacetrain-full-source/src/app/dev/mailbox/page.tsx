import { notFound } from 'next/navigation';
import { desc } from 'drizzle-orm';
import { db, schema } from '@/db';
import { appConfig } from '@/lib/env';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Dev mailbox' };

/**
 * Everything the app "sends" while EMAIL_TRANSPORT=console lands here, so
 * sign-up and password reset can be finished without a mail provider.
 * The route does not exist in production.
 */
export default async function DevMailboxPage() {
  const config = appConfig();
  if (config.isProd) notFound();

  const mails = await db.select().from(schema.devMail).orderBy(desc(schema.devMail.createdAt)).limit(30);

  return (
    <div className="app-shell">
      <main className="app-main">
        <div className="page-head">
          <div>
            <h1>Dev mailbox</h1>
            <p className="page-sub">
              Emails captured by the console transport. Nothing here leaves the machine, and this page is absent in
              production. With email confirmation gone, this is only used for password resets.
            </p>
          </div>
          <span className="badge">{config.email.transport}</span>
        </div>

        {mails.length === 0 ? (
          <div className="empty">
            No mail yet. Ask for a password reset and the message will appear here.
          </div>
        ) : (
          <div className="stack" style={{ gap: 12 }}>
            {mails.map((mail) => (
              <div className="card" key={mail.id}>
                <div className="card-head">
                  <h3>{mail.subject}</h3>
                  <span className="small muted">{new Date(mail.createdAt).toLocaleString()}</span>
                </div>
                <p className="small muted" style={{ marginTop: 0 }}>
                  to {mail.to}
                </p>
                <pre className="mail-body">{mail.body}</pre>
                {mail.link ? (
                  <p style={{ marginBottom: 0 }}>
                    <a className="btn btn-sm btn-primary" href={mail.link}>
                      Open link
                    </a>
                  </p>
                ) : null}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
