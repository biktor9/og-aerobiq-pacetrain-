'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { AuthShell } from '@/components/auth-shell';
import { signUp } from '@/lib/auth-client';

/**
 * There is no confirmation mail, so a typo in the address would silently lock
 * the athlete out of password resets. These are the mistakes people actually
 * make on a keyboard — the confirmation step calls them out.
 */
const TYPO_DOMAINS: Record<string, string> = {
  'gmial.com': 'gmail.com',
  'gmai.com': 'gmail.com',
  'gmail.co': 'gmail.com',
  'gmail.con': 'gmail.com',
  'gmail.cm': 'gmail.com',
  'gnail.com': 'gmail.com',
  'hotmial.com': 'hotmail.com',
  'hotmai.com': 'hotmail.com',
  'hotmail.co': 'hotmail.com',
  'outlok.com': 'outlook.com',
  'outlook.co': 'outlook.com',
  'yahoo.co': 'yahoo.com',
  'yaho.com': 'yahoo.com',
  'icloud.co': 'icloud.com',
  'protonmai.com': 'protonmail.com'
};

function typoHint(email: string): string {
  const domain = (email.split('@')[1] ?? '').trim().toLowerCase();
  const suggestion = TYPO_DOMAINS[domain];
  return suggestion ? `@${domain} is usually a typo for @${suggestion}.` : '';
}

export default function SignUpPage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState<'details' | 'confirm'>('details');

  const confirmedEmail = email.trim();
  const hint = typoHint(confirmedEmail);

  function review(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');

    if (password.length < 8) {
      setError('Use at least 8 characters for the password.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(confirmedEmail)) {
      setError('That does not look like an email address.');
      return;
    }
    setStep('confirm');
  }

  async function createAccount() {
    setBusy(true);
    setError('');

    const { error: authError } = await signUp.email({
      name: name.trim(),
      email: confirmedEmail,
      password,
      callbackURL: '/plan'
    });

    if (authError) {
      setError(authError.message || 'Could not create the account. Try a different email.');
      setBusy(false);
      return;
    }

    router.push('/plan');
    router.refresh();
  }

  return (
    <AuthShell
      title={step === 'details' ? 'Create your account' : 'Is this the right email?'}
      subtitle={
        step === 'details'
          ? 'Free while the shared coach budget lasts. No confirmation mail — you double-check the address yourself.'
          : 'We skip the confirmation email, so the address on the account has to be right the first time.'
      }
      footer={
        <>
          Already have an account? <Link href="/sign-in">Sign in</Link>
        </>
      }
    >
      {step === 'details' ? (
        <form onSubmit={review} className="stack" style={{ gap: 13 }}>
          <div className="field">
            <label htmlFor="name">Name</label>
            <input
              id="name"
              className="input"
              autoComplete="name"
              required
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="Alex Runner"
            />
          </div>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              className="input"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@example.com"
            />
            <span className="field-hint">This is the address you sign in with. Double-check it.</span>
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              className="input"
              type="password"
              autoComplete="new-password"
              required
              minLength={8}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="At least 8 characters"
            />
            <span className="field-hint">Eight characters or more. A passphrase works well.</span>
          </div>
          {error ? <div className="alert alert-error">{error}</div> : null}
          <button className="btn btn-primary" type="submit">
            Continue
          </button>
          <p className="field-hint" style={{ textAlign: 'center' }}>
            One confirmation step, then the planner opens.
          </p>
        </form>
      ) : (
        <form
          className="stack"
          style={{ gap: 13 }}
          onSubmit={(event) => {
            event.preventDefault();
            void createAccount();
          }}
        >
          <div className="alert">
            <strong>
              Are you sure <span className="mono">{confirmedEmail}</span> is correct?
            </strong>
            <p className="small" style={{ marginTop: 6, marginBottom: 0 }}>
              No confirmation mail is sent, so nobody checks the address for you. If it is wrong you cannot sign in
              again or reset the password.
            </p>
          </div>
          {hint ? <div className="alert alert-error">{hint}</div> : null}
          <div className="stack" style={{ gap: 2 }}>
            <span className="small muted">Account</span>
            <span>
              <strong>{name.trim() || 'Unnamed'}</strong> · <span className="mono">{confirmedEmail}</span>
            </span>
          </div>
          {error ? <div className="alert alert-error">{error}</div> : null}
          <button className="btn btn-primary" type="submit" disabled={busy}>
            {busy ? 'Creating…' : 'Yes, that is correct — create the account'}
          </button>
          <button
            className="btn"
            type="button"
            disabled={busy}
            onClick={() => {
              setError('');
              setStep('details');
            }}
          >
            No, let me change it
          </button>
        </form>
      )}
    </AuthShell>
  );
}
