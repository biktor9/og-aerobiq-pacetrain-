// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import SignUpPage from '@/app/(auth)/sign-up/page';

const mocks = vi.hoisted(() => ({
  signUpEmail: vi.fn(),
  push: vi.fn(),
  refresh: vi.fn()
}));

vi.mock('@/lib/auth-client', () => ({
  signUp: { email: mocks.signUpEmail }
}));

vi.mock('next/navigation', () => ({
  useRouter: () => ({ push: mocks.push, refresh: mocks.refresh })
}));

vi.mock('next/link', () => ({
  default: ({ href, children }: { href: string; children: React.ReactNode }) => <a href={href}>{children}</a>
}));

async function fillDetails(email = 'alex@example.com', password = 'longenough1') {
  const user = userEvent.setup();
  await user.type(screen.getByLabelText('Name'), 'Alex Runner');
  await user.type(screen.getByLabelText('Email'), email);
  await user.type(screen.getByLabelText('Password'), password);
  return user;
}

describe('sign-up page', () => {
  beforeEach(() => {
    mocks.signUpEmail.mockReset().mockResolvedValue({ data: {}, error: null });
    mocks.push.mockReset();
    mocks.refresh.mockReset();
  });

  afterEach(() => cleanup());

  it('starts with the details step and no mailed confirmation', () => {
    render(<SignUpPage />);

    expect(screen.getByRole('heading', { level: 1, name: 'Create your account' })).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Continue' })).toBeInTheDocument();
    expect(screen.queryByText(/Are you sure/i)).not.toBeInTheDocument();
  });

  it('asks the athlete to confirm the address before creating anything', async () => {
    render(<SignUpPage />);
    const user = await fillDetails();

    await user.click(screen.getByRole('button', { name: 'Continue' }));

    expect(screen.getByRole('heading', { level: 1, name: 'Is this the right email?' })).toBeInTheDocument();
    expect(screen.getByText(/Are you sure/i)).toBeInTheDocument();
    expect(screen.getAllByText('alex@example.com')).toHaveLength(2);
    expect(mocks.signUpEmail).not.toHaveBeenCalled();
  });

  it('creates the account and opens the planner once the address is confirmed', async () => {
    render(<SignUpPage />);
    const user = await fillDetails();

    await user.click(screen.getByRole('button', { name: 'Continue' }));
    await user.click(screen.getByRole('button', { name: /yes, that is correct/i }));

    expect(mocks.signUpEmail).toHaveBeenCalledWith({
      name: 'Alex Runner',
      email: 'alex@example.com',
      password: 'longenough1',
      callbackURL: '/plan'
    });
    expect(mocks.push).toHaveBeenCalledWith('/plan');
    expect(mocks.refresh).toHaveBeenCalled();
  });

  it('goes back to the form when the address is wrong', async () => {
    render(<SignUpPage />);
    const user = await fillDetails('alex@exmaple.com');

    await user.click(screen.getByRole('button', { name: 'Continue' }));
    await user.click(screen.getByRole('button', { name: /let me change it/i }));

    expect(screen.getByRole('heading', { level: 1, name: 'Create your account' })).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toHaveValue('alex@exmaple.com');
    expect(mocks.signUpEmail).not.toHaveBeenCalled();
  });

  it('flags a domain that is usually a typo', async () => {
    render(<SignUpPage />);
    const user = await fillDetails('alex@gmial.com');

    await user.click(screen.getByRole('button', { name: 'Continue' }));

    expect(screen.getByText('@gmial.com is usually a typo for @gmail.com.')).toBeInTheDocument();
  });

  it('keeps the athlete on the confirm step when the API rejects the sign-up', async () => {
    mocks.signUpEmail.mockResolvedValue({ data: null, error: { message: 'User already exists' } });
    render(<SignUpPage />);
    const user = await fillDetails();

    await user.click(screen.getByRole('button', { name: 'Continue' }));
    await user.click(screen.getByRole('button', { name: /yes, that is correct/i }));

    expect(await screen.findByText('User already exists')).toBeInTheDocument();
    expect(screen.getByRole('heading', { level: 1, name: 'Is this the right email?' })).toBeInTheDocument();
    expect(mocks.push).not.toHaveBeenCalled();
  });

  it('rejects a short password before the confirmation step', async () => {
    render(<SignUpPage />);
    const user = await fillDetails('alex@example.com', 'short');

    await user.click(screen.getByRole('button', { name: 'Continue' }));

    expect(screen.getByText('Use at least 8 characters for the password.')).toBeInTheDocument();
    expect(screen.getByRole('heading', { level: 1, name: 'Create your account' })).toBeInTheDocument();
    expect(mocks.signUpEmail).not.toHaveBeenCalled();
  });
});
