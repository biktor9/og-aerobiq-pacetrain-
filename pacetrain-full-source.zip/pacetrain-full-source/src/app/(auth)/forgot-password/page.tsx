'use client';

import Link from 'next/link';
import { useState } from 'react';
import { AuthShell } from '@/components/auth-shell';
import { requestPasswordReset } from '@/lib/auth-client';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');

    const { error: authError } = await requestPasswordReset({
      email: email.trim(),
      redirectTo: '/reset-password'
    });

    setBusy(false);
    if (authError) {
      setError(authError.message || 'Could not send the reset link.');
      return;
    }
    setSent(true);
  }

  return (
    <AuthShell
      title="Reset your password"
      subtitle="We will email you a link that lets you choose a new one."
      footer={
        <>
          Remembered it? <Link href="/sign-in">Back to sign in</Link>
        </>
      }
    >
      {sent ? (
        <div className="stack" style={{ gap: 14 }}>
          <div className="alert alert-good">
            If an account exists for {email}, the link is on its way. It expires in one hour.
          </div>
          <Link className="btn" href="/sign-in">
            Back to sign in
          </Link>
        </div>
      ) : (
        <form onSubmit={onSubmit} className="stack" style={{ gap: 13 }}>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              className="input"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@example.com"
            />
          </div>
          {error ? <div className="alert alert-error">{error}</div> : null}
          <button className="btn btn-primary" type="submit" disabled={busy}>
            {busy ? 'Sending…' : 'Send reset link'}
          </button>
        </form>
      )}
    </AuthShell>
  );
}
