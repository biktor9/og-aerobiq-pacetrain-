'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useState } from 'react';
import { AuthShell } from '@/components/auth-shell';
import { resetPassword } from '@/lib/auth-client';

function ResetInner() {
  const router = useRouter();
  const params = useSearchParams();
  const token = params.get('token') ?? '';
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');

    if (!token) {
      setError('This link is missing its token. Request a new email from the sign-in page.');
      return;
    }
    if (password.length < 8) {
      setError('Use at least 8 characters.');
      return;
    }
    if (password !== confirm) {
      setError('The two passwords do not match.');
      return;
    }

    setBusy(true);
    const { error: authError } = await resetPassword({ newPassword: password, token });
    setBusy(false);

    if (authError) {
      setError(authError.message || 'That link is invalid or has expired.');
      return;
    }
    setDone(true);
    setTimeout(() => {
      router.push('/sign-in');
      router.refresh();
    }, 1200);
  }

  return (
    <AuthShell
      title="Choose a new password"
      subtitle={token ? 'Pick something you have not used here before.' : 'This link is incomplete.'}
      footer={
        <>
          <Link href="/sign-in">Back to sign in</Link>
        </>
      }
    >
      {done ? (
        <div className="alert alert-good">Password updated. Taking you to the sign-in page…</div>
      ) : (
        <form onSubmit={onSubmit} className="stack" style={{ gap: 13 }}>
          <div className="field">
            <label htmlFor="password">New password</label>
            <input
              id="password"
              className="input"
              type="password"
              autoComplete="new-password"
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </div>
          <div className="field">
            <label htmlFor="confirm">Repeat it</label>
            <input
              id="confirm"
              className="input"
              type="password"
              autoComplete="new-password"
              required
              value={confirm}
              onChange={(event) => setConfirm(event.target.value)}
            />
          </div>
          {error ? <div className="alert alert-error">{error}</div> : null}
          <button className="btn btn-primary" type="submit" disabled={busy}>
            {busy ? 'Saving…' : 'Save new password'}
          </button>
        </form>
      )}
    </AuthShell>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={null}>
      <ResetInner />
    </Suspense>
  );
}
