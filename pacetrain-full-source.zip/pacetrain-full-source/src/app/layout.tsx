import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: { default: 'PaceTrain', template: '%s · PaceTrain' },
  description:
    'Plan the week, detect the reps automatically, and talk it through with a coach that has read your training.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
