import Link from 'next/link';
import { AccountMenu } from '@/components/account-menu';
import { getSession } from '@/lib/session';

/** Pricing lives outside the app shell: an expired account still has to see it. */
export default async function PaywallLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();

  return (
    <div className="app-shell">
      <header className="topbar">
        <Link href={session?.user ? '/plan' : '/'} className="brand">
          <span className="brand-mark">P</span>
          PaceTrain
        </Link>
        <div className="topbar-spacer" />
        {session?.user ? (
          <AccountMenu name={session.user.name} email={session.user.email} />
        ) : (
          <div className="row" style={{ gap: 8 }}>
            <Link className="btn btn-sm" href="/sign-in">
              Sign in
            </Link>
            <Link className="btn btn-sm btn-primary" href="/sign-up">
              Create account
            </Link>
          </div>
        )}
      </header>
      <main className="app-main">{children}</main>
    </div>
  );
}
