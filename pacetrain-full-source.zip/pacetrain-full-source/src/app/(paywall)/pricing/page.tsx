import Link from 'next/link';
import { PlanCards } from '@/components/plan-cards';
import { ACCESS_MESSAGE, accessFor, expiryLabel, planLabel, trialUsed } from '@/domain/billing';
import { accessForUser } from '@/lib/billing-server';
import { subscriptionHistory } from '@/lib/data';
import { appConfig } from '@/lib/env';
import { getSession } from '@/lib/session';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Pricing' };

const WHAT_YOU_GET = [
  'The week planner, with km and time planned side by side',
  'Automatic interval detection and best efforts from your watch data',
  'Fitness, fatigue and form — the whole training history, not just today',
  'Wellness check-in, readiness score and race countdowns',
  'The AI coach, fed with your real training and your next race'
];

export default async function PricingPage() {
  const session = await getSession();
  const user = session?.user ?? null;

  const [access, history] = user
    ? await Promise.all([accessForUser(user.id), subscriptionHistory(user.id, 20)])
    : [accessFor(null), []];
  const used = trialUsed(history);
  const { contactEmail } = appConfig().paywall;

  return (
    <div className="stack" style={{ gap: 18 }}>
      <div className="pricing-head">
        <span className="badge">PaceTrain membership</span>
        <h1 style={{ margin: '10px 0 6px' }}>A week from 10 kr. A full season for 140.</h1>
        <p className="page-sub" style={{ maxWidth: 640, margin: 0 }}>
          Pick a period, send one email, and train. No checkout on this site, no subscription, no card stored anywhere —
          payment is arranged directly with the developer and the period is switched on by hand.
        </p>
      </div>

      {access.active ? (
        <div className="alert alert-good">
          <strong>You are in.</strong> {planLabel(access.plan)} · {access.daysLeft} days left
          {access.expiresAt ? ` · until ${expiryLabel(access.expiresAt)}` : ''}.{' '}
          <Link href="/plan">Back to training →</Link>
        </div>
      ) : access.reason === 'expired' ? (
        <div className="alert alert-warn">
          <strong>Your period ended{access.expiresAt ? ` on ${expiryLabel(access.expiresAt)}` : ''}.</strong> Pick a new
          one below — everything you logged is still here.
        </div>
      ) : null}

      <PlanCards access={access} trialUsed={used} contactEmail={contactEmail} />

      <div className="pricing-grid">
        <div className="card">
          <div className="card-head">
            <h3>What you get</h3>
            <span className="small muted">the same, on every period</span>
          </div>
          <ul className="plan-perks" style={{ marginTop: 0 }}>
            {WHAT_YOU_GET.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>

        <div className="card">
          <div className="card-head">
            <h3>How it works</h3>
          </div>
          <ol className="buy-steps">
            <li>Choose a period and email the developer.</li>
            <li>Pay by Swish or bank transfer — you get the details in the reply.</li>
            <li>The period is switched on, usually the same day. Then you train.</li>
          </ol>
          <div className="billing-note">
            <strong>Where the money goes.</strong>
            <p className="small" style={{ margin: '4px 0 0' }}>
              {ACCESS_MESSAGE}
            </p>
          </div>
        </div>
      </div>

      {!user ? (
        <p className="small muted">
          Already have an account? <Link href="/sign-in">Sign in</Link> to see your remaining days.
        </p>
      ) : null}
    </div>
  );
}

