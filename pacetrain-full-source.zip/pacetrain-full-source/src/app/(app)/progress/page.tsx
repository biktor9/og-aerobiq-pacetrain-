import Link from 'next/link';
import { EventsPanel } from '@/components/events-panel';
import { FitnessChart } from '@/components/fitness-chart';
import { eventCountdown, nextEvent, PHASE_LABELS, sortEvents } from '@/domain/events';
import { fitnessSeries, fitnessSummary } from '@/domain/fitness';
import { recoveryScore } from '@/domain/recovery';
import { addDays, startOfDay, toISODate } from '@/domain/week';
import { activitiesBetween, listEvents, listSessionsBetween, listSickNotes, recentWellness } from '@/lib/data';
import { requireUser } from '@/lib/session';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Progress' };

const RANGES = [90, 180, 365] as const;

function signed(value: number): string {
  return `${value > 0 ? '+' : ''}${Math.round(value)}`;
}

/**
 * The "how is it going?" page: fitness, fatigue and form from the activities
 * that actually happened, the readiness check-in, and the next race. It is the
 * intervals.icu dashboard cut down to the three questions an athlete asks.
 */
export default async function ProgressPage({ searchParams }: { searchParams: Promise<{ range?: string }> }) {
  const user = await requireUser();
  const params = await searchParams;
  const requested = Number(params.range);
  const range = (RANGES as readonly number[]).includes(requested) ? requested : 90;

  const today = startOfDay(new Date());
  const todayISO = toISODate(today);
  // The curve is warmed up with 84 days before the visible window.
  const from = toISODate(addDays(today, -(range + 83)));

  const [activities, sessions, entries, events, sick] = await Promise.all([
    activitiesBetween(user.id, from, toISODate(addDays(today, 14)), 3000),
    listSessionsBetween(user.id, todayISO, toISODate(addDays(today, 14))),
    recentWellness(user.id, 60),
    listEvents(user.id),
    listSickNotes(user.id, 10)
  ]);

  const series = fitnessSeries({ activities, sessions, days: range, today });
  const fitness = fitnessSummary(series);
  const raceList = sortEvents(events, today);
  const next = nextEvent(events, today);
  const countdown = next ? eventCountdown(next, today) : null;
  const recovery = recoveryScore({
    today: entries.find((entry) => entry.date === todayISO) ?? null,
    entries,
    form: fitness ? { tsb: fitness.today.tsb, atl: fitness.today.atl } : null,
    sick,
    todayISO
  });

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div>
          <h1>Progress</h1>
          <p className="page-sub">
            {countdown && next
              ? countdown.days === 0
                ? `Race day: ${next.name} · ${PHASE_LABELS[countdown.phase]}`
                : `${countdown.days} days until ${next.name} · ${PHASE_LABELS[countdown.phase]} block`
              : 'Fitness, fatigue and form — plus how ready you are today.'}
          </p>
        </div>
        <div className="row">
          <div className="segmented" aria-label="Chart range">
            {RANGES.map((option) => (
              <Link
                key={option}
                href={`/progress?range=${option}`}
                aria-current={option === range ? 'page' : undefined}
              >
                {option === 365 ? '1y' : `${option}d`}
              </Link>
            ))}
          </div>
          <Link className="btn btn-sm" href="/plan">
            This week
          </Link>
        </div>
      </div>

      {fitness ? (
        <div className="stat-grid">
          <div className="stat">
            <div className="stat-label">Fitness</div>
            <div className="stat-value">{Math.round(fitness.today.ctl)}</div>
            <div className="stat-note">{signed(fitness.rampPct)}% over 7 days · 42-day load</div>
          </div>
          <div className="stat">
            <div className="stat-label">Fatigue</div>
            <div className="stat-value">{Math.round(fitness.today.atl)}</div>
            <div className="stat-note">7-day load</div>
          </div>
          <div className="stat">
            <div className="stat-label">Form</div>
            <div className="stat-value">{signed(fitness.today.tsb)}</div>
            <div className="stat-note">
              <span
                className={`badge ${
                  fitness.form.tone === 'good'
                    ? 'badge-good'
                    : fitness.form.tone === 'bad'
                      ? 'badge-bad'
                      : fitness.form.tone === 'warn'
                        ? 'badge-warn'
                        : ''
                }`}
              >
                {fitness.form.label}
              </span>
            </div>
          </div>
          <div className="stat">
            <div className="stat-label">Last 7 days</div>
            <div className="stat-value">{Math.round(fitness.weekLoad)}</div>
            <div className="stat-note">{Math.round(fitness.plannedLoad)} load planned next week</div>
          </div>
          <div className="stat">
            <div className="stat-label">Recovery</div>
            <div className="stat-value">{recovery.score}</div>
            <div className="stat-note">
              <span
                className={`badge ${
                  recovery.tone === 'good'
                    ? 'badge-good'
                    : recovery.tone === 'bad'
                      ? 'badge-bad'
                      : recovery.tone === 'warn'
                        ? 'badge-warn'
                        : ''
                }`}
              >
                {recovery.label}
              </span>
            </div>
          </div>
        </div>
      ) : null}

      <div className="card">
        <div className="card-head">
          <h3>Fitness, fatigue and form</h3>
          <span className="small muted">last {range} days · dashed tail is the plan</span>
        </div>
        <FitnessChart points={series} days={range} />
        {fitness ? (
          <p className="small muted" style={{ marginTop: 10, marginBottom: 0 }}>
            {fitness.form.advice}
          </p>
        ) : null}
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-head">
            <h3>Recovery today</h3>
            <span className="small muted">{recovery.hasData ? 'from your morning check-in' : 'nothing logged yet'}</span>
          </div>
          <div className="recovery-head">
            <div className={`readiness readiness-${recovery.tone}`}>
              <span className="readiness-score">{recovery.score}</span>
              <span className="readiness-label">{recovery.label}</span>
            </div>
            <p className="small muted" style={{ margin: 0 }}>
              {recovery.summary}
            </p>
          </div>
          <Link className="btn btn-sm" href="/recovery" style={{ marginTop: 12 }}>
            Open the morning check-in →
          </Link>
        </div>
        <EventsPanel events={raceList} todayISO={todayISO} />
      </div>

      {!activities.length ? (
        <div className="alert">
          <strong>Nothing imported yet.</strong>
          <p className="small" style={{ marginTop: 4 }}>
            Fitness, fatigue and form are built from your activities. Connect intervals.icu in{' '}
            <Link href="/settings">Settings</Link>, or load the sample week from the Plan tab to see how it looks with
            data.
          </p>
        </div>
      ) : null}
    </div>
  );
}
