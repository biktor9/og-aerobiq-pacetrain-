import { AnalysisView } from '@/components/analysis-view';
import { appConfig } from '@/lib/env';
import { getSettings, listActivities } from '@/lib/data';
import { requireUser } from '@/lib/session';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Analysis' };

export default async function AnalysisPage({ searchParams }: { searchParams: Promise<{ activity?: string }> }) {
  const user = await requireUser();
  const params = await searchParams;
  const [activities, settings] = await Promise.all([listActivities(user.id, 80), getSettings(user.id)]);

  // The AI parser only runs when there is a key to run it with — the page says
  // which of the two it is instead of leaving a dead button.
  const aiConfigured = Boolean(appConfig().deepseek.apiKey) || Boolean(settings.deepseekKeyEnc);

  const requested = params.activity;
  const selectedId =
    requested && activities.some((activity) => activity.id === requested) ? requested : (activities[0]?.id ?? null);

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div>
          <h1>Analysis</h1>
          <p className="page-sub">
            Intervals are found in the stream itself. Write the session you meant to run and it is compared with what
            happened — no manual marking.
          </p>
        </div>
      </div>

      <AnalysisView activities={activities} initialActivityId={selectedId} aiConfigured={aiConfigured} />
    </div>
  );
}
