import Link from 'next/link';
import { BaselinesPanel } from '@/components/baselines-panel';
import { SickPanel } from '@/components/sick-panel';
import { WellnessPanel } from '@/components/wellness-panel';
import { addDays, startOfDay, toISODate, weekdayLabel } from '@/domain/week';
import { baselineTable } from '@/domain/baselines';
import { fitnessSeries, fitnessSummary } from '@/domain/fitness';
import { observedMaxHr } from '@/domain/hr-zones';
import { recoveryScore } from '@/domain/recovery';
import { wellnessDays, wellnessSummary } from '@/domain/wellness';
import { activitiesBetween, getSettings, listSickNotes, recentWellness } from '@/lib/data';
import { requireUser } from '@/lib/session';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Recovery' };

/**
 * The morning question: how recovered am I, and does the athlete agree?
 * HRV, resting heart rate and sleep are scored against the athlete's own
 * baseline; the check-in below lets them overrule the watch in words.
 */
export default async function RecoveryPage() {
  const user = await requireUser();
  const today = startOfDay(new Date());
  const todayISO = toISODate(today);

  const [entries, sick, fitnessActivities, settings] = await Promise.all([
    recentWellness(user.id, 60),
    listSickNotes(user.id, 10),
    activitiesBetween(user.id, toISODate(addDays(today, -174)), todayISO, 2000),
    getSettings(user.id)
  ]);

  const wellness = wellnessSummary(entries, { today });
  const days = wellnessDays(entries, { today, days: 14 });
  const fitness = fitnessSummary(fitnessSeries({ activities: fitnessActivities, days: 60, projectedDays: 0, today }));

  // The athlete's own numbers, when they typed any; a rolling average otherwise.
  const manual = {
    hrvMs: settings.baselineHrvMs ?? null,
    restingHr: settings.baselineRestingHr ?? null,
    sleepHours: settings.baselineSleepHours ?? null
  };
  const baselines = baselineTable(entries, manual);
  const observed = observedMaxHr(fitnessActivities);

  const recovery = recoveryScore({
    today: entries.find((entry) => entry.date === todayISO) ?? null,
    entries,
    form: fitness ? { tsb: fitness.today.tsb, atl: fitness.today.atl } : null,
    sick,
    todayISO,
    baselines: manual
  });

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div>
          <h1>Recovery</h1>
          <p className="page-sub">
            {weekdayLabel(today)} {today.getDate()} · {recovery.summary}
          </p>
        </div>
        <Link className="btn btn-sm" href="/progress">
          Trends →
        </Link>
      </div>

      {recovery.sick ? (
        <div className="alert alert-warn">
          <strong>You are marked as sick.</strong> The coach will not push sessions until the illness note is over —
          delete or shorten it on the right when you are back.
        </div>
      ) : null}

      <div className="card">
        <div className="recovery-head">
          <div className={`readiness readiness-${recovery.tone}`}>
            <span className="readiness-score">{recovery.score}</span>
            <span className="readiness-label">{recovery.label}</span>
          </div>
          <div>
            <strong style={{ fontSize: 15 }}>{recovery.summary}</strong>
            <p className="small muted" style={{ margin: '4px 0 0' }}>
              {recovery.hasData
                ? 'Scored from overnight HRV and resting heart rate against your own baseline, sleep, soreness, stress, training form and your own read.'
                : 'Log sleep and HRV below — two or three mornings is all it takes to build a baseline.'}
            </p>
          </div>
        </div>

        {recovery.signals.length ? (
          <table className="seg-table recovery-signals" style={{ marginTop: 14 }}>
            <thead>
              <tr>
                <th>Signal</th>
                <th>Today</th>
                <th>What it means</th>
              </tr>
            </thead>
            <tbody>
              {recovery.signals.map((signal) => (
                <tr key={signal.key}>
                  <td>
                    <span className={`dot tone-${signal.verdict}`} style={{ marginRight: 6 }} />
                    {signal.label}
                  </td>
                  <td className="mono">{signal.value}</td>
                  <td className="small muted">{signal.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : null}
      </div>

      <div className="grid-2">
        <WellnessPanel entries={entries} summary={wellness} days={days} todayISO={todayISO} />
        <SickPanel notes={sick} todayISO={todayISO} />
      </div>

      <BaselinesPanel
        baselines={baselines}
        maxHr={settings.maxHr ?? null}
        observedMaxHr={observed}
      />
    </div>
  );
}
