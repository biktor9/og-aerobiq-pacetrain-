﻿import Link from 'next/link';
import { DashboardEditor } from '@/components/dashboard-editor';
import { PlanWidgets, type PlanData } from '@/components/plan-widgets';
import { runningTotals } from '@/domain/activity';
import { parseDashboard, parseProgressStyle, parseSizes } from '@/domain/dashboard';
import { eventCountdown } from '@/domain/events';
import { areaAround, heatTotals, isHeatPeriod, latestRoutes, periodStart, routesInArea } from '@/domain/heat';
import { observedMaxHr, parseZoneBounds, parseZoneModes, zoneMinutes } from '@/domain/hr-zones';
import { ramp, weekStats } from '@/domain/load';
import { formatPace, paceTable } from '@/domain/pace';
import { fitnessSeries, fitnessSummary } from '@/domain/fitness';
import { recoveryScore, sickDays as sickDates } from '@/domain/recovery';
import { sportMix } from '@/domain/sport-mix';
import { buildCalendarWeeks } from '@/domain/week-summary';
import {
  addDays,
  addWeeks,
  fmtDuration,
  isWeekKey,
  mondayOfWeekKey,
  startOfWeek,
  toISODate,
  weekKey,
  weekRangeLabel,
  weekdayLabel
} from '@/domain/week';
import {
  activitiesBetween,
  getSettings,
  listSessionsBetween,
  previousWeekLoad,
  recentWellness,
  sickNotesCovering,
  upcomingEvents,
  weekSessions
} from '@/lib/data';
import { requireUser } from '@/lib/session';
import { missingRoutes, storedRoutes } from '@/lib/routes';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Plan' };

export default async function PlanPage({
  searchParams
}: {
  searchParams: Promise<{ week?: string; edit?: string }>;
}) {
  const user = await requireUser();
  const params = await searchParams;
  const monday = params.week && isWeekKey(params.week) ? mondayOfWeekKey(params.week) : startOfWeek(new Date());
  const key = weekKey(monday);
  const editing = params.edit === '1';

  const [sessions, previousLoad, settings, weekActivities, recentActivities, stripActivities, stripSessions, races, sickNotes] =
    await Promise.all([
      weekSessions(user.id, monday),
      previousWeekLoad(user.id, monday),
      getSettings(user.id),
      // What actually happened this week, and the paces it implies.
      activitiesBetween(user.id, toISODate(monday), toISODate(addDays(monday, 6))),
      activitiesBetween(user.id, toISODate(addDays(new Date(), -60)), toISODate(new Date()), 300),
      // The calendar's window: the last three weeks, this one and the next.
      activitiesBetween(user.id, toISODate(addWeeks(monday, -3)), toISODate(addDays(addWeeks(monday, 1), 6)), 600),
      listSessionsBetween(user.id, toISODate(addWeeks(monday, -3)), toISODate(addDays(addWeeks(monday, 1), 6))),
      upcomingEvents(user.id, 1),
      sickNotesCovering(user.id, toISODate(addWeeks(monday, -3)), toISODate(addDays(addWeeks(monday, 1), 6)))
    ]);

  const paces = paceTable(recentActivities);
  const weekRuns = runningTotals(weekActivities);
  const stats = weekStats(sessions);
  const rampInfo = ramp(stats.load, previousLoad);

  // The heat map: the traces stored for the chosen window, kept to the chosen
  // area. Both choices live in user_settings, so they survive a reload.
  const heatPeriod = isHeatPeriod(settings.heatPeriod) ? settings.heatPeriod : 'week';
  const heatFrom = toISODate(periodStart(heatPeriod, new Date()));
  const [heatStored, heatMissing] = await Promise.all([
    storedRoutes(user.id, heatFrom),
    missingRoutes(user.id, heatFrom)
  ]);
  const heatArea =
    settings.heatLat != null && settings.heatLng != null
      ? {
          lat: settings.heatLat,
          lng: settings.heatLng,
          radiusKm: settings.heatRadiusKm ?? 15,
          label: settings.heatLabel || 'Your area'
        }
      : areaAround(heatStored.flatMap((route) => route.points));
  // A year of daily runs is a lot of points to send to the browser: the newest
  // three hundred traces are drawn, and the totals describe exactly those.
  const heatRecent = latestRoutes(heatStored, 300);
  const heatVisible = heatArea ? routesInArea(heatRecent, heatArea) : [];
  const heatSummary = heatTotals(heatVisible);
  // What the week was actually made of, sport by sport.
  const mix = sportMix({ activities: weekActivities, sessions });
  const thisWeek = weekKey(startOfWeek(new Date()));
  // The calendar: the last three weeks, this week, then next week's plan.
  const weeks = buildCalendarWeeks({ monday, activities: stripActivities, sessions: stripSessions });
  const current = weeks[weeks.length - 2];
  // The last row is next week; it carries the plan that has not happened yet.
  const nextWeek = weeks[weeks.length - 1];
  const planPct = Math.min(100, Math.max(0, current.donePlanPct));
  // The heart-rate bar: the week's minutes, split over the athlete's own zones.
  // A max or a set of boundaries typed in Settings wins over the defaults.
  const maxHr = settings.maxHr && settings.maxHr > 100 ? settings.maxHr : observedMaxHr(recentActivities);
  const zoneBounds = parseZoneBounds(settings.hrZoneBounds, maxHr);
  const zoneModes = parseZoneModes(settings.hrZoneModes);
  const weekZones = zoneMinutes(weekActivities, { bounds: zoneBounds, modes: zoneModes });
  const nextRace = races[0] ?? null;
  const raceCountdown = nextRace ? eventCountdown(nextRace, new Date()) : null;
  const paceNote =
    weekRuns.avgPaceSecPerKm && current.runs
      ? `${current.runs} run${current.runs === 1 ? '' : 's'} · ${formatPace(weekRuns.avgPaceSecPerKm)} avg`
      : current.runs
        ? `${current.runs} run${current.runs === 1 ? '' : 's'}`
        : `run · trail · orienteering at ${formatPace(paces.run)}`;

  // The page's own layout, and how percentages are drawn.
  const dashboard = parseDashboard(settings.dashboardJson);
  const progressStyle = parseProgressStyle(settings.progressStyle);
  const sizes = parseSizes(settings.dashboardSizes);

  // The morning recovery score, for the recovery block. Same inputs as the
  // Recovery page, so the two can never disagree.
  const [entries, fitnessActivities] = await Promise.all([
    recentWellness(user.id, 14),
    activitiesBetween(user.id, toISODate(addDays(new Date(), -60)), toISODate(new Date()), 200)
  ]);
  const todayISO = toISODate(new Date());
  const fitness = fitnessSummary(fitnessSeries({ activities: fitnessActivities, days: 60, projectedDays: 0 }));
  const recovery = recoveryScore({
    today: entries.find((entry) => entry.date === todayISO) ?? null,
    entries,
    form: fitness ? { tsb: fitness.today.tsb, atl: fitness.today.atl } : null,
    sick: sickNotes,
    todayISO,
    baselines: {
      hrvMs: settings.baselineHrvMs ?? null,
      restingHr: settings.baselineRestingHr ?? null,
      sleepHours: settings.baselineSleepHours ?? null
    }
  });

  // Sessions still to do this week: not finished, not dropped.
  const outstanding = sessions
    .filter((session) => session.status === 'planned' && !session.linkedActivityId)
    .map((session) => {
      const date = new Date(`${session.date}T00:00:00`);
      return {
        id: session.id,
        weekday: weekdayLabel(date).slice(0, 3),
        dayOfMonth: date.getDate(),
        title: session.title,
        mode: session.mode,
        minutes: session.durationMin
      };
    });

  // Load per week across the window, so the ramp card has something to draw.
  const loadBars = weeks.map((week) => {
    const weekActivitiesInWindow = stripActivities.filter((activity) => week.days.some((day) => day.date === activity.date));
    return {
      key: week.key,
      label: week.label,
      load: Math.round(weekActivitiesInWindow.reduce((total, activity) => total + (activity.load ?? 0), 0))
    };
  });

  // Everything the widgets need, assembled once.
  const planData: PlanData = {
    order: dashboard.order,
    progressStyle,
    sizes,
    current,
    nextWeek,
    weeks,
    weekKeyValue: key,
    mondayISO: toISODate(monday),
    sickDays: sickDates(sickNotes),
    paceNote,
    load: stats.load,
    rampInfo,
    previousLoad,
    loadBars,
    loadPeak: Math.max(1, ...loadBars.map((bar) => bar.load)),
    avgPaceSecPerKm: weekRuns.avgPaceSecPerKm ?? null,
    outstanding,
    recovery: {
      hasData: recovery.hasData,
      score: recovery.score,
      summary: recovery.summary,
      label: recovery.label
    },
    sessions,
    weekActivities,
    paces,
    mix,
    zones: weekZones,
    zoneBounds,
    zoneModes,
    heat: {
      routes: heatVisible,
      area: heatArea,
      period: heatPeriod,
      missing: heatMissing,
      totals: heatSummary,
      loaded: heatStored.length
    }
  };

  return (
    <div className="stack" style={{ gap: 18 }}>
      <div className="page-head">
        <div>
          <h1>
            Week {key.slice(6)}{' '}
            <span className="muted" style={{ fontSize: 15, fontWeight: 500 }}>
              {weekRangeLabel(monday)}
            </span>
          </h1>
          <p className="page-sub">
            {current.sessions
              ? `${current.sessions} sessions · ${fmtDuration(current.plannedMinutes)} planned`
              : 'No sessions planned yet'}
            {current.runningKm ? ` · ${current.runningKm.toFixed(1)} km run` : ''}
            {settings.weeklyMinutesTarget ? ` of a ${fmtDuration(settings.weeklyMinutesTarget)} weekly target` : ''}
            {nextRace && raceCountdown ? (
              <>
                {' · '}
                <Link href="/progress">
                  {raceCountdown.days === 0
                    ? `race day: ${nextRace.name}`
                    : `${raceCountdown.days} days to ${nextRace.name}`}
                </Link>
              </>
            ) : null}
          </p>
        </div>
        <div className="row-wrap" style={{ gap: 6 }}>
          <Link className="btn btn-sm" href={`/plan?week=${weekKey(addWeeks(monday, -1))}`}>
            ‹ Prev
          </Link>
          {key !== thisWeek ? (
            <Link className="btn btn-sm" href="/plan">
              This week
            </Link>
          ) : null}
          <Link className="btn btn-sm" href={`/plan?week=${weekKey(addWeeks(monday, 1))}`}>
            Next ›
          </Link>
          <Link
            className={`btn btn-sm${editing ? ' btn-primary' : ''}`}
            href={editing ? `/plan?week=${key}` : `/plan?week=${key}&edit=1`}
            title="Move, remove and add the blocks on this page"
          >
            {editing ? 'Editing…' : '✎ Edit'}
          </Link>
          <Link className="btn btn-sm btn-primary" href="/coach">
            Ask the coach
          </Link>
        </div>
      </div>

      <PlanWidgets data={planData} editing={editing} />
    </div>
  );
}
