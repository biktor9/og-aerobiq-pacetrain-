import Link from 'next/link';
import { GrantAccessForm } from '@/components/grant-access-form';
import { PlanCards } from '@/components/plan-cards';
import { ACCESS_MESSAGE, expiryLabel, formatSek, planLabel, trialUsed } from '@/domain/billing';
import { accessForUser } from '@/lib/billing-server';
import { subscriptionHistory } from '@/lib/data';
import { appConfig } from '@/lib/env';
import { isAdmin, requireUser } from '@/lib/session';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Billing' };

const SOURCE_LABELS: Record<string, string> = {
  manual: 'manual',
  grant: 'switched on',
  demo: 'sample'
};

export default async function BillingPage() {
  const user = await requireUser();
  const [access, history] = await Promise.all([accessForUser(user.id), subscriptionHistory(user.id, 20)]);
  const used = trialUsed(history);
  const spent = history.reduce((sum, entry) => sum + entry.amountSek, 0);
  const { contactEmail } = appConfig().paywall;

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div>
          <h1>Plan &amp; billing</h1>
          <p className="page-sub">
            {access.active
              ? `${planLabel(access.plan)} · ${access.daysLeft} days left`
              : 'No active plan. Pick a period below and get in touch.'}
          </p>
        </div>
        <Link className="btn btn-sm" href="/pricing">
          See the prices
        </Link>
      </div>

      <div className="stat-grid">
        <div className="stat">
          <div className="stat-label">Plan</div>
          <div className="stat-value">{planLabel(access.plan)}</div>
          <div className="stat-note">{access.active ? 'active' : access.reason === 'expired' ? 'expired' : 'none yet'}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Days left</div>
          <div className="stat-value">{access.daysLeft}</div>
          <div className="stat-note">
            {access.expiresAt ? `until ${expiryLabel(access.expiresAt)}` : 'nothing to count down'}
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Paid so far</div>
          <div className="stat-value">{formatSek(spent)}</div>
          <div className="stat-note">
            {history.length} payment{history.length === 1 ? '' : 's'} · one-off, no auto-renew
          </div>
        </div>
      </div>

      <PlanCards access={access} trialUsed={used} contactEmail={contactEmail} compact />

      <p className="small faint" style={{ margin: 0 }}>
        {ACCESS_MESSAGE}
      </p>

      {history.length ? (
        <div className="card">
          <div className="card-head">
            <h3>History</h3>
            <span className="small muted">every period, including grants</span>
          </div>
          <table className="seg-table">
            <thead>
              <tr>
                <th>From</th>
                <th>To</th>
                <th>Plan</th>
                <th>Amount</th>
                <th>Source</th>
              </tr>
            </thead>
            <tbody>
              {history.map((entry) => (
                <tr key={entry.id}>
                  <td>{expiryLabel(entry.startedAt)}</td>
                  <td>{expiryLabel(entry.expiresAt)}</td>
                  <td>{planLabel(entry.plan)}</td>
                  <td>{entry.amountSek ? formatSek(entry.amountSek) : '—'}</td>
                  <td className="small muted">
                    {SOURCE_LABELS[entry.source] ?? entry.source}
                    {entry.note ? ` · ${entry.note}` : ''}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}

      {isAdmin(user) ? (
        <div className="card">
          <div className="card-head">
            <h3>Grant access</h3>
            <span className="small muted">admin — switch a period on after the payment arrives</span>
          </div>
          <GrantAccessForm />
          {!contactEmail ? (
            <p className="field-hint" style={{ marginTop: 10 }}>
              Set <code>CONTACT_EMAIL</code> in the environment to show your address on the pricing page.
            </p>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

