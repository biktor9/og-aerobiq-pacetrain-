import Link from 'next/link';
import { redirect } from 'next/navigation';
import { AccountMenu } from '@/components/account-menu';
import { PageBanner } from '@/components/page-banner';
import { TopNav } from '@/components/top-nav';
import { accessForUser } from '@/lib/billing-server';
import { pageNotes } from '@/lib/data';
import { appConfig } from '@/lib/env';
import { getSession, isAdmin } from '@/lib/session';

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  if (!session?.user) redirect('/sign-in');

  const admin = isAdmin(session.user);

  // The paywall. Admins (the people running the site) always get in; everyone
  // else needs a paid period that has not run out. Set PAYWALL_ENABLED=false to
  // open the site up again without deleting anyone's subscription.
  if (appConfig().paywall.enabled && !admin) {
    const access = await accessForUser(session.user.id);
    if (!access.active) redirect('/pricing');
  }

  // Every tab's note, read once for the shell rather than per page.
  const notes = await pageNotes();

  return (
    <div className="app-shell">
      <header className="topbar">
        <Link href="/plan" className="brand">
          <span className="brand-mark">P</span>
          PaceTrain
        </Link>
        <TopNav isAdmin={admin} />
        <div className="topbar-spacer" />
        <AccountMenu name={session.user.name} email={session.user.email} />
      </header>
      <main className="app-main">
        <PageBanner isAdmin={admin} notes={notes} />
        {children}
      </main>
    </div>
  );
}

