import Link from 'next/link';
import { notFound } from 'next/navigation';
import { IntervalChart } from '@/components/interval-chart';
import { TileMap } from '@/components/tile-map';
import { centreOf, radiusOf, routeBounds } from '@/domain/geo';
import { describeBlocks } from '@/domain/interval-text';
import { formatPace, isDistanceMode } from '@/domain/pace';
import { mode as modeInfo, zone } from '@/domain/types';
import { fmtClock, fmtKm, parseISODate, weekdayLabel } from '@/domain/week';
import { activityDetail } from '@/lib/activity-detail';
import { requireUser } from '@/lib/session';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Activity' };

const FEEL_LABELS = ['terrible', 'poor', 'OK', 'good', 'great'];

/** `+4″`, `−1:12` — how a split differs from the average. */
function signedSpan(seconds: number): string {
  const rounded = Math.round(seconds);
  if (!rounded) return 'even';
  const magnitude = Math.abs(rounded);
  const text = magnitude >= 60 ? fmtClock(magnitude) : `${magnitude}″`;
  return `${rounded > 0 ? '+' : '−'}${text}`;
}

export default async function ActivityPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireUser();
  const { id } = await params;
  const detail = await activityDetail(user.id, id);
  if (!detail) notFound();

  const { activity, splits, charts, planned, efforts, route, note } = detail;

  const bounds = route.length > 1 ? routeBounds(route) : null;
  const mapCentre = bounds ? centreOf(bounds) : null;
  const mapRadiusKm = bounds ? Math.max(0.4, radiusOf(bounds) * 1.15) : 2;

  const ascending = splits?.rows.length ? splits.rows.reduce((sum, row) => sum + (row.gainM ?? 0), 0) : null;
  const descending = splits?.rows.length ? splits.rows.reduce((sum, row) => sum + (row.lossM ?? 0), 0) : null;
  // One time base for the whole header: the stream's moving time when there are
  // splits, the activity's own moving time otherwise. Time ÷ Distance is then the
  // pace shown, and both agree with intervals.icu.
  const displaySec = splits && splits.totalSec > 0 ? splits.totalSec : activity.durationSec;
  const avgPace =
    activity.distanceM >= 500 && displaySec > 0 ? displaySec / (activity.distanceM / 1000) : null;

  // Runners read pace; a ride or a ski reads speed. Both come from seconds/km.
  const runningSplits = isDistanceMode(activity.mode);
  const paceText = (pace: number) => (runningSplits ? formatPace(pace) : `${(3600 / pace).toFixed(1)} km/h`);

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <Link className="small muted" href="/activities">
          ← Activities
        </Link>
        <div className="row" style={{ gap: 6 }}>
          <Link className="btn btn-sm" href={`/activities?edit=${activity.id}`}>
            Edit
          </Link>
          <Link className="btn btn-sm" href={`/analysis?activity=${activity.id}`}>
            Analyse intervals →
          </Link>
        </div>
      </div>

      <div className="page-head" style={{ marginBottom: 0 }}>
        <div>
          <h1>{activity.name || 'Activity'}</h1>
          <p className="page-sub">
            {weekdayLabel(parseISODate(activity.date))} {parseISODate(activity.date).getDate()} ·{' '}
            {modeInfo(activity.mode).label}
            {activity.source === 'demo' ? ' · sample data' : ''}
          </p>
          {activity.rpe || activity.feel || activity.notes ? (
            <div className="stack" style={{ gap: 6, marginTop: 8 }}>
              <div className="row-wrap" style={{ gap: 6 }}>
                {activity.feel ? <span className="badge">felt {FEEL_LABELS[activity.feel - 1]}</span> : null}
                {activity.rpe ? <span className="badge">RPE {activity.rpe}/10</span> : null}
              </div>
              {activity.notes ? (
                <p className="small muted" style={{ margin: 0 }}>
                  {activity.notes}
                </p>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>

      <div className="stat-grid">
        <div className="stat">
          <div className="stat-label">Time</div>
          <div className="stat-value">{fmtClock(displaySec)}</div>
          <div className="stat-note">
            {splits
              ? `moving time from the stream${
                  Math.abs(displaySec - activity.durationSec) >= 60
                    ? ` · device says ${fmtClock(activity.durationSec)}`
                    : ''
                }`
              : `${Math.round(activity.durationSec / 60)} minutes moving`}
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Distance</div>
          <div className="stat-value">{activity.distanceM ? fmtKm(activity.distanceM) : '—'}</div>
          <div className="stat-note">
            {splits?.rows.length ? `${splits.rows.length} km splits` : 'no kilometre splits'}
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">{runningSplits ? 'Average pace' : 'Average speed'}</div>
          <div className="stat-value">{avgPace ? paceText(avgPace) : '—'}</div>
          <div className="stat-note">
            {activity.distanceM >= 500 && displaySec > 0
              ? `${fmtClock(displaySec)} over ${(activity.distanceM / 1000).toFixed(2)} km`
              : 'no distance recorded'}
            {splits?.fastest ? ` · fastest ${paceText(splits.fastest.paceSecPerKm ?? 0)}` : ''}
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Heart rate</div>
          <div className="stat-value">{activity.avgHr ? `${activity.avgHr} bpm` : '—'}</div>
          <div className="stat-note">{activity.maxHr ? `max ${activity.maxHr} bpm` : 'no heart rate recorded'}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Climbing</div>
          <div className="stat-value">{ascending !== null ? `${ascending} m` : '—'}</div>
          <div className="stat-note">{descending !== null ? `${descending} m down` : 'no altitude recorded'}</div>
        </div>
      </div>

      <div className="row-wrap" style={{ gap: 6 }}>
        {splits?.fastest ? (
          <span className="badge badge-good">
            fastest km {splits.fastest.index} · {paceText(splits.fastest.paceSecPerKm ?? 0)}
          </span>
        ) : null}
        {splits?.slowest && splits.slowest.index !== splits.fastest?.index ? (
          <span className="badge badge-warn">
            slowest km {splits.slowest.index} · {paceText(splits.slowest.paceSecPerKm ?? 0)}
          </span>
        ) : null}
        {splits?.biggestClimb ? (
          <span className="badge">biggest climb km {splits.biggestClimb.index} · ↑{splits.biggestClimb.gainM} m</span>
        ) : null}
        {activity.load ? <span className="badge">load {Math.round(activity.load)}</span> : null}
      </div>

      {mapCentre ? (
        <div className="card">
          <div className="card-head">
            <h3>Route</h3>
            <span className="small muted">satellite · drag to pan, + / − to zoom</span>
          </div>
          <TileMap
            lines={[{ id: activity.id, points: route }]}
            centre={mapCentre}
            radiusKm={mapRadiusKm}
            height={380}
            ariaLabel={`Route of ${activity.name || 'this activity'} on a satellite map`}
          />
        </div>
      ) : null}

      <div className="card">
        <div className="card-head">
          <h3>Kilometre splits</h3>
          <span className="small muted">
            {splits?.rows.length
              ? `${(splits.totalM / 1000).toFixed(2)} km · ${fmtClock(splits.totalSec)}`
              : 'worked out from the recorded stream'}
          </span>
        </div>

        {splits?.rows.length ? (
          <div className="scroll-y">
            <table className="seg-table">
              <thead>
                <tr>
                  <th>Km</th>
                  <th>Time</th>
                  <th>{runningSplits ? 'Pace' : 'Speed'}</th>
                  <th>Avg HR</th>
                  <th>Max HR</th>
                  <th>Climb</th>
                  {runningSplits ? <th>vs avg</th> : null}
                </tr>
              </thead>
              <tbody>
                {splits.rows.map((row) => (
                  <tr key={row.index}>
                    <td>
                      {row.index}
                      {row.partial ? (
                        <span className="small faint"> · {Math.round(row.distanceM)} m</span>
                      ) : null}
                    </td>
                    <td className="mono">{fmtClock(row.durationSec)}</td>
                    <td>{row.paceSecPerKm ? paceText(row.paceSecPerKm) : '—'}</td>
                    <td>{row.avgHr ?? '—'}</td>
                    <td>{row.maxHr ?? '—'}</td>
                    <td>
                      {row.gainM !== null ? (
                        <span className="small">
                          ↑{row.gainM}
                          {row.lossM ? ` ↓${row.lossM}` : ''} m
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    {runningSplits ? (
                      <td>
                        {row.deltaVsAveragePaceSec === null ? (
                          <span className="faint">—</span>
                        ) : (
                          <span className={`badge ${row.deltaVsAveragePaceSec <= 0 ? 'badge-good' : 'badge-warn'}`}>
                            {signedSpan(row.deltaVsAveragePaceSec)}
                          </span>
                        )}
                      </td>
                    ) : null}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty">{note || 'No splits for this activity.'}</div>
        )}
      </div>

      {efforts.length ? (
        <div className="card">
          <div className="card-head">
            <h3>Best efforts</h3>
            <span className="small muted">fastest stretch of the session over each distance</span>
          </div>
          <table className="seg-table">
            <thead>
              <tr>
                <th>Distance</th>
                <th>Time</th>
                <th>{runningSplits ? 'Pace' : 'Speed'}</th>
                <th>Starts at</th>
              </tr>
            </thead>
            <tbody>
              {efforts.map((effort) => (
                <tr key={effort.label}>
                  <td>{effort.label}</td>
                  <td className="mono">{fmtClock(effort.seconds)}</td>
                  <td>{paceText(effort.paceSecPerKm)}</td>
                  <td className="small muted">{fmtClock(effort.startSec)} into the session</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}


      {charts.pace || charts.hr ? (
        <div className="card">
          <div className="card-head">
            <h3>Over the session</h3>
            <span className="small muted">from the recorded streams</span>
          </div>
          <div className="stack" style={{ gap: 12 }}>
            {charts.pace ? (
              <div>
                <div className="small muted">{charts.pace.label}</div>
                <IntervalChart
                  time={charts.pace.time}
                  values={charts.pace.values}
                  unit={charts.pace.unit}
                  segments={[]}
                  invert={charts.pace.invert}
                  label={charts.pace.label}
                  footer=""
                />
              </div>
            ) : null}
            {charts.hr ? (
              <div>
                <div className="small muted">{charts.hr.label}</div>
                <IntervalChart
                  time={charts.hr.time}
                  values={charts.hr.values}
                  unit={charts.hr.unit}
                  segments={[]}
                  label={charts.hr.label}
                  footer=""
                />
              </div>
            ) : null}
          </div>
        </div>
      ) : null}

      <div className="card">
        <div className="card-head">
          <h3>Planned for this day</h3>
          {planned ? (
            <span className="row small" style={{ gap: 5 }}>
              <span className="dot" style={{ background: zone(planned.zone).color }} />Z{planned.zone}
            </span>
          ) : null}
        </div>

        {planned ? (
          <div className="stack" style={{ gap: 8 }}>
            <div className="spread">
              <span>{planned.title || describeBlocks(planned.blocks) || 'Planned session'}</span>
              <span className="small muted">
                {planned.durationMin}′{planned.targetKm ? ` · ${planned.targetKm} km` : ''}
              </span>
            </div>
            <table className="seg-table">
              <thead>
                <tr>
                  <th>Metric</th>
                  <th>Planned</th>
                  <th>Actual</th>
                  <th>Δ</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Time</td>
                  <td>{fmtClock(planned.durationMin * 60)}</td>
                  <td>{fmtClock(activity.durationSec)}</td>
                  <td>{signedSpan(activity.durationSec - planned.durationMin * 60)}</td>
                </tr>
                {planned.targetKm ? (
                  <tr>
                    <td>Distance</td>
                    <td>{planned.targetKm.toFixed(1)} km</td>
                    <td>{fmtKm(activity.distanceM)}</td>
                    <td>
                      {`${activity.distanceM / 1000 - planned.targetKm >= 0 ? '+' : '−'}${Math.abs(
                        activity.distanceM / 1000 - planned.targetKm
                      ).toFixed(1)} km`}
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty">
            Nothing was planned for this day. <Link href="/plan">Plan the week →</Link>
          </div>
        )}
      </div>
    </div>
  );
}

