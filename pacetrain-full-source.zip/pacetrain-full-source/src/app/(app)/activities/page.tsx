import Link from 'next/link';
import { ActivitiesView } from '@/components/activities-view';
import { ImportButtons } from '@/components/import-buttons';
import { activityRangeBounds, DEFAULT_ACTIVITY_RANGE, isActivityRangeId } from '@/domain/activity';
import { parseISODate, toISODate, weekdayLabel } from '@/domain/week';
import { activitiesBetween, countActivities } from '@/lib/data';
import { requireUser } from '@/lib/session';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Activities' };

export default async function ActivitiesPage({
  searchParams
}: {
  searchParams: Promise<{ range?: string; days?: string; day?: string; edit?: string }>;
}) {
  const user = await requireUser();
  const params = await searchParams;

  // `?days=30` is the old link shape; keep it working.
  const requested = params.range ?? (params.days ? `${Number(params.days)}d` : null);
  const rangeId = isActivityRangeId(requested) ? requested : DEFAULT_ACTIVITY_RANGE;
  const today = new Date();

  // `?day=2026-10-12` comes from clicking a day in the four-week calendar.
  const day = typeof params.day === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(params.day) ? params.day : null;
  const bounds = day
    ? {
        id: 'day' as const,
        from: day,
        to: day,
        label: `${weekdayLabel(parseISODate(day))} ${parseISODate(day).getDate()}`
      }
    : activityRangeBounds(rangeId, today);

  const editId = typeof params.edit === 'string' && params.edit ? params.edit : null;

  const [activities, total] = await Promise.all([
    activitiesBetween(user.id, bounds.from, bounds.to),
    countActivities(user.id)
  ]);

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div>
          <h1>Activities</h1>
          <p className="page-sub">
            {bounds.label} · running distance counts run, trail and orienteering together.
            {day ? (
              <>
                {' '}
                <Link href="/activities">Back to the usual range →</Link>
              </>
            ) : null}
          </p>
        </div>
        <ImportButtons />
      </div>

      <ActivitiesView
        activities={activities}
        range={day ? 'day' : rangeId}
        rangeLabel={bounds.label}
        total={total}
        initialEditId={editId}
      />
    </div>
  );
}
