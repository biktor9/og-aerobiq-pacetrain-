import { desc, eq, sql } from 'drizzle-orm';
import { db, schema } from '@/db';
import { appConfig } from '@/lib/env';
import { requireAdmin } from '@/lib/session';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Admin' };

export default async function AdminPage() {
  await requireAdmin();
  const config = appConfig();
  const today = new Date().toISOString().slice(0, 10);

  const [
    totalUsers,
    adminUsers,
    sessionCount,
    activityCount,
    analysisCount,
    messageCount,
    usageToday,
    recentUsers
  ] = await Promise.all([
    db.$count(schema.user),
    db.$count(schema.user, eq(schema.user.role, 'admin')),
    db.$count(schema.plannedSessions),
    db.$count(schema.activities),
    db.$count(schema.analyses),
    db.$count(schema.chatMessages),
    db
      .select({
        requests: sql<number>`coalesce(sum(${schema.usageDaily.requests}), 0)`,
        byok: sql<number>`coalesce(sum(${schema.usageDaily.byokRequests}), 0)`,
        promptTokens: sql<number>`coalesce(sum(${schema.usageDaily.promptTokens}), 0)`,
        completionTokens: sql<number>`coalesce(sum(${schema.usageDaily.completionTokens}), 0)`
      })
      .from(schema.usageDaily)
      .where(eq(schema.usageDaily.day, today)),
    db
      .select({
        id: schema.user.id,
        name: schema.user.name,
        email: schema.user.email,
        role: schema.user.role,
        createdAt: schema.user.createdAt
      })
      .from(schema.user)
      .orderBy(desc(schema.user.createdAt))
      .limit(10)
  ]);

  const usage = usageToday[0] ?? { requests: 0, byok: 0, promptTokens: 0, completionTokens: 0 };
  const tokensUsed = Number(usage.promptTokens) + Number(usage.completionTokens);
  const budgetPct = config.deepseek.dailyTokenBudget
    ? Math.min(100, Math.round((tokensUsed / config.deepseek.dailyTokenBudget) * 100))
    : 0;

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div>
          <h1>Admin</h1>
          <p className="page-sub">Usage, storage and the people using the app.</p>
        </div>
      </div>

      <div className="stat-grid">
        <div className="stat">
          <div className="stat-label">Users</div>
          <div className="stat-value">{totalUsers}</div>
          <div className="stat-note">
            {adminUsers} admin{adminUsers === 1 ? '' : 's'}
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Planned sessions</div>
          <div className="stat-value">{sessionCount}</div>
          <div className="stat-note">rows in planned_sessions</div>
        </div>
        <div className="stat">
          <div className="stat-label">Activities</div>
          <div className="stat-value">{activityCount}</div>
          <div className="stat-note">imported or demo</div>
        </div>
        <div className="stat">
          <div className="stat-label">Analyses</div>
          <div className="stat-value">{analysisCount}</div>
          <div className="stat-note">cached detector runs</div>
        </div>
        <div className="stat">
          <div className="stat-label">Coach messages</div>
          <div className="stat-value">{messageCount}</div>
          <div className="stat-note">stored turns</div>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Today&apos;s shared-key usage</h3>
          <span className="small muted">
            {config.deepseek.apiKey
              ? `budget ${config.deepseek.dailyTokenBudget.toLocaleString()} tokens`
              : 'no shared key configured'}
          </span>
        </div>
        <div className="stat-grid" style={{ gridTemplateColumns: 'repeat(3, minmax(0, 1fr))' }}>
          <div className="stat">
            <div className="stat-label">Requests</div>
            <div className="stat-value">{Number(usage.requests)}</div>
            <div className="stat-note">{Number(usage.byok)} on own keys</div>
          </div>
          <div className="stat">
            <div className="stat-label">Tokens</div>
            <div className="stat-value">{tokensUsed.toLocaleString()}</div>
            <div className="stat-note">
              {Number(usage.promptTokens).toLocaleString()} in · {Number(usage.completionTokens).toLocaleString()} out
            </div>
          </div>
          <div className="stat">
            <div className="stat-label">Budget used</div>
            <div className="stat-value">{budgetPct}%</div>
            <div className="meter" style={{ marginTop: 6 }}>
              <div className="meter-fill" style={{ width: `${budgetPct}%` }} />
            </div>
          </div>
        </div>
        <p className="field-hint" style={{ marginTop: 10 }}>
          The shared budget is a safety valve for the whole site, counted in UTC days.
        </p>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Newest accounts</h3>
        </div>
        <div className="scroll-y">
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Joined</th>
              </tr>
            </thead>
            <tbody>
              {recentUsers.map((row) => (
                <tr key={row.id}>
                  <td>{row.name}</td>
                  <td>{row.email}</td>
                  <td>{row.role}</td>
                  <td>{new Date(row.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
