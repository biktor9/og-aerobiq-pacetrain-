import { CoachChat } from '@/components/coach-chat';
import { chatHistory, getSettings } from '@/lib/data';
import { appConfig } from '@/lib/env';
import { requireUser } from '@/lib/session';
import { checkQuota } from '@/lib/usage';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Coach' };

export default async function CoachPage() {
  const user = await requireUser();
  const [settings, history] = await Promise.all([getSettings(user.id), chatHistory(user.id, 40)]);

  const config = appConfig();
  const ownKey = Boolean(settings.deepseekKeyEnc);
  const apiKey = ownKey || config.deepseek.apiKey;
  const mode: 'shared' | 'own-key' | 'offline' = !apiKey ? 'offline' : ownKey ? 'own-key' : 'shared';

  const { decision } = await checkQuota(
    { id: user.id, createdAt: new Date(user.createdAt) },
    { hasOwnKey: ownKey, dailyTokenBudget: config.deepseek.dailyTokenBudget }
  );

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div>
          <h1>Coach</h1>
          <p className="page-sub">
            It reads this week&apos;s plan, the last two weeks of training and your latest interval analysis — nothing
            else.
          </p>
        </div>
      </div>

      {!decision.allowed ? (
        <div className="alert alert-warn">
          <strong>Coach paused.</strong> {decision.message}
        </div>
      ) : null}

      <CoachChat
        initialMessages={history.map((message) => ({ role: message.role, content: message.content }))}
        initialMeta={{
          mode,
          model: apiKey ? config.deepseek.model : 'rule-engine',
          remainingHour: Number.isFinite(decision.remainingHour) ? decision.remainingHour : null,
          remainingDay: Number.isFinite(decision.remainingDay) ? decision.remainingDay : null
        }}
      />
    </div>
  );
}
