import Link from 'next/link';
import { CoachKeyForm, DangerZone, IcuForm, ProfileForm } from '@/components/settings-panels';
import { ZonesForm } from '@/components/zones-form';
import { parseProgressStyle } from '@/domain/dashboard';
import { observedMaxHr, parseZoneBounds, parseZoneModes, sportsWithHeartRate } from '@/domain/hr-zones';
import { activitiesBetween, countActivities, getIcuCredentials, getSettings } from '@/lib/data';
import { appConfig } from '@/lib/env';
import { requireUser } from '@/lib/session';
import { addDays, toISODate } from '@/domain/week';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Settings' };

export default async function SettingsPage() {
  const user = await requireUser();
  const today = new Date();
  const [settings, icu, activityCount, recent] = await Promise.all([
    getSettings(user.id),
    getIcuCredentials(user.id),
    countActivities(user.id),
    activitiesBetween(user.id, toISODate(addDays(today, -120)), toISODate(today), 400)
  ]);
  const config = appConfig();

  // The zones come from the athlete's own numbers, or from the maximum heart rate
  // their activities show.
  const maxHr = settings.maxHr && settings.maxHr > 100 ? settings.maxHr : observedMaxHr(recent);
  const bounds = parseZoneBounds(settings.hrZoneBounds, maxHr);
  const zoneModes = parseZoneModes(settings.hrZoneModes);
  const sports = sportsWithHeartRate(recent);

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="page-head" style={{ marginBottom: 0 }}>
        <div>
          <h1>Settings</h1>
          <p className="page-sub">Your goal, the coach&apos;s key and the intervals.icu connection.</p>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Account</h3>
          <span className={`badge ${user.role === 'admin' ? 'badge-good' : ''}`}>
            {user.role === 'admin' ? 'administrator' : 'member'}
          </span>
        </div>
        <div className="stack" style={{ gap: 4 }}>
          <p style={{ margin: 0 }}>
            <strong>{user.name}</strong> · {user.email}
          </p>
          <p className="small muted" style={{ margin: 0 }}>
            Member since {new Date(user.createdAt).toLocaleDateString()}
          </p>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Training profile</h3>
          <span className="small muted">Read by the coach on every question</span>
        </div>
        <ProfileForm
          initial={{
            goalText: settings.goalText,
            eventDate: settings.eventDate ?? '',
            weeklyMinutesTarget: settings.weeklyMinutesTarget,
            weeklyLoadTarget: settings.weeklyLoadTarget,
            primaryMode: settings.primaryMode,
            coachTone: settings.coachTone,
            athleteNotes: settings.athleteNotes
          }}
        />
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Heart-rate zones</h3>
          <span className="small muted">Your own boundaries, and which sports count</span>
        </div>
        <ZonesForm bounds={bounds} maxHr={settings.maxHr ?? null} modes={zoneModes} sports={sports} />
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Plan page</h3>
          <span className="small muted">Which blocks it shows, and how percentages look</span>
        </div>
        <div className="stack" style={{ gap: 10 }}>
          <p className="small muted" style={{ margin: 0 }}>
            The layout is arranged on the page itself: open <a href="/plan">Plan</a>, press{' '}
            <strong>✎ Edit</strong> in the corner, then drag the blocks around or cross out the ones you do not
            want. Percentages are drawn as{' '}
            <strong>{parseProgressStyle(settings.progressStyle) === 'ring' ? 'rings' : 'bars'}</strong>.
          </p>
          <div className="row-wrap" style={{ gap: 8 }}>
            <Link className="btn btn-sm" href="/plan?edit=1">
              Arrange the plan page
            </Link>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Your DeepSeek key</h3>
          <span className="small muted">Optional — bring your own to skip the shared limits</span>
        </div>
        <CoachKeyForm hasOwnKey={Boolean(settings.deepseekKeyEnc)} />
        {!config.deepseek.apiKey ? (
          <p className="field-hint" style={{ marginTop: 10 }}>
            The site has no shared DeepSeek key configured, so the coach runs on its offline rule engine until you add
            your own.
          </p>
        ) : null}
      </div>

      <div className="card">
        <div className="card-head">
          <h3>intervals.icu</h3>
          <span className="small muted">Imports activities and their streams for interval detection</span>
        </div>
        <IcuForm
          activityCount={activityCount}
          status={{
            connected: Boolean(icu),
            athleteId: icu?.athleteId ?? '',
            keyLast4: icu?.keyLast4 ?? '',
            status: icu?.status ?? 'untested',
            lastError: icu?.lastError ?? null,
            lastSyncAt: icu?.lastSyncAt ? icu.lastSyncAt.toISOString() : null
          }}
        />
      </div>

      <div className="card" style={{ borderColor: 'var(--bad)' }}>
        <div className="card-head">
          <h3>Danger zone</h3>
        </div>
        <DangerZone email={user.email} />
      </div>
    </div>
  );
}
