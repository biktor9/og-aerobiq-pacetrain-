import type { ProgressStyle } from '@/domain/dashboard';

/**
 * A percentage, drawn the way the athlete chose: a meter that fills left to
 * right, or a ring that closes. Both show the same number, and both take the
 * colour of whatever they measure.
 */

function clamp(value: number): number {
  return Math.min(100, Math.max(0, Math.round(value)));
}

export function ProgressRing({
  percent,
  label,
  note,
  size = 88,
  color = 'var(--accent)'
}: {
  /** 0–100. */
  percent: number;
  /** The big number in the middle. */
  label: string;
  /** A short line under it, or null. */
  note?: string | null;
  size?: number;
  color?: string;
}) {
  const value = clamp(percent);
  const stroke = 9;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const dash = (value / 100) * circumference;
  const centre = size / 2;

  return (
    <div className="ring-wrap">
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        role="img"
        aria-label={`${value}%${note ? `, ${note}` : ''}`}
        className="ring"
      >
        <circle
          cx={centre}
          cy={centre}
          r={radius}
          fill="none"
          stroke="var(--surface-3)"
          strokeWidth={stroke}
        />
        {value > 0 ? (
          <circle
            cx={centre}
            cy={centre}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={`${dash} ${circumference - dash}`}
            // Start the fill at twelve o'clock rather than three.
            transform={`rotate(-90 ${centre} ${centre})`}
            className="ring-fill"
          />
        ) : null}
        <text
          x="50%"
          y="50%"
          dominantBaseline="central"
          textAnchor="middle"
          className="ring-label"
          fill="currentColor"
        >
          {label}
        </text>
      </svg>
      {note ? <span className="ring-note">{note}</span> : null}
    </div>
  );
}

/** A bare meter, for the places that do not need a number inside it. */
export function ProgressBar({ percent, color = 'var(--accent)' }: { percent: number; color?: string }) {
  return (
    <div className="meter">
      <div className="meter-fill" style={{ width: `${clamp(percent)}%`, background: color }} />
    </div>
  );
}

/**
 * The percent widget: a ring when the athlete chose rings, a filling bar
 * otherwise. `compact` keeps the ring small enough for a stat tile.
 */
export function Progress({
  percent,
  label,
  note,
  style,
  color
}: {
  percent: number;
  label: string;
  note?: string | null;
  style: ProgressStyle;
  color?: string;
}) {
  if (style === 'ring') return <ProgressRing percent={percent} label={label} note={note} size={72} color={color} />;
  return (
    <div className="stack" style={{ gap: 4 }}>
      <div className="stat-value" style={{ marginTop: 0 }}>{label}</div>
      <ProgressBar percent={percent} color={color} />
      {note ? <span className="stat-note">{note}</span> : null}
    </div>
  );
}
