/**
 * A dry run of the page's layout: shows which block ids are drawn, and in what
 * order, without any of the data the real blocks need. The order test uses it
 * to prove nothing re-sorts the blocks.
 */
export function WidgetOrderProbe({ order }: { order: string[] }) {
  return (
    <div className="page-flow">
      {order.map((id) =>
        id === 'overview' ? null : (
          <div key={id} data-drawn={id}>
            {id}
          </div>
        )
      )}
    </div>
  );
}
