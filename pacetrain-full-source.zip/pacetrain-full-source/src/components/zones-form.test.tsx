// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ZonesForm } from '@/components/zones-form';
import type { ZoneBounds } from '@/domain/hr-zones';
import { MODES } from '@/domain/types';

const mocks = vi.hoisted(() => ({
  saveZonesAction: vi.fn(),
  refresh: vi.fn()
}));

vi.mock('@/actions/settings', () => ({
  saveZonesAction: mocks.saveZonesAction,
  saveProfileAction: vi.fn(),
  saveOwnKeyAction: vi.fn(),
  clearOwnKeyAction: vi.fn(),
  connectIcuAction: vi.fn(),
  disconnectIcuAction: vi.fn(),
  syncIcuAction: vi.fn(),
  deleteAccountAction: vi.fn()
}));

vi.mock('next/navigation', () => ({
  useRouter: () => ({ refresh: mocks.refresh, push: vi.fn() })
}));

const BOUNDS: ZoneBounds = [110, 133, 152, 168];
const SPORTS = [
  { mode: 'run' as const, activities: 12, minutes: 600 },
  { mode: 'bike' as const, activities: 3, minutes: 180 },
  { mode: 'strength' as const, activities: 4, minutes: 240 }
];

function renderForm(overrides: Partial<Parameters<typeof ZonesForm>[0]> = {}) {
  return render(
    <ZonesForm bounds={BOUNDS} maxHr={null} modes={null} sports={SPORTS} {...overrides} />
  );
}

beforeEach(() => {
  for (const mock of Object.values(mocks)) mock.mockReset();
  mocks.saveZonesAction.mockResolvedValue({ ok: true, data: undefined });
});

afterEach(cleanup);

describe('ZonesForm', () => {
  it('starts from the stored boundaries and shows the ranges they imply', () => {
    renderForm();

    expect((screen.getByLabelText('Z1 ends at') as HTMLInputElement).value).toBe('110');
    expect((screen.getByLabelText('Z4 ends at') as HTMLInputElement).value).toBe('168');
    expect(screen.getByText(/Z2 · 111–133 bpm/)).toBeInTheDocument();
    expect(screen.getByText(/Z5 · 169\+ bpm/)).toBeInTheDocument();
  });

  it('saves the boundaries, the maximum and the sports', async () => {
    renderForm();

    // A number input reports each keystroke, so the value is set outright.
    fireEvent.change(screen.getByLabelText('Z2 ends at'), { target: { value: '135' } });
    await userEvent.type(screen.getByLabelText('Max HR'), '188');
    // Leaving one sport out is what makes the bar mean aerobic work.
    await userEvent.click(screen.getByRole('button', { name: /Strength/ }));
    await userEvent.click(screen.getByRole('button', { name: 'Save zones' }));

    expect(mocks.saveZonesAction).toHaveBeenCalledWith({
      bounds: [110, 135, 152, 168],
      maxHr: 188,
      // Unticking strength leaves every other sport counted, on screen or not.
      modes: ['run', 'trail', 'orienteering', 'ski', 'mtb', 'bike']
    });
    expect(mocks.refresh).toHaveBeenCalled();
  });

  it('refuses boundaries that do not rise', () => {
    renderForm();

    fireEvent.change(screen.getByLabelText('Z2 ends at'), { target: { value: '100' } });

    expect(screen.getByRole('button', { name: 'Save zones' })).toBeDisabled();
    expect(screen.getByText(/each zone must end above the previous one/)).toBeInTheDocument();
  });

  it('stores "every sport" as no choice at all', async () => {
    // Every sport was ticked except run: ticking run back leaves none excluded,
    // which the action stores as null ("all of them").
    renderForm({ modes: MODES.map((mode) => mode.id).filter((id) => id !== 'run') });
    await userEvent.click(screen.getByRole('button', { name: /Run/ }));
    await userEvent.click(screen.getByRole('button', { name: 'Save zones' }));

    const payload = mocks.saveZonesAction.mock.calls[0][0];
    expect(payload.modes).toEqual([]);
  });

  it('counts every sport when none is ticked', async () => {
    renderForm({ modes: null });

    // Unticking the only sport with a heart rate leaves the rest counted.
    await userEvent.click(screen.getByRole('button', { name: /Run/ }));
    await userEvent.click(screen.getByRole('button', { name: 'Save zones' }));

    const payload = mocks.saveZonesAction.mock.calls[0][0];
    expect(payload.modes).not.toContain('run');
    expect(payload.modes).toHaveLength(MODES.length - 1);
  });

  it('says why a save failed', async () => {
    mocks.saveZonesAction.mockResolvedValue({ ok: false, error: 'Each zone has to end above the one before it.' });
    renderForm();

    await userEvent.click(screen.getByRole('button', { name: 'Save zones' }));

    expect(await screen.findByText('Each zone has to end above the one before it.')).toBeInTheDocument();
  });
});
