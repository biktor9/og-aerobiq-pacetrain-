// @vitest-environment jsdom
import { afterEach, describe, expect, it } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import { WeekCalendar } from '@/components/week-calendar';
import { toSession } from '@/domain/plan';
import type { Activity, Session } from '@/domain/types';
import { startOfWeek } from '@/domain/week';
import { buildCalendarWeeks, buildWeekStrip } from '@/domain/week-summary';

afterEach(cleanup);

const TODAY = new Date(2026, 9, 21); // Wed 21 Oct 2026
const MONDAY = new Date(2026, 9, 19);

function activity(overrides: Partial<Activity> & { id: string; date: string }): Activity {
  return {
    externalId: overrides.id,
    mode: 'run',
    name: 'Run',
    durationSec: 3600,
    distanceM: 10_000,
    avgHr: null,
    maxHr: null,
    load: null,
    source: 'intervals.icu',
    linkedSessionId: null,
    ...overrides
  };
}

function session(date: string, minutes: number): Session {
  return toSession({
    id: `s-${date}`,
    date,
    mode: 'run',
    kind: 'steady',
    title: 'Session',
    zone: 2,
    minutes,
    targetKm: null,
    reps: 1,
    workMin: minutes,
    recoverMin: 0,
    warmupMin: 0,
    cooldownMin: 0,
    notes: '',
    status: 'planned',
    structure: null,
    linkedActivityId: null
  });
}

function weeksFor() {
  return buildWeekStrip({
    monday: MONDAY,
    weeks: 5,
    activities: [
      activity({ id: 'a', date: '2026-10-19', durationSec: 3600, distanceM: 10_000 }),
      activity({ id: 'b', date: '2026-10-20', durationSec: 1800, distanceM: 5000 }),
      activity({ id: 'c', date: '2026-10-21', mode: 'bike', durationSec: 2700, distanceM: 8000 })
    ],
    sessions: [
      session('2026-10-19', 60),
      session('2026-10-20', 30),
      session('2026-10-21', 45),
      session('2026-10-22', 50),
      session('2026-10-23', 40)
    ],
    today: TODAY
  });
}

describe('WeekCalendar', () => {
  it('shows a cell for every day of every week', () => {
    const { container } = render(<WeekCalendar weeks={weeksFor()} />);

    expect(screen.getByText('Last 3 weeks, this week and next')).toBeInTheDocument();
    expect(container.querySelectorAll('.cal-day')).toHaveLength(35);
    expect(container.querySelectorAll('.cal-day.is-today')).toHaveLength(1);
    expect(container.querySelectorAll('.cal-day.is-planned')).toHaveLength(2);
  });

  it('leaves a day with nothing on it bare instead of shading it', () => {
    const { container } = render(<WeekCalendar weeks={weeksFor()} />);

    // Sat/Sun of this week have neither a session nor a run.
    const saturday = container.querySelector('[title^="Sat 24"]');
    expect(saturday).not.toBeNull();
    expect(saturday).toHaveClass('is-blank');
    expect(saturday).not.toHaveClass('is-verdict');
  });

  it('keeps the plan for a day still to come unjudged, not red', () => {
    const { container } = render(<WeekCalendar weeks={weeksFor()} />);

    // Thursday is planned and has not happened yet: a dashed outline, no red.
    const thursday = container.querySelector('[title^="Thu 22"]');
    expect(thursday).not.toBeNull();
    expect(thursday).toHaveClass('is-pending');
    expect(thursday).not.toHaveClass('is-verdict');
    expect((thursday as HTMLElement).style.background).toBe('');
  });

  it('paints a settled day by how it went against the plan', () => {
    const { container } = render(<WeekCalendar weeks={weeksFor()} />);

    // Monday ran the whole hour that was planned.
    const monday = container.querySelector('[title^="Mon 19"]');
    expect(monday).toHaveClass('is-verdict');
    expect(monday).toHaveAttribute('data-verdict', 'on-plan');
  });

  it('turns a day red once it has ended with nothing done', () => {
    const weeks = buildWeekStrip({
      monday: MONDAY,
      weeks: 2,
      activities: [],
      sessions: [session('2026-10-19', 60)],
      // Friday evening: Monday is long gone and nothing was done.
      today: new Date(2026, 9, 23, 20)
    });
    const { container } = render(<WeekCalendar weeks={weeks} />);

    const monday = container.querySelector('[title^="Mon 19"]');
    expect(monday).toHaveClass('is-verdict');
    expect(monday).toHaveAttribute('data-verdict', 'skipped');
  });

  it('marks the week after this one, so next week is easy to find', () => {
    const weeks = weeksFor();
    const { container } = render(<WeekCalendar weeks={weeks} nextWeek={weeks[4].key} />);

    expect(screen.getByText('next')).toBeInTheDocument();
    expect(container.querySelectorAll('.cal-row.is-next')).toHaveLength(1);
    const nextRow = container.querySelector('.cal-row.is-next');
    expect(nextRow?.querySelector('a.cal-week-key')).toHaveAttribute('href', `/plan?week=${weeks[4].key}`);
  });

  it('never puts the next badge on a week that has already happened', () => {
    const today = new Date(2026, 9, 28); // Wed 28 Oct 2026
    const weeks = buildCalendarWeeks({ monday: startOfWeek(today), activities: [], sessions: [], today });
    const { container } = render(<WeekCalendar weeks={weeks} />);

    // Without being told which row is next, the one after the current week wins.
    const nextRow = container.querySelector('.cal-row.is-next');
    expect(nextRow?.querySelector('a.cal-week-key')).toHaveAttribute('href', '/plan?week=2026-W45');
    // The current week is the second-to-last row, and it is not marked next.
    const currentRow = container.querySelector('.cal-row.is-selected, .cal-row');
    expect(currentRow).not.toBeNull();
    expect(container.querySelectorAll('.cal-row.is-next')).toHaveLength(1);
  });

  it('adds up the four weeks in the head', () => {
    render(<WeekCalendar weeks={weeksFor()} />);

    expect(screen.getByText('15.0 km run · 2h 15m · 3 days trained')).toBeInTheDocument();
  });

  it('lists kilometres, time and the share of the plan for each week', () => {
    render(<WeekCalendar weeks={weeksFor()} />);

    expect(screen.getAllByText('15.0 km').length).toBeGreaterThan(0);
    expect(screen.getByText('2h 15m')).toBeInTheDocument();
    expect(screen.getByText('100%')).toBeInTheDocument();
    expect(screen.getByText('now')).toBeInTheDocument();
  });

  it('links each week to its plan', () => {
    render(<WeekCalendar weeks={weeksFor()} />);

    expect(screen.getByText('W43').closest('a')).toHaveAttribute('href', '/plan?week=2026-W43');
    expect(screen.getByText('W42').closest('a')).toHaveAttribute('href', '/plan?week=2026-W42');
  });

  it('opens the activities when a trained day is clicked', () => {
    const { container } = render(<WeekCalendar weeks={weeksFor()} />);

    const links = container.querySelectorAll('a.cal-day');
    expect(links).toHaveLength(3);
    expect(links[0]).toHaveAttribute('href', '/activities?day=2026-10-19');
    expect(links[2]).toHaveAttribute('href', '/activities?day=2026-10-21');
  });

  it('marks sick days', () => {
    const { container } = render(<WeekCalendar weeks={weeksFor()} sickDays={['2026-10-20']} />);

    const sick = container.querySelectorAll('.cal-day.is-sick');
    expect(sick).toHaveLength(1);
    expect(sick[0]).toHaveAttribute('title', expect.stringContaining('sick'));
  });

  it('renders nothing without weeks', () => {
    const { container } = render(<WeekCalendar weeks={[]} />);
    expect(container).toBeEmptyDOMElement();
  });
});
