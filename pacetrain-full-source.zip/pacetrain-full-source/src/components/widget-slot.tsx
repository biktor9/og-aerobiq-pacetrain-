'use client';

import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { ProgressBar, ProgressRing } from '@/components/progress';
import {
  SIZES_FOR,
  SIZE_LABEL,
  sizeOf,
  sizesFor,
  WIDGETS,
  type ProgressStyle,
  type Sizes,
  type WidgetId,
  type WidgetSize
} from '@/domain/dashboard';

/**
 * Editing happens on the page itself: the blocks stay where they are, gain a
 * grip to drag by and a cross to remove them, and a bar along the bottom holds
 * everything else. These pieces are what the blocks are wrapped in.
 */

export interface EditApi {
  order: WidgetId[];
  style: ProgressStyle;
  sizes: Sizes;
  onReorder: (from: WidgetId, to: WidgetId) => void;
  onMoveTo: (id: WidgetId, edge: 'top' | 'bottom') => void;
  onResize: (id: WidgetId, size: WidgetSize) => void;
  onRemove: (id: WidgetId) => void;
  onStyle: (style: ProgressStyle) => void;
  onSave: () => void;
  onReset: () => void;
  onClose: () => void;
  /** Order as it was when editing began, so we know whether to warn on leave. */
  dirty: boolean;
  busy: boolean;
  saved: boolean;
  error: string;
  /**
   * The block the athlete has picked up and may move. Only one at a time: with
   * nothing chosen, the page cannot be rearranged by accident, and with one
   * chosen only that one answers the pointer.
   */
  selected: WidgetId | null;
  /** Chooses a block, or releases the one that is chosen (`null`). */
  onSelect: (id: WidgetId | null) => void;
  /**
   * The block being dragged right now, or null.
   *
   * `again` says this press is a second press on the block that was already
   * chosen, which is what puts it down on release rather than leaving it
   * chosen. The block decides it, from the chosen state it was drawn with.
   */
  dragging: { id: WidgetId; again: boolean } | null;
  onDragStart: (drag: { id: WidgetId; again: boolean } | null) => void;
}

const EditContext = createContext<EditApi | null>(null);

export function EditProvider({ value, children }: { value: EditApi | null; children: ReactNode }) {
  return <EditContext.Provider value={value}>{children}</EditContext.Provider>;
}

export function useEdit(): EditApi | null {
  return useContext(EditContext);
}

/**
 * The order the blocks should be drawn in right now, or null when nothing is
 * being edited. Kept separate from `useEdit` so a component that only needs the
 * order does not tie itself to the rest of the editor.
 */
export function useLiveOrder(): WidgetId[] | null {
  return useContext(EditContext)?.order ?? null;
}

/** The sizes being edited right now, or null when nothing is being edited. */
export function useLiveSizes(): Sizes | null {
  return useContext(EditContext)?.sizes ?? null;
}

/** The block currently picked up by the pointer, or null. */
export function useDragging(): WidgetId | null {
  return useContext(EditContext)?.dragging?.id ?? null;
}

/** The block the athlete has chosen to move, or null when none is chosen. */
export function useSelected(): WidgetId | null {
  return useContext(EditContext)?.selected ?? null;
}

/** Ends a pointer drag, wherever the pointer was released. */
export function useEndDrag(): (() => void) | null {
  const edit = useContext(EditContext);
  return edit ? () => edit.onDragStart(null) : null;
}

/**
 * Picking a block up, and putting it down again.
 *
 * Editing is deliberate rather than accidental: the first press on a block
 * chooses it, and only a chosen block follows the pointer. Pressing the chosen
 * block again — or Escape, or anywhere off the blocks — releases it, and then
 * nothing on the page can be moved until something is chosen again. That way a
 * stray click while reading the page never rearranges it.
 *
 * While a chosen block is being dragged, the pointer is followed over the page
 * and the block it is over is asked to take its place. The hit test is done
 * against every block rather than against drop zones, so a tile dropped beside
 * another tile lands in the row it was aimed at, whether or not there is a gap.
 */
export function useSlotDrag(id: WidgetId): {
  onPointerDown: (event: React.PointerEvent) => void;
  /** True when this block is the chosen one. */
  chosen: boolean;
  /** True while this particular block is being moved. */
  held: boolean;
} {
  const edit = useContext(EditContext);
  const chosen = edit?.selected === id;
  const held = edit?.dragging?.id === id;

  // Follow the pointer, but only for the block that was chosen and picked up.
  useEffect(() => {
    if (!edit?.dragging) return;

    const from = edit.dragging.id;
    let raf = 0;

    const onMove = (event: PointerEvent) => {
      if (raf) return;
      raf = window.requestAnimationFrame(() => {
        raf = 0;
        const target = document
          .elementFromPoint(event.clientX, event.clientY)
          ?.closest('[data-widget]') as HTMLElement | null;
        const over = target?.dataset.widget as WidgetId | undefined;
        if (over && over !== from) edit.onReorder(from, over);
      });
    };

    window.addEventListener('pointermove', onMove);
    return () => {
      window.removeEventListener('pointermove', onMove);
      if (raf) window.cancelAnimationFrame(raf);
    };
  }, [edit?.dragging]);

  return {
    chosen,
    held,
    onPointerDown(event) {
      if (!edit) return;
      if ((event.target as HTMLElement).closest('.slot-bar')) return;
      if (event.button !== 0) return;
      event.preventDefault();
      // A press always ends the drag the press before it started, so a second
      // press is never taken for the release of the first.
      edit.onDragStart(null);
      // Not chosen yet: this press chooses it and goes no further. The next
      // press on the same block is the one that moves it.
      if (edit.selected !== id) {
        edit.onSelect(id);
        return;
      }
      // Chosen: this press picks it up. `again` is true, so releasing without
      // moving it puts it down; dragging it away leaves it chosen to go on.
      edit.onDragStart({ id, again: true });
    }
  };
}

/** The label the editor shows on a block's grip. */
export function labelFor(id: WidgetId): string {
  return WIDGETS.find((widget) => widget.id === id)?.label ?? 'Block';
}

/** The drag payload, so a block dropped from elsewhere is ignored. */
const WIDGET_MIME = 'text/widget';

/**
 * Wraps one block. Outside edit mode this is a passthrough, so the page is
 * exactly what it was. In edit mode it becomes a draggable frame with a grip,
 * the block's name, and a cross to take it off the page.
 *
 * `span` lets a tile sit in the grid; cards take the full width.
 */
export function WidgetSlot({
  id,
  span = false,
  hidden = false,
  children
}: {
  id: WidgetId;
  /** A tile, which shares its row rather than taking the full width. */
  span?: boolean;
  /** True when the block itself is not drawn, so it is never dragged or named. */
  hidden?: boolean;
  children?: ReactNode;
}) {
  const edit = useEdit();
  const [picked, setPicked] = useState(false);
  const drag = useSlotDrag(id);

  if (!edit || hidden) {
    return <>{children}</>;
  }

  const name = labelFor(id);
  const size = sizeOf(edit.sizes, id);
  const options = sizesFor(id);
  const kind = options === SIZES_FOR.tile ? 'tile' : 'card';

  // Only blocks that are actually drawn can be moved past each other, so the
  // ends are decided by the visible list, not the stored one.
  const visible: WidgetId[] = edit.order.filter((entry: WidgetId) => entry !== 'overview');
  const index = visible.indexOf(id);

  /** Moves this block by one place, for the keyboard buttons. */
  function nudge(direction: -1 | 1) {
    if (!edit) return;
    const next = index + direction;
    if (next < 0 || next >= visible.length) return;
    edit.onReorder(id, visible[next]);
  }

  return (
    <div
      className={`slot${span ? ' slot-tile' : ''}${drag.chosen ? ' is-chosen' : ''}${
        edit.dragging?.id === id ? ' is-dragging' : ''
      }`}
      data-widget={id}
      data-editing="true"
      // Carries the chosen state so the stylesheet can say "chosen blocks are
      // grabbable, the rest are not" without a class for every case.
      data-chosen={drag.chosen ? 'true' : 'false'}
      // A tile's body ignores the pointer so its contents cannot swallow the
      // drag, which leaves the frame itself to pick the block up.
      onPointerDown={span ? drag.onPointerDown : undefined}
      title={drag.chosen ? 'Chosen — press again to let go' : 'Press to choose, then drag to move'}
    >
      {/* The bar sits on top of a selection the way a caption does, so the block
          keeps the exact size it has outside the editor. */}
      <div className="slot-bar">
        <span className="slot-grip" aria-hidden="true">
          ⠿
        </span>
        <span className="slot-name">{name}</span>
        <button
          className="slot-btn"
          type="button"
          aria-label={`Change the size of ${name}`}
          aria-expanded={picked}
          title="Size"
          onClick={() => setPicked((open) => !open)}
        >
          ⤢
        </button>
        <button
          className="slot-btn slot-remove"
          type="button"
          aria-label={`Remove ${name}`}
          title="Take this off the page"
          onClick={() => edit.onRemove(id)}
        >
          ×
        </button>
      </div>

      {picked ? (
        <div className="slot-sizes" role="group" aria-label={`Move or size ${name}`}>
          {options.map((option) => (
            <button
              key={option}
              type="button"
              className="chip"
              aria-pressed={size === option}
              onClick={() => {
                edit.onResize(id, option);
                setPicked(false);
              }}
            >
              {SIZE_LABEL[option][kind]}
            </button>
          ))}
          <div className="slot-moves">
            <button
              className="slot-btn"
              type="button"
              aria-label={`Move ${name} up`}
              disabled={index <= 0}
              title="Up a place"
              onClick={() => nudge(-1)}
            >
              ↑
            </button>
            <button
              className="slot-btn"
              type="button"
              aria-label={`Move ${name} down`}
              disabled={index >= visible.length - 1}
              title="Down a place"
              onClick={() => nudge(1)}
            >
              ↓
            </button>
            <button
              className="slot-btn"
              type="button"
              aria-label={`Move ${name} to the top`}
              disabled={index <= 0}
              title="Send to the top"
              onClick={() => edit.onMoveTo(id, 'top')}
            >
              ⤒
            </button>
            <button
              className="slot-btn"
              type="button"
              aria-label={`Move ${name} to the bottom`}
              disabled={index === visible.length - 1}
              title="Send to the bottom"
              onClick={() => edit.onMoveTo(id, 'bottom')}
            >
              ⤓
            </button>
          </div>
        </div>
      ) : null}

      <div className="slot-body" onPointerDown={drag.onPointerDown} title="Drag to move">
        {children}
      </div>
    </div>
  );
}

/** A drop zone between blocks, marking where the dragged block would land. */
export function DropGap({ before }: { before: WidgetId }) {
  const edit = useEdit();
  if (!edit) return null;
  const dragged = edit.dragging?.id ?? null;
  const active = dragged !== null && dragged !== before;

  return (
    <div
      className={`drop-gap${active ? ' is-ready' : ''}`}
      data-drop-before={before}
      // The gap takes the drop from the pointer drag, and from a file or text
      // drag so a block can be moved with the keyboard too.
      onPointerEnter={() => {
        if (active && dragged) edit.onReorder(dragged, before);
      }}
      onDragOver={(event) => {
        if (!event.dataTransfer?.types?.includes(WIDGET_MIME)) return;
        event.preventDefault();
        event.currentTarget.classList.add('is-over');
      }}
      onDragLeave={(event) => event.currentTarget.classList.remove('is-over')}
      onDrop={(event) => {
        event.currentTarget.classList.remove('is-over');
        const from = event.dataTransfer?.getData(WIDGET_MIME) as WidgetId;
        if (from && from !== before) {
          event.preventDefault();
          edit.onReorder(from, before);
        }
      }}
    />
  );
}

/** The Bars / Rings switch, with a live preview of each. */
export function StyleSwitch({ style, onStyle }: { style: ProgressStyle; onStyle: (style: ProgressStyle) => void }) {
  return (
    <div className="row-wrap" style={{ gap: 10, alignItems: 'center' }}>
      <div className="segmented" role="group" aria-label="How percentages are drawn">
        <button type="button" aria-pressed={style === 'ring'} onClick={() => onStyle('ring')}>
          Rings
        </button>
        <button type="button" aria-pressed={style === 'bar'} onClick={() => onStyle('bar')}>
          Bars
        </button>
      </div>
      {style === 'ring' ? (
        <ProgressRing percent={62} label="62%" size={46} />
      ) : (
        <div style={{ width: 90 }}>
          <ProgressBar percent={62} />
        </div>
      )}
    </div>
  );
}
