// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { CoachKeyForm, DangerZone, IcuForm, ProfileForm } from '@/components/settings-panels';

const mocks = vi.hoisted(() => ({
  saveProfileAction: vi.fn(),
  saveOwnKeyAction: vi.fn(),
  clearOwnKeyAction: vi.fn(),
  connectIcuAction: vi.fn(),
  disconnectIcuAction: vi.fn(),
  syncIcuAction: vi.fn(),
  deleteAccountAction: vi.fn(),
  refresh: vi.fn()
}));

vi.mock('@/actions/settings', () => ({
  saveProfileAction: mocks.saveProfileAction,
  saveOwnKeyAction: mocks.saveOwnKeyAction,
  clearOwnKeyAction: mocks.clearOwnKeyAction,
  connectIcuAction: mocks.connectIcuAction,
  disconnectIcuAction: mocks.disconnectIcuAction,
  syncIcuAction: mocks.syncIcuAction,
  deleteAccountAction: mocks.deleteAccountAction
}));

vi.mock('next/navigation', () => ({
  useRouter: () => ({ refresh: mocks.refresh, push: vi.fn() })
}));

const profile = {
  goalText: 'Sub-3 marathon in April',
  eventDate: '2026-04-12',
  weeklyMinutesTarget: 360,
  weeklyLoadTarget: 240,
  primaryMode: 'run',
  coachTone: 'direct',
  athleteNotes: 'Two kids, can train early.'
};

const disconnected = {
  connected: false,
  athleteId: '',
  keyLast4: '',
  status: 'untested',
  lastError: null,
  lastSyncAt: null
};

beforeEach(() => {
  for (const mock of Object.values(mocks)) mock.mockReset();
});

afterEach(() => {
  cleanup();
});

describe('ProfileForm', () => {
  it('shows the stored values', () => {
    render(<ProfileForm initial={profile} />);
    expect(screen.getByLabelText('Goal')).toHaveValue(profile.goalText);
    expect(screen.getByLabelText('Weekly minutes target')).toHaveValue(360);
    expect(screen.getByRole('button', { name: 'Direct' })).toHaveAttribute('aria-pressed', 'true');
  });

  it('sends numbers, not strings, and confirms the save', async () => {
    mocks.saveProfileAction.mockResolvedValue({ ok: true, data: undefined });
    render(<ProfileForm initial={profile} />);

    await userEvent.clear(screen.getByLabelText('Weekly minutes target'));
    await userEvent.type(screen.getByLabelText('Weekly minutes target'), '420');
    await userEvent.click(screen.getByRole('button', { name: 'Analytical' }));
    await userEvent.click(screen.getByRole('button', { name: 'Save profile' }));

    expect(await screen.findByText(/saved\. the coach will use this/i)).toBeInTheDocument();
    expect(mocks.saveProfileAction).toHaveBeenCalledTimes(1);
    expect(mocks.saveProfileAction.mock.calls[0][0]).toMatchObject({
      goalText: profile.goalText,
      weeklyMinutesTarget: 420,
      weeklyLoadTarget: 240,
      coachTone: 'analytical'
    });
    expect(mocks.refresh).toHaveBeenCalled();
  });

  it('surfaces a validation error from the server', async () => {
    mocks.saveProfileAction.mockResolvedValue({ ok: false, error: 'Those settings are not valid.' });
    render(<ProfileForm initial={profile} />);

    await userEvent.click(screen.getByRole('button', { name: 'Save profile' }));

    expect(await screen.findByText('Those settings are not valid.')).toBeInTheDocument();
    expect(mocks.refresh).not.toHaveBeenCalled();
  });
});

describe('CoachKeyForm', () => {
  it('keeps the save button disabled until the key looks real', async () => {
    render(<CoachKeyForm hasOwnKey={false} />);
    const save = screen.getByRole('button', { name: 'Save key' });
    expect(save).toBeDisabled();

    await userEvent.type(screen.getByLabelText(/paste your deepseek key/i), 'sk-12345678901234567890');
    expect(save).toBeEnabled();
  });

  it('saves the key and clears the field', async () => {
    mocks.saveOwnKeyAction.mockResolvedValue({ ok: true, data: undefined });
    render(<CoachKeyForm hasOwnKey={false} />);

    const input = screen.getByLabelText(/paste your deepseek key/i);
    await userEvent.type(input, 'sk-abcdefghijklmnopqrstuvwxyz');
    await userEvent.click(screen.getByRole('button', { name: 'Save key' }));

    expect(await screen.findByText(/key saved and encrypted/i)).toBeInTheDocument();
    expect(mocks.saveOwnKeyAction).toHaveBeenCalledWith('sk-abcdefghijklmnopqrstuvwxyz');
    expect(input).toHaveValue('');
  });

  it('offers removal only when a key is stored', async () => {
    mocks.clearOwnKeyAction.mockResolvedValue({ ok: true, data: undefined });
    const { rerender } = render(<CoachKeyForm hasOwnKey={false} />);
    expect(screen.queryByRole('button', { name: 'Remove key' })).not.toBeInTheDocument();

    rerender(<CoachKeyForm hasOwnKey />);
    await userEvent.click(screen.getByRole('button', { name: 'Remove key' }));

    expect(await screen.findByText(/key removed/i)).toBeInTheDocument();
    expect(mocks.clearOwnKeyAction).toHaveBeenCalled();
  });
});

describe('IcuForm', () => {
  it('explains where to find the credentials while disconnected', () => {
    render(<IcuForm status={disconnected} />);
    expect(screen.getByText(/find your athlete id and api key/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Connect intervals.icu' })).toBeDisabled();
  });

  it('connects with the typed credentials', async () => {
    mocks.connectIcuAction.mockResolvedValue({ ok: true, data: { name: 'Alex Runner' } });
    render(<IcuForm status={disconnected} />);

    await userEvent.type(screen.getByLabelText('Athlete ID'), 'i12345');
    await userEvent.type(screen.getByLabelText('API key'), 'abcdefghijklmno');
    await userEvent.click(screen.getByRole('button', { name: 'Connect intervals.icu' }));

    expect(await screen.findByText('Connected to Alex Runner.')).toBeInTheDocument();
    expect(mocks.connectIcuAction).toHaveBeenCalledWith({ athleteId: 'i12345', apiKey: 'abcdefghijklmno' });
    expect(mocks.refresh).toHaveBeenCalled();
  });

  it('reports a failed connection test', async () => {
    mocks.connectIcuAction.mockResolvedValue({ ok: false, error: 'intervals.icu rejected that key.' });
    render(<IcuForm status={disconnected} />);

    await userEvent.type(screen.getByLabelText('Athlete ID'), 'i12345');
    await userEvent.type(screen.getByLabelText('API key'), 'abcdefghijklmno');
    await userEvent.click(screen.getByRole('button', { name: 'Connect intervals.icu' }));

    expect(await screen.findByText('intervals.icu rejected that key.')).toBeInTheDocument();
  });

  it('syncs and disconnects an existing connection', async () => {
    mocks.syncIcuAction.mockResolvedValue({ ok: true, data: { scanned: 12, imported: 3 } });
    mocks.disconnectIcuAction.mockResolvedValue({ ok: true, data: undefined });
    render(
      <IcuForm status={{ ...disconnected, connected: true, athleteId: 'i12345', keyLast4: 'abcd' }} />
    );

    expect(screen.getByText(/connected as/i)).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: /sync last 30 days/i }));
    expect(await screen.findByText('Scanned 12 activities, imported 3 new ones.')).toBeInTheDocument();
    expect(mocks.syncIcuAction).toHaveBeenCalledWith(30);

    await userEvent.click(screen.getByRole('button', { name: 'Disconnect' }));
    expect(await screen.findByText(/disconnected\. stored activities stay/i)).toBeInTheDocument();
    expect(mocks.disconnectIcuAction).toHaveBeenCalled();
  });
});

describe('DangerZone', () => {
  it('requires the exact email before deleting', async () => {
    mocks.deleteAccountAction.mockResolvedValue({ ok: true, data: undefined });
    render(<DangerZone email="runner@example.test" />);
    const button = screen.getByRole('button', { name: 'Delete my account' });
    expect(button).toBeDisabled();

    const input = screen.getByLabelText(/to confirm/i);
    await userEvent.type(input, 'runner@example.tes');
    expect(button).toBeDisabled();

    await userEvent.type(input, 't');
    expect(button).toBeEnabled();

    await userEvent.click(button);
    expect(mocks.deleteAccountAction).toHaveBeenCalledTimes(1);
  });
});
