'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const TABS = [
  { href: '/plan', label: 'Plan' },
  { href: '/recovery', label: 'Recovery' },
  { href: '/progress', label: 'Progress' },
  { href: '/activities', label: 'Activities' },
  { href: '/analysis', label: 'Analysis' },
  { href: '/coach', label: 'Coach' },
  { href: '/settings', label: 'Settings' }
];

export function TopNav({ isAdmin }: { isAdmin: boolean }) {
  const pathname = usePathname();
  const tabs = isAdmin ? [...TABS, { href: '/admin', label: 'Admin' }] : TABS;

  return (
    <nav className="tabs" aria-label="Main">
      {tabs.map((tab) => (
        <Link
          key={tab.href}
          href={tab.href}
          className="tab"
          aria-current={pathname === tab.href || pathname.startsWith(`${tab.href}/`) ? 'page' : undefined}
        >
          {tab.label}
        </Link>
      ))}
    </nav>
  );
}
