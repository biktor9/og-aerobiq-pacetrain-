// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ReactNode } from 'react';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { WeekBoard } from '@/components/week-board';
import { initialSession, toSession } from '@/domain/plan';

const mocks = vi.hoisted(() => ({
  moveSessionAction: vi.fn(),
  copyPreviousWeekAction: vi.fn(),
  loadDemoAction: vi.fn(),
  clearWeekAction: vi.fn(),
  saveSessionAction: vi.fn(),
  deleteSessionAction: vi.fn(),
  refresh: vi.fn()
}));

vi.mock('next/navigation', () => ({
  useRouter: () => ({ refresh: mocks.refresh, push: vi.fn() })
}));

vi.mock('next/link', () => ({
  default: ({ href, children }: { href: string; children: ReactNode }) => <a href={href}>{children}</a>
}));

vi.mock('@/actions/sessions', () => ({
  moveSessionAction: mocks.moveSessionAction,
  copyPreviousWeekAction: mocks.copyPreviousWeekAction,
  loadDemoAction: mocks.loadDemoAction,
  clearWeekAction: mocks.clearWeekAction,
  saveSessionAction: mocks.saveSessionAction,
  deleteSessionAction: mocks.deleteSessionAction
}));

const easyDay = toSession({
  ...initialSession('2026-10-20', 'run'),
  title: 'Easy 40',
  id: 's1',
  linkedActivityId: null
});

function renderBoard() {
  return render(<WeekBoard sessions={[easyDay]} mondayISO="2026-10-19" weekKey="2026-10-19" />);
}

/** The day column whose date number is `day` (the week runs 19–25 here). */
function dayColumn(day: string): HTMLElement {
  const column = screen.getByText(day).closest('section');
  if (!column) throw new Error(`No column for the ${day}th`);
  return column;
}

function transfer() {
  return { setData: vi.fn(), effectAllowed: '', dropEffect: '' } as unknown as DataTransfer;
}

beforeEach(() => {
  for (const mock of Object.values(mocks)) mock.mockReset();
  mocks.moveSessionAction.mockResolvedValue({ ok: true, data: { date: '2026-10-21' } });
});

afterEach(() => {
  cleanup();
});

describe('WeekBoard', () => {
  it('moves a session to the day it is dropped on', async () => {
    renderBoard();
    const card = screen.getByRole('button', { name: /Easy 40/ });
    const dataTransfer = transfer();

    fireEvent.dragStart(card, { dataTransfer });
    fireEvent.dragOver(dayColumn('21'), { dataTransfer });
    fireEvent.drop(dayColumn('21'), { dataTransfer });

    await waitFor(() => expect(mocks.moveSessionAction).toHaveBeenCalledWith('s1', '2026-10-21'));
    expect(mocks.refresh).toHaveBeenCalled();
  });

  it('ignores a drop back onto the same day', async () => {
    renderBoard();
    const card = screen.getByRole('button', { name: /Easy 40/ });
    const dataTransfer = transfer();

    fireEvent.dragStart(card, { dataTransfer });
    fireEvent.drop(dayColumn('20'), { dataTransfer });

    expect(mocks.moveSessionAction).not.toHaveBeenCalled();
  });

  it('opens the session for editing when it is clicked instead', async () => {
    renderBoard();
    fireEvent.click(screen.getByRole('button', { name: /Easy 40/ }));
    expect(screen.getByRole('dialog', { name: 'Session' })).toBeInTheDocument();
  });
});
