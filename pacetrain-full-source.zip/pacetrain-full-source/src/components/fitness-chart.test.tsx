// @vitest-environment jsdom
import { afterEach, describe, expect, it } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import { FitnessChart } from '@/components/fitness-chart';
import type { FitnessPoint } from '@/domain/fitness';

afterEach(cleanup);

function series(count: number): FitnessPoint[] {
  return Array.from({ length: count }, (_, index) => ({
    date: `2026-10-${String(index + 1).padStart(2, '0')}`,
    load: index % 2 ? 60 : 0,
    ctl: 40 + index,
    atl: 45 + (index % 5),
    tsb: index % 2 ? -8 : 6,
    projected: index >= count - 3
  }));
}

describe('FitnessChart', () => {
  it('draws one labelled chart for the window', () => {
    const { container } = render(<FitnessChart points={series(20)} days={90} />);

    expect(screen.getByRole('img', { name: /fitness, fatigue and form over the last 90 days/i })).toBeInTheDocument();
    // One bar per day for form, plus the two load lines.
    expect(container.querySelectorAll('rect')).toHaveLength(20);
    expect(container.querySelectorAll('path')).toHaveLength(4);
  });

  it('asks for data instead of drawing an empty frame', () => {
    render(<FitnessChart points={series(1)} days={90} />);
    expect(screen.getByText(/No training yet/i)).toBeInTheDocument();
  });
});
