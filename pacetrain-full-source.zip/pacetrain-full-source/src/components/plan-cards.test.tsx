// @vitest-environment jsdom
import { afterEach, describe, expect, it } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import { PlanCards } from '@/components/plan-cards';
import { ACCESS_MESSAGE, accessFor } from '@/domain/billing';

afterEach(cleanup);

const CONTACT = 'dev@pacetrain.test';

function renderCards(overrides: { trialUsed?: boolean; contactEmail?: string; active?: boolean } = {}) {
  const access = overrides.active
    ? accessFor({
        id: 's1',
        plan: 'halfYear',
        status: 'active',
        source: 'grant',
        amountSek: 90,
        reference: '',
        note: '',
        startedAt: '2026-10-01T00:00:00.000Z',
        expiresAt: '2099-01-01T00:00:00.000Z'
      })
    : accessFor(null);

  return render(
    <PlanCards
      access={access}
      trialUsed={overrides.trialUsed ?? false}
      contactEmail={overrides.contactEmail ?? CONTACT}
    />
  );
}

describe('PlanCards', () => {
  it('shows the four prices, the per-week maths and the message', () => {
    renderCards();

    expect(screen.getByText('Test period')).toBeInTheDocument();
    expect(screen.getByText('3 months')).toBeInTheDocument();
    expect(screen.getByText('6 months')).toBeInTheDocument();
    expect(screen.getByText('12 months')).toBeInTheDocument();
    expect(screen.getByText('≈10 kr/week')).toBeInTheDocument();
    expect(screen.getByText('≈3.8 kr/week')).toBeInTheDocument();
    expect(screen.getByText('≈3.5 kr/week')).toBeInTheDocument();
    expect(screen.getByText('≈2.7 kr/week')).toBeInTheDocument();
    expect(screen.getByText(ACCESS_MESSAGE)).toBeInTheDocument();
  });

  it('sends the buyer to the developer instead of a checkout', () => {
    renderCards();

    expect(screen.getByText(/How to buy:/)).toBeInTheDocument();
    const links = screen.getAllByRole('link', { name: 'Contact developer' });
    expect(links).toHaveLength(4);

    const href = links[1].getAttribute('href') ?? '';
    expect(href.startsWith(`mailto:${CONTACT}`)).toBe(true);
    expect(decodeURIComponent(href)).toContain('3 months (50 kr)');
    // No card payment anywhere.
    expect(screen.queryByRole('button', { name: /Pay/ })).not.toBeInTheDocument();
  });

  it('falls back to plain text when no contact address is set', () => {
    renderCards({ contactEmail: '' });

    expect(screen.getByText(/contact the developer/i)).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Contact developer' })).not.toBeInTheDocument();
    expect(screen.getAllByText('Contact developer')).toHaveLength(4);
  });

  it('offers one test period per account', () => {
    renderCards({ trialUsed: true });

    expect(screen.getByRole('button', { name: 'Trial already used' })).toBeDisabled();
    expect(screen.getAllByRole('link', { name: 'Contact developer' })).toHaveLength(3);
  });

  it('marks the period that is already running', () => {
    renderCards({ active: true });

    expect(screen.getByText('your plan')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Trial is for new members' })).toBeDisabled();
  });
});

