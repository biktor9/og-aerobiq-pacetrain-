'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { signOut } from '@/lib/auth-client';

export function AccountMenu({ name, email }: { name: string; email: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const initial = (name || email || '?').trim().charAt(0).toUpperCase();

  async function onSignOut() {
    setBusy(true);
    await signOut();
    router.push('/sign-in');
    router.refresh();
  }

  return (
    <details style={{ position: 'relative' }}>
      <summary
        style={{
          listStyle: 'none',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          padding: '4px 8px 4px 4px',
          borderRadius: 999,
          border: '1px solid var(--border)',
          background: 'var(--surface)'
        }}
        aria-label="Account menu"
      >
        <span
          style={{
            width: 26,
            height: 26,
            borderRadius: '50%',
            background: 'var(--accent-soft)',
            color: 'var(--accent)',
            display: 'grid',
            placeItems: 'center',
            fontSize: 12,
            fontWeight: 700
          }}
        >
          {initial}
        </span>
        <span style={{ fontSize: 13, fontWeight: 550, maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {name || 'Athlete'}
        </span>
      </summary>
      <div
        style={{
          position: 'absolute',
          right: 0,
          top: 'calc(100% + 8px)',
          width: 230,
          background: 'var(--surface)',
          border: '1px solid var(--border)',
          borderRadius: 12,
          boxShadow: 'var(--shadow)',
          padding: 8,
          zIndex: 40
        }}
      >
        <div style={{ padding: '6px 8px 10px', borderBottom: '1px solid var(--border)', marginBottom: 6 }}>
          <div style={{ fontSize: 13, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis' }}>{name}</div>
          <div className="small faint" style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {email}
          </div>
        </div>
        <Link href="/billing" className="btn btn-ghost" style={{ width: '100%', justifyContent: 'flex-start' }}>
          Plan &amp; billing
        </Link>
        <Link href="/settings" className="btn btn-ghost" style={{ width: '100%', justifyContent: 'flex-start' }}>
          Settings
        </Link>
        <button
          type="button"
          className="btn btn-ghost"
          style={{ width: '100%', justifyContent: 'flex-start' }}
          onClick={onSignOut}
          disabled={busy}
        >
          {busy ? 'Signing out…' : 'Sign out'}
        </button>
      </div>
    </details>
  );
}
