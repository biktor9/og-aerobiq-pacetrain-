'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import {
  clearOwnKeyAction,
  connectIcuAction,
  deleteAccountAction,
  disconnectIcuAction,
  saveOwnKeyAction,
  saveProfileAction,
  syncIcuAction
} from '@/actions/settings';
import { MODES } from '@/domain/types';

export interface ProfileValues {
  goalText: string;
  eventDate: string;
  weeklyMinutesTarget: number;
  weeklyLoadTarget: number;
  primaryMode: string;
  coachTone: string;
  athleteNotes: string;
}

export interface IcuStatus {
  connected: boolean;
  athleteId: string;
  keyLast4: string;
  status: string;
  lastError: string | null;
  lastSyncAt: string | null;
}

const TONES = [
  { id: 'direct', label: 'Direct' },
  { id: 'supportive', label: 'Supportive' },
  { id: 'analytical', label: 'Analytical' },
  { id: 'concise', label: 'Very brief' }
];

function Status({ message, tone }: { message: string; tone: 'good' | 'bad' }) {
  if (!message) return null;
  return <div className={`alert alert-${tone}`}>{message}</div>;
}

export function ProfileForm({ initial }: { initial: ProfileValues }) {
  const router = useRouter();
  const [values, setValues] = useState(initial);
  const [status, setStatus] = useState({ message: '', tone: 'good' as 'good' | 'bad' });
  const [busy, setBusy] = useState(false);

  const patch = (changes: Partial<ProfileValues>) => setValues((current) => ({ ...current, ...changes }));

  async function save() {
    setBusy(true);
    const result = await saveProfileAction({
      ...values,
      weeklyMinutesTarget: Number(values.weeklyMinutesTarget) || 0,
      weeklyLoadTarget: Number(values.weeklyLoadTarget) || 0
    });
    setBusy(false);
    if (!result.ok) {
      setStatus({ message: result.error, tone: 'bad' });
      return;
    }
    setStatus({ message: 'Saved. The coach will use this from the next answer.', tone: 'good' });
    router.refresh();
  }

  return (
    <div className="stack" style={{ gap: 12 }}>
      <div className="field">
        <label htmlFor="goal">Goal</label>
        <input
          id="goal"
          className="input"
          value={values.goalText}
          maxLength={300}
          placeholder="Sub-3 marathon in April, or: build an aerobic base over winter"
          onChange={(event) => patch({ goalText: event.target.value })}
        />
      </div>

      <div className="field-row">
        <div className="field">
          <label htmlFor="event">Target event date</label>
          <input
            id="event"
            className="input"
            type="date"
            value={values.eventDate}
            onChange={(event) => patch({ eventDate: event.target.value })}
          />
        </div>
        <div className="field">
          <label htmlFor="mode">Main discipline</label>
          <select
            id="mode"
            className="select"
            value={values.primaryMode}
            onChange={(event) => patch({ primaryMode: event.target.value })}
          >
            {MODES.map((mode) => (
              <option key={mode.id} value={mode.id}>
                {mode.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="field-row">
        <div className="field">
          <label htmlFor="minutes">Weekly minutes target</label>
          <input
            id="minutes"
            className="input"
            type="number"
            min={0}
            max={3000}
            value={values.weeklyMinutesTarget}
            onChange={(event) => patch({ weeklyMinutesTarget: Number(event.target.value) })}
          />
        </div>
        <div className="field">
          <label htmlFor="load">Weekly load target</label>
          <input
            id="load"
            className="input"
            type="number"
            min={0}
            max={2000}
            value={values.weeklyLoadTarget}
            onChange={(event) => patch({ weeklyLoadTarget: Number(event.target.value) })}
          />
        </div>
      </div>

      <div className="field">
        <label>Coach tone</label>
        <div className="segmented">
          {TONES.map((tone) => (
            <button
              key={tone.id}
              type="button"
              aria-pressed={values.coachTone === tone.id}
              onClick={() => patch({ coachTone: tone.id })}
            >
              {tone.label}
            </button>
          ))}
        </div>
      </div>

      <div className="field">
        <label htmlFor="notes">About you</label>
        <textarea
          id="notes"
          className="textarea"
          value={values.athleteNotes}
          maxLength={1000}
          placeholder="Training history, availability, injuries to respect, what has worked before."
          onChange={(event) => patch({ athleteNotes: event.target.value })}
        />
        <span className="field-hint">Sent to the coach with every question. Keep it short and factual.</span>
      </div>

      <Status message={status.message} tone={status.tone} />

      <div>
        <button className="btn btn-primary" type="button" onClick={save} disabled={busy}>
          {busy ? 'Saving…' : 'Save profile'}
        </button>
      </div>
    </div>
  );
}

export function CoachKeyForm({ hasOwnKey }: { hasOwnKey: boolean }) {
  const router = useRouter();
  const [key, setKey] = useState('');
  const [status, setStatus] = useState({ message: '', tone: 'good' as 'good' | 'bad' });
  const [busy, setBusy] = useState(false);

  async function save() {
    setBusy(true);
    const result = await saveOwnKeyAction(key);
    setBusy(false);
    if (!result.ok) {
      setStatus({ message: result.error, tone: 'bad' });
      return;
    }
    setKey('');
    setStatus({ message: 'Key saved and encrypted. Requests now use it.', tone: 'good' });
    router.refresh();
  }

  async function remove() {
    setBusy(true);
    await clearOwnKeyAction();
    setBusy(false);
    setStatus({ message: 'Key removed. You are back on the shared quota.', tone: 'good' });
    router.refresh();
  }

  return (
    <div className="stack" style={{ gap: 12 }}>
      <div className="alert">
        {hasOwnKey
          ? 'Your own DeepSeek key is in use. Shared-key limits do not apply.'
          : 'Without your own key you share the site-wide DeepSeek key and its daily limits.'}
      </div>

      <div className="field">
        <label htmlFor="dskey">{hasOwnKey ? 'Replace key' : 'Paste your DeepSeek key'}</label>
        <input
          id="dskey"
          className="input"
          type="password"
          autoComplete="off"
          value={key}
          placeholder="sk-…"
          onChange={(event) => setKey(event.target.value)}
        />
        <span className="field-hint">
          Stored encrypted (AES-256-GCM) and only decrypted on the server for your own requests. It is never sent to the
          browser again.
        </span>
      </div>

      <Status message={status.message} tone={status.tone} />

      <div className="row">
        <button className="btn btn-primary" type="button" onClick={save} disabled={busy || key.trim().length < 20}>
          {busy ? 'Saving…' : 'Save key'}
        </button>
        {hasOwnKey ? (
          <button className="btn btn-danger" type="button" onClick={remove} disabled={busy}>
            Remove key
          </button>
        ) : null}
      </div>
    </div>
  );
}

export function IcuForm({ status, activityCount = 0 }: { status: IcuStatus; activityCount?: number }) {
  const router = useRouter();
  const [athleteId, setAthleteId] = useState(status.athleteId);
  const [apiKey, setApiKey] = useState('');
  const [feedback, setFeedback] = useState({ message: '', tone: 'good' as 'good' | 'bad' });
  const [busy, setBusy] = useState(false);

  async function connect() {
    setBusy(true);
    const result = await connectIcuAction({ athleteId, apiKey });
    setBusy(false);
    if (!result.ok) {
      setFeedback({ message: result.error, tone: 'bad' });
      return;
    }
    setApiKey('');
    setFeedback({ message: `Connected to ${result.data.name}.`, tone: 'good' });
    router.refresh();
  }

  async function sync() {
    setBusy(true);
    const result = await syncIcuAction(30);
    setBusy(false);
    if (!result.ok) {
      setFeedback({ message: result.error, tone: 'bad' });
      return;
    }
    const skipped = result.data.unavailable ?? 0;
    setFeedback({
      message: `Scanned ${result.data.scanned} activities, imported ${result.data.imported} new ones.${
        skipped
          ? ` ${skipped} Strava ${skipped === 1 ? 'activity is' : 'activities are'} hidden from the intervals.icu API.`
          : ''
      }`,
      tone: 'good'
    });
    router.refresh();
  }

  async function disconnect() {
    setBusy(true);
    await disconnectIcuAction();
    setBusy(false);
    setFeedback({ message: 'Disconnected. Stored activities stay.', tone: 'good' });
    router.refresh();
  }

  return (
    <div className="stack" style={{ gap: 12 }}>
      {status.connected ? (
        <div className="alert alert-good">
          Connected as <strong>{status.athleteId}</strong>
          {status.keyLast4 ? ` · key ends ${status.keyLast4}` : ''}
          {status.lastSyncAt ? ` · last sync ${new Date(status.lastSyncAt).toLocaleString()}` : ' · never synced'}
        </div>
      ) : (
        <div className="alert">
          Find your athlete ID and API key on intervals.icu under <em>Settings → Developer</em>. The key is encrypted
          before it touches the database.
        </div>
      )}

      {status.lastError ? <div className="alert alert-error">Last error: {status.lastError}</div> : null}

      <div className="field-row">
        <div className="field">
          <label htmlFor="athlete">Athlete ID</label>
          <input
            id="athlete"
            className="input"
            value={athleteId}
            placeholder="i12345"
            onChange={(event) => setAthleteId(event.target.value)}
          />
        </div>
        <div className="field">
          <label htmlFor="icukey">{status.connected ? 'New API key (optional)' : 'API key'}</label>
          <input
            id="icukey"
            className="input"
            type="password"
            autoComplete="off"
            value={apiKey}
            placeholder="••••••••"
            onChange={(event) => setApiKey(event.target.value)}
          />
        </div>
      </div>

      <Status message={feedback.message} tone={feedback.tone} />

      <div className="row">
        <button
          className="btn btn-primary"
          type="button"
          onClick={connect}
          disabled={busy || !athleteId.trim() || apiKey.trim().length < 10}
        >
          {busy ? 'Working…' : status.connected ? 'Update connection' : 'Connect intervals.icu'}
        </button>
        {status.connected ? (
          <>
            <button className="btn" type="button" onClick={sync} disabled={busy}>
              Sync last 30 days
            </button>
            <button className="btn btn-danger" type="button" onClick={disconnect} disabled={busy}>
              Disconnect
            </button>
          </>
        ) : null}
      </div>

      {activityCount > 0 ? (
        <p className="small muted" style={{ margin: 0 }}>
          {activityCount} {activityCount === 1 ? 'activity' : 'activities'} stored ·{' '}
          <a href="/activities">View activities →</a>
        </p>
      ) : null}
    </div>
  );
}

export function DangerZone({ email }: { email: string }) {
  const [confirmation, setConfirmation] = useState('');
  const [busy, setBusy] = useState(false);
  const matches = confirmation.trim().toLowerCase() === email.toLowerCase();

  async function remove() {
    if (!matches) return;
    setBusy(true);
    await deleteAccountAction();
  }

  return (
    <div className="stack" style={{ gap: 10 }}>
      <p className="small muted">
        Deleting the account removes your sessions, activities, analyses, chat history and stored keys. This cannot be
        undone.
      </p>
      <div className="field">
        <label htmlFor="confirm">Type {email} to confirm</label>
        <input
          id="confirm"
          className="input"
          value={confirmation}
          onChange={(event) => setConfirmation(event.target.value)}
          placeholder={email}
        />
      </div>
      <div>
        <button className="btn btn-danger" type="button" onClick={remove} disabled={!matches || busy}>
          {busy ? 'Deleting…' : 'Delete my account'}
        </button>
      </div>
    </div>
  );
}
