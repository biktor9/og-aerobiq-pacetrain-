import Link from 'next/link';

export function AuthShell({
  title,
  subtitle,
  children,
  footer
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
}) {
  return (
    <main className="auth-shell">
      <div className="auth-card">
        <div className="auth-brand">
          <span className="brand-mark">P</span>
          <span>PaceTrain</span>
        </div>
        <h1 style={{ fontSize: 22, marginTop: 12 }}>{title}</h1>
        {subtitle ? <p className="auth-sub" style={{ marginTop: 6 }}>{subtitle}</p> : <div style={{ height: 16 }} />}
        {children}
        {footer ? <div className="auth-foot">{footer}</div> : null}
      </div>
      <p className="small faint" style={{ position: 'absolute', bottom: 18 }}>
        <Link href="/">PaceTrain</Link> · plan the week, review the reps
      </p>
    </main>
  );
}
