import type { FitnessPoint } from '@/domain/fitness';
import { parseISODate, shortDate } from '@/domain/week';

/**
 * Fitness, fatigue and form in one picture.
 *
 * The top two-thirds are the two load lines an athlete actually trains by:
 * fitness (42-day) climbing slowly, fatigue (7-day) moving fast. The strip at
 * the bottom is form, drawn around a zero line so "fresh" and "carrying
 * fatigue" are visible at a glance. The dashed tail is the plan, not history.
 */

const WIDTH = 840;
const HEIGHT = 300;
const PAD = { left: 44, right: 16, top: 14, bottom: 26 };

function linePath(points: { x: number; y: number }[]): string {
  return points.map((point, index) => `${index ? 'L' : 'M'}${point.x.toFixed(1)},${point.y.toFixed(1)}`).join('');
}

export function FitnessChart({ points, days }: { points: FitnessPoint[]; days: number }) {
  if (points.length < 2) {
    return <div className="empty">No training yet. Import activities and the curve starts building itself.</div>;
  }

  const innerW = WIDTH - PAD.left - PAD.right;
  const innerH = HEIGHT - PAD.top - PAD.bottom;
  const lineArea = innerH * 0.68;
  const barTop = PAD.top + innerH * 0.74;
  const barArea = innerH * 0.22;

  const maxLoad = Math.max(10, ...points.map((point) => Math.max(point.ctl, point.atl))) * 1.08;
  const maxForm = Math.max(10, ...points.map((point) => Math.abs(point.tsb))) * 1.1;

  const stepX = innerW / Math.max(1, points.length - 1);
  const x = (index: number) => PAD.left + index * stepX;
  const yLoad = (value: number) => PAD.top + (1 - value / maxLoad) * lineArea;
  const midForm = barTop + barArea / 2;
  const yForm = (value: number) => midForm - (value / maxForm) * (barArea / 2);

  const actual = points.filter((point) => !point.projected);
  const splitIndex = actual.length; // first projected index
  const boundary = Math.max(0, splitIndex - 1);

  const ctlPoints = points.map((point, index) => ({ x: x(index), y: yLoad(point.ctl) }));
  const atlPoints = points.map((point, index) => ({ x: x(index), y: yLoad(point.atl) }));

  const gridValues = [0.25, 0.5, 0.75, 1].map((fraction) => maxLoad * fraction);
  const tickCount = 4;
  const barWidth = Math.max(1, stepX * 0.55);

  return (
    <div className="chart-wrap">
      <svg
        className="chart-svg"
        viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
        role="img"
        aria-label={`Fitness, fatigue and form over the last ${days} days`}
      >
        {gridValues.map((value) => (
          <g key={value}>
            <line x1={PAD.left} x2={WIDTH - PAD.right} y1={yLoad(value)} y2={yLoad(value)} stroke="var(--border)" strokeWidth={1} />
            <text x={PAD.left - 8} y={yLoad(value) + 4} textAnchor="end" fontSize="10" fill="var(--faint)">
              {Math.round(value)}
            </text>
          </g>
        ))}

        <line x1={PAD.left} x2={WIDTH - PAD.right} y1={midForm} y2={midForm} stroke="var(--border-strong)" strokeWidth={1} />
        <text x={PAD.left - 8} y={midForm + 4} textAnchor="end" fontSize="10" fill="var(--faint)">
          0
        </text>

        {/* Form: fresh above the line, tired below it. */}
        {points.map((point, index) => {
          const top = point.tsb >= 0 ? yForm(point.tsb) : midForm;
          const height = Math.max(1, Math.abs(midForm - yForm(point.tsb)));
          return (
            <rect
              key={point.date}
              x={x(index) - barWidth / 2}
              y={top}
              width={barWidth}
              height={height}
              rx={Math.min(1.5, barWidth / 2)}
              fill={point.tsb >= 0 ? 'var(--good)' : 'var(--warn)'}
              opacity={point.projected ? 0.25 : 0.45}
            />
          );
        })}

        {splitIndex < points.length ? (
          <line
            x1={x(boundary)}
            x2={x(boundary)}
            y1={PAD.top}
            y2={PAD.top + innerH}
            stroke="var(--border-strong)"
            strokeDasharray="3 4"
          />
        ) : null}

        <path d={linePath(ctlPoints.slice(0, splitIndex))} fill="none" stroke="var(--accent)" strokeWidth={2.2} />
        <path d={linePath(atlPoints.slice(0, splitIndex))} fill="none" stroke="var(--warn)" strokeWidth={1.8} opacity={0.9} />

        {splitIndex < points.length ? (
          <>
            <path
              d={linePath(ctlPoints.slice(boundary))}
              fill="none"
              stroke="var(--accent)"
              strokeWidth={2.2}
              strokeDasharray="5 4"
              opacity={0.7}
            />
            <path
              d={linePath(atlPoints.slice(boundary))}
              fill="none"
              stroke="var(--warn)"
              strokeWidth={1.8}
              strokeDasharray="5 4"
              opacity={0.6}
            />
          </>
        ) : null}

        {Array.from({ length: tickCount + 1 }, (_, index) => {
          const position = Math.round((index / tickCount) * (points.length - 1));
          const point = points[position];
          return (
            <text
              key={point.date}
              x={x(position)}
              y={HEIGHT - 6}
              textAnchor={index === 0 ? 'start' : index === tickCount ? 'end' : 'middle'}
              fontSize="10"
              fill="var(--faint)"
            >
              {shortDate(parseISODate(point.date))}
            </text>
          );
        })}
      </svg>
    </div>
  );
}
