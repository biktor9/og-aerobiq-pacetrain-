import type { ZoneBounds, ZoneMinutes } from '@/domain/hr-zones';
import { zoneRange, zoneSlices } from '@/domain/hr-zones';
import { mode as modeInfo, type ModeId, type ZoneId } from '@/domain/types';
import { fmtDuration } from '@/domain/week';

/**
 * The week's bar, split by heart-rate zone instead of by sport. Every imported
 * session is placed in the zones it touched — from intervals.icu's own zone
 * times when it sent them, from average and peak heart rate against the
 * athlete's own boundaries otherwise — and the bar shows the share each zone got.
 */

function Bar({ totals }: { totals: Record<ZoneId, number> }) {
  const slices = zoneSlices(totals);
  if (!slices.length) return <div className="zone-bar" />;
  return (
    <div className="zone-bar" role="img" aria-label="Time in each heart-rate zone">
      {slices.map((slice) => (
        <span
          key={slice.id}
          className="zone-seg"
          style={{ width: `${slice.share}%`, background: slice.color }}
          title={`${slice.label}: ${fmtDuration(slice.minutes)}`}
        />
      ))}
    </div>
  );
}

/** `111–133 bpm`, `169+ bpm`. */
function rangeText(bounds: ZoneBounds, id: ZoneId): string {
  const { from, to } = zoneRange(id, bounds);
  if (to === null) return `${from + 1}+ bpm`;
  return from === 0 ? `under ${to + 1} bpm` : `${from + 1}–${to} bpm`;
}

export function ZonePanel({
  total,
  bounds,
  modes,
  periodLabel
}: {
  total: ZoneMinutes;
  bounds: ZoneBounds;
  /** The sports counted, or null for all of them. */
  modes: ModeId[] | null;
  /** `26 Oct–1 Nov 2026` */
  periodLabel: string;
}) {
  const slices = zoneSlices(total.zones);
  const easy = (total.zones[1] ?? 0) + (total.zones[2] ?? 0);
  const share = total.totalMinutes > 0 ? Math.round((easy / total.totalMinutes) * 100) : 0;
  const sportNames = modes && modes.length ? modes.map((id) => modeInfo(id).label).join(', ') : 'every sport';

  return (
    <div className="card">
      <div className="card-head">
        <h3>Heart-rate zones</h3>
        <span className="small muted">
          {total.totalMinutes
            ? `${fmtDuration(total.totalMinutes)} with a heart rate · ${periodLabel}`
            : 'no heart rate yet'}
        </span>
      </div>

      {total.totalMinutes > 0 ? (
        <>
          <Bar totals={total.zones} />
          <div className="zone-legend" style={{ marginTop: 8 }}>
            {slices.map((slice) => (
              <span key={slice.id} className="row" style={{ gap: 5 }}>
                <span className="dot" style={{ background: slice.color }} />
                {slice.label} {fmtDuration(slice.minutes)} · {slice.share}%
                <span className="faint">{rangeText(bounds, slice.id)}</span>
              </span>
            ))}
          </div>
          <p className="small muted" style={{ margin: '8px 0 0' }}>
            {share}% easy (Z1–Z2). Zones come from intervals.icu&apos;s own zone times where it sent them, and from
            each session&apos;s average and peak heart rate otherwise. Counting {sportNames}.
            {total.withoutHr
              ? ` ${total.withoutHr} session${total.withoutHr === 1 ? '' : 's'} had no heart rate.`
              : ''}
          </p>
        </>
      ) : (
        <p className="small muted">
          Import activities from intervals.icu and the week&apos;s time is split across Z1–Z5 here. The boundaries and
          the sports counted are yours to set in <a href="/settings">Settings</a>.
        </p>
      )}
    </div>
  );
}

/** A compact version of the same bar, for a stat tile. */
export function ZoneMeter({ totals, bounds }: { totals: Record<ZoneId, number>; bounds: ZoneBounds }) {
  const slices = zoneSlices(totals);
  return (
    <div className="stack" style={{ gap: 6 }}>
      <Bar totals={totals} />
      <div className="zone-legend">
        {slices.map((slice) => (
          <span key={slice.id} className="row" style={{ gap: 4 }} title={rangeText(bounds, slice.id)}>
            <span className="dot" style={{ background: slice.color }} />
            {slice.label} · {slice.share}%
          </span>
        ))}
      </div>
    </div>
  );
}
