'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { deleteWellnessAction, saveWellnessAction } from '@/actions/wellness';
import { FEELINGS, type Feeling, type WellnessEntry, type WellnessSummary } from '@/domain/wellness';
import { parseISODate, weekdayLabel } from '@/domain/week';

/**
 * The morning check-in: sleep (hours and quality), overnight HRV, resting heart
 * rate, soreness, stress, and the two things a watch cannot measure — how it
 * feels compared with the numbers, and what else is going on in life.
 * Clicking a day loads it back into the form, so a typo is one save away.
 */

interface Draft {
  sleep: string;
  quality: number | null;
  hrv: string;
  rhr: string;
  weight: string;
  soreness: number | null;
  mood: number;
  stress: number;
  feeling: Feeling | null;
  notes: string;
}

function draftFor(entry: WellnessEntry | null | undefined): Draft {
  return {
    sleep: entry?.sleepHours != null ? String(entry.sleepHours) : '7.5',
    quality: entry?.sleepQuality ?? null,
    hrv: entry?.hrvMs != null ? String(entry.hrvMs) : '',
    rhr: entry?.restingHr != null ? String(entry.restingHr) : '',
    weight: entry?.weightKg != null ? String(entry.weightKg) : '',
    soreness: entry?.soreness ?? null,
    mood: entry?.mood ?? 3,
    stress: entry?.stress ?? 3,
    feeling: entry?.feeling ?? null,
    notes: entry?.notes ?? ''
  };
}

function numberOrNull(value: string): number | null {
  if (!value.trim()) return null;
  const parsed = Number(value.replace(',', '.'));
  return Number.isFinite(parsed) ? parsed : null;
}

function deltaText(delta: number | null, unit: string): string {
  if (delta === null || Math.abs(delta) < 0.05) return 'steady vs last week';
  return `${delta > 0 ? '+' : '−'}${Math.abs(delta).toFixed(1)}${unit} vs last week`;
}

const QUALITY_LABELS = ['Terrible', 'Poor', 'OK', 'Good', 'Great'];
const SORENESS_LABELS = ['Fresh', 'Fine', 'Some', 'Sore', 'Very sore'];
const MOOD_LABELS = ['Drained', 'Low', 'OK', 'Good', 'Great'];
const STRESS_LABELS = ['Calm', 'Easy', 'Normal', 'Busy', 'Wired'];

export function WellnessPanel({
  entries,
  summary,
  days,
  todayISO
}: {
  entries: WellnessEntry[];
  summary: WellnessSummary;
  days: { date: string; entry: WellnessEntry | null }[];
  todayISO: string;
}) {
  const router = useRouter();
  const [date, setDate] = useState(todayISO);
  const [draft, setDraft] = useState<Draft>(() => draftFor(entries.find((entry) => entry.date === todayISO)));
  const [status, setStatus] = useState({ message: '', tone: 'good' as 'good' | 'bad' });
  const [busy, setBusy] = useState(false);

  const selected = entries.find((entry) => entry.date === date) ?? null;
  const patch = (changes: Partial<Draft>) => setDraft((current) => ({ ...current, ...changes }));

  function pick(day: string) {
    // Clearing the date input must not wipe the form into an invalid state.
    if (!day) return;
    setDate(day);
    setDraft(draftFor(entries.find((entry) => entry.date === day)));
    setStatus({ message: '', tone: 'good' });
  }

  async function save() {
    setBusy(true);
    const result = await saveWellnessAction({
      date,
      sleepHours: numberOrNull(draft.sleep),
      sleepQuality: draft.quality,
      hrvMs: numberOrNull(draft.hrv),
      restingHr: numberOrNull(draft.rhr),
      weightKg: numberOrNull(draft.weight),
      soreness: draft.soreness,
      mood: draft.mood,
      stress: draft.stress,
      feeling: draft.feeling,
      notes: draft.notes
    });
    setBusy(false);
    if (!result.ok) {
      setStatus({ message: result.error, tone: 'bad' });
      return;
    }
    setStatus({ message: `Saved for ${date}.`, tone: 'good' });
    router.refresh();
  }

  async function remove() {
    setBusy(true);
    const result = await deleteWellnessAction(date);
    setBusy(false);
    if (!result.ok) {
      setStatus({ message: result.error, tone: 'bad' });
      return;
    }
    setDraft(draftFor(null));
    setStatus({ message: `Cleared ${date}.`, tone: 'good' });
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-head">
        <h3>Morning check-in</h3>
        <span className="small muted">{summary.filled} of the last 7 days logged</span>
      </div>

      <div className="wellness-facts">
        <div>
          <span className="stat-label">Sleep</span>
          <strong>{summary.sleepAvg === null ? '—' : `${summary.sleepAvg.toFixed(1)}h`}</strong>
          <span className="faint small">{deltaText(summary.sleepDelta, 'h')}</span>
        </div>
        <div>
          <span className="stat-label">HRV</span>
          <strong>{summary.hrvAvg === null ? '—' : `${summary.hrvAvg} ms`}</strong>
          <span className="faint small">{summary.hrvDelta === null ? 'no baseline' : `${summary.hrvDelta > 0 ? '+' : ''}${summary.hrvDelta} ms vs last week`}</span>
        </div>
        <div>
          <span className="stat-label">Resting HR</span>
          <strong>{summary.restingHrAvg === null ? '—' : `${Math.round(summary.restingHrAvg)} bpm`}</strong>
          <span className="faint small">{deltaText(summary.restingHrDelta, ' bpm')}</span>
        </div>
      </div>

      <div className="wellness-strip" role="group" aria-label="Last two weeks of wellness">
        {days.map((day) => {
          const sleep = day.entry?.sleepHours ?? null;
          const tone = sleep === null ? '' : sleep < 6.5 ? 'is-low' : sleep >= 7.5 ? 'is-good' : '';
          const parsed = parseISODate(day.date);
          return (
            <button
              key={day.date}
              type="button"
              className={`wellness-day ${tone} ${day.date === date ? 'is-selected' : ''}`}
              onClick={() => pick(day.date)}
              title={`${weekdayLabel(parsed)} ${parsed.getDate()}${
                sleep === null ? ' · nothing logged' : ` · ${sleep}h sleep`
              }`}
            >
              <span className="wellness-day-date">{parsed.getDate()}</span>
              <span className="wellness-day-value">{sleep === null ? '·' : sleep.toFixed(1)}</span>
            </button>
          );
        })}
      </div>

      {status.message ? (
        <div className={`alert alert-${status.tone}`} style={{ marginTop: 10 }}>
          {status.message}
        </div>
      ) : null}

      <div className="stack" style={{ gap: 10, marginTop: 12 }}>
        <div className="field-row">
          <div className="field">
            <label htmlFor="wellness-date">Day</label>
            <input
              id="wellness-date"
              className="input"
              type="date"
              value={date}
              max={todayISO}
              onChange={(event) => pick(event.target.value)}
            />
          </div>
          <div className="field">
            <label htmlFor="wellness-sleep">Sleep (hours)</label>
            <input
              id="wellness-sleep"
              className="input"
              type="number"
              step="0.5"
              min="0"
              max="16"
              value={draft.sleep}
              onChange={(event) => patch({ sleep: event.target.value })}
            />
          </div>
          <div className="field">
            <label htmlFor="wellness-hrv">Overnight HRV</label>
            <input
              id="wellness-hrv"
              className="input"
              type="number"
              step="1"
              min="5"
              max="300"
              placeholder="ms"
              value={draft.hrv}
              onChange={(event) => patch({ hrv: event.target.value })}
            />
          </div>
          <div className="field">
            <label htmlFor="wellness-rhr">Resting HR</label>
            <input
              id="wellness-rhr"
              className="input"
              type="number"
              step="1"
              min="25"
              max="120"
              placeholder="bpm"
              value={draft.rhr}
              onChange={(event) => patch({ rhr: event.target.value })}
            />
          </div>
        </div>

        <div className="field-row">
          <div className="field">
            <label>Sleep quality</label>
            <div className="segmented">
              {QUALITY_LABELS.map((label, index) => (
                <button
                  key={label}
                  type="button"
                  aria-pressed={draft.quality === index + 1}
                  onClick={() => patch({ quality: draft.quality === index + 1 ? null : index + 1 })}
                  title={label}
                >
                  {index + 1}
                </button>
              ))}
            </div>
            <span className="field-hint">{draft.quality ? QUALITY_LABELS[draft.quality - 1] : 'tap again to clear'}</span>
          </div>

          <div className="field">
            <label>Soreness</label>
            <div className="segmented">
              {SORENESS_LABELS.map((label, index) => (
                <button
                  key={label}
                  type="button"
                  aria-pressed={draft.soreness === index + 1}
                  onClick={() => patch({ soreness: draft.soreness === index + 1 ? null : index + 1 })}
                  title={label}
                >
                  {index + 1}
                </button>
              ))}
            </div>
            <span className="field-hint">{draft.soreness ? SORENESS_LABELS[draft.soreness - 1] : 'tap again to clear'}</span>
          </div>
        </div>

        <div className="field-row">
          <div className="field">
            <label htmlFor="wellness-weight">Weight (kg)</label>
            <input
              id="wellness-weight"
              className="input"
              type="number"
              step="0.1"
              min="25"
              max="250"
              placeholder="optional"
              value={draft.weight}
              onChange={(event) => patch({ weight: event.target.value })}
            />
          </div>

          <div className="field">
            <label>How does it feel?</label>
            <div className="segmented">
              {FEELINGS.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  aria-pressed={draft.feeling === option.id}
                  onClick={() => patch({ feeling: draft.feeling === option.id ? null : option.id })}
                  title={option.label}
                >
                  {option.id === 'better' ? 'Better' : option.id === 'worse' ? 'Worse' : 'As usual'}
                </button>
              ))}
            </div>
            <span className="field-hint">
              {draft.feeling ? 'this nudges the score — your body outranks the watch' : 'optional, but it counts'}
            </span>
          </div>
        </div>

        <div className="field-row">
          <div className="field">
            <label>Mood</label>
            <div className="segmented">
              {MOOD_LABELS.map((label, index) => (
                <button
                  key={label}
                  type="button"
                  aria-pressed={draft.mood === index + 1}
                  onClick={() => patch({ mood: index + 1 })}
                  title={label}
                >
                  {index + 1}
                </button>
              ))}
            </div>
            <span className="field-hint">{MOOD_LABELS[draft.mood - 1]}</span>
          </div>

          <div className="field">
            <label>Stress</label>
            <div className="segmented">
              {STRESS_LABELS.map((label, index) => (
                <button
                  key={label}
                  type="button"
                  aria-pressed={draft.stress === index + 1}
                  onClick={() => patch({ stress: index + 1 })}
                  title={label}
                >
                  {index + 1}
                </button>
              ))}
            </div>
            <span className="field-hint">{STRESS_LABELS[draft.stress - 1]}</span>
          </div>
        </div>

        <div className="field">
          <label htmlFor="wellness-notes">In your own words</label>
          <textarea
            id="wellness-notes"
            className="textarea"
            rows={2}
            value={draft.notes}
            maxLength={400}
            placeholder="More tired than the numbers say. Hectic week at work, slept badly after a late meeting…"
            onChange={(event) => patch({ notes: event.target.value })}
          />
          <span className="field-hint">The coach reads this before it reads any chart.</span>
        </div>

        <div className="row" style={{ gap: 8 }}>
          <button className="btn btn-primary" type="button" disabled={busy} onClick={save}>
            {busy ? 'Saving…' : selected ? 'Update day' : 'Save day'}
          </button>
          {selected ? (
            <button className="btn btn-ghost" type="button" disabled={busy} onClick={remove}>
              Delete
            </button>
          ) : null}
        </div>
      </div>
    </div>
  );
}
