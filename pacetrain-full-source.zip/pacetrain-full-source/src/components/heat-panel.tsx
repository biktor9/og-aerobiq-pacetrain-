'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { loadRoutesAction, setHeatAreaAction, setHeatPeriodAction } from '@/actions/heat';
import { TileMap } from '@/components/tile-map';
import { HEAT_PERIODS, heatPeriodLabel, type HeatPeriod, type HeatRoute } from '@/domain/heat';
import type { Area, LatLng } from '@/domain/geo';

/**
 * The heat map on the plan page: every trace you have run, piled up, inside one
 * area and one window. The area is chosen here and remembered, so the map opens
 * on the same place until it is changed again.
 */
export function HeatPanel({
  routes,
  area,
  period,
  missing,
  totals,
  loaded
}: {
  routes: HeatRoute[];
  area: Area | null;
  period: HeatPeriod;
  /** Activities in the window whose trace has not been read yet. */
  missing: number;
  totals: { sessions: number; km: number };
  /** Traces already stored for the window, inside the area or not. */
  loaded: number;
}) {
  const router = useRouter();
  const [activePeriod, setActivePeriod] = useState<HeatPeriod>(period);
  const [radius, setRadius] = useState(area?.radiusKm ?? 15);
  const [label, setLabel] = useState(area?.label ?? '');
  const [pending, setPending] = useState<LatLng | null>(null);
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  /** Only the saved centre is handed to the map, so a drag never bounces back. */
  const noteView = (next: LatLng) => {
    const rounded: LatLng = [Math.round(next[0] * 1e4) / 1e4, Math.round(next[1] * 1e4) / 1e4];
    setPending((current) =>
      current && current[0] === rounded[0] && current[1] === rounded[1] ? current : rounded
    );
  };

  async function choosePeriod(next: HeatPeriod) {
    setActivePeriod(next);
    setBusy('period');
    setError('');
    const result = await setHeatPeriodAction(next);
    setBusy('');
    if (!result.ok) setError(result.error);
    else router.refresh();
  }

  async function saveArea() {
    const target: LatLng | null = pending ?? (area ? [area.lat, area.lng] : null);
    if (!target) return;

    setBusy('save');
    setError('');
    setNotice('');
    const result = await setHeatAreaAction({
      lat: target[0],
      lng: target[1],
      radiusKm: radius,
      label: label.trim() || 'Your area'
    });
    setBusy('');
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setPending(null);
    setNotice('Area saved — the map opens here from now on.');
    router.refresh();
  }

  async function loadRoutes() {
    setBusy('load');
    setError('');
    setNotice('');
    const result = await loadRoutesAction();
    setBusy('');
    if (!result.ok) {
      setError(result.error);
      return;
    }
    const { loaded: read, remaining } = result.data;
    setNotice(
      remaining > 0 ? `Read ${read} traces · ${remaining} still to go.` : `Read ${read} traces — the map is complete.`
    );
    router.refresh();
  }

  const areaName = area?.label || 'your area';

  /** Something on this card differs from what is stored, so the button offers to keep it. */
  const dirty =
    pending !== null ||
    (area !== null && (radius !== area.radiusKm || (label.trim() !== '' && label.trim() !== area.label)));

  return (
    <div className="card">
      <div className="card-head">
        <div>
          <h3>Where you have been</h3>
          <p className="small muted" style={{ margin: '2px 0 0' }}>
            {totals.sessions
              ? `${totals.sessions} session${totals.sessions === 1 ? '' : 's'} · ${totals.km} km in ${areaName} ${heatPeriodLabel(activePeriod).toLowerCase()}`
              : `Nothing mapped in ${areaName} ${heatPeriodLabel(activePeriod).toLowerCase()} yet`}
          </p>
        </div>
        <div className="segmented">
          {HEAT_PERIODS.map((option) => (
            <button
              key={option.id}
              type="button"
              aria-pressed={activePeriod === option.id}
              disabled={busy === 'period'}
              onClick={() => void choosePeriod(option.id)}
            >
              {option.label.replace('This ', '')}
            </button>
          ))}
        </div>
      </div>

      {error ? <div className="alert alert-error">{error}</div> : null}
      {notice ? <div className="alert alert-good">{notice}</div> : null}

      {area ? (
        <TileMap
          lines={routes.map((route) => ({ id: route.id, points: route.points }))}
          centre={[area.lat, area.lng]}
          radiusKm={radius}
          height={420}
          square
          markers={false}
          halo
          blend
          lineColor="#3ff0ff"
          lineWidth={2.6}
          opacity={0.62}
          onViewChange={noteView}
          ariaLabel={`Heat map of your runs around ${areaName}`}
        />
      ) : (
        <div className="alert">
          <strong>No traces yet.</strong>
          <p className="small" style={{ marginTop: 4 }}>
            Import activities from intervals.icu, read their traces below and this map fills in.
          </p>
        </div>
      )}

      <div className="row-wrap" style={{ gap: 10, justifyContent: 'space-between', marginTop: 10 }}>
        <div className="row" style={{ gap: 6 }}>
          <span className="small muted">Radius</span>
          <button
            className="btn btn-sm"
            type="button"
            aria-label="Smaller area"
            onClick={() => setRadius((current) => Math.max(2, current - 5))}
          >
            −
          </button>
          <span className="small" style={{ minWidth: 46, textAlign: 'center' }}>
            {radius} km
          </span>
          <button
            className="btn btn-sm"
            type="button"
            aria-label="Larger area"
            onClick={() => setRadius((current) => Math.min(80, current + 5))}
          >
            +
          </button>
        </div>

        <div className="row" style={{ gap: 6 }}>
          <input
            className="input"
            style={{ width: 170 }}
            value={label}
            maxLength={60}
            placeholder="Name this area"
            aria-label="Area name"
            onChange={(event) => setLabel(event.target.value)}
          />
          <button
            className="btn btn-sm btn-primary"
            type="button"
            disabled={busy === 'save'}
            onClick={() => void saveArea()}
          >
            {dirty ? 'Use this view' : busy === 'save' ? 'Saving…' : 'Save area'}
          </button>
        </div>
      </div>

      {dirty ? (
        <p className="small faint" style={{ margin: '6px 0 0' }}>
          “Use this view” stores this centre, radius and name — the page opens on the stored area until you change it.
          Scroll to zoom, drag to pan.
        </p>
      ) : (
        <p className="small faint" style={{ margin: '6px 0 0' }}>
          Scroll to zoom, drag to pan.
        </p>
      )}

      {routes.length === 0 && loaded > 0 ? (
        <p className="small muted" style={{ margin: '8px 0 0' }}>
          {loaded} trace{loaded === 1 ? '' : 's'} loaded, but none of them come within {radius} km of {areaName}.
          Widen the radius or drag the map somewhere you have run.
        </p>
      ) : null}

      {missing > 0 ? (
        <div className="alert" style={{ marginTop: 10 }}>
          <strong>
            {missing} activit{missing === 1 ? 'y has' : 'ies have'} no trace read yet.
          </strong>
          <p className="small" style={{ marginTop: 4 }}>
            Each trace is one call to intervals.icu, so they come in batches. A loaded trace is kept, and a run
            without GPS is remembered as having none.
          </p>
          <button className="btn btn-sm" type="button" disabled={busy === 'load'} onClick={() => void loadRoutes()}>
            {busy === 'load' ? 'Reading traces…' : `Read ${Math.min(12, missing)} traces`}
          </button>
        </div>
      ) : null}
    </div>
  );
}
