'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';

type Role = 'user' | 'assistant';

interface Message {
  role: Role;
  content: string;
}

interface Meta {
  mode: 'shared' | 'own-key' | 'offline';
  model: string;
  remainingHour: number | null;
  remainingDay: number | null;
}

const SUGGESTIONS = [
  'How did this week look?',
  'What should I do tomorrow?',
  'Is my load ramping too fast?',
  'How were my intervals?'
];

function renderInline(text: string, keyPrefix: string) {
  return text.split(/(\*\*[^*]+\*\*|_[^_]+_)/g).map((part, index) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={`${keyPrefix}-${index}`}>{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith('_') && part.endsWith('_') && part.length > 2) {
      return <em key={`${keyPrefix}-${index}`}>{part.slice(1, -1)}</em>;
    }
    return <span key={`${keyPrefix}-${index}`}>{part}</span>;
  });
}

export function CoachChat({ initialMessages, initialMeta }: { initialMessages: Message[]; initialMeta: Meta }) {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState('');
  const [meta, setMeta] = useState<Meta>(initialMeta);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const node = scrollRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [messages]);

  function appendToLast(text: string) {
    setMessages((current) => {
      const copy = [...current];
      const last = copy[copy.length - 1];
      if (last && last.role === 'assistant') {
        copy[copy.length - 1] = { ...last, content: last.content + text };
      }
      return copy;
    });
  }

  function dropEmptyLast() {
    setMessages((current) => {
      const copy = [...current];
      const last = copy[copy.length - 1];
      if (last && last.role === 'assistant' && !last.content) copy.pop();
      return copy;
    });
  }

  async function ask(question: string) {
    const trimmed = question.trim();
    if (!trimmed || streaming) return;

    setError('');
    setInput('');
    setStreaming(true);
    setMessages((current) => [...current, { role: 'user', content: trimmed }, { role: 'assistant', content: '' }]);

    let response: Response;
    try {
      response = await fetch('/api/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: trimmed })
      });
    } catch {
      dropEmptyLast();
      setError('Could not reach the coach. Check your connection and try again.');
      setStreaming(false);
      return;
    }

    if (!response.ok || !response.body) {
      const data = (await response.json().catch(() => ({}))) as { error?: string };
      dropEmptyLast();
      setError(data.error ?? 'The coach is unavailable right now.');
      setStreaming(false);
      return;
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let boundary = buffer.indexOf('\n\n');
        while (boundary >= 0) {
          const block = buffer.slice(0, boundary);
          buffer = buffer.slice(boundary + 2);
          boundary = buffer.indexOf('\n\n');

          const event = /^event:\s*(.+)$/m.exec(block)?.[1]?.trim();
          const dataLine = block.split('\n').find((line) => line.startsWith('data:'));
          if (!dataLine) continue;

          let payload: Record<string, unknown>;
          try {
            payload = JSON.parse(dataLine.slice(5).trim()) as Record<string, unknown>;
          } catch {
            continue;
          }

          if (event === 'meta') {
            setMeta(payload as unknown as Meta);
          } else if (event === 'delta' && typeof payload.text === 'string') {
            appendToLast(payload.text);
          } else if (event === 'error') {
            setError(String(payload.message ?? 'The coach stopped early.'));
          }
        }
      }
    } catch {
      setError('The connection dropped mid-answer.');
    } finally {
      dropEmptyLast();
      setStreaming(false);
      inputRef.current?.focus();
    }
  }

  return (
    <div className="chat-layout">
      <section className="chat-card">
        <div className="chat-scroll" ref={scrollRef}>
          {messages.length === 0 ? (
            <div className="empty">
              Ask about your week, your load, or a session you just did. The coach reads your plan and your last two
              weeks of activities.
            </div>
          ) : null}

          {messages.map((message, index) => (
            <div
              key={index}
              className={`msg ${message.role === 'user' ? 'msg-user' : 'msg-assistant'} ${
                streaming && index === messages.length - 1 && message.role === 'assistant' ? 'typing' : ''
              }`}
            >
              {message.role === 'assistant' ? renderInline(message.content, `m${index}`) : message.content}
            </div>
          ))}

          {error ? <div className="alert alert-error">{error}</div> : null}
        </div>

        <div className="suggestions">
          {SUGGESTIONS.map((suggestion) => (
            <button
              key={suggestion}
              type="button"
              className="suggestion"
              disabled={streaming}
              onClick={() => ask(suggestion)}
            >
              {suggestion}
            </button>
          ))}
        </div>

        <form
          className="composer"
          onSubmit={(event) => {
            event.preventDefault();
            void ask(input);
          }}
        >
          <textarea
            ref={inputRef}
            value={input}
            placeholder="Ask the coach…"
            rows={1}
            maxLength={1500}
            onChange={(event) => setInput(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                void ask(input);
              }
            }}
          />
          <button className="btn btn-primary" type="submit" disabled={streaming || input.trim().length < 2}>
            {streaming ? 'Thinking…' : 'Send'}
          </button>
        </form>
      </section>

      <aside className="stack" style={{ gap: 12 }}>
        <div className="card card-tight">
          <div className="spread">
            <h3>Coach status</h3>
            <span className={`badge ${meta.mode === 'offline' ? 'badge-warn' : 'badge-good'}`}>
              {meta.mode === 'offline' ? 'Offline' : meta.mode === 'own-key' ? 'Your key' : 'Shared key'}
            </span>
          </div>
          <p className="small muted" style={{ marginTop: 8 }}>
            Model: <span className="mono">{meta.model}</span>
          </p>
          {meta.mode === 'offline' ? (
            <p className="small muted" style={{ marginTop: 8 }}>
              No DeepSeek key is configured, so answers come from the built-in rule engine. Add your own key in{' '}
              <Link href="/settings">Settings</Link> for full coaching.
            </p>
          ) : meta.mode === 'own-key' ? (
            <p className="small muted" style={{ marginTop: 8 }}>
              Requests use your own key, so the shared limits do not apply. The key stays encrypted on the server.
            </p>
          ) : (
            <p className="small muted" style={{ marginTop: 8 }}>
              Using the shared key.{' '}
              {meta.remainingDay === null ? 'No daily limit.' : `${meta.remainingDay} messages left today`}
              {meta.remainingHour === null ? '' : `, ${meta.remainingHour} this hour`}.
            </p>
          )}
        </div>

        <div className="card card-tight">
          <h3>What it can see</h3>
          <ul className="small muted" style={{ marginTop: 8, display: 'grid', gap: 5 }}>
            <li>Your goal and weekly targets</li>
            <li>This week&apos;s planned sessions</li>
            <li>Activities from the last 14 days</li>
            <li>Your most recent interval analysis</li>
          </ul>
          <p className="field-hint" style={{ marginTop: 10 }}>
            It never sees other athletes, your password, or your API keys.
          </p>
        </div>

        <div className="card card-tight">
          <h3>Make answers better</h3>
          <p className="small muted" style={{ marginTop: 8 }}>
            Fill in the goal and notes in <Link href="/settings">Settings</Link>, and import a few activities so the
            coach has something concrete to work with.
          </p>
        </div>
      </aside>
    </div>
  );
}
