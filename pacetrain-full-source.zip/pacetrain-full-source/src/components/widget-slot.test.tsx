﻿// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { EditProvider, WidgetSlot, labelFor, type EditApi } from '@/components/widget-slot';
import type { WidgetId } from '@/domain/dashboard';

afterEach(cleanup);

function api(overrides: Partial<EditApi> = {}): EditApi {
  return {
    order: ['mix', 'zones', 'board'] as WidgetId[],
    style: 'ring',
    sizes: {},
    onReorder: vi.fn(),
    onMoveTo: vi.fn(),
    onResize: vi.fn(),
    onRemove: vi.fn(),
    onStyle: vi.fn(),
    onSave: vi.fn(),
    onReset: vi.fn(),
    onClose: vi.fn(),
    dirty: false,
    busy: false,
    saved: false,
    error: '',
    selected: null,
    onSelect: vi.fn(),
    dragging: null,
    onDragStart: vi.fn(),
    ...overrides
  };
}

describe('WidgetSlot outside edit mode', () => {
  it('is a bare passthrough, with no frame or controls', () => {
    const { container } = render(
      <WidgetSlot id="mix">
        <div>the block itself</div>
      </WidgetSlot>
    );

    expect(screen.getByText('the block itself')).toBeInTheDocument();
    expect(container.querySelector('[data-editing]')).toBeNull();
    expect(screen.queryByRole('button')).toBeNull();
  });

  it('passes a hidden block straight through as well', () => {
    const { container } = render(
      <EditProvider value={api()}>
        <WidgetSlot id="mix" hidden>
          <div>inner</div>
        </WidgetSlot>
      </EditProvider>
    );

    expect(screen.getByText('inner')).toBeInTheDocument();
    expect(container.querySelector('[data-editing]')).toBeNull();
  });
});

describe('WidgetSlot while editing', () => {
  it('shows the blockâ€™s name and its controls', () => {
    render(
      <EditProvider value={api()}>
        <WidgetSlot id="zones">
          <div>inner</div>
        </WidgetSlot>
      </EditProvider>
    );

    expect(screen.getByText('Heart-rate zones')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Remove Heart-rate zones' })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Change the size of Heart-rate zones' })).toBeEnabled();
  });

  it('asks for a reorder with the neighbours it moved between', async () => {
    const handlers = api();
    render(
      <EditProvider value={handlers}>
        <WidgetSlot id="zones">
          <div>inner</div>
        </WidgetSlot>
      </EditProvider>
    );

    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Heart-rate zones' }));
    await userEvent.click(screen.getByRole('button', { name: 'Move Heart-rate zones up' }));
    expect(handlers.onReorder).toHaveBeenCalledWith('zones', 'mix');

    await userEvent.click(screen.getByRole('button', { name: 'Move Heart-rate zones down' }));
    expect(handlers.onReorder).toHaveBeenCalledWith('zones', 'board');
  });

  it('stops the arrows at the ends rather than wrapping', async () => {
    const handlers = api();
    render(
      <EditProvider value={handlers}>
        <WidgetSlot id="mix">
          <div>a</div>
        </WidgetSlot>
        <WidgetSlot id="board">
          <div>b</div>
        </WidgetSlot>
      </EditProvider>
    );

    // The first block has nowhere above it, and the last nowhere below.
    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Sports' }));
    expect(screen.getByRole('button', { name: 'Move Sports up' })).toBeDisabled();
    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Week board' }));
    expect(screen.getByRole('button', { name: 'Move Week board down' })).toBeDisabled();
  });

  it('sends a block straight to the top or bottom', async () => {
    const handlers = api();
    render(
      <EditProvider value={handlers}>
        <WidgetSlot id="zones">
          <div>a</div>
        </WidgetSlot>
      </EditProvider>
    );

    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Heart-rate zones' }));
    await userEvent.click(screen.getByRole('button', { name: 'Move Heart-rate zones to the top' }));
    expect(handlers.onMoveTo).toHaveBeenCalledWith('zones', 'top');

    await userEvent.click(screen.getByRole('button', { name: 'Move Heart-rate zones to the bottom' }));
    expect(handlers.onMoveTo).toHaveBeenCalledWith('zones', 'bottom');
  });

  it('disables the jump buttons when the block is already there', async () => {
    render(
      <EditProvider value={api()}>
        <WidgetSlot id="mix">
          <div>a</div>
        </WidgetSlot>
        <WidgetSlot id="board">
          <div>b</div>
        </WidgetSlot>
      </EditProvider>
    );

    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Sports' }));
    expect(screen.getByRole('button', { name: 'Move Sports to the top' })).toBeDisabled();
    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Week board' }));
    expect(screen.getByRole('button', { name: 'Move Week board to the bottom' })).toBeDisabled();
  });

  it('removes the block it belongs to', async () => {
    const handlers = api();
    render(
      <EditProvider value={handlers}>
        <WidgetSlot id="board">
          <div>inner</div>
        </WidgetSlot>
      </EditProvider>
    );

    await userEvent.click(screen.getByRole('button', { name: 'Remove Week board' }));
    expect(handlers.onRemove).toHaveBeenCalledWith('board');
  });

  it('is chosen by the first press, and only moved by the next one', () => {
    const handlers = api();
    const { container } = render(
      <EditProvider value={handlers}>
        <WidgetSlot id="heat">
          <div>inner</div>
        </WidgetSlot>
      </EditProvider>
    );

    const body = container.querySelector('.slot-body') as HTMLElement;
    // Nothing is chosen yet, so the first press picks the block up rather than
    // dragging it: a stray click can never rearrange the page. It also cancels
    // any drag an earlier press may have left running.
    fireEvent.pointerDown(body, { button: 0 });
    expect(handlers.onSelect).toHaveBeenCalledWith('heat');
    expect(handlers.onDragStart).not.toHaveBeenCalledWith(expect.objectContaining({ id: 'heat' }));
  });

  it('moves once it is the chosen block', () => {
    const handlers = api({ selected: 'heat' });
    const { container } = render(
      <EditProvider value={handlers}>
        <WidgetSlot id="heat">
          <div>inner</div>
        </WidgetSlot>
      </EditProvider>
    );

    const body = container.querySelector('.slot-body') as HTMLElement;
    fireEvent.pointerDown(body, { button: 0 });
    expect(handlers.onDragStart).toHaveBeenCalledWith({ id: 'heat', again: true });
    expect(handlers.onSelect).not.toHaveBeenCalled();
  });

  it('leaves the other blocks alone while one is chosen', () => {
    const handlers = api({ selected: 'heat' });
    const { container } = render(
      <EditProvider value={handlers}>
        <WidgetSlot id="heat">
          <div>a</div>
        </WidgetSlot>
        <WidgetSlot id="mix">
          <div>b</div>
        </WidgetSlot>
      </EditProvider>
    );

    const other = container.querySelector('[data-widget="mix"] .slot-body') as HTMLElement;
    fireEvent.pointerDown(other, { button: 0 });
    // Pressing another block chooses it; it never drags anything.
    expect(handlers.onSelect).toHaveBeenCalledWith('mix');
    expect(handlers.onDragStart).not.toHaveBeenCalledWith(expect.objectContaining({ id: 'heat' }));
    expect(handlers.onDragStart).not.toHaveBeenCalledWith(expect.objectContaining({ id: 'mix' }));
  });

  it('marks the chosen block, so the page can show which one it is', () => {
    const handlers = api({ selected: 'heat' });
    const { container } = render(
      <EditProvider value={handlers}>
        <WidgetSlot id="heat">
          <div>a</div>
        </WidgetSlot>
        <WidgetSlot id="mix">
          <div>b</div>
        </WidgetSlot>
      </EditProvider>
    );

    const chosen = container.querySelector('[data-widget="heat"]') as HTMLElement;
    const other = container.querySelector('[data-widget="mix"]') as HTMLElement;
    expect(chosen.dataset.chosen).toBe('true');
    expect(chosen.className).toContain('is-chosen');
    expect(other.dataset.chosen).toBe('false');
    expect(other.className).not.toContain('is-chosen');
  });

  it('does not start a drag from the control bar', () => {
    const handlers = api();
    const { container } = render(
      <EditProvider value={handlers}>
        <WidgetSlot id="heat">
          <div>inner</div>
        </WidgetSlot>
      </EditProvider>
    );

    const button = screen.getByRole('button', { name: 'Change the size of Heat map' });
    fireEvent.pointerDown(button, { button: 0, bubbles: true });
    expect(handlers.onDragStart).not.toHaveBeenCalled();
    // The frame is still there, so the bar was found.
    expect(container.querySelector('.slot-bar')).not.toBeNull();
  });
});

describe('WidgetSlot pointer drag', () => {
  /** Stops jsdom complaining that requestAnimationFrame does not exist. */
  beforeEach(() => {
    vi.stubGlobal('requestAnimationFrame', (fn: () => void) => {
      fn();
      return 0;
    });
    vi.stubGlobal('cancelAnimationFrame', () => {});
  });

  afterEach(() => vi.unstubAllGlobals());

  it('reorders onto whatever block the pointer is over', () => {
    const handlers = api({ dragging: { id: 'mix', again: false } });
    render(
      <EditProvider value={handlers}>
        <WidgetSlot id="mix">
          <div>a</div>
        </WidgetSlot>
        <WidgetSlot id="board">
          <div>b</div>
        </WidgetSlot>
      </EditProvider>
    );

    // The pointer is over the Week board, so Sports should take its place.
    const board = document.querySelector('[data-widget="board"]') as HTMLElement;
    const fromPoint = vi.fn(() => board);
    document.elementFromPoint = fromPoint;

    fireEvent.pointerMove(window, { clientX: 10, clientY: 10 });
    expect(handlers.onReorder).toHaveBeenCalledWith('mix', 'board');
  });

  it('leaves things alone while the pointer is over the block being moved', () => {
    const handlers = api({ dragging: { id: 'mix', again: false } });
    render(
      <EditProvider value={handlers}>
        <WidgetSlot id="mix">
          <div>a</div>
        </WidgetSlot>
      </EditProvider>
    );

    const own = document.querySelector('[data-widget="mix"]') as HTMLElement;
    document.elementFromPoint = vi.fn(() => own);

    fireEvent.pointerMove(window, { clientX: 10, clientY: 10 });
    expect(handlers.onReorder).not.toHaveBeenCalled();
  });

  it('does nothing when the pointer is over no block at all', () => {
    const handlers = api({ dragging: { id: 'mix', again: false } });
    render(
      <EditProvider value={handlers}>
        <WidgetSlot id="mix">
          <div>a</div>
        </WidgetSlot>
      </EditProvider>
    );

    document.elementFromPoint = vi.fn(() => null);
    fireEvent.pointerMove(window, { clientX: 10, clientY: 10 });
    expect(handlers.onReorder).not.toHaveBeenCalled();
  });
});

describe('WidgetSlot sizes', () => {
  it('offers small, wide and large for a tile', async () => {
    const handlers = api();
    render(
      <EditProvider value={handlers}>
        <WidgetSlot id="stat-load" span>
          <div>tile</div>
        </WidgetSlot>
      </EditProvider>
    );

    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Load' }));
    const group = screen.getByRole('group', { name: 'Move or size Load' });
    expect(within(group).getByRole('button', { name: 'Small' })).toBeInTheDocument();
    expect(within(group).getByRole('button', { name: 'Wide' })).toBeInTheDocument();
    expect(within(group).getByRole('button', { name: 'Large' })).toBeInTheDocument();
  });

  it('offers full width and half width for a card', async () => {
    render(
      <EditProvider value={api()}>
        <WidgetSlot id="mix">
          <div>card</div>
        </WidgetSlot>
      </EditProvider>
    );

    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Sports' }));
    const group = screen.getByRole('group', { name: 'Move or size Sports' });
    expect(within(group).getByRole('button', { name: 'Full width' })).toBeInTheDocument();
    expect(within(group).getByRole('button', { name: 'Half width' })).toBeInTheDocument();
  });

  it('marks the size it is currently drawn at', async () => {
    render(
      <EditProvider value={api({ sizes: { mix: 'wide' } })}>
        <WidgetSlot id="mix">
          <div>card</div>
        </WidgetSlot>
      </EditProvider>
    );

    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Sports' }));
    expect(screen.getByRole('button', { name: 'Half width' })).toHaveAttribute('aria-pressed', 'true');
    expect(screen.getByRole('button', { name: 'Full width' })).toHaveAttribute('aria-pressed', 'false');
  });

  it('asks for the new size and closes the picker', async () => {
    const handlers = api();
    render(
      <EditProvider value={handlers}>
        <WidgetSlot id="mix">
          <div>card</div>
        </WidgetSlot>
      </EditProvider>
    );

    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Sports' }));
    await userEvent.click(screen.getByRole('button', { name: 'Half width' }));

    expect(handlers.onResize).toHaveBeenCalledWith('mix', 'wide');
    expect(screen.queryByRole('group', { name: 'Move or size Sports' })).not.toBeInTheDocument();
  });
});

describe('labelFor', () => {
  it('names every widget in the catalogue', () => {
    for (const id of ['overview', 'mix', 'zones', 'calendar', 'board', 'heat'] as WidgetId[]) {
      expect(labelFor(id)).not.toBe('Block');
    }
  });

  it('has something to say about an id it does not know', () => {
    expect(labelFor('mystery' as WidgetId)).toBe('Block');
  });
});
