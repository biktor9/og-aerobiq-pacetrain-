'use client';

export function NumberStepper({
  value,
  onChange,
  min = 0,
  max = 999,
  step = 1,
  suffix
}: {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
}) {
  const clamp = (next: number) => Math.min(max, Math.max(min, Math.round(next * 10) / 10));

  return (
    <div className="stepper">
      <button type="button" aria-label="Decrease" onClick={() => onChange(clamp(value - step))}>
        −
      </button>
      <input
        type="number"
        value={Number.isFinite(value) ? value : min}
        min={min}
        max={max}
        step={step}
        onChange={(event) => {
          const next = Number(event.target.value);
          onChange(Number.isFinite(next) ? clamp(next) : min);
        }}
        aria-label={suffix ? `Value in ${suffix}` : 'Value'}
      />
      <button type="button" aria-label="Increase" onClick={() => onChange(clamp(value + step))}>
        +
      </button>
    </div>
  );
}
