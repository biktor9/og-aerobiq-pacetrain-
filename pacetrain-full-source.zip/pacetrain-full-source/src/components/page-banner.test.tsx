// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { PageBanner } from '@/components/page-banner';
import { BETA_TEXT } from '@/domain/page-notes';

const mocks = vi.hoisted(() => ({
  savePageNoteAction: vi.fn(),
  pathname: { current: '/plan' }
}));

vi.mock('@/actions/settings', () => ({
  savePageNoteAction: mocks.savePageNoteAction
}));

vi.mock('next/navigation', () => ({
  usePathname: () => mocks.pathname.current
}));

beforeEach(() => {
  mocks.savePageNoteAction.mockReset();
  mocks.savePageNoteAction.mockResolvedValue({ ok: true, data: { body: '' } });
  mocks.pathname.current = '/plan';
});

afterEach(cleanup);

function renderBanner(notes: Record<string, string> = {}, isAdmin = false) {
  return render(<PageBanner isAdmin={isAdmin} notes={notes} />);
}

describe('PageBanner', () => {
  it('says this is a beta on every tab', () => {
    renderBanner();
    expect(screen.getByText(BETA_TEXT)).toBeInTheDocument();
    expect(screen.getByText('Beta')).toBeInTheDocument();
  });

  it('shows the note written for the tab that is open', () => {
    renderBanner({ plan: 'The calendar now shows your next week.' });
    expect(screen.getByText('The calendar now shows your next week.')).toBeInTheDocument();
  });

  it('shows only this tab’s note, even when others have one', () => {
    renderBanner({ plan: 'about the plan', coach: 'about the coach' });
    expect(screen.getByText('about the plan')).toBeInTheDocument();
    expect(screen.queryByText('about the coach')).not.toBeInTheDocument();
  });

  it('follows the tab when the page changes', () => {
    mocks.pathname.current = '/coach';
    renderBanner({ plan: 'about the plan', coach: 'about the coach' });
    expect(screen.getByText('about the coach')).toBeInTheDocument();
    expect(screen.queryByText('about the plan')).not.toBeInTheDocument();
  });

  it('gives a reader no way to write', () => {
    renderBanner({}, false);
    expect(screen.queryByRole('button', { name: /note/i })).not.toBeInTheDocument();
    expect(screen.queryByRole('textbox')).not.toBeInTheDocument();
  });

  it('gives an admin a pen, and saves what they write against this tab', async () => {
    renderBanner({}, true);

    await userEvent.click(screen.getByRole('button', { name: 'Write a note' }));
    const box = screen.getByRole('textbox');
    await userEvent.type(box, 'New this week');
    await userEvent.click(screen.getByRole('button', { name: 'Save note' }));

    await waitFor(() => expect(mocks.savePageNoteAction).toHaveBeenCalledTimes(1));
    expect(mocks.savePageNoteAction).toHaveBeenCalledWith({ page: 'plan', body: 'New this week' });
    // The form closes once it is stored.
    await waitFor(() => expect(screen.queryByRole('textbox')).not.toBeInTheDocument());
  });

  it('opens on the note already there, so an update can be changed', async () => {
    renderBanner({ plan: 'first draft' }, true);

    await userEvent.click(screen.getByRole('button', { name: 'Edit note' }));
    expect(screen.getByRole('textbox')).toHaveValue('first draft');
  });

  it('keeps the box open when the save fails, and says why', async () => {
    mocks.savePageNoteAction.mockResolvedValue({ ok: false, error: 'Only an admin can write these notes.' });
    renderBanner({}, true);

    await userEvent.click(screen.getByRole('button', { name: 'Write a note' }));
    await userEvent.type(screen.getByRole('textbox'), 'text');
    await userEvent.click(screen.getByRole('button', { name: 'Save note' }));

    expect(await screen.findByText('Only an admin can write these notes.')).toBeInTheDocument();
    expect(screen.getByRole('textbox')).toHaveValue('text');
  });

  it('writes the note on the tab that is open, not on the first one', async () => {
    mocks.pathname.current = '/recovery';
    renderBanner({}, true);

    await userEvent.click(screen.getByRole('button', { name: 'Write a note' }));
    await userEvent.type(screen.getByRole('textbox'), 'rest week');
    await userEvent.click(screen.getByRole('button', { name: 'Save note' }));

    await waitFor(() =>
      expect(mocks.savePageNoteAction).toHaveBeenCalledWith({ page: 'recovery', body: 'rest week' })
    );
  });

  it('offers no note box on a page that is not a tab', () => {
    mocks.pathname.current = '/pricing';
    renderBanner({}, true);
    expect(screen.getByText(BETA_TEXT)).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /note/i })).not.toBeInTheDocument();
  });
});
