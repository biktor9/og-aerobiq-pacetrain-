'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  SATELLITE_ATTRIBUTION,
  TILE_SIZE,
  clampZoom,
  project,
  satelliteTileUrl,
  tileRange,
  unproject,
  zoomForRadius,
  type LatLng
} from '@/domain/geo';

/**
 * A small slippy map on satellite tiles: no API key, no map library. Tiles are
 * plain images in Web Mercator and the traces are an SVG polyline drawn in the
 * same pixel space, so panning and zooming move both together.
 */

export interface MapLine {
  id: string;
  points: LatLng[];
}

export function TileMap({
  lines,
  centre,
  radiusKm,
  height = 340,
  square = false,
  interactive = true,
  markers = true,
  lineColor = '#5ee7ff',
  lineWidth = 2.5,
  opacity = 0.9,
  blend = false,
  halo = false,
  onViewChange,
  ariaLabel = 'Route on a satellite map'
}: {
  lines: MapLine[];
  centre: LatLng;
  radiusKm: number;
  height?: number;
  /** A square frame, as tall as it is wide. Height is then only a maximum. */
  square?: boolean;
  interactive?: boolean;
  markers?: boolean;
  lineColor?: string;
  lineWidth?: number;
  opacity?: number;
  /** Additive blending, so overlapping runs glow like a heat map. */
  blend?: boolean;
  /**
   * Draw a soft dark outline under each line. A pale trace over a pale road is
   * invisible otherwise; the halo is what makes a heat map readable on imagery.
   */
  halo?: boolean;
  onViewChange?: (centre: LatLng, zoom: number) => void;
  ariaLabel?: string;
}) {
  const [centreLat, centreLng] = centre;
  const box = useRef<HTMLDivElement | null>(null);
  const drag = useRef<{ x: number; y: number; lat: number; lng: number; moved: boolean } | null>(null);

  const [width, setWidth] = useState(900);
  const [frameHeight, setFrameHeight] = useState(height);
  const [view, setView] = useState({ lat: centreLat, lng: centreLng, zoom: zoomForRadius(radiusKm, 900, height) });

  useEffect(() => {
    const element = box.current;
    if (!element) return;
    const measure = () => {
      const measured = Math.max(240, element.clientWidth);
      setWidth(measured);
      // A square map is as tall as it is wide, but never taller than asked for.
      setFrameHeight(square ? Math.min(Math.max(240, height), measured) : height);
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  }, [square, height]);

  // A new area (or a wider window) reframes the map.
  useEffect(() => {
    setView({ lat: centreLat, lng: centreLng, zoom: zoomForRadius(radiusKm, width, frameHeight) });
  }, [centreLat, centreLng, radiusKm, width, frameHeight]);

  const tiles = useMemo(
    () => tileRange([view.lat, view.lng], view.zoom, width, frameHeight),
    [view.lat, view.lng, view.zoom, width, frameHeight]
  );

  const centrePixel = project(view.lat, view.lng, view.zoom);
  const left = centrePixel.x - width / 2;
  const top = centrePixel.y - frameHeight / 2;

  function toPixel([lat, lng]: LatLng): [number, number] {
    const pixel = project(lat, lng, view.zoom);
    return [pixel.x - left, pixel.y - top];
  }

  function panTo(x: number, y: number, zoom: number) {
    const [lat, lng] = unproject(x, y, zoom);
    setView({ lat, lng, zoom });
    onViewChange?.([lat, lng], zoom);
  }

  /** Zooms about the middle of the map: one step is one tile level. */
  function zoomBy(delta: number) {
    const zoom = clampZoom(view.zoom + delta);
    if (zoom === view.zoom) return;
    const pixel = project(view.lat, view.lng, zoom);
    panTo(pixel.x, pixel.y, zoom);
  }

  /** Zooms about the cursor, which is what a scroll wheel over a map expects. */
  function zoomAt(delta: number, clientX: number, clientY: number) {
    const zoom = clampZoom(view.zoom + delta);
    if (zoom === view.zoom) return;
    const element = box.current;
    const rect = element?.getBoundingClientRect();
    const offsetX = rect ? clientX - rect.left : width / 2;
    const offsetY = rect ? clientY - rect.top : frameHeight / 2;
    const anchor = project(view.lat, view.lng, view.zoom);
    const worldX = anchor.x - width / 2 + offsetX;
    const worldY = anchor.y - frameHeight / 2 + offsetY;
    // The point under the cursor stays under the cursor at the new zoom.
    const scale = 2 ** (zoom - view.zoom);
    panTo(worldX * scale, worldY * scale, zoom);
  }

  return (
    <div
      ref={box}
      className={`tile-map ${interactive ? 'is-draggable' : ''}`}
      style={{ height: frameHeight }}
      role="group"
      aria-label={ariaLabel}
      onPointerDown={(event) => {
        if (!interactive) return;
        // Older browsers and jsdom do not implement pointer capture.
        if (typeof event.currentTarget.setPointerCapture === 'function') {
          event.currentTarget.setPointerCapture(event.pointerId);
        }
        drag.current = { x: event.clientX, y: event.clientY, lat: view.lat, lng: view.lng, moved: false };
      }}
      onPointerMove={(event) => {
        const start = drag.current;
        if (!start) return;
        const dx = event.clientX - start.x;
        const dy = event.clientY - start.y;
        if (Math.abs(dx) > 2 || Math.abs(dy) > 2) start.moved = true;
        const pixel = project(start.lat, start.lng, view.zoom);
        panTo(pixel.x - dx, pixel.y - dy, view.zoom);
      }}
      onPointerUp={() => {
        drag.current = null;
      }}
      onPointerCancel={() => {
        drag.current = null;
      }}
      // A laptop without a numeric keypad zooms with the wheel; a mouse drag pans.
      onWheel={(event) => {
        if (!interactive) return;
        event.preventDefault();
        zoomAt(event.deltaY < 0 ? 1 : -1, event.clientX, event.clientY);
      }}
    >
      <div className="tile-layer">
        {tiles.map((tile) => (
          <img
            key={`${tile.zoom}-${tile.x}-${tile.y}`}
            className="map-tile"
            src={satelliteTileUrl(tile.zoom, tile.x, tile.y)}
            alt=""
            width={TILE_SIZE}
            height={TILE_SIZE}
            style={{ left: tile.left, top: tile.top }}
            draggable={false}
            loading="lazy"
          />
        ))}
      </div>

      <svg
        className="route-layer"
        width={width}
        height={frameHeight}
        viewBox={`0 0 ${width} ${frameHeight}`}
        aria-hidden="true"
      >
        <g style={blend ? { mixBlendMode: 'screen' } : undefined}>
          {halo
            ? lines.map((line) => (
                <polyline
                  key={`${line.id}-halo`}
                  points={line.points
                    .map(toPixel)
                    .map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`)
                    .join(' ')}
                  fill="none"
                  stroke="#04121b"
                  strokeWidth={lineWidth + 2.6}
                  strokeLinejoin="round"
                  strokeLinecap="round"
                  opacity={0.55}
                />
              ))
            : null}
          {lines.map((line) => (
            <polyline
              key={line.id}
              points={line.points
                .map(toPixel)
                .map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`)
                .join(' ')}
              fill="none"
              stroke={lineColor}
              strokeWidth={lineWidth}
              strokeLinejoin="round"
              strokeLinecap="round"
              opacity={opacity}
            />
          ))}
          {markers
            ? lines.map((line) => {
                const first = line.points[0];
                const last = line.points[line.points.length - 1];
                if (!first || !last) return null;
                const [startX, startY] = toPixel(first);
                const [endX, endY] = toPixel(last);
                return (
                  <g key={`${line.id}-ends`}>
                    <circle cx={startX} cy={startY} r={4} fill="#38d977" stroke="#04120a" strokeWidth={1.5} />
                    <circle cx={endX} cy={endY} r={4} fill="#ff5a5a" stroke="#170404" strokeWidth={1.5} />
                  </g>
                );
              })
            : null}
        </g>
      </svg>

      {interactive ? (
        <div className="map-zoom">
          <button type="button" onClick={() => zoomBy(1)} aria-label="Zoom in">
            +
          </button>
          <button type="button" onClick={() => zoomBy(-1)} aria-label="Zoom out">
            −
          </button>
        </div>
      ) : null}

      <span className="map-attr">{SATELLITE_ATTRIBUTION}</span>
    </div>
  );
}
