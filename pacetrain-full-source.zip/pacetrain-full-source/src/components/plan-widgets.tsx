﻿'use client';

import Link from 'next/link';
import { HeatPanel } from '@/components/heat-panel';
import { Progress } from '@/components/progress';
import { WeekBoard } from '@/components/week-board';
import { WeekCalendar } from '@/components/week-calendar';
import { ZonePanel } from '@/components/zone-panel';
import { DashboardEditor } from '@/components/dashboard-editor';
import { useDragging, useLiveOrder, useLiveSizes, WidgetSlot } from '@/components/widget-slot';
import type { ProgressStyle, Sizes, WidgetId } from '@/domain/dashboard';
import { layoutRows, showsStats, sizeOf, STAT_WIDGETS, visibleStats } from '@/domain/dashboard';
import type { ZoneBounds } from '@/domain/hr-zones';
import type { ZoneMinutes } from '@/domain/hr-zones';
import { ramp } from '@/domain/load';
import type { Area, LatLng } from '@/domain/geo';
import type { HeatPeriod, HeatRoute } from '@/domain/heat';
import { formatPace } from '@/domain/pace';
import { mode as modeInfo, type ModeId } from '@/domain/types';
import type { WeekSummary } from '@/domain/week-summary';
import { addWeeks, fmtDuration, weekKey } from '@/domain/week';

/**
 * The plan page's blocks, each one independent so the layout can put them in
 * any order. The page decides which of these to render; nothing here knows
 * about the configuration except which percentage style to draw.
 */
export interface PlanData {
  order: WidgetId[];
  progressStyle: ProgressStyle;
  /** How big each widget is drawn; missing entries keep their natural size. */
  sizes: Sizes;

  current: WeekSummary;
  nextWeek: WeekSummary;
  weeks: WeekSummary[];
  weekKeyValue: string;
  mondayISO: string;
  sickDays: string[];
  paceNote: string;
  load: number;
  rampInfo: ReturnType<typeof ramp>;

  sessions: Parameters<typeof WeekBoard>[0]['sessions'];
  weekActivities: Parameters<typeof WeekBoard>[0]['activities'];
  paces: Parameters<typeof WeekBoard>[0]['paces'];

  mix: {
    slices: { mode: ModeId; share: number; minutes: number; km: number }[];
    totalMinutes: number;
    source: 'actual' | 'planned' | 'none';
  };
  zones: ZoneMinutes;
  zoneBounds: ZoneBounds;
  zoneModes: ModeId[] | null;

  heat: {
    routes: HeatRoute[];
    area: Area | null;
    period: HeatPeriod;
    missing: number;
    totals: { sessions: number; km: number };
    loaded: number;
  };

  /** The week's average pace, or null when nothing was run. */
  avgPaceSecPerKm: number | null;
  /** Last week's load, for the ramp card. */
  previousLoad: number;
  /** Load for the weeks in the window, drawn as bars. */
  loadBars: { key: string; label: string; load: number }[];
  /** The tallest bar, so the bars scale to something. */
  loadPeak: number;
  /** Sessions in this week that are neither done nor dropped. */
  outstanding: { id: string; weekday: string; dayOfMonth: number; title: string; mode: ModeId; minutes: number }[];
  /** The morning recovery score, or a note that there is none. */
  recovery: { hasData: boolean; score: number; summary: string; label: string };
}

/** One stat tile. `ring` tiles draw their number inside a circle. */
function Tile({
  id,
  label,
  value,
  note,
  percent,
  style
}: {
  id: WidgetId;
  label: string;
  value: string;
  note: React.ReactNode;
  percent?: number;
  style: ProgressStyle;
}) {
  if (percent !== undefined && style === 'ring') {
    return (
      <div className="stat has-ring" data-widget={id}>
        <div className="stat-label">{label}</div>
        <Progress percent={percent} label={value} note={null} style="ring" />
        <div className="stat-note" style={{ marginTop: 4 }}>{note}</div>
      </div>
    );
  }

  return (
    <div className="stat" data-widget={id}>
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      {percent !== undefined ? (
        <Progress percent={percent} label={value} style="bar" />
      ) : null}
      <div className="stat-note">{note}</div>
    </div>
  );
}

/**
 * One tile on its own, by id. The grid and the editor both use this, so a tile
 * looks the same whether it is in the row or being dragged around.
 */
export function TileFor({ id, data }: { id: WidgetId; data: PlanData }) {
  const { current, nextWeek, progressStyle } = data;
  switch (id) {
    case 'stat-running':
      return (
        <Tile
          id={id}
          label="Running"
          value={`${current.runningKm.toFixed(1)} km`}
          note={data.paceNote}
          style={progressStyle}
        />
      );
    case 'stat-time':
      return (
        <Tile
          id={id}
          label="Time trained"
          value={fmtDuration(current.minutes)}
          note={
            <>
              {current.activities
                ? `${current.activities} activit${current.activities === 1 ? 'y' : 'ies'}`
                : 'nothing imported yet'}
              {current.plannedMinutes ? ` · ${fmtDuration(current.plannedMinutes)} planned` : ''}
            </>
          }
          style={progressStyle}
        />
      );
    case 'stat-planned':
      return (
        <Tile
          id={id}
          label="Planned"
          value={fmtDuration(current.plannedMinutes)}
          note={
            current.plannedSoFarMinutes
              ? `${fmtDuration(current.plannedSoFarMinutes)} due so far`
              : 'nothing due yet this week'
          }
          style={progressStyle}
        />
      );
    case 'stat-plan-done':
      return (
        <Tile
          id={id}
          label="Plan done so far"
          value={current.plannedSoFarMinutes ? `${current.donePlanPct}%` : '—'}
          percent={current.plannedSoFarMinutes ? current.donePlanPct : 0}
          note={
            current.plannedSoFarMinutes
              ? `${fmtDuration(current.donePlanMinutes)} of ${fmtDuration(current.plannedSoFarMinutes)} due`
              : 'no plan to measure against'
          }
          style={progressStyle}
        />
      );
    case 'stat-expected':
      return (
        <Tile
          id={id}
          label="Expected this week"
          value={`${current.plannedRunningKm.toFixed(1)} km`}
          note={
            current.plannedRunningKm
              ? `running, from the plan${
                  nextWeek.plannedRunningKm ? ` · next week ${nextWeek.plannedRunningKm.toFixed(1)} km` : ''
                }`
              : 'nothing planned to run yet'
          }
          style={progressStyle}
        />
      );
    case 'stat-expected-time':
      return (
        <Tile
          id={id}
          label="Expected time"
          value={fmtDuration(current.plannedMinutes)}
          note={current.plannedMinutes ? 'the week’s plan in full' : 'nothing planned yet'}
          style={progressStyle}
        />
      );
    case 'stat-remaining-time':
      return (
        <Tile
          id={id}
          label="Still to do"
          value={fmtDuration(Math.max(0, current.plannedMinutes - current.donePlanMinutes))}
          note={
            current.plannedMinutes
              ? `of ${fmtDuration(current.plannedMinutes)} planned`
              : 'nothing planned to do'
          }
          style={progressStyle}
        />
      );
    case 'stat-sessions-done':
      return (
        <Tile
          id={id}
          label="Sessions done"
          value={`${current.done}${current.sessions ? ` / ${current.sessions}` : ''}`}
          percent={current.sessions ? Math.round((current.done / current.sessions) * 100) : 0}
          note={
            current.sessions
              ? current.skipped
                ? `${current.skipped} skipped`
                : `${current.sessions - current.done} still ahead`
              : 'no sessions planned'
          }
          style={progressStyle}
        />
      );
    case 'stat-streak':
      return (
        <Tile
          id={id}
          label="Trained"
          value={`${current.trainedDays} day${current.trainedDays === 1 ? '' : 's'}`}
          percent={Math.round((current.trainedDays / 7) * 100)}
          note={`out of seven${current.activities ? ` · ${current.activities} sessions` : ''}`}
          style={progressStyle}
        />
      );
    case 'stat-avg-pace':
      return (
        <Tile
          id={id}
          label="Average pace"
          value={data.avgPaceSecPerKm ? formatPace(data.avgPaceSecPerKm) : '—'}
          note={
            data.avgPaceSecPerKm
              ? `over ${current.runs} run${current.runs === 1 ? '' : 's'}`
              : 'no runs logged yet'
          }
          style={progressStyle}
        />
      );
    case 'stat-load':
      return (
        <Tile
          id={id}
          label="Load"
          value={String(data.load)}
          note={
            <span
              className={`badge ${
                data.rampInfo.tone === 'up' ? 'badge-warn' : data.rampInfo.tone === 'down' ? 'badge-accent' : ''
              }`}
            >
              {data.rampInfo.label}
            </span>
          }
          style={progressStyle}
        />
      );
    default:
      return null;
  }
}

/** The whole grid of numbers, with only the tiles the athlete kept. */
export function OverviewTiles({ data }: { data: PlanData }) {
  return (
    <div className="stat-grid six">
      {visibleStats(data.order).map((id) => (
        <TileFor key={id} id={id} data={data} />
      ))}
    </div>
  );
}

/** The sports the week was made of, or is planned to be. */
export function SportsMix({ mix }: { mix: PlanData['mix'] }) {
  if (!mix.slices.length) return null;
  return (
    <div className="card" data-widget="mix">
      <div className="card-head">
        <h3>Sports</h3>
        <span className="small muted">
          {mix.source === 'actual' ? 'what you actually did' : 'what is planned'} · {fmtDuration(mix.totalMinutes)}
        </span>
      </div>
      <div className="zone-bar">
        {mix.slices.map((slice) => (
          <span
            key={slice.mode}
            className="zone-seg"
            style={{ width: `${slice.share}%`, background: modeInfo(slice.mode).color }}
            title={`${modeInfo(slice.mode).label}: ${slice.share}% · ${fmtDuration(slice.minutes)}${
              slice.km ? ` · ${slice.km.toFixed(1)} km` : ''
            }`}
          />
        ))}
      </div>
      <div className="zone-legend" style={{ marginTop: 8 }}>
        {mix.slices.map((slice) => (
          <span key={slice.mode} className="row" style={{ gap: 5 }}>
            <span className="dot" style={{ background: modeInfo(slice.mode).color }} />
            {modeInfo(slice.mode).label} · {slice.share}% · {fmtDuration(slice.minutes)}
            {slice.km ? ` · ${slice.km.toFixed(1)} km` : ''}
          </span>
        ))}
      </div>
    </div>
  );
}


/**
 * Hosts the blocks. This is the boundary between the server and the browser:
 * the page hands down plain data and whether editing is on, and everything
 * inside — the frames, the grip, the drag handling — is client code.
 */
export function PlanWidgets(props: {
  data: PlanData;
  editing?: boolean;
  initialOrder?: WidgetId[];
  initialStyle?: ProgressStyle;
}) {
  if (!props.editing) {
    return <WidgetList data={props.data} editing={false} />;
  }
  return (
    <DashboardEditor
      order={props.initialOrder ?? props.data.order}
      progressStyle={props.initialStyle ?? props.data.progressStyle}
      sizes={props.data.sizes}
    >
      <WidgetList data={props.data} editing />
    </DashboardEditor>
  );
}

/**
 * The blocks themselves. A run of tiles is drawn as one row, side by side, so
 * the page keeps the shape of the start page; a card ends the run. The order
 * is still the athlete's own, so a tile placed between two cards stays between
 * them — only the drawing is grouped.
 *
 * Editing uses exactly the same layout: the page looks the way it will when it
 * is saved, and the blocks are simply movable inside it.
 */
function WidgetList({ data, editing }: { data: PlanData; editing: boolean }) {
  const live = useLiveOrder();
  const liveSizes = useLiveSizes();
  const dragged = useDragging();
  const order = live ?? data.order;
  const sizes = liveSizes ?? data.sizes;
  const rows = layoutRows(order, sizes);

  return (
    <div className={`page-flow${editing ? ' is-editing' : ''}`}>
      {rows.map((row) => (
        <div
          key={row.key}
          className={`flow-row${row.kind === 'tiles' ? ' is-tiles' : ' is-cards'}${
            editing ? ' is-editable' : ''
          }`}
        >
          {row.ids.map((id) => renderBlock(id, data, sizes, editing, dragged))}
        </div>
      ))}
    </div>
  );
}


/**
 * A key for one block in a row. The block being dragged is keyed by itself so
 * it keeps its frame — and the fact that it is chosen — as the pointer carries
 * it past its neighbours; everything else is keyed by its id as usual.
 */
function blockKey(id: WidgetId, dragged: WidgetId | null): string {
  return id === dragged ? `dragged:${id}` : id;
}

/**
 * One block by id, or null when it is not drawn at all. Kept apart from the loop
 * above so every block is treated the same way.
 */
function renderBlock(id: WidgetId, data: PlanData, sizes: Sizes, edit: boolean, dragged: WidgetId | null = null) {
  const current = data.current;
  const progressStyle = data.progressStyle;
  const size = sizeOf(sizes, id);

  // Tiles: narrow blocks that sit in a row, wherever they were put.
  if (STAT_WIDGETS.includes(id)) {
    const card = (
      <div className={`stat is-tile-sliver${progressStyle === 'ring' ? ' has-ring' : ''}`}>
        <TileFor id={id} data={data} />
      </div>
    );
    return (
      <div className={`flow-tile size-${size}`} key={blockKey(id, dragged)}>
        {edit ? (
          <WidgetSlot id={id} span>
            {card}
          </WidgetSlot>
        ) : (
          card
        )}
      </div>
    );
  }

  const body = renderCard(id, data, current, progressStyle);
  if (!body) return null;
  return (
    <div className={`flow-card size-${size}`} key={blockKey(id, dragged)}>
      {edit ? <WidgetSlot id={id}>{body}</WidgetSlot> : body}
    </div>
  );
}

/** The card blocks, by id. */
function renderCard(id: WidgetId, data: PlanData, current: PlanData['current'], progressStyle: ProgressStyle) {
  switch (id) {
    case 'plan-done':
      return (
        <>
          <div className="card">
            <div className="card-head">
              <h3>Plan progress</h3>
              <span className="small muted">{current.label}</span>
            </div>
            <div className="row-wrap" style={{ gap: 20, alignItems: 'center' }}>
              {current.plannedSoFarMinutes ? (
                <>
                  <Progress
                    percent={current.donePlanPct}
                    label={`${current.donePlanPct}%`}
                    style={progressStyle}
                    color={current.donePlanPct >= 100 ? 'var(--good)' : 'var(--accent)'}
                  />
                  <div className="stack" style={{ gap: 4 }}>
                    <span>
                      <strong>{fmtDuration(current.donePlanMinutes)}</strong> of{' '}
                      {fmtDuration(current.plannedSoFarMinutes)} due so far
                    </span>
                    <span className="small muted">
                      {current.done} of {current.sessions} sessions done
                      {current.skipped ? ` · ${current.skipped} skipped` : ''}
                    </span>
                  </div>
                </>
              ) : (
                <p className="small muted" style={{ margin: 0 }}>
                  Nothing was due this week, so there is nothing to measure yet.
                </p>
              )}
            </div>
          </div>
        </>
      );
    case 'plan-left':
      return (
        <>
          <div className="card">
            <div className="card-head">
              <h3>Sessions left</h3>
              <span className="small muted">{current.label}</span>
            </div>
            {data.outstanding.length ? (
              <div className="stack" style={{ gap: 6 }}>
                {data.outstanding.map((item) => (
                  <div key={item.id} className="row-wrap" style={{ gap: 8, alignItems: 'baseline' }}>
                    <span className="small muted" style={{ minWidth: 58 }}>
                      {item.weekday} {item.dayOfMonth}
                    </span>
                    <strong style={{ fontSize: 13 }}>{item.title}</strong>
                    <span className="small muted">{modeInfo(item.mode).label}</span>
                    <div style={{ flex: 1 }} />
                    <span className="small faint">{fmtDuration(item.minutes)}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="small muted" style={{ margin: 0 }}>
                Nothing outstanding: every session this week is done or dropped.
              </p>
            )}
          </div>
        </>
      );
    case 'load-ramp':
      return (
        <>
          <div className="card">
            <div className="card-head">
              <h3>Load ramp</h3>
              <span className="small muted">this week against the last four</span>
            </div>
            <div className="row-wrap" style={{ gap: 16, alignItems: 'flex-end' }}>
              <div>
                <div className="stat-label">This week</div>
                <div className="stat-value">{data.load}</div>
              </div>
              <div>
                <div className="stat-label">Last week</div>
                <div className="stat-value muted">{data.previousLoad}</div>
              </div>
              <span
                className={`badge ${
                  data.rampInfo.tone === 'up' ? 'badge-warn' : data.rampInfo.tone === 'down' ? 'badge-accent' : ''
                }`}
              >
                {data.rampInfo.label}
              </span>
            </div>
            {data.loadBars.length ? (
              <div className="load-bars" style={{ marginTop: 12 }}>
                {data.loadBars.map((bar) => (
                  <span
                    key={bar.key}
                    className={`load-bar${bar.key === data.weekKeyValue ? ' is-selected' : ''}`}
                    title={`${bar.label}: load ${bar.load}`}
                    style={{ height: `${Math.max(6, (bar.load / Math.max(1, data.loadPeak)) * 48)}px` }}
                  />
                ))}
              </div>
            ) : null}
          </div>
        </>
      );
    case 'week-strip':
      return (
        <>
          <div className="card">
            <div className="card-head">
              <h3>Week numbers</h3>
              <span className="small muted">distance, time and plan, side by side</span>
            </div>
            <div className="week-strip">
              {data.weeks.map((week) => (
                <div
                  key={week.key}
                  className={`week-strip-col${week.key === data.weekKeyValue ? ' is-selected' : ''}`}
                >
                  <div className="stat-label">{week.key.slice(5)}</div>
                  <div className="stat-value" style={{ fontSize: 16 }}>
                    {week.runningKm.toFixed(1)} <span className="small faint">km</span>
                  </div>
                  <div className="small muted">{fmtDuration(week.minutes)}</div>
                  <div className="small faint">
                    {week.plannedRunningKm ? `${week.plannedRunningKm.toFixed(1)} km planned` : 'no plan'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      );
    case 'recovery':
      return (
        <>
          <div className="card">
            <div className="card-head">
              <h3>Recovery</h3>
              <span className="small muted">{data.recovery.label}</span>
            </div>
            {data.recovery.hasData ? (
              <div className="row-wrap" style={{ gap: 20, alignItems: 'center' }}>
                <Progress
                  percent={data.recovery.score}
                  label={String(data.recovery.score)}
                  style={progressStyle}
                  color={data.recovery.score >= 67 ? 'var(--good)' : data.recovery.score >= 34 ? 'var(--warn)' : 'var(--bad)'}
                />
                <div className="stack" style={{ gap: 2 }}>
                  <strong>{data.recovery.summary}</strong>
                  <span className="small faint">out of 100, from your morning log</span>
                </div>
              </div>
            ) : (
              <p className="small muted" style={{ margin: 0 }}>
                No morning log yet. <Link href="/recovery">Log how you slept</Link> and the score appears here.
              </p>
            )}
          </div>
        </>
      );
    case 'mix':
      return (
        <>
          <SportsMix mix={data.mix} />
        </>
      );
    case 'zones':
      return (
        <>
          <ZonePanel
            total={data.zones}
            bounds={data.zoneBounds}
            modes={data.zoneModes}
            periodLabel={data.current.label}
          />
        </>
      );
    case 'calendar':
      return (
        <>
          <WeekCalendar
            weeks={data.weeks}
            selected={data.weekKeyValue}
            sickDays={data.sickDays}
            nextWeek={data.nextWeek?.key}
          />
        </>
      );
    case 'board':
      return (
        <>
          <WeekBoard
            sessions={data.sessions}
            activities={data.weekActivities}
            paces={data.paces}
            mondayISO={data.mondayISO}
            weekKey={data.weekKeyValue}
          />
        </>
      );
    case 'heat':
      return (
        <>
          <HeatPanel
            routes={data.heat.routes}
            area={data.heat.area}
            period={data.heat.period}
            missing={data.heat.missing}
            totals={data.heat.totals}
            loaded={data.heat.loaded}
          />
        </>
      );
    default:
      return null;
  }
}
