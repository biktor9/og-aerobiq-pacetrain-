'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useRef, useState } from 'react';
import { ActivitySheet } from '@/components/activity-sheet';
import { ACTIVITY_RANGES, activityTotals, runningTotals, type ActivityRangeId } from '@/domain/activity';
import { duplicatesById } from '@/domain/duplicates';
import { formatPace } from '@/domain/pace';
import { MODES, type Activity, type ModeId, mode as modeInfo } from '@/domain/types';
import { fmtClock, fmtDuration, fmtKm, parseISODate, weekdayLabel } from '@/domain/week';

const SOURCE_LABELS: Record<Activity['source'], string> = {
  'intervals.icu': 'intervals.icu',
  demo: 'sample',
  manual: 'manual'
};

function kmLabel(meters: number): string {
  return `${(meters / 1000).toFixed(1)} km`;
}

export function ActivitiesView({
  activities,
  range,
  rangeLabel,
  total,
  initialEditId
}: {
  activities: Activity[];
  /** Which window is on screen; drives the range chips. `day` comes from the calendar. */
  range: ActivityRangeId | 'day';
  /** Human sentence for the empty state, e.g. "This month". */
  rangeLabel: string;
  total: number;
  /** Deep link from the activity page: `/activities?edit=<id>`. */
  initialEditId?: string | null;
}) {
  const router = useRouter();
  const [modeFilter, setModeFilter] = useState<ModeId | 'all'>('all');
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<Activity | null>(null);

  // Opening `/activities?edit=<id>` should open that activity straight away.
  // The ref keeps a router.refresh() after saving from re-opening the sheet.
  const openedRef = useRef<string | null>(null);
  useEffect(() => {
    if (!initialEditId || openedRef.current === initialEditId) return;
    openedRef.current = initialEditId;
    const match = activities.find((activity) => activity.id === initialEditId);
    if (match) setEditing(match);
  }, [initialEditId, activities]);

  const duplicates = useMemo(() => duplicatesById(activities), [activities]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return activities.filter(
      (activity) =>
        (modeFilter === 'all' || activity.mode === modeFilter) &&
        (!needle || activity.name.toLowerCase().includes(needle))
    );
  }, [activities, modeFilter, query]);

  const totals = useMemo(() => activityTotals(filtered), [filtered]);
  const running = useMemo(() => runningTotals(filtered), [filtered]);

  // Only offer the disciplines that actually appear in the range.
  const modeOptions = useMemo(
    () => MODES.filter((option) => activities.some((activity) => activity.mode === option.id)),
    [activities]
  );

  if (!activities.length) {
    return (
      <div className="empty">
        <p>{total ? `Nothing in ${rangeLabel.toLowerCase()}.` : 'No activities imported yet.'}</p>
        <p className="small" style={{ marginTop: 6 }}>
          {total
            ? 'Widen the range above to see older training.'
            : 'Connect intervals.icu in Settings, then press "Import this week" (or load the sample week from the Plan tab).'}
        </p>
        <p className="small" style={{ marginTop: 10 }}>
          <Link href={total ? '/activities?range=90d' : '/settings'}>
            {total ? 'Show 90 days →' : 'Open Settings →'}
          </Link>
        </p>
      </div>
    );
  }

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="row-wrap" style={{ justifyContent: 'space-between' }}>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
          {ACTIVITY_RANGES.map((option) => (
            <Link
              key={option.id}
              className={`btn btn-sm ${range === option.id ? 'btn-primary' : ''}`}
              href={`/activities?range=${option.id}`}
              title={option.title}
              aria-current={range === option.id ? 'page' : undefined}
            >
              {option.label}
            </Link>
          ))}
        </div>
        <div className="row" style={{ gap: 6 }}>
          <button
            type="button"
            className={`btn btn-sm ${modeFilter === 'all' ? 'btn-primary' : ''}`}
            aria-pressed={modeFilter === 'all'}
            onClick={() => setModeFilter('all')}
          >
            All
          </button>
          {modeOptions.map((option) => (
            <button
              key={option.id}
              type="button"
              className={`btn btn-sm ${modeFilter === option.id ? 'btn-primary' : ''}`}
              aria-pressed={modeFilter === option.id}
              onClick={() => setModeFilter(option.id)}
            >
              {option.short}
            </button>
          ))}
        </div>
      </div>

      <div className="stat-grid">
        <div className="stat">
          <div className="stat-label">Activities</div>
          <div className="stat-value">{totals.count}</div>
          <div className="stat-note">
            {totals.count === activities.length ? `all ${activities.length} in range` : `of ${activities.length} in range`}
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Running km</div>
          <div className="stat-value">{running.km.toFixed(1)}</div>
          <div className="stat-note">
            run · trail · orienteering ({running.count} {running.count === 1 ? 'session' : 'sessions'})
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Running time</div>
          <div className="stat-value">{fmtDuration(running.minutes)}</div>
          <div className="stat-note">
            {running.avgPaceSecPerKm ? `${formatPace(running.avgPaceSecPerKm)} average` : 'no measured pace yet'}
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Total time</div>
          <div className="stat-value">{fmtDuration(totals.minutes)}</div>
          <div className="stat-note">longest {totals.longestKm ? kmLabel(totals.longestKm * 1000) : '—'}</div>
        </div>
      </div>

      <div className="row-wrap" style={{ justifyContent: 'space-between' }}>
        <div className="row-wrap" style={{ gap: 6 }}>
          {Object.entries(totals.byMode)
            .sort((a, b) => b[1].km - a[1].km || b[1].minutes - a[1].minutes)
            .map(([id, modeTotals]) => (
              <span key={id} className="badge">
                <span className="dot" style={{ background: modeInfo(id as ModeId).color, marginRight: 5 }} />
                {modeInfo(id as ModeId).short} · {modeTotals.count} · {modeTotals.km.toFixed(1)} km
              </span>
            ))}
        </div>
        <input
          className="input"
          style={{ maxWidth: 240 }}
          value={query}
          placeholder="Search by name"
          aria-label="Search activities"
          onChange={(event) => setQuery(event.target.value)}
        />
      </div>

      {filtered.length ? (
        <div className="scroll-y">
          <table className="seg-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Discipline</th>
                <th>Activity</th>
                <th>Time</th>
                <th>Distance</th>
                <th>HR</th>
                <th>Load</th>
                <th>Source</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {filtered.map((activity) => (
                <tr key={activity.id}>
                  <td title={activity.date}>
                    {weekdayLabel(parseISODate(activity.date))} {parseISODate(activity.date).getDate()}
                  </td>
                  <td>
                    <span className="row" style={{ gap: 5 }}>
                      <span className="dot" style={{ background: modeInfo(activity.mode).color }} />
                      {modeInfo(activity.mode).label}
                    </span>
                  </td>
                  <td>
                    <span className="row" style={{ gap: 6 }}>
                      <Link href={`/activities/${activity.id}`}>{activity.name || 'Untitled'}</Link>
                      {duplicates.get(activity.id)?.length ? (
                        <span
                          className="badge badge-warn"
                          title={`Same day and almost the same numbers as ${
                            duplicates.get(activity.id)?.map((item) => item.name || item.id).join(', ')
                          }`}
                        >
                          duplicate?
                        </span>
                      ) : null}
                      {activity.rpe ? <span className="badge">RPE {activity.rpe}</span> : null}
                    </span>
                  </td>

                  <td>{fmtClock(activity.durationSec)}</td>
                  <td>{activity.distanceM ? fmtKm(activity.distanceM) : '—'}</td>
                  <td>{activity.avgHr ? `${activity.avgHr} bpm` : '—'}</td>
                  <td>{activity.load ? Math.round(activity.load) : '—'}</td>
                  <td className="small muted">{SOURCE_LABELS[activity.source] ?? activity.source}</td>
                  <td>
                    <span className="row" style={{ gap: 8 }}>
                      <button className="btn btn-sm btn-ghost" type="button" onClick={() => setEditing(activity)}>
                        Edit
                      </button>
                      <Link href={`/activities/${activity.id}`}>Details →</Link>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="empty">Nothing matches that discipline or search.</div>
      )}

      {editing ? (
        <ActivitySheet
          activity={editing}
          duplicates={duplicates.get(editing.id) ?? []}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            router.refresh();
          }}
        />
      ) : null}
    </div>
  );
}
