﻿// @vitest-environment jsdom
import { Fragment } from 'react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { DashboardEditor } from '@/components/dashboard-editor';
import { DropGap, labelFor, useEdit, WidgetSlot } from '@/components/widget-slot';
import { WIDGETS, type Sizes, type WidgetId } from '@/domain/dashboard';

const mocks = vi.hoisted(() => ({
  saveDashboardAction: vi.fn(),
  resetDashboardAction: vi.fn(),
  push: vi.fn(),
  refresh: vi.fn()
}));

vi.mock('@/actions/settings', () => ({
  saveDashboardAction: mocks.saveDashboardAction,
  resetDashboardAction: mocks.resetDashboardAction,
  saveProfileAction: vi.fn(),
  saveZonesAction: vi.fn(),
  saveOwnKeyAction: vi.fn(),
  clearOwnKeyAction: vi.fn(),
  connectIcuAction: vi.fn(),
  disconnectIcuAction: vi.fn(),
  syncIcuAction: vi.fn(),
  deleteAccountAction: vi.fn()
}));

vi.mock('next/navigation', () => ({
  useRouter: () => ({ refresh: mocks.refresh, push: mocks.push })
}));

const ALL: WidgetId[] = WIDGETS.map((widget) => widget.id);

/** The blocks, as the editor draws them: one draggable frame each. */
function frames() {
  return Array.from(document.querySelectorAll('[data-editing="true"]')).map((node) =>
    node.getAttribute('data-widget')
  );
}

/**
 * Presses a block: chooses it, or picks it up when it is already chosen, and
 * ends whatever drag the press before it started.
 */
function press(id: WidgetId) {
  const body = document.querySelector(`[data-widget="${id}"] .slot-body`) as HTMLElement;
  fireEvent.pointerDown(body, { button: 0 });
}

function isChosen(id: WidgetId) {
  const slot = document.querySelector(`[data-widget="${id}"]`) as HTMLElement;
  return slot.dataset.chosen === 'true';
}

function chosenIds() {
  return Array.from(document.querySelectorAll('[data-chosen="true"]')).map((node) =>
    node.getAttribute('data-widget')
  );
}

function renderEditor(overrides: { order?: WidgetId[]; progressStyle?: 'bar' | 'ring'; sizes?: Sizes } = {}) {
  const order = overrides.order ?? ALL;
  return render(
    <DashboardEditor order={order} progressStyle={overrides.progressStyle ?? 'ring'} sizes={overrides.sizes}>
      <Probe order={order} />
    </DashboardEditor>
  );
}

/**
 * Stands in for PlanWidgets in the tests: the same frames and gaps, without the
 * real blocks and the data they need.
 */
function Probe({ order }: { order: WidgetId[] }) {
  const edit = useEdit();
  if (!edit) return null;
  return (
    <>
      {edit.order
        // The tile-row marker draws nothing; the tiles are the blocks.
        .filter((id) => id !== 'overview')
        .map((id) => (
          // The block being dragged keeps its frame (and its chosen state) as
          // the pointer carries it past its neighbours, exactly as the real
          // layout does.
          <Fragment key={id === edit.dragging?.id ? `dragged:${id}` : id}>
            <DropGap before={id} />
            <WidgetSlot id={id}>
              <div>{labelFor(id)} body</div>
            </WidgetSlot>
          </Fragment>
        ))}
    </>
  );
}

beforeEach(() => {
  for (const mock of Object.values(mocks)) mock.mockReset();
  mocks.saveDashboardAction.mockResolvedValue({ ok: true, data: undefined });
  mocks.resetDashboardAction.mockResolvedValue({ ok: true, data: undefined });
});

afterEach(cleanup);

describe('DashboardEditor', () => {
  it('wraps every block in a frame with a grip and a name', () => {
    renderEditor();

    // Every block except the tile-row marker, which draws nothing of its own.
    expect(frames()).toEqual(ALL.filter((id) => id !== 'overview'));
    expect(screen.getByText('Heat map')).toBeInTheDocument();
    expect(screen.getByText('Calendar')).toBeInTheDocument();
  });

  it('offers the tile-row marker nowhere, since the tiles are their own blocks', () => {
    renderEditor();
    expect(screen.queryByRole('button', { name: 'Remove Tile row' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Add Tile row' })).not.toBeInTheDocument();
  });

  it('starts with nothing hidden', () => {
    renderEditor();
    expect(screen.queryByText('Not shown:')).not.toBeInTheDocument();
  });

  it('moves a block up a place', async () => {
    renderEditor();

    const index = ALL.indexOf('calendar');
    const above = ALL[index - 1];
    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Calendar' }));
    await userEvent.click(screen.getByRole('button', { name: 'Move Calendar up' }));
    await userEvent.click(screen.getByRole('button', { name: 'Save layout' }));

    const order = mocks.saveDashboardAction.mock.calls[0][0].order as WidgetId[];
    // It swapped places with the block that was above it.
    expect(order[index]).toBe(above);
    expect(order[index - 1]).toBe('calendar');
  });

  it('sends a block to the top with one press', async () => {
    renderEditor();

    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Heat map' }));
    await userEvent.click(screen.getByRole('button', { name: 'Move Heat map to the top' }));
    await userEvent.click(screen.getByRole('button', { name: 'Save layout' }));

    const order = mocks.saveDashboardAction.mock.calls[0][0].order as WidgetId[];
    expect(order[0]).toBe('heat');
  });

  it('picks a block up with one press and puts it down with the next', async () => {
    renderEditor();

    expect(isChosen('heat')).toBe(false);

    // First press: chosen. The choice lands on the next render, the way it does
    // in the browser.
    press('heat');
    await waitFor(() => expect(isChosen('heat')).toBe(true));

    // Second press: back to nothing chosen, and the page is still.
    press('heat');
    fireEvent.pointerUp(window);
    await waitFor(() => expect(isChosen('heat')).toBe(false));
  });

  it('stays chosen when it was just picked up, ready to be dragged', async () => {
    renderEditor();

    press('heat');
    await waitFor(() => expect(isChosen('heat')).toBe(true));
    // Letting go of the press that chose it leaves it chosen.
    fireEvent.pointerUp(window);
    expect(isChosen('heat')).toBe(true);
  });

  it('moves a chosen block when the pointer crosses another one', async () => {
    vi.stubGlobal('requestAnimationFrame', (fn: () => void) => {
      fn();
      return 0;
    });
    vi.stubGlobal('cancelAnimationFrame', () => {});

    try {
      renderEditor();

      // Choose Heat map, then pick it up.
      press('heat');
      await waitFor(() => expect(isChosen('heat')).toBe(true));
      fireEvent.pointerUp(window);
      press('heat');

      // Carry it over Sports, then let go of it there.
      const over = document.querySelector('[data-widget="mix"]') as HTMLElement;
      document.elementFromPoint = vi.fn(() => over);
      fireEvent.pointerMove(window, { clientX: 10, clientY: 10 });
      fireEvent.pointerUp(window);

      // It took Sports' place, and stays chosen so it can be dragged on.
      await waitFor(() => expect(frames()[14]).toBe('heat'));
      expect(frames()[15]).toBe('mix');
      expect(isChosen('heat')).toBe(true);
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it('chooses only one block at a time', async () => {
    renderEditor();

    press('heat');
    press('mix');

    expect(chosenIds()).toEqual(['mix']);
  });

  it('puts the chosen block down when Escape is pressed', async () => {
    renderEditor();

    press('heat');
    expect(isChosen('heat')).toBe(true);

    fireEvent.keyDown(window, { key: 'Escape' });
    await waitFor(() => expect(chosenIds()).toEqual([]));
  });

  it('puts the chosen block down when the page itself is pressed', async () => {
    renderEditor();

    press('heat');
    expect(isChosen('heat')).toBe(true);

    // A press on empty page releases it; the next press starts from nothing.
    fireEvent.pointerDown(document.querySelector('.editor-surface') as HTMLElement, { button: 0 });
    await waitFor(() => expect(chosenIds()).toEqual([]));
  });

  it('does not let go while the editor bar is being used', async () => {
    renderEditor();

    press('heat');
    await waitFor(() => expect(isChosen('heat')).toBe(true));

    fireEvent.pointerDown(screen.getByRole('button', { name: 'Reset' }), { button: 0 });
    expect(isChosen('heat')).toBe(true);
  });

  it('lets a block go when it is taken off the page', async () => {
    renderEditor();

    press('heat');
    await userEvent.click(screen.getByRole('button', { name: 'Remove Heat map' }));

    await userEvent.click(screen.getByRole('button', { name: 'Add Heat map' }));
    // Back on the page, and not still chosen from before.
    expect(isChosen('heat')).toBe(false);
  });

  it('removes a block from the page and offers it back in the bar', async () => {
    renderEditor();

    await userEvent.click(screen.getByRole('button', { name: 'Remove Heat map' }));

    // Gone from the page, waiting in the bar.
    expect(frames()).not.toContain('heat');
    expect(screen.getByText('Not shown:')).toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: 'Add Heat map' }));
    expect(frames()).toContain('heat');
  });

  it('puts a restored block back where it belongs', async () => {
    renderEditor({ order: ALL.filter((id) => id !== 'mix') });

    await userEvent.click(screen.getByRole('button', { name: 'Add Sports' }));
    await userEvent.click(screen.getByRole('button', { name: 'Save layout' }));

    const order = mocks.saveDashboardAction.mock.calls[0][0].order as WidgetId[];
    // It comes back just before the zones, as it sits in the catalogue.
    expect(order.indexOf('mix')).toBe(order.indexOf('zones') - 1);
  });

  it('reorders by dragging a block onto the gap before another', () => {
    renderEditor();

    // There is a gap before every block, marked with what it sits before.
    const gap = document.querySelector('[data-drop-before="mix"]') as HTMLElement;
    expect(gap).not.toBeNull();

    const store: Record<string, string> = { 'text/widget': 'heat' };
    fireEvent.dragOver(gap);
    fireEvent.drop(gap, { dataTransfer: { getData: (type: string) => store[type] ?? '' } });

    // The dragged block moved up to just before the mix.
    expect(frames().indexOf('heat')).toBe(frames().indexOf('mix') - 1);
  });

  it('ignores a drop onto itself', () => {
    renderEditor();
    const gap = document.querySelector('[data-drop-before="mix"]') as HTMLElement;
    const before = frames();

    fireEvent.drop(gap, { dataTransfer: { getData: () => 'mix' } });

    expect(frames()).toEqual(before);
  });

  it('saves the order and the progress style together, then leaves editing', async () => {
    renderEditor({ progressStyle: 'ring' });

    await userEvent.click(screen.getByRole('button', { name: 'Bars' }));
    await userEvent.click(screen.getByRole('button', { name: 'Save layout' }));

    expect(mocks.saveDashboardAction).toHaveBeenCalledWith({ order: ALL, progressStyle: 'bar', sizes: {} });
    expect(mocks.push).toHaveBeenCalledWith('/plan');
  });

  it('saves a size the athlete picks', async () => {
    renderEditor();

    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Sports' }));
    await userEvent.click(screen.getByRole('button', { name: 'Half width' }));
    await userEvent.click(screen.getByRole('button', { name: 'Save layout' }));

    expect(mocks.saveDashboardAction).toHaveBeenCalledWith({
      order: ALL,
      progressStyle: 'ring',
      sizes: { mix: 'wide' }
    });
  });

  it('keeps the stored sizes when nothing is changed', async () => {
    renderEditor({ sizes: { mix: 'wide' } });

    await userEvent.click(screen.getByRole('button', { name: 'Save layout' }));

    expect(mocks.saveDashboardAction).toHaveBeenCalledWith({
      order: ALL,
      progressStyle: 'ring',
      sizes: { mix: 'wide' }
    });
  });

  it('counts a size change as an unsaved change', async () => {
    const confirm = vi.spyOn(window, 'confirm').mockReturnValue(false);
    renderEditor();

    await userEvent.click(screen.getByRole('button', { name: 'Change the size of Sports' }));
    await userEvent.click(screen.getByRole('button', { name: 'Half width' }));
    await userEvent.click(screen.getByRole('button', { name: 'Close' }));

    expect(confirm).toHaveBeenCalled();
    confirm.mockRestore();
  });

  it('shows a preview of the chosen style', async () => {
    renderEditor({ progressStyle: 'bar' });
    expect(screen.queryByRole('img')).toBeNull();

    await userEvent.click(screen.getByRole('button', { name: 'Rings' }));
    expect(screen.getByRole('img')).toBeInTheDocument();
  });

  it('puts everything back on reset', async () => {
    renderEditor({ order: ['board'] });

    // Only the board is on the page to begin with.
    expect(frames()).toEqual(['board']);
    expect(screen.getByText('Not shown:')).toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: 'Reset' }));

    expect(mocks.resetDashboardAction).toHaveBeenCalled();
    expect(screen.getByText('Saved')).toBeInTheDocument();
  });

  it('says why a save failed and stays put', async () => {
    mocks.saveDashboardAction.mockResolvedValue({ ok: false, error: 'That layout does not look right.' });
    renderEditor();

    await userEvent.click(screen.getByRole('button', { name: 'Save layout' }));

    expect(await screen.findByText('That layout does not look right.')).toBeInTheDocument();
    expect(mocks.push).not.toHaveBeenCalled();
  });

  it('asks before closing with unsaved changes', async () => {
    const confirm = vi.spyOn(window, 'confirm').mockReturnValue(false);
    renderEditor();

    await userEvent.click(screen.getByRole('button', { name: 'Remove Heat map' }));
    await userEvent.click(screen.getByRole('button', { name: 'Close' }));

    expect(confirm).toHaveBeenCalled();
    expect(mocks.push).not.toHaveBeenCalled();
    confirm.mockRestore();
  });

  it('closes without asking when nothing changed', async () => {
    const confirm = vi.spyOn(window, 'confirm');
    renderEditor();

    await userEvent.click(screen.getByRole('button', { name: 'Close' }));

    expect(confirm).not.toHaveBeenCalled();
    expect(mocks.push).toHaveBeenCalledWith('/plan');
    confirm.mockRestore();
  });
});


