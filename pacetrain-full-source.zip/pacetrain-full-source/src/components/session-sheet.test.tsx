﻿// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { SessionSheet } from '@/components/session-sheet';
import { initialSession } from '@/domain/plan';
import type { SessionInput } from '@/domain/types';

const mocks = vi.hoisted(() => ({
  saveSessionAction: vi.fn(),
  deleteSessionAction: vi.fn(),
  onClose: vi.fn(),
  onSaved: vi.fn()
}));

vi.mock('@/actions/sessions', () => ({
  saveSessionAction: mocks.saveSessionAction,
  deleteSessionAction: mocks.deleteSessionAction
}));

function renderSheet(
  initial: SessionInput & { id?: string; linkedActivityId?: string | null } = initialSession('2026-10-20', 'run')
) {
  return render(<SessionSheet initial={initial} onClose={mocks.onClose} onSaved={mocks.onSaved} />);
}

beforeEach(() => {
  for (const mock of Object.values(mocks)) mock.mockReset();
  mocks.saveSessionAction.mockResolvedValue({ ok: true, data: { id: 'session-1' } });
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe('SessionSheet', () => {
  it('shows the seven disciplines and switches mode', async () => {
    renderSheet();
    expect(screen.getByRole('button', { name: 'Orienteering' })).toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: 'MTB' }));
    expect(screen.getByRole('button', { name: 'MTB' })).toHaveAttribute('aria-pressed', 'true');

    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));
    expect(mocks.saveSessionAction.mock.calls[0][0]).toMatchObject({ mode: 'mtb' });
  });

  it('offers duration and distance together and saves both', async () => {
    renderSheet();
    expect(screen.getByText('Duration (min)')).toBeInTheDocument();
    expect(screen.getByText('Distance (km)')).toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));

    const saved = mocks.saveSessionAction.mock.calls[0][0];
    // 60′ at the fallback 5:30/km is 11 km, and both are stored.
    expect(saved.minutes).toBe(60);
    expect(saved.targetKm).toBe(11);
    expect(mocks.onSaved).toHaveBeenCalled();
  });

  it('keeps the minutes when only the distance changes', async () => {
    renderSheet();
    const field = screen.getByText('Distance (km)').closest('.field') as HTMLElement;

    await userEvent.click(within(field).getByRole('button', { name: /increase/i }));
    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));

    const saved = mocks.saveSessionAction.mock.calls[0][0];
    expect(saved.targetKm).toBe(12);
    expect(saved.minutes).toBe(60);
  });

  it('warns when the two numbers disagree with the usual pace', () => {
    renderSheet({ ...initialSession('2026-10-20', 'run'), minutes: 60, targetKm: 20 });

    const warning = screen.getByRole('status');
    expect(warning).toHaveTextContent(/disagree by 45%/);
    expect(warning).toHaveTextContent(/Both are saved as written/);
  });

  it('stays quiet when the pair is close to the usual pace', () => {
    renderSheet({ ...initialSession('2026-10-20', 'run'), minutes: 66, targetKm: 12 });
    expect(screen.queryByRole('status')).not.toBeInTheDocument();
    expect(screen.getByText(/5:30\/km implied/)).toBeInTheDocument();
  });

  it('previews both numbers for a session planned that way', () => {
    renderSheet({ ...initialSession('2026-10-20', 'trail'), targetKm: 16, minutes: 107 });
    expect(screen.getByText('16 km · 107′ @ Z2')).toBeInTheDocument();
  });

  it('shows kilometres for cycling too, since they are saved the same way', async () => {
    renderSheet();
    await userEvent.click(screen.getByRole('button', { name: 'Bike' }));

    expect(screen.getByText('Distance (km)')).toBeInTheDocument();
    // A bicycle at 24 km/h: 60′ is 24 km.
    expect(screen.getByDisplayValue('24')).toBeInTheDocument();
  });

  it('moves the session when the day changes', async () => {
    renderSheet({ ...initialSession('2026-10-20', 'run'), id: 'session-1' });
    const day = screen.getByLabelText('Day') as HTMLInputElement;
    expect(day.value).toBe('2026-10-20');

    // A date input only reports a whole value, so it is set rather than typed.
    fireEvent.change(day, { target: { value: '2026-10-23' } });
    expect(day.value).toBe('2026-10-23');

    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));
    expect(mocks.saveSessionAction.mock.calls[0][0]).toMatchObject({ id: 'session-1', date: '2026-10-23' });
  });

  it('keeps kilometres for intervals and drops them for strength', async () => {
    renderSheet();
    await userEvent.click(screen.getByRole('button', { name: 'Intervals' }));
    // An interval session is planned in kilometres too — 8×800 m is a distance.
    expect(screen.getByText('Work per rep')).toBeInTheDocument();

    cleanup();
    renderSheet(initialSession('2026-10-20', 'strength'));
    expect(screen.queryByText('Distance (km)')).not.toBeInTheDocument();
    expect(screen.getByText('Duration (min)')).toBeInTheDocument();
  });

  it('lets an interval session be planned before the reps are decided', async () => {
    renderSheet();
    await userEvent.click(screen.getByRole('button', { name: 'Intervals' }));

    // "Not chosen yet" hides the rep fields and keeps time, zone and distance.
    await userEvent.click(screen.getByLabelText(/not chosen yet/i));
    expect(screen.queryByText('Work per rep')).not.toBeInTheDocument();
    expect(screen.getByText('Duration (min)')).toBeInTheDocument();

    // The kilometres are typed by hand: the time alone must not invent one.
    const kmField = screen.getByText('Distance (km)').closest('.field') as HTMLElement;
    fireEvent.change(within(kmField).getByRole('spinbutton'), { target: { value: '12' } });

    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));
    const saved = mocks.saveSessionAction.mock.calls[0][0];
    expect(saved.kind).toBe('intervals');
    expect(saved.reps).toBeNull();
    expect(saved.workMin).toBeNull();
    expect(saved.targetKm).toBe(12);
    expect(saved.zone).toBe(2);
  });

  it('plans an interval set in kilometres', async () => {
    renderSheet({ ...initialSession('2026-10-20', 'run'), kind: 'intervals', reps: 8, workMin: 8 });
    // Three km switches exist now (rep, warm-up, cool-down), so this one is
    // picked out by its group.
    const unit = screen.getByRole('group', { name: 'Rep unit' });
    await userEvent.click(within(unit).getByRole('button', { name: 'km' }));

    const field = screen.getByText('Work per rep').closest('.field') as HTMLElement;
    const input = within(field).getByRole('spinbutton') as HTMLInputElement;
    fireEvent.change(input, { target: { value: '0.8' } });
    expect(input.value).toBe('0.8');

    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));
    const saved = mocks.saveSessionAction.mock.calls[0][0];
    expect(saved.targetReps).toBe(0.8);
    // 8 × 800 m at the working pace is a real work length, not 8 minutes of nothing.
    expect(saved.workMin).toBeGreaterThan(3);
    expect(saved.targetKm).toBeGreaterThan(6);
  });

  it('writes the warm-up in kilometres when asked', async () => {
    renderSheet({ ...initialSession('2026-10-20', 'run'), kind: 'intervals', reps: 4, workMin: 8 });

    // The default 15′ warm-up becomes 2.7 km at the fallback 5:30/km pace.
    const warmup = screen.getByRole('group', { name: 'Warm-up unit' });
    await userEvent.click(within(warmup).getByRole('button', { name: 'km' }));
    expect(screen.getByText('Warm-up (km)')).toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));
    const saved = mocks.saveSessionAction.mock.calls[0][0];
    expect(saved.warmupKm).toBeGreaterThan(2);
    expect(saved.warmupKm).toBeLessThan(3.5);
  });

  it('saves a typed warm-up distance', async () => {
    renderSheet({ ...initialSession('2026-10-20', 'run'), kind: 'intervals', reps: 4, workMin: 8 });

    const warmup = screen.getByRole('group', { name: 'Warm-up unit' });
    await userEvent.click(within(warmup).getByRole('button', { name: 'km' }));
    const field = screen.getByText('Warm-up (km)').closest('.field') as HTMLElement;
    fireEvent.change(within(field).getByRole('spinbutton'), { target: { value: '2' } });

    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));
    expect(mocks.saveSessionAction.mock.calls[0][0].warmupKm).toBe(2);
  });

  it('goes back to minutes and clears the distance', async () => {
    renderSheet({ ...initialSession('2026-10-20', 'run'), kind: 'intervals', reps: 4, workMin: 8, warmupKm: 2 });

    const warmup = screen.getByRole('group', { name: 'Warm-up unit' });
    await userEvent.click(within(warmup).getByRole('button', { name: 'Time' }));
    expect(screen.getByText('Warm-up (min)')).toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));
    expect(mocks.saveSessionAction.mock.calls[0][0].warmupKm).toBeNull();
  });

  it('plans a total distance on an interval set with reps', async () => {
    renderSheet({ ...initialSession('2026-10-20', 'run'), kind: 'intervals', reps: 6, workMin: 4, recoverMin: 2 });

    const field = screen.getByLabelText('Total distance (km)') as HTMLInputElement;
    // Empty means "whatever the plan adds up to", so the placeholder shows it.
    expect(field.value).toBe('');
    expect(field.placeholder).toMatch(/^\d+(\.\d)?$/);

    fireEvent.change(field, { target: { value: '14' } });
    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));

    const saved = mocks.saveSessionAction.mock.calls[0][0];
    expect(saved.targetKm).toBe(14);
    // The reps keep their own length; the total is separate.
    expect(saved.reps).toBe(6);
    expect(saved.workMin).toBe(4);
  });

  it('saves the estimate as the total when none was typed', async () => {
    renderSheet({ ...initialSession('2026-10-20', 'run'), kind: 'intervals', reps: 6, workMin: 4, recoverMin: 2 });

    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));

    const saved = mocks.saveSessionAction.mock.calls[0][0];
    expect(saved.targetKm).toBeGreaterThan(8);
    expect(saved.targetKm).toBeLessThan(20);
  });

  it('saves a session marked skipped, and lets go of the linked activity', async () => {
    renderSheet({ ...initialSession('2026-10-20', 'run'), id: 'session-1', linkedActivityId: 'act-9' });

    await userEvent.click(screen.getByRole('button', { name: 'Skipped' }));
    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));

    const saved = mocks.saveSessionAction.mock.calls[0][0];
    expect(saved.status).toBe('skipped');
    // A skipped session is not fulfilled by the activity it was linked to.
    expect(saved.linkedActivityId).toBeNull();
    // And the distance is a number or null, never undefined: the database layer
    // would silently drop an undefined column and keep the old value.
    expect(saved.targetKm === undefined).toBe(false);
  });

  it('keeps the link when the session is not skipped', async () => {
    renderSheet({ ...initialSession('2026-10-20', 'run'), id: 'session-1', linkedActivityId: 'act-9' });

    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));

    expect(mocks.saveSessionAction.mock.calls[0][0].linkedActivityId).toBe('act-9');
  });

  it('never sends an undefined distance for a strength session', async () => {
    renderSheet(initialSession('2026-10-20', 'strength'));

    await userEvent.click(screen.getByRole('button', { name: 'Skipped' }));
    await userEvent.click(screen.getByRole('button', { name: 'Save session' }));

    const saved = mocks.saveSessionAction.mock.calls[0][0];
    expect(saved.status).toBe('skipped');
    expect(saved.targetKm).toBeNull();
  });
});
