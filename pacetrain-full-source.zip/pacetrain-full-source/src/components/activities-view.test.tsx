// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ActivitiesView } from '@/components/activities-view';
import { updateActivityAction } from '@/actions/activities';
import type { Activity } from '@/domain/types';

vi.mock('next/link', () => ({
  default: ({ children, href, ...rest }: { children: React.ReactNode; href: string }) => (
    <a href={href} {...rest}>
      {children}
    </a>
  )
}));

vi.mock('next/navigation', () => ({ useRouter: () => ({ refresh: vi.fn(), push: vi.fn(), replace: vi.fn() }) }));

vi.mock('@/actions/activities', () => ({
  updateActivityAction: vi.fn(async () => ({ ok: true, data: { id: 'run-1' } })),
  deleteActivityAction: vi.fn(async () => ({ ok: true, data: undefined })),
  restoreActivityAction: vi.fn(async () => ({ ok: true, data: undefined }))
}));

const activities: Activity[] = [
  {
    id: 'run-1',
    externalId: 'i1',
    date: '2026-10-22',
    mode: 'run',
    name: 'Threshold 4×8′',
    durationSec: 3600,
    distanceM: 12_000,
    avgHr: 152,
    maxHr: 175,
    load: 92,
    source: 'intervals.icu',
    linkedSessionId: null
  },
  {
    id: 'trail-1',
    externalId: 'i2',
    date: '2026-10-20',
    mode: 'trail',
    name: 'Long trail run',
    durationSec: 5400,
    distanceM: 15_000,
    avgHr: 138,
    maxHr: 149,
    load: 74,
    source: 'intervals.icu',
    linkedSessionId: null
  },
  {
    id: 'bike-1',
    externalId: 'i3',
    date: '2026-10-19',
    mode: 'bike',
    name: 'Easy spin',
    durationSec: 3600,
    distanceM: 30_000,
    avgHr: 120,
    maxHr: 135,
    load: 40,
    source: 'intervals.icu',
    linkedSessionId: null
  }
];

afterEach(() => {
  cleanup();
});

describe('ActivitiesView', () => {
  it('shows the imported activities with running distance and no bike kilometres', () => {
    render(<ActivitiesView activities={activities} range="30d" rangeLabel="Last 30 days" total={3} />);

    expect(screen.getByText('Threshold 4×8′')).toBeInTheDocument();
    expect(screen.getByText('Easy spin')).toBeInTheDocument();

    // run 12 km + trail 15 km, the bike does not count as running.
    const running = screen.getByText('Running km').closest('.stat') as HTMLElement;
    expect(within(running).getByText('27.0')).toBeInTheDocument();
    expect(within(running).getByText(/2 sessions/)).toBeInTheDocument();

    const links = screen.getAllByRole('link', { name: /details/i });
    expect(links).toHaveLength(3);
    expect(links[0]).toHaveAttribute('href', '/activities/run-1');
    // The name is a link too, so the row opens from either place.
    expect(screen.getByRole('link', { name: 'Threshold 4×8′' })).toHaveAttribute('href', '/activities/run-1');
  });

  it('filters by discipline', async () => {
    render(<ActivitiesView activities={activities} range="30d" rangeLabel="Last 30 days" total={3} />);

    await userEvent.click(screen.getByRole('button', { name: 'TRL' }));

    expect(screen.getByText('Long trail run')).toBeInTheDocument();
    expect(screen.queryByText('Threshold 4×8′')).not.toBeInTheDocument();
    expect(screen.queryByText('Easy spin')).not.toBeInTheDocument();
  });

  it('filters by name', async () => {
    render(<ActivitiesView activities={activities} range="30d" rangeLabel="Last 30 days" total={3} />);

    await userEvent.type(screen.getByLabelText('Search activities'), 'threshold');

    expect(screen.getByText('Threshold 4×8′')).toBeInTheDocument();
    expect(screen.queryByText('Long trail run')).not.toBeInTheDocument();
  });

  it('says plainly when the filter matches nothing', async () => {
    render(<ActivitiesView activities={activities} range="30d" rangeLabel="Last 30 days" total={3} />);

    await userEvent.type(screen.getByLabelText('Search activities'), 'swim');

    expect(screen.getByText('Nothing matches that discipline or search.')).toBeInTheDocument();
  });

  it('offers the range chips and the settings path when nothing is imported', () => {
    render(<ActivitiesView activities={[]} range="30d" rangeLabel="Last 30 days" total={0} />);

    expect(screen.getByText('No activities imported yet.')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /open settings/i })).toHaveAttribute('href', '/settings');
  });

  it('opens the editor for an imported activity', async () => {
    render(<ActivitiesView activities={activities} range="30d" rangeLabel="Last 30 days" total={3} />);

    await userEvent.click(screen.getAllByRole('button', { name: 'Edit' })[0]);

    expect(screen.getByRole('dialog', { name: 'Activity' })).toBeInTheDocument();
    expect(screen.getByLabelText('Name')).toHaveValue('Threshold 4×8′');
  });

  it('opens the editor straight from the edit link', () => {
    render(<ActivitiesView activities={activities} range="30d" rangeLabel="Last 30 days" total={3} initialEditId="trail-1" />);

    expect(screen.getByLabelText('Name')).toHaveValue('Long trail run');
  });

  it('saves a correction to the local copy', async () => {
    render(<ActivitiesView activities={activities} range="30d" rangeLabel="Last 30 days" total={3} />);

    await userEvent.click(screen.getAllByRole('button', { name: 'Edit' })[0]);
    await userEvent.clear(screen.getByLabelText('Name'));
    await userEvent.type(screen.getByLabelText('Name'), 'Threshold 4x8 fixed');
    await userEvent.selectOptions(screen.getByLabelText('Discipline'), 'trail');
    await userEvent.click(screen.getByRole('button', { name: /Save changes/i }));

    expect(updateActivityAction).toHaveBeenCalledWith(
      expect.objectContaining({
        id: 'run-1',
        name: 'Threshold 4x8 fixed',
        mode: 'trail',
        durationSec: 3600,
        distanceM: 12_000
      })
    );
  });

  it('flags two imports that look like the same workout', () => {
    const doubled: Activity[] = [...activities, { ...activities[0], id: 'run-1b', name: 'Threshold 4x8 (again)' }];
    render(<ActivitiesView activities={doubled} range="30d" rangeLabel="Last 30 days" total={4} />);

    expect(screen.getAllByText('duplicate?')).toHaveLength(2);
  });

  it('offers this week, this month, rolling windows and this year', () => {
    render(<ActivitiesView activities={activities} range="30d" rangeLabel="Last 30 days" total={3} />);

    expect(screen.getByRole('link', { name: 'Week' })).toHaveAttribute('href', '/activities?range=week');
    expect(screen.getByRole('link', { name: 'Month' })).toHaveAttribute('href', '/activities?range=month');
    expect(screen.getByRole('link', { name: '90 days' })).toHaveAttribute('href', '/activities?range=90d');
    expect(screen.getByRole('link', { name: '365 days' })).toHaveAttribute('href', '/activities?range=365d');
    expect(screen.getByRole('link', { name: 'Year' })).toHaveAttribute('href', '/activities?range=year');
    expect(screen.getByRole('link', { name: '30 days' })).toHaveAttribute('aria-current', 'page');
  });

  it('points at the wider range when the window is empty but data exists', () => {
    render(<ActivitiesView activities={[]} range="week" rangeLabel="This week" total={29} />);

    expect(screen.getByText(/nothing in this week/i)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /show 90 days/i })).toHaveAttribute('href', '/activities?range=90d');
  });
});
