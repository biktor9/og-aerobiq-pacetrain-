import Link from 'next/link';
import { ACCESS_MESSAGE, PLANS, formatSek, perWeek, type Access } from '@/domain/billing';

/**
 * The prices, and how to buy: a mail to the developer. There is no checkout on
 * the site — no card fields, no payment provider — the period is switched on by
 * hand once the money has arrived.
 */

function mailtoFor(email: string, planName: string, price: number): string {
  const subject = `PaceTrain — ${planName} (${price} kr)`;
  const body = [
    'Hi!',
    '',
    `I would like the ${planName} for ${price} kr.`,
    'The email on my PaceTrain account is: ',
    '',
    'Thanks!'
  ].join('\n');
  return `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

export function PlanCards({
  access,
  trialUsed,
  contactEmail,
  compact = false
}: {
  access: Access;
  /** The 10 kr test period is once per account. */
  trialUsed: boolean;
  /** Where the "contact developer" link goes; empty hides the address. */
  contactEmail: string;
  compact?: boolean;
}) {
  return (
    <div className="stack" style={{ gap: 12 }}>
      {!compact ? <p className="billing-message">{ACCESS_MESSAGE}</p> : null}

      {contactEmail ? (
        <div className="alert">
          <strong>How to buy:</strong> email{' '}
          <a href={`mailto:${contactEmail}`}>{contactEmail}</a> and say which period you want. Access is switched on as
          soon as the payment lands — usually the same day.
        </div>
      ) : (
        <div className="alert alert-warn">
          <strong>How to buy:</strong> contact the developer and say which period you want. Payments are arranged
          directly, and access is switched on by hand.
        </div>
      )}

      <div className="plan-grid">
        {PLANS.map((plan) => {
          const isCurrent = access.active && access.plan === plan.id;
          const blocked = plan.trialOnly && (trialUsed || access.active);
          const label = blocked
            ? access.active
              ? 'Trial is for new members'
              : 'Trial already used'
            : 'Contact developer';
          const className = `btn${plan.id === 'year' ? ' btn-primary' : ''}`;

          return (
            <div key={plan.id} className={`plan-card${plan.id === 'year' ? ' is-best' : ''}${isCurrent ? ' is-current' : ''}`}>
              <div className="plan-head">
                <span className="plan-name">{plan.name}</span>
                {plan.id === 'year' ? <span className="badge badge-accent">best value</span> : null}
                {isCurrent ? <span className="badge badge-good">your plan</span> : null}
              </div>

              <div className="plan-price">
                {formatSek(plan.priceSek)}
                <span className="plan-per-week">≈{perWeek(plan)} kr/week</span>
              </div>

              <p className="small muted" style={{ margin: 0 }}>
                {plan.tagline}
              </p>

              <ul className="plan-perks">
                {plan.perks.map((perk) => (
                  <li key={perk}>{perk}</li>
                ))}
              </ul>

              {blocked ? (
                <button className="btn" type="button" disabled style={{ width: '100%' }}>
                  {label}
                </button>
              ) : contactEmail ? (
                <a className={className} href={mailtoFor(contactEmail, plan.name, plan.priceSek)} style={{ width: '100%' }}>
                  {label}
                </a>
              ) : (
                <span className={className} aria-disabled="true" style={{ width: '100%', opacity: 0.6 }}>
                  {label}
                </span>
              )}
            </div>
          );
        })}
      </div>

      <p className="small faint" style={{ margin: 0 }}>
        One-off payments, no auto-renew. Days add up when you renew early, and nothing is charged twice behind your
        back.{' '}
        {access.active ? (
          <Link href="/billing">See your periods →</Link>
        ) : null}
      </p>
    </div>
  );
}

