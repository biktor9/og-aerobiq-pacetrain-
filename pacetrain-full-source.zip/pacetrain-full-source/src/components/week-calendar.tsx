import Link from 'next/link';
import { dayColour, LEGEND } from '@/domain/calendar-colour';
import type { DayStatus, HeatLevel, WeekSummary } from '@/domain/week-summary';
import { fmtDuration } from '@/domain/week';

/**
 * Five weeks side by side: one cell per day, coloured by how the day went
 * against the plan — red for a skipped day, through yellow at half the plan,
 * green when it was followed, and blue for more than planned, blending in
 * between. Only settled days are judged: a day still to come stays blank, and
 * a day that is still going only turns red if the athlete marked it skipped.
 * A day with no training keeps a bare cell, and a planned day with nothing
 * imported keeps its dashed outline, so a gap is visible without opening the
 * week. The week after this one is always in the list, marked.
 */

const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const LEVELS: HeatLevel[] = [1, 2, 3, 4];

function dayTitle(day: DayStatus): string {
  const parts: string[] = [`${day.weekday} ${day.dayOfMonth}`];
  if (day.activities) {
    const distance = day.runningKm > 0 ? day.runningKm : day.km;
    parts.push(
      [
        `${day.activities} session${day.activities === 1 ? '' : 's'}`,
        distance > 0 ? `${distance.toFixed(1)} km` : '',
        fmtDuration(day.minutes)
      ]
        .filter(Boolean)
        .join(' · ')
    );
  } else {
    parts.push(day.isFuture ? 'still to come' : 'no training');
  }
  if (day.planned) parts.push(`${day.planned} planned · ${fmtDuration(day.plannedMinutes)}`);
  return parts.join(' · ');
}

export function WeekCalendar({
  weeks,
  selected,
  sickDays = [],
  nextWeek
}: {
  weeks: WeekSummary[];
  selected?: string;
  /** Illness dates, so a sick day shows in the calendar. */
  sickDays?: string[];
  /**
   * The key of next week's row. When it is not given, the week after the one
   * marked `isCurrentWeek` is used — so the badge cannot end up on last week.
   */
  nextWeek?: string;
}) {
  if (!weeks.length) return null;

  const sick = new Set(sickDays);
  const maxKm = Math.max(...weeks.map((week) => week.runningKm), 1);
  const totalKm = weeks.reduce((sum, week) => sum + week.runningKm, 0);
  const totalMinutes = weeks.reduce((sum, week) => sum + week.minutes, 0);
  const totalDays = weeks.reduce((sum, week) => sum + week.trainedDays, 0);
  const currentIndex = weeks.findIndex((week) => week.isCurrentWeek);
  const nextIndex = currentIndex >= 0 ? currentIndex + 1 : -1;
  const upcoming = nextWeek ?? (nextIndex < weeks.length ? weeks[nextIndex]?.key : undefined) ?? null;

  return (
    <div className="card">
      <div className="card-head">
        <h3>Last 3 weeks, this week and next</h3>
        <span className="small muted">
          {totalKm.toFixed(1)} km run · {fmtDuration(totalMinutes)} · {totalDays} days trained
        </span>
      </div>

      <div className="cal-scroll">
        <div className="cal">
          <div className="cal-head">
            <span className="cal-week-key">Week</span>
            {WEEKDAYS.map((label) => (
              <span key={label} className="cal-day-label" title={label}>
                {label.slice(0, 1)}
              </span>
            ))}
            <span className="cal-col">Volume</span>
            <span className="cal-col">Km</span>
            <span className="cal-col">Time</span>
            <span className="cal-col">Plan</span>
            <span className="cal-col cal-col-next">Plan km</span>
          </div>

          {weeks.map((week) => (
            <CalendarRow
              key={week.key}
              week={week}
              selected={week.key === selected}
              isNext={week.key === upcoming}
              maxKm={maxKm}
              sick={sick}
            />
          ))}
        </div>
      </div>

      <div className="cal-legend">
        <span className="faint">Against the plan</span>
        {LEGEND.map((stop) => (
          <span key={stop.label} className="cal-swatch" style={{ background: stop.color }} title={stop.label} />
        ))}
        <span className="faint">{LEGEND.map((stop) => stop.label).join(' · ')}</span>
        <span className="cal-swatch level-0" title="rest day" />
        <span className="faint">no plan</span>
        <span className="cal-swatch level-2" title="trained, nothing planned" />
        <span className="faint">training shade where there was no plan</span>
        <span className="cal-swatch is-planned" title="planned, nothing imported" />
        <span className="faint">planned, not done</span>
      </div>
    </div>
  );
}

function CalendarRow({
  week,
  selected,
  isNext,
  maxKm,
  sick
}: {
  week: WeekSummary;
  selected: boolean;
  isNext: boolean;
  maxKm: number;
  sick: Set<string>;
}) {
  return (
    <div className={['cal-row', selected ? 'is-selected' : '', isNext ? 'is-next' : ''].filter(Boolean).join(' ')}>
      <Link className="cal-week-key" href={`/plan?week=${week.key}`} title={week.label}>
        {week.key.slice(5)}
        {week.isCurrentWeek ? <span className="cal-now">now</span> : null}
        {isNext ? <span className="cal-upcoming">next</span> : null}
      </Link>

      {week.days.map((day) => {
        const verdict = dayColour({
          minutes: day.minutes,
          plannedMinutes: day.plannedMinutes,
          skipped: day.skipped,
          // A day that is still to come, or is still going on, is not judged:
          // the session it is waiting for may yet happen. Only a day that has
          // ended — or that the athlete has marked skipped — turns red.
          ended: !day.isFuture && !day.isToday
        });
        const className = [
          'cal-day',
          // A day with a plan is coloured by how it went; one without keeps
          // the plain training shade, since there is nothing to compare to.
          verdict.ratio !== null ? 'is-verdict' : `level-${day.level}`,
          // Nothing done and nothing planned to do yet: the cell is left bare
          // rather than wearing a shade that would read as "you missed this".
          day.minutes <= 0 && verdict.ratio === null ? 'is-blank' : '',
          day.isToday ? 'is-today' : '',
          day.isFuture ? 'is-future' : '',
          day.planned && !day.activities ? 'is-planned' : '',
          verdict.verdict === 'pending' ? 'is-pending' : '',
          sick.has(day.date) ? 'is-sick' : ''
        ]
          .filter(Boolean)
          .join(' ');
        const title = [dayTitle(day), verdict.ratio !== null ? verdict.label : '', sick.has(day.date) ? 'sick' : '']
          .filter(Boolean)
          .join(' · ');

        // A planned day is painted directly; the stylesheet cannot learn a
        // colour that depends on the numbers, so it comes through as a style.
        const paint = verdict.ratio !== null ? { background: verdict.color, borderColor: verdict.color } : undefined;

        // A day with training opens straight onto those activities.
        return day.activities > 0 ? (
          <Link
            key={day.date}
            href={`/activities?day=${day.date}`}
            className={className}
            style={paint}
            data-verdict={verdict.verdict}
            title={`${title} — open the activities`}
          >
            {day.dayOfMonth}
          </Link>
        ) : (
          <span key={day.date} className={className} style={paint} data-verdict={verdict.verdict} title={title}>
            {day.dayOfMonth}
          </span>
        );
      })}

      <span className="cal-col cal-bar">
        <span style={{ width: `${Math.round((week.runningKm / maxKm) * 100)}%` }} />
      </span>
      <span className="cal-col">{week.runningKm.toFixed(1)} km</span>
      <span className="cal-col">{fmtDuration(week.minutes)}</span>
      <span className="cal-col">
        {week.plannedSoFarMinutes ? (
          <span
            className={`badge ${week.donePlanPct >= 80 ? 'badge-good' : week.donePlanPct >= 50 ? '' : 'badge-warn'}`}
            title={`${fmtDuration(week.donePlanMinutes)} of ${fmtDuration(week.plannedSoFarMinutes)} of the plan due so far`}
          >
            {week.donePlanPct}%
          </span>
        ) : (
          <span className="faint">—</span>
        )}
      </span>
      <span className="cal-col cal-col-next" title={`${week.forecastMinutes}′ in the plan by Sunday`}>
        {week.plannedRunningKm ? `${week.plannedRunningKm.toFixed(1)} km` : <span className="faint">—</span>}
      </span>
    </div>
  );
}
