'use client';

import type { DetectionResult } from '@/domain/types';
import { fmtClock } from '@/domain/week';

export interface ChartSeries {
  time: number[];
  values: (number | null)[];
  unit: string;
  label: string;
}

const WIDTH = 840;
const HEIGHT = 260;
const PAD = { left: 52, right: 14, top: 14, bottom: 30 };

function nice(value: number): string {
  if (Math.abs(value) >= 100) return String(Math.round(value));
  if (Math.abs(value) >= 10) return value.toFixed(0);
  return value.toFixed(1);
}

export function StreamChart({ series, result }: { series: ChartSeries; result: DetectionResult }) {
  const { time, values, unit } = series;
  const innerW = WIDTH - PAD.left - PAD.right;
  const innerH = HEIGHT - PAD.top - PAD.bottom;

  const numeric = values.filter((value): value is number => value !== null && Number.isFinite(value));
  if (!time.length || !numeric.length) {
    return <div className="empty">No samples for this metric.</div>;
  }

  const rawMin = Math.min(...numeric);
  const rawMax = Math.max(...numeric);
  const pad = (rawMax - rawMin) * 0.08 || 1;
  const min = rawMin - pad;
  const max = rawMax + pad;
  const span = max - min || 1;
  const xMax = time[time.length - 1] || 1;
  const invert = unit === '/km';

  const x = (t: number) => PAD.left + (t / xMax) * innerW;
  const y = (value: number) =>
    invert
      ? PAD.top + ((value - min) / span) * innerH
      : PAD.top + (1 - (value - min) / span) * innerH;

  // Break the line where samples are missing instead of drawing across gaps.
  let path = '';
  let started = false;
  for (let i = 0; i < values.length; i++) {
    const value = values[i];
    if (value === null || !Number.isFinite(value)) {
      started = false;
      continue;
    }
    path += `${started ? 'L' : 'M'}${x(time[i]).toFixed(1)},${y(value).toFixed(1)}`;
    started = true;
  }

  const areaPath = `${path}L${x(time[time.length - 1]).toFixed(1)},${(PAD.top + innerH).toFixed(1)}L${x(time[0]).toFixed(1)},${(PAD.top + innerH).toFixed(1)}Z`;

  const gridValues = [min + span * 0.25, min + span * 0.5, min + span * 0.75];
  const xTicks = [0, 0.25, 0.5, 0.75, 1];

  return (
    <div className="chart-wrap">
      <svg
        className="chart-svg"
        viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
        role="img"
        aria-label={`${series.label} over time with detected intervals shaded`}
      >
        <rect x={0} y={0} width={WIDTH} height={HEIGHT} fill="transparent" />

        {result.work.map((segment, index) => (
          <rect
            key={`work-${index}`}
            x={x(segment.startSec)}
            y={PAD.top}
            width={Math.max(1, x(segment.endSec) - x(segment.startSec))}
            height={innerH}
            fill="var(--accent)"
            opacity={0.1}
          />
        ))}

        {gridValues.map((value) => (
          <g key={value}>
            <line
              x1={PAD.left}
              x2={WIDTH - PAD.right}
              y1={y(value)}
              y2={y(value)}
              stroke="var(--border)"
              strokeWidth={1}
            />
            <text x={PAD.left - 8} y={y(value) + 4} textAnchor="end" fontSize="10" fill="var(--faint)">
              {nice(value)}
            </text>
          </g>
        ))}

        <path d={areaPath} fill="var(--accent)" opacity={0.07} />
        <path d={path} fill="none" stroke="var(--accent)" strokeWidth={1.6} strokeLinejoin="round" />

        {result.threshold > 0 ? (
          <g>
            <line
              x1={PAD.left}
              x2={WIDTH - PAD.right}
              y1={y(result.threshold)}
              y2={y(result.threshold)}
              stroke="var(--bad)"
              strokeDasharray="5 4"
              strokeWidth={1.2}
            />
            <text x={WIDTH - PAD.right} y={y(result.threshold) - 5} textAnchor="end" fontSize="10" fill="var(--bad)">
              threshold {nice(result.threshold)} {unit}
            </text>
          </g>
        ) : null}

        {xTicks.map((fraction) => {
          const t = xMax * fraction;
          return (
            <text
              key={fraction}
              x={x(t)}
              y={HEIGHT - 8}
              textAnchor={fraction === 0 ? 'start' : fraction === 1 ? 'end' : 'middle'}
              fontSize="10"
              fill="var(--faint)"
            >
              {fmtClock(t)}
            </text>
          );
        })}

        <line x1={PAD.left} x2={WIDTH - PAD.right} y1={PAD.top + innerH} y2={PAD.top + innerH} stroke="var(--border)" />
      </svg>
    </div>
  );
}
