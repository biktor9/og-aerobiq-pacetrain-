'use client';

import { useEffect, useState } from 'react';
import { deleteActivityAction, updateActivityAction } from '@/actions/activities';
import { MODES, type Activity, type ModeId } from '@/domain/types';

/**
 * Fix an imported activity: the name, the day, the discipline, the numbers,
 * and how it felt. Imports come from a watch and are not always right, and the
 * same workout can arrive twice — this is where that gets corrected, without
 * touching intervals.icu itself.
 */

const FEEL_LABELS = ['Terrible', 'Poor', 'OK', 'Good', 'Great'];

interface Draft {
  name: string;
  date: string;
  mode: ModeId;
  minutes: string;
  km: string;
  avgHr: string;
  maxHr: string;
  load: string;
  rpe: string;
  feel: number | null;
  notes: string;
}

function numberOrNull(value: string): number | null {
  if (!value.trim()) return null;
  const parsed = Number(value.replace(',', '.'));
  return Number.isFinite(parsed) ? parsed : null;
}

function draftFor(activity: Activity): Draft {
  return {
    name: activity.name,
    date: activity.date,
    mode: activity.mode,
    minutes: activity.durationSec ? String(Math.round((activity.durationSec / 60) * 10) / 10) : '',
    km: activity.distanceM ? String(Math.round((activity.distanceM / 1000) * 100) / 100) : '',
    avgHr: activity.avgHr ? String(activity.avgHr) : '',
    maxHr: activity.maxHr ? String(activity.maxHr) : '',
    load: activity.load ? String(Math.round(activity.load)) : '',
    rpe: activity.rpe ? String(activity.rpe) : '',
    feel: activity.feel ?? null,
    notes: activity.notes ?? ''
  };
}

export function ActivitySheet({
  activity,
  duplicates = [],
  onClose,
  onSaved
}: {
  activity: Activity;
  /** Other activities that look like the same workout. */
  duplicates?: Activity[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [draft, setDraft] = useState<Draft>(() => draftFor(activity));
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const patch = (changes: Partial<Draft>) => setDraft((current) => ({ ...current, ...changes }));

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  async function save() {
    setBusy(true);
    setError('');
    const result = await updateActivityAction({
      id: activity.id,
      name: draft.name,
      date: draft.date,
      mode: draft.mode,
      durationSec: Math.round((numberOrNull(draft.minutes) ?? 0) * 60),
      distanceM: Math.round((numberOrNull(draft.km) ?? 0) * 1000),
      avgHr: numberOrNull(draft.avgHr),
      maxHr: numberOrNull(draft.maxHr),
      load: numberOrNull(draft.load),
      rpe: numberOrNull(draft.rpe),
      feel: draft.feel,
      notes: draft.notes
    });
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    onSaved();
  }

  async function remove() {
    if (!window.confirm('Remove this activity from PaceTrain? The import itself is untouched.')) return;
    setBusy(true);
    const result = await deleteActivityAction(activity.id);
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    onSaved();
  }

  return (
    <div className="sheet-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <aside className="sheet" role="dialog" aria-modal="true" aria-label="Activity">
        <div className="sheet-head">
          <div>
            <h2>Edit activity</h2>
            <p className="small muted">
              {activity.source === 'intervals.icu' ? 'Imported from intervals.icu' : activity.source} · changes stay on
              PaceTrain
            </p>
          </div>
          <button type="button" className="btn btn-ghost btn-icon" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>

        <div className="sheet-body">
          {duplicates.length ? (
            <div className="alert alert-warn">
              This looks like the same workout as{' '}
              {duplicates.map((item) => item.name || item.id).join(', ')}. If it was imported twice, delete this one.
            </div>
          ) : null}

          <div className="field-row">
            <div className="field">
              <label htmlFor="activity-name">Name</label>
              <input
                id="activity-name"
                className="input"
                value={draft.name}
                maxLength={80}
                onChange={(event) => patch({ name: event.target.value })}
              />
            </div>
            <div className="field">
              <label htmlFor="activity-date">Day</label>
              <input
                id="activity-date"
                className="input"
                type="date"
                value={draft.date}
                onChange={(event) => patch({ date: event.target.value })}
              />
            </div>
          </div>

          <div className="field-row">
            <div className="field">
              <label htmlFor="activity-mode">Discipline</label>
              <select
                id="activity-mode"
                className="select"
                value={draft.mode}
                onChange={(event) => patch({ mode: event.target.value as ModeId })}
              >
                {MODES.map((mode) => (
                  <option key={mode.id} value={mode.id}>
                    {mode.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="activity-minutes">Duration (min)</label>
              <input
                id="activity-minutes"
                className="input"
                type="number"
                min="0"
                step="0.5"
                value={draft.minutes}
                onChange={(event) => patch({ minutes: event.target.value })}
              />
            </div>
            <div className="field">
              <label htmlFor="activity-km">Distance (km)</label>
              <input
                id="activity-km"
                className="input"
                type="number"
                min="0"
                step="0.1"
                value={draft.km}
                onChange={(event) => patch({ km: event.target.value })}
              />
            </div>
          </div>

          <div className="field-row">
            <div className="field">
              <label htmlFor="activity-avg-hr">Avg HR</label>
              <input
                id="activity-avg-hr"
                className="input"
                type="number"
                min="30"
                max="260"
                value={draft.avgHr}
                onChange={(event) => patch({ avgHr: event.target.value })}
              />
            </div>
            <div className="field">
              <label htmlFor="activity-max-hr">Max HR</label>
              <input
                id="activity-max-hr"
                className="input"
                type="number"
                min="30"
                max="260"
                value={draft.maxHr}
                onChange={(event) => patch({ maxHr: event.target.value })}
              />
            </div>
            <div className="field">
              <label htmlFor="activity-load">Load</label>
              <input
                id="activity-load"
                className="input"
                type="number"
                min="0"
                max="2000"
                value={draft.load}
                onChange={(event) => patch({ load: event.target.value })}
              />
            </div>
            <div className="field">
              <label htmlFor="activity-rpe">RPE (1–10)</label>
              <select
                id="activity-rpe"
                className="select"
                value={draft.rpe}
                onChange={(event) => patch({ rpe: event.target.value })}
              >
                <option value="">—</option>
                {Array.from({ length: 10 }, (_, index) => index + 1).map((value) => (
                  <option key={value} value={value}>
                    {value}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="field">
            <label>Feel</label>
            <div className="segmented">
              {FEEL_LABELS.map((label, index) => (
                <button
                  key={label}
                  type="button"
                  aria-pressed={draft.feel === index + 1}
                  onClick={() => patch({ feel: draft.feel === index + 1 ? null : index + 1 })}
                  title={label}
                >
                  {index + 1}
                </button>
              ))}
            </div>
            <span className="field-hint">{draft.feel ? FEEL_LABELS[draft.feel - 1] : 'how it felt, optional'}</span>
          </div>

          <div className="field">
            <label htmlFor="activity-notes">Notes</label>
            <textarea
              id="activity-notes"
              className="textarea"
              value={draft.notes}
              maxLength={500}
              rows={3}
              placeholder="Felt strong on the hills, right calf tight afterwards."
              onChange={(event) => patch({ notes: event.target.value })}
            />
          </div>

          {error ? <div className="alert alert-error">{error}</div> : null}
        </div>

        <div className="sheet-foot">
          <button className="btn btn-primary" type="button" onClick={save} disabled={busy}>
            {busy ? 'Saving…' : 'Save changes'}
          </button>
          <button className="btn" type="button" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <div style={{ flex: 1 }} />
          <button className="btn btn-danger" type="button" onClick={remove} disabled={busy}>
            Delete
          </button>
        </div>
      </aside>
    </div>
  );
}
