'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { deleteSickNoteAction, saveSickNoteAction } from '@/actions/sick';
import { SEVERITY_LABELS, type SickNote } from '@/domain/recovery';
import { shortDate, parseISODate } from '@/domain/week';

/**
 * "I'm sick" is training data too. One row per period, symptoms in plain words
 * so the coach can plan around it instead of guessing why the week fell apart.
 */
export function SickPanel({ notes, todayISO }: { notes: SickNote[]; todayISO: string }) {
  const router = useRouter();
  const [dateFrom, setDateFrom] = useState(todayISO);
  const [dateTo, setDateTo] = useState(todayISO);
  const [symptoms, setSymptoms] = useState('');
  const [severity, setSeverity] = useState(2);
  const [detail, setDetail] = useState('');
  const [status, setStatus] = useState({ message: '', tone: 'good' as 'good' | 'bad' });
  const [busy, setBusy] = useState(false);

  async function save() {
    setBusy(true);
    const result = await saveSickNoteAction({
      dateFrom,
      dateTo,
      symptoms,
      severity,
      notes: detail
    });
    setBusy(false);
    if (!result.ok) {
      setStatus({ message: result.error, tone: 'bad' });
      return;
    }
    setSymptoms('');
    setDetail('');
    setStatus({ message: 'Saved. The coach will work around it.', tone: 'good' });
    router.refresh();
  }

  async function remove(id: string) {
    setBusy(true);
    await deleteSickNoteAction(id);
    setBusy(false);
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-head">
        <h3>I&apos;m sick</h3>
        <span className="small muted">logged so the plan and the coach know</span>
      </div>

      {notes.length ? (
        <ul className="sick-list">
          {notes.map((note) => (
            <li key={note.id}>
              <div>
                <strong>
                  {shortDate(parseISODate(note.dateFrom))}
                  {note.dateFrom !== note.dateTo ? ` → ${shortDate(parseISODate(note.dateTo))}` : ''}
                </strong>
                <span className="badge" style={{ marginLeft: 6 }}>
                  {SEVERITY_LABELS[note.severity - 1] ?? 'Rough'}
                </span>
                <div className="small muted">
                  {note.symptoms}
                  {note.notes ? ` · ${note.notes}` : ''}
                </div>
              </div>
              <button className="btn btn-sm btn-ghost" type="button" disabled={busy} onClick={() => remove(note.id ?? '')}>
                Delete
              </button>
            </li>
          ))}
        </ul>
      ) : null}

      <div className="field-row" style={{ marginTop: notes.length ? 12 : 0 }}>
        <div className="field">
          <label htmlFor="sick-from">From</label>
          <input
            id="sick-from"
            className="input"
            type="date"
            value={dateFrom}
            onChange={(event) => {
              setDateFrom(event.target.value);
              if (event.target.value > dateTo) setDateTo(event.target.value);
            }}
          />
        </div>
        <div className="field">
          <label htmlFor="sick-to">To</label>
          <input
            id="sick-to"
            className="input"
            type="date"
            value={dateTo}
            min={dateFrom}
            onChange={(event) => setDateTo(event.target.value)}
          />
        </div>
      </div>

      <div className="field">
        <label htmlFor="sick-symptoms">Symptoms</label>
        <input
          id="sick-symptoms"
          className="input"
          value={symptoms}
          maxLength={200}
          placeholder="Sore throat, fever 38.2, blocked nose"
          onChange={(event) => setSymptoms(event.target.value)}
        />
      </div>

      <div className="field">
        <label>How bad?</label>
        <div className="segmented">
          {SEVERITY_LABELS.map((label, index) => (
            <button
              key={label}
              type="button"
              aria-pressed={severity === index + 1}
              onClick={() => setSeverity(index + 1)}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="field">
        <label htmlFor="sick-notes">Anything else</label>
        <input
          id="sick-notes"
          className="input"
          value={detail}
          maxLength={300}
          placeholder="Stayed in bed, no appetite"
          onChange={(event) => setDetail(event.target.value)}
        />
      </div>

      <button className="btn btn-primary" type="button" disabled={busy || !symptoms.trim()} onClick={save}>
        {busy ? 'Saving…' : 'Save illness'}
      </button>

      {status.message ? (
        <div className={`alert alert-${status.tone}`} style={{ marginTop: 10 }}>
          {status.message}
        </div>
      ) : null}
    </div>
  );
}
