'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { importThisWeekAction, importTodayAction } from '@/actions/icu';

/**
 * Two small imports for the corner of the activities screen: today, or the
 * week so far. Both are idempotent, so pressing them twice costs nothing — the
 * second press simply finds nothing new.
 */

type Scope = 'day' | 'week';

export function ImportButtons() {
  const router = useRouter();
  const [busy, setBusy] = useState<Scope | null>(null);
  const [status, setStatus] = useState({ message: '', tone: 'good' as 'good' | 'bad' });

  async function run(scope: Scope) {
    setBusy(scope);
    setStatus({ message: '', tone: 'good' });
    const result = scope === 'day' ? await importTodayAction() : await importThisWeekAction();
    setBusy(null);

    if (!result.ok) {
      setStatus({ message: result.error, tone: 'bad' });
      return;
    }

    const { imported, scanned, unavailable, from, to } = result.data;
    const window = from === to ? 'today' : `${from} → ${to}`;
    const base = imported
      ? `${imported} new ${imported === 1 ? 'activity' : 'activities'} for ${window}.`
      : scanned
        ? `Nothing new — ${scanned} already imported for ${window}.`
        : `Nothing on intervals.icu for ${window}.`;
    // Strava activities reach intervals.icu but not its API, and a hidden run is
    // worth saying out loud rather than leaving a mystery gap in the week.
    const hidden = unavailable
      ? ` ${unavailable} Strava ${unavailable === 1 ? 'activity is' : 'activities are'} not available through the intervals.icu API, so ${unavailable === 1 ? 'it' : 'they'} cannot be imported.`
      : '';
    setStatus({ message: base + hidden, tone: imported || !unavailable ? 'good' : 'bad' });
    router.refresh();
  }

  return (
    <div className="stack" style={{ gap: 5, alignItems: 'flex-end' }}>
      <div className="row" style={{ gap: 6 }}>
        <button
          className="btn btn-sm"
          type="button"
          disabled={busy !== null}
          onClick={() => run('day')}
          title="Import today's activities from intervals.icu"
        >
          {busy === 'day' ? 'Importing…' : 'Import today'}
        </button>
        <button
          className="btn btn-sm btn-primary"
          type="button"
          disabled={busy !== null}
          onClick={() => run('week')}
          title="Import Monday to today from intervals.icu"
        >
          {busy === 'week' ? 'Importing…' : 'Import this week'}
        </button>
      </div>

      {status.message ? (
        <span
          className="small"
          role="status"
          style={{
            color: status.tone === 'bad' ? 'var(--bad)' : 'var(--muted)',
            maxWidth: 320,
            textAlign: 'right'
          }}
        >
          {status.message}
        </span>
      ) : null}

      <Link className="small faint" href="/settings">
        intervals.icu setup
      </Link>
    </div>
  );
}
