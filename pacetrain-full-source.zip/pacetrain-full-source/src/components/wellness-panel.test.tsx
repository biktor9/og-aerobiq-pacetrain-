// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { WellnessPanel } from '@/components/wellness-panel';
import { wellnessDays, wellnessSummary, type WellnessEntry } from '@/domain/wellness';
import { saveWellnessAction } from '@/actions/wellness';

vi.mock('next/navigation', () => ({ useRouter: () => ({ refresh: vi.fn() }) }));
vi.mock('@/actions/wellness', () => ({
  saveWellnessAction: vi.fn(async () => ({ ok: true, data: { date: '2026-10-24' } })),
  deleteWellnessAction: vi.fn(async () => ({ ok: true, data: undefined }))
}));

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

const TODAY = new Date(2026, 9, 24);
const TODAY_ISO = '2026-10-24';

const entries: WellnessEntry[] = [
  {
    date: '2026-10-22',
    sleepHours: 6.2,
    sleepQuality: 2,
    hrvMs: 48,
    restingHr: 54,
    weightKg: 71.4,
    soreness: 4,
    mood: 3,
    stress: 4,
    feeling: 'worse',
    notes: 'hectic week at work'
  },
  {
    date: '2026-10-23',
    sleepHours: 8.1,
    sleepQuality: 5,
    hrvMs: 66,
    restingHr: 48,
    weightKg: null,
    soreness: 1,
    mood: 4,
    stress: 2,
    feeling: 'better',
    notes: 'felt good'
  }
];

function panel() {
  const summary = wellnessSummary(entries, { today: TODAY });
  const days = wellnessDays(entries, { today: TODAY, days: 14 });
  return render(<WellnessPanel entries={entries} summary={summary} days={days} todayISO={TODAY_ISO} />);
}

describe('WellnessPanel', () => {
  it('shows the week in sleep, HRV and resting heart rate', () => {
    const { container } = panel();

    expect(screen.getByText('Morning check-in')).toBeInTheDocument();
    expect(screen.getByText('HRV')).toBeInTheDocument();
    expect(screen.getByText(/ms$/)).toBeInTheDocument();
    expect(container.querySelectorAll('.wellness-facts strong')).toHaveLength(3);
  });

  it('draws two weeks of days and fills the ones that were logged', () => {
    const { container } = panel();

    expect(container.querySelectorAll('.wellness-day')).toHaveLength(14);
    expect(container.querySelectorAll('.wellness-day.is-low')).toHaveLength(1);
    expect(container.querySelectorAll('.wellness-day.is-good')).toHaveLength(1);
  });

  it('loads a day back into the form when it is clicked', async () => {
    panel();
    const user = userEvent.setup();

    await user.click(screen.getByTitle('Thu 22 · 6.2h sleep'));
    expect((screen.getByLabelText('Sleep (hours)') as HTMLInputElement).value).toBe('6.2');
    expect((screen.getByLabelText('Day') as HTMLInputElement).value).toBe('2026-10-22');
    expect((screen.getByLabelText('Overnight HRV') as HTMLInputElement).value).toBe('48');
    expect((screen.getByLabelText('In your own words') as HTMLTextAreaElement).value).toBe('hectic week at work');
  });

  it('saves the day it is showing, with the note', async () => {
    panel();
    const user = userEvent.setup();

    await user.clear(screen.getByLabelText('Resting HR'));
    await user.type(screen.getByLabelText('Resting HR'), '47');
    await user.type(screen.getByLabelText('In your own words'), 'more tired than the numbers say');
    await user.click(screen.getByRole('button', { name: /Save day|Update day/ }));

    expect(saveWellnessAction).toHaveBeenCalledWith({
      date: TODAY_ISO,
      sleepHours: 7.5,
      sleepQuality: null,
      hrvMs: null,
      restingHr: 47,
      weightKg: null,
      soreness: null,
      mood: 3,
      stress: 3,
      feeling: null,
      notes: 'more tired than the numbers say'
    });
  });
});
