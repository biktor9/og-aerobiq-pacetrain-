// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ImportButtons } from '@/components/import-buttons';
import { importThisWeekAction, importTodayAction } from '@/actions/icu';

vi.mock('next/link', () => ({
  default: ({ children, href, ...rest }: { children: React.ReactNode; href: string }) => (
    <a href={href} {...rest}>
      {children}
    </a>
  )
}));
vi.mock('next/navigation', () => ({ useRouter: () => ({ refresh: vi.fn() }) }));
vi.mock('@/actions/icu', () => ({
  importTodayAction: vi.fn(),
  importThisWeekAction: vi.fn()
}));

const todayResult = {
  ok: true as const,
  data: { imported: 1, scanned: 1, unavailable: 0, from: '2026-10-24', to: '2026-10-24' }
};
const weekResult = {
  ok: true as const,
  data: { imported: 0, scanned: 3, unavailable: 0, from: '2026-10-19', to: '2026-10-24' }
};
const stravaOnlyResult = {
  ok: true as const,
  data: { imported: 0, scanned: 0, unavailable: 2, from: '2026-10-24', to: '2026-10-24' }
};

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

describe('ImportButtons', () => {
  it('has a button for today and one for this week', () => {
    render(<ImportButtons />);

    expect(screen.getByRole('button', { name: 'Import today' })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Import this week' })).toBeEnabled();
    expect(screen.getByRole('link', { name: /intervals.icu setup/i })).toHaveAttribute('href', '/settings');
  });

  it('imports the day and says what arrived', async () => {
    vi.mocked(importTodayAction).mockResolvedValue(todayResult);
    render(<ImportButtons />);

    await userEvent.click(screen.getByRole('button', { name: 'Import today' }));

    expect(importTodayAction).toHaveBeenCalledTimes(1);
    expect(await screen.findByRole('status')).toHaveTextContent('1 new activity for today.');
    expect(importThisWeekAction).not.toHaveBeenCalled();
  });

  it('imports the week and is honest when nothing is new', async () => {
    vi.mocked(importThisWeekAction).mockResolvedValue(weekResult);
    render(<ImportButtons />);

    await userEvent.click(screen.getByRole('button', { name: 'Import this week' }));

    expect(await screen.findByRole('status')).toHaveTextContent(
      'Nothing new — 3 already imported for 2026-10-19 → 2026-10-24.'
    );
  });

  it('explains an import where every activity was a Strava placeholder', async () => {
    vi.mocked(importTodayAction).mockResolvedValue(stravaOnlyResult);
    render(<ImportButtons />);

    await userEvent.click(screen.getByRole('button', { name: 'Import today' }));

    const status = await screen.findByRole('status');
    expect(status).toHaveTextContent('Nothing on intervals.icu for today.');
    expect(status).toHaveTextContent('2 Strava activities are not available through the intervals.icu API');
  });

  it('shows why an import failed', async () => {
    vi.mocked(importTodayAction).mockResolvedValue({ ok: false, error: 'Connect intervals.icu in Settings first.' });
    render(<ImportButtons />);

    await userEvent.click(screen.getByRole('button', { name: 'Import today' }));

    expect(await screen.findByRole('status')).toHaveTextContent('Connect intervals.icu in Settings first.');
  });
});
