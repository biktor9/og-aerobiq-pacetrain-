'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { IntervalChart, type ChartSegment } from '@/components/interval-chart';
import { IntervalTable } from '@/components/interval-table';
import { compareToIntent } from '@/domain/compare';
import { describeBlocks, parseIntervalText } from '@/domain/interval-text';
import type { IntervalReport } from '@/domain/interval-stats';
import { formatPace } from '@/domain/pace';
import { normalizeStructure } from '@/domain/plan';
import type { Activity, Block, DetectionResult } from '@/domain/types';
import { fmtClock, fmtKm } from '@/domain/week';

interface AnalyseResponse {
  result: DetectionResult;
  series: { time: number[]; values: (number | null)[]; unit: string; label: string };
  summary: string;
  report: IntervalReport;
  /** True when the intervals came from the watch's own laps. */
  fromLaps?: boolean;
  /** Every lap intervals.icu has, with what the detector made of it. */
  laps?: {
    index: number;
    kind: 'work' | 'recover';
    startSec: number;
    durationSec: number;
    avg: number;
    max: number;
    label: string;
  }[];
  error?: string;
}

/**
 * The analyser. Pick an activity and the detector finds the intervals; write the
 * session you meant to run in the same place and it is compared with what
 * happened. Typing is parsed locally on every keystroke, so the comparison
 * updates without a round trip; the AI parser is only asked once, on blur, when
 * the local one cannot find a duration.
 */
export function AnalysisView({
  activities,
  initialActivityId,
  aiConfigured = false
}: {
  activities: Activity[];
  initialActivityId: string | null;
  /** True when a DeepSeek key exists (shared or the athlete's own). */
  aiConfigured?: boolean;
}) {
  const [activityId, setActivityId] = useState(initialActivityId ?? activities[0]?.id ?? '');
  const [text, setText] = useState('');
  const [data, setData] = useState<AnalyseResponse | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [aiBlocks, setAiBlocks] = useState<Block[] | null>(null);
  const [aiNote, setAiNote] = useState('');
  const [aiError, setAiError] = useState('');
  const [preferAi, setPreferAi] = useState(false);
  const [reading, setReading] = useState(false);
  /** Which laps to analyse. Empty means every lap the watch recorded. */
  const [lapChoice, setLapChoice] = useState<number[] | null>(null);
  /** Set when the athlete asks for the stream to be read instead of the laps. */
  const [streamOnly, setStreamOnly] = useState(false);

  useEffect(() => {
    if (!activityId) return;
    const controller = new AbortController();

    setBusy(true);
    setError('');
    setData(null);

    (async () => {
      try {
        const body: Record<string, unknown> = { activityId };
        // A pick only travels with the request when the athlete made one.
        if (lapChoice) body.laps = lapChoice;
        if (streamOnly) body.ignoreLaps = true;
        const response = await fetch('/api/analysis', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
          signal: controller.signal
        });
        const payload = (await response.json().catch(() => null)) as AnalyseResponse | null;
        if (controller.signal.aborted) return;

        if (!response.ok || !payload?.result) {
          setError(payload?.error ?? 'The detector could not read this activity.');
          return;
        }
        setData(payload);
      } catch {
        if (!controller.signal.aborted) {
          setError('Could not run the detector. Check the connection and try again.');
        }
      } finally {
        if (!controller.signal.aborted) setBusy(false);
      }
    })();

    return () => controller.abort();
  }, [activityId, lapChoice, streamOnly]);

  /** A new activity starts from all of its laps again. */
  function chooseActivity(id: string) {
    setActivityId(id);
    setLapChoice(null);
    setStreamOnly(false);
  }

  const selected = activities.find((activity) => activity.id === activityId) ?? null;
  const parsed = useMemo(() => parseIntervalText(text), [text]);
  // The AI result wins only when it was asked for explicitly; otherwise the
  // deterministic parser is what the athlete sees.
  const blocks =
    preferAi && aiBlocks?.length ? aiBlocks : parsed.ok && parsed.blocks.length ? parsed.blocks : aiBlocks;

  const comparison = useMemo(
    () => (data && blocks ? compareToIntent(data.result, blocks) : null),
    [data, blocks]
  );

  /** Each work block in seconds, so the report can line rep against target. */
  const plannedWork = useMemo(
    () => (blocks ? blocks.filter((block) => block.kind === 'work').map((block) => block.minutes * 60) : null),
    [blocks]
  );

  const segments = useMemo<ChartSegment[]>(
    () =>
      data
        ? data.result.segments.map((segment) => ({
            startSec: segment.startSec,
            endSec: segment.endSec,
            kind: segment.kind
          }))
        : [],
    [data]
  );

  async function readWithAi(explicit: boolean) {
    const trimmed = text.trim();
    if (trimmed.length < 3) return;
    // On blur the AI is only a fallback for text the local parser could not
    // read. The button asks for it on purpose, whatever the local parse said.
    if (!explicit && parsed.ok) return;

    setReading(true);
    setAiError('');
    try {
      const response = await fetch('/api/intervals/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: trimmed })
      });
      const payload = (await response.json().catch(() => null)) as {
        source?: 'local' | 'ai';
        parsed?: { blocks: Block[] };
        error?: string;
        note?: string;
      } | null;

      if (!response.ok) {
        setAiError(payload?.error ?? `The AI parser could not answer (${response.status}).`);
        return;
      }

      const structure = payload?.parsed?.blocks ? normalizeStructure(payload.parsed.blocks) : null;
      if (!structure?.length) {
        setAiError(payload?.note ?? 'The AI could not find a session in that text.');
        return;
      }

      setAiBlocks(structure);
      setPreferAi(true);
      setAiNote(
        payload?.source === 'ai'
          ? `Read with AI · ${describeBlocks(structure)}`
          : (payload?.note ?? 'No AI key is configured, so the local parser read it.')
      );
    } catch {
      setAiError('Could not reach the parser. Check the connection and try again.');
    } finally {
      setReading(false);
    }
  }

  if (!activities.length) {
    return (
      <div className="empty">
        <p>No activities yet.</p>
        <p className="small" style={{ marginTop: 6 }}>
          Import from intervals.icu in <Link href="/settings">Settings</Link>, or load the sample week from the Plan tab
          to try the detector on demo data.
        </p>
      </div>
    );
  }

  const hint = !text.trim()
    ? 'Optional. Write the session in your own words — planned vs actual is computed as you type.'
    : parsed.ok
      ? `${describeBlocks(parsed.blocks)} · ${Math.round(parsed.totalMin)}′ planned`
      : (parsed.warnings[0] ?? 'No duration found yet.');
  // A phrase the parser skipped is worth saying even when the rest read fine.
  const skipped = parsed.ok && parsed.warnings.length ? parsed.warnings[0] : '';
  const totals = data?.report.totals ?? null;

  return (
    <div className="stack" style={{ gap: 16 }}>
      <div className="card">
        <div className="card-head">
          <h3>Activity</h3>
          {selected ? (
            <Link className="small" href={`/activities/${selected.id}`}>
              Splits and details →
            </Link>
          ) : null}
        </div>

        <div className="field-row">
          <div className="field">
            <label htmlFor="activity">Activity</label>
            <select
              id="activity"
              className="select"
              value={activityId}
              onChange={(event) => chooseActivity(event.target.value)}
            >
              {activities.map((activity) => (
                <option key={activity.id} value={activity.id}>
                  {activity.date} · {activity.name || 'Untitled'}
                  {activity.distanceM ? ` · ${fmtKm(activity.distanceM)}` : ''}
                </option>
              ))}
            </select>
            <span className="field-hint">
              {selected
                ? `${fmtClock(selected.durationSec)} · ${selected.distanceM ? fmtKm(selected.distanceM) : 'no distance'}`
                : ''}
            </span>
          </div>

          <div className="field">
            <label htmlFor="intent">Session as planned</label>
            <textarea
              id="intent"
              className="textarea"
              value={text}
              maxLength={600}
              placeholder="20′ warm-up, 6×800m @ 3:30/km, 90″ jog, 10′ down"
              onChange={(event) => {
                setText(event.target.value);
                setAiBlocks(null);
                setAiNote('');
                setAiError('');
                setPreferAi(false);
              }}
              onBlur={() => void readWithAi(false)}
            />
            <span className="field-hint">{hint}</span>
            {skipped ? (
              <span className="field-hint" style={{ color: 'var(--warn)' }}>
                {skipped}
              </span>
            ) : null}

            <div className="row-wrap" style={{ gap: 8, marginTop: 8 }}>
              <button
                className="btn btn-sm"
                type="button"
                disabled={reading || !text.trim() || !aiConfigured}
                onClick={() => void readWithAi(true)}
              >
                {reading ? 'Reading…' : 'Ask the AI to read it'}
              </button>
              <span className="field-hint" style={{ margin: 0 }}>
                {aiNote ||
                  (aiConfigured
                    ? 'For phrasing the local parser misses. The AI never overwrites what you type.'
                    : 'No AI key configured — add DEEPSEEK_API_KEY, or your own key in Settings.')}
              </span>
            </div>

            {aiError ? (
              <div className="alert alert-error" style={{ marginTop: 8 }}>
                {aiError}
              </div>
            ) : null}
          </div>
        </div>
      </div>


      {error ? (
        <div className="card">
          <div className="card-head">
            <h3>Detector</h3>
            <span className="badge badge-warn">no result</span>
          </div>
          <p className="small muted">{error}</p>
        </div>
      ) : null}

      {busy ? <div className="empty">Finding intervals in the stream…</div> : null}

      {data ? (
        <>
          {data.fromLaps && data.laps?.length ? (
            <div className="card">
              <div className="card-head">
                <h3>Laps from the watch</h3>
                <span className="small muted">
                  {data.laps.filter((lap) => lap.kind === 'work').length} of {data.laps.length} used as intervals
                </span>
              </div>
              <p className="small muted" style={{ marginBottom: 8 }}>
                intervals.icu already had these laps, so the analysis takes them as they are instead of guessing from
                the stream. Untick a lap to leave it out — a jog, a stop, a warm-up lap.
              </p>
              <div className="lap-list">
                {data.laps.map((lap) => (
                  <label key={lap.index} className={`lap-row ${lap.kind === 'work' ? 'is-work' : ''}`}>
                    <input
                      type="checkbox"
                      checked={lap.kind === 'work'}
                      onChange={() => {
                        const next = data.laps
                          ?.filter((item) => (item.index === lap.index ? item.kind !== 'work' : item.kind === 'work'))
                          .map((item) => item.index);
                        setLapChoice(next ?? null);
                      }}
                    />
                    <span className="lap-index">#{lap.index}</span>
                    <span className="lap-label">{lap.label}</span>
                    <span className="mono small">
                      {fmtClock(lap.durationSec)} ·{' '}
                      {data.series.unit === '/km' ? formatPace(lap.avg) : `${Math.round(lap.avg)} ${data.series.unit}`}
                    </span>
                    <span className={`badge ${lap.kind === 'work' ? 'badge-good' : ''}`}>
                      {lap.kind === 'work' ? 'rep' : 'easy'}
                    </span>
                  </label>
                ))}
              </div>
            </div>
          ) : null}

          <div className="card">
            <div className="card-head">
              <h3>Detected intervals</h3>
              <span className="small muted">
                {data.fromLaps ? 'from the watch’s laps' : 'found in the stream'} · {data.summary}
              </span>
            </div>
            <div className="row-wrap" style={{ gap: 8, marginTop: 6 }}>
              {data.fromLaps ? (
                <button className="btn btn-sm btn-ghost" type="button" onClick={() => setStreamOnly(true)}>
                  Read the stream instead
                </button>
              ) : streamOnly ? (
                <button className="btn btn-sm" type="button" onClick={() => setStreamOnly(false)}>
                  Use the watch’s laps again
                </button>
              ) : null}
              {lapChoice ? (
                <button className="btn btn-sm btn-ghost" type="button" onClick={() => setLapChoice(null)}>
                  Use every lap
                </button>
              ) : null}
            </div>

            <div className="stat-grid">
              <div className="stat">
                <div className="stat-label">Reps</div>
                <div className="stat-value">{data.result.reps}</div>
                <div className="stat-note">{data.result.reps === 1 ? 'effort found' : 'efforts found'}</div>
              </div>
              <div className="stat">
                <div className="stat-label">Work time</div>
                <div className="stat-value">{fmtClock(data.result.workTimeSec)}</div>
                <div className="stat-note">
                  {Math.round((data.result.workTimeSec / Math.max(1, data.result.durationSec)) * 100)}% of{' '}
                  {fmtClock(data.result.durationSec)}
                </div>
              </div>
              <div className="stat">
                <div className="stat-label">Avg rep</div>
                <div className="stat-value">{fmtClock(data.result.avgWorkSec)}</div>
                <div className="stat-note">
                  {totals?.paceSecPerKm ? `${formatPace(totals.paceSecPerKm)} average` : 'no pace measured'}
                </div>
              </div>
              <div className="stat">
                <div className="stat-label">Heart rate</div>
                <div className="stat-value">{totals?.avgHr ? `${totals.avgHr} bpm` : '—'}</div>
                <div className="stat-note">{totals?.maxHr ? `max ${totals.maxHr} bpm` : 'no heart rate recorded'}</div>
              </div>
              <div className="stat">
                <div className="stat-label">Climbing</div>
                <div className="stat-value">{totals && totals.gainM !== null ? `${totals.gainM} m` : '—'}</div>
                <div className="stat-note">{totals?.lossM ? `${totals.lossM} m down` : 'no altitude recorded'}</div>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-head">
              <h3>Intervals</h3>
              <span className="small muted">pace, heart rate and climbing for every rep</span>
            </div>
            <IntervalTable report={data.report} plannedSeconds={plannedWork} />
          </div>

          <div className="card">
            <div className="card-head">
              <h3>{data.series.label} over the session</h3>
              <span className="small muted">shaded = detected work · {data.series.unit}</span>
            </div>
            <IntervalChart
              time={data.series.time}
              values={data.series.values}
              unit={data.series.unit}
              segments={segments}
              invert={data.series.unit === '/km'}
              label={data.series.label}
            />
          </div>

          {comparison ? (
            <div className="card">
              <div className="card-head">
                <h3>Planned vs actual</h3>
                <span className={`badge ${comparison.onTarget ? 'badge-good' : 'badge-warn'}`}>
                  {comparison.onTarget ? 'on target' : 'off target'}
                </span>
              </div>
              <p className="small muted">{comparison.verdict}</p>
              <table className="seg-table">
                <thead>
                  <tr>
                    <th>Metric</th>
                    <th>Planned</th>
                    <th>Actual</th>
                    <th>Δ</th>
                  </tr>
                </thead>
                <tbody>
                  {comparison.rows.map((row) => (
                    <tr key={row.label}>
                      <td>{row.label}</td>
                      <td>{row.target}</td>
                      <td>{row.actual}</td>
                      <td>{row.delta}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : null}
        </>
      ) : null}
    </div>
  );
}

