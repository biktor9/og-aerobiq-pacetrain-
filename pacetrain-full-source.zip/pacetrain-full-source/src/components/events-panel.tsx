'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { deleteEventAction, saveEventAction } from '@/actions/events';
import { PRIORITY_LABELS, eventCountdown, type EventPriority, type RaceEvent } from '@/domain/events';
import { MODES, mode } from '@/domain/types';
import { fmtClock, parseISODate, shortDate } from '@/domain/week';

/**
 * Races and goals. One list, one countdown, and the one sentence of advice
 * that matters at this distance from the start line. intervals.icu has a whole
 * season planner; the useful version for one athlete is "what is next and what
 * should this block look like?".
 */

function parseTimeInput(value: string): number | null {
  const trimmed = value.trim();
  if (!trimmed) return null;
  const parts = trimmed.split(':').map((part) => Number(part));
  if (parts.some((part) => !Number.isFinite(part) || part < 0)) return null;
  if (parts.length === 3) return Math.round(parts[0] * 3600 + parts[1] * 60 + parts[2]);
  if (parts.length === 2) return Math.round(parts[0] * 60 + parts[1]);
  if (parts.length === 1) return Math.round(parts[0] * 60);
  return null;
}

const TONES: Record<string, string> = {
  good: 'badge-good',
  ok: '',
  warn: 'badge-warn',
  neutral: ''
};

interface Draft {
  name: string;
  date: string;
  mode: string;
  priority: EventPriority;
  distance: string;
  target: string;
  notes: string;
}

const EMPTY: Draft = { name: '', date: '', mode: 'run', priority: 'A', distance: '', target: '', notes: '' };

export function EventsPanel({ events, todayISO }: { events: RaceEvent[]; todayISO: string }) {
  const router = useRouter();
  const [draft, setDraft] = useState<Draft>({ ...EMPTY, date: todayISO });
  const [status, setStatus] = useState({ message: '', tone: 'good' as 'good' | 'bad' });
  const [busy, setBusy] = useState(false);

  const today = parseISODate(todayISO);
  const upcoming = events.filter((event) => event.date >= todayISO);
  const past = events.filter((event) => event.date < todayISO);
  const next = upcoming[0] ?? null;
  const nextCountdown = next ? eventCountdown(next, today) : null;

  const patch = (changes: Partial<Draft>) => setDraft((current) => ({ ...current, ...changes }));

  async function save() {
    setBusy(true);
    const result = await saveEventAction({
      name: draft.name,
      date: draft.date,
      mode: draft.mode,
      priority: draft.priority,
      distanceKm: draft.distance.trim() ? Number(draft.distance.replace(',', '.')) : null,
      targetTimeSec: parseTimeInput(draft.target),
      notes: draft.notes
    });
    setBusy(false);
    if (!result.ok) {
      setStatus({ message: result.error, tone: 'bad' });
      return;
    }
    setDraft({ ...EMPTY, date: todayISO });
    setStatus({ message: 'Race added.', tone: 'good' });
    router.refresh();
  }

  async function remove(id: string) {
    setBusy(true);
    const result = await deleteEventAction(id);
    setBusy(false);
    if (!result.ok) {
      setStatus({ message: result.error, tone: 'bad' });
      return;
    }
    setStatus({ message: 'Race removed.', tone: 'good' });
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-head">
        <h3>Races &amp; goals</h3>
        <span className="small muted">{upcoming.length} ahead</span>
      </div>

      {next && nextCountdown ? (
        <div className="next-race">
          <div>
            <div className="next-race-name">{next.name}</div>
            <div className="small muted">
              {shortDate(parseISODate(next.date))} · {mode(next.mode).label}
              {next.distanceKm ? ` · ${next.distanceKm} km` : ''}
              {next.targetTimeSec ? ` · target ${fmtClock(next.targetTimeSec)}` : ''}
            </div>
          </div>
          <div className="next-race-when">
            <span className={`badge ${TONES[nextCountdown.tone] ?? ''}`}>{nextCountdown.label}</span>
            <span className="small muted">{PRIORITY_LABELS[next.priority]}</span>
          </div>
        </div>
      ) : null}

      {nextCountdown ? <p className="small muted" style={{ marginTop: 8 }}>{nextCountdown.advice}</p> : null}

      {events.length ? (
        <ul className="event-list">
          {[...upcoming, ...past].map((event) => {
            const countdown = eventCountdown(event, today);
            return (
              <li key={event.id} className={event.date < todayISO ? 'is-past' : ''}>
                <span className="dot" style={{ background: mode(event.mode).color }} />
                <span className="event-name">
                  {event.name}
                  <span className="small faint"> {shortDate(parseISODate(event.date))}</span>
                </span>
                <span className={`badge ${TONES[countdown.tone] ?? ''}`}>{countdown.label}</span>
                <span className="badge">{PRIORITY_LABELS[event.priority]}</span>
                {event.distanceKm ? <span className="small muted">{event.distanceKm} km</span> : null}
                <button
                  className="btn btn-sm btn-ghost"
                  type="button"
                  disabled={busy}
                  onClick={() => remove(event.id)}
                  aria-label={`Delete ${event.name}`}
                >
                  ×
                </button>
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="small muted" style={{ marginTop: 10 }}>
          No races yet. Add the one you are training for and the plan gets a deadline.
        </p>
      )}

      {status.message ? (
        <div className={`alert alert-${status.tone}`} style={{ marginTop: 10 }}>
          {status.message}
        </div>
      ) : null}

      <div className="stack" style={{ gap: 10, marginTop: 12, borderTop: '1px solid var(--border)', paddingTop: 12 }}>
        <div className="field-row">
          <div className="field">
            <label htmlFor="event-name">Race</label>
            <input
              id="event-name"
              className="input"
              value={draft.name}
              maxLength={80}
              placeholder="Autumn half marathon"
              onChange={(event) => patch({ name: event.target.value })}
            />
          </div>
          <div className="field">
            <label htmlFor="event-date">Date</label>
            <input
              id="event-date"
              className="input"
              type="date"
              value={draft.date}
              onChange={(event) => patch({ date: event.target.value })}
            />
          </div>
          <div className="field">
            <label htmlFor="event-mode">Discipline</label>
            <select
              id="event-mode"
              className="select"
              value={draft.mode}
              onChange={(event) => patch({ mode: event.target.value })}
            >
              {MODES.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="field-row">
          <div className="field">
            <label htmlFor="event-distance">Distance (km)</label>
            <input
              id="event-distance"
              className="input"
              type="number"
              step="0.1"
              min="0"
              max="1000"
              placeholder="21.1"
              value={draft.distance}
              onChange={(event) => patch({ distance: event.target.value })}
            />
          </div>
          <div className="field">
            <label htmlFor="event-target">Target time</label>
            <input
              id="event-target"
              className="input"
              placeholder="1:30:00"
              value={draft.target}
              onChange={(event) => patch({ target: event.target.value })}
            />
          </div>
          <div className="field">
            <label>Priority</label>
            <div className="segmented">
              {(['A', 'B', 'C'] as EventPriority[]).map((priority) => (
                <button
                  key={priority}
                  type="button"
                  aria-pressed={draft.priority === priority}
                  onClick={() => patch({ priority })}
                  title={PRIORITY_LABELS[priority]}
                >
                  {priority}
                </button>
              ))}
            </div>
            <span className="field-hint">
              {draft.priority === 'A' ? 'The goal race' : draft.priority === 'B' ? 'A tune-up at effort' : 'A training race'}
            </span>
          </div>
        </div>

        <div className="field">
          <label htmlFor="event-notes">Notes</label>
          <input
            id="event-notes"
            className="input"
            value={draft.notes}
            maxLength={300}
            placeholder="Hilly course, start at 9:00, aim for even splits…"
            onChange={(event) => patch({ notes: event.target.value })}
          />
        </div>

        <button className="btn btn-primary" type="button" disabled={busy || !draft.name.trim()} onClick={save}>
          {busy ? 'Saving…' : 'Add race'}
        </button>
      </div>
    </div>
  );
}

