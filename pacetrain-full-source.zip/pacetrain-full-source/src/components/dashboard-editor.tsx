﻿'use client';

import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { resetDashboardAction, saveDashboardAction } from '@/actions/settings';
import { StyleSwitch, EditProvider, labelFor, type EditApi } from '@/components/widget-slot';
import {
  addWidget,
  hiddenWidgets,
  moveWidget,
  removeWidget,
  WIDGETS,
  type ProgressStyle,
  type Sizes,
  type WidgetId,
  type WidgetSize
} from '@/domain/dashboard';

/**
 * Editing the Plan page happens on the page itself. This component owns the
 * draft layout while editing, hands it to the blocks through `EditProvider`
 * (so they can be dragged and removed where they sit), and draws the bar along
 * the bottom that carries everything else: what is hidden, the Bars/Rings
 * switch, save, reset and close.
 */
export function DashboardEditor({
  order,
  progressStyle,
  sizes: initialSizes = {},
  children
}: {
  order: WidgetId[];
  progressStyle: ProgressStyle;
  sizes?: Sizes;
  children: React.ReactNode;
}) {
  const router = useRouter();
  const [current, setCurrent] = useState<WidgetId[]>(order);
  const [style, setStyle] = useState<ProgressStyle>(progressStyle);
  const [sizes, setSizes] = useState<Sizes>(initialSizes);
  const [selected, setSelected] = useState<WidgetId | null>(null);
  const [dragging, setDragging] = useState<{ id: WidgetId; again: boolean } | null>(null);
  /**
   * The order as it is right now, and where the block being dragged started.
   * Refs rather than state, because the release listener is re-attached every
   * time the block is dragged over a new one and must read the current order,
   * not the copy it closed over.
   */
  const currentRef = useRef(current);
  const dragStartIndex = useRef(-1);
  currentRef.current = current;
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);

  const dirty = useMemo(
    () =>
      style !== progressStyle ||
      current.join('|') !== order.join('|') ||
      JSON.stringify(sizes) !== JSON.stringify(initialSizes),
    [current, style, sizes, order, progressStyle, initialSizes]
  );

  // A block picked up by the pointer is released wherever the pointer goes, so
  // a drag that ends outside the page still finishes cleanly. A second press on
  // the chosen block that did not move it puts it down; a press that dragged it
  // somewhere leaves it chosen, so it can be dragged on.
  useEffect(() => {
    if (!dragging) return;
    const release = () => {
      const stayed = currentRef.current.indexOf(dragging.id) === dragStartIndex.current;
      if (dragging.again && stayed) setSelected(null);
      setDragging(null);
    };
    window.addEventListener('pointerup', release);
    window.addEventListener('pointercancel', release);
    return () => {
      window.removeEventListener('pointerup', release);
      window.removeEventListener('pointercancel', release);
    };
  }, [dragging]);

  /** Picks a block up, and remembers where it was picked up from. */
  const startDrag = useCallback(
    (drag: { id: WidgetId; again: boolean } | null) => {
      if (!drag) {
        setDragging(null);
        return;
      }
      dragStartIndex.current = currentRef.current.indexOf(drag.id);
      setDragging(drag);
    },
    []
  );

  /*
   * Escape puts the chosen block down from anywhere, including from inside a
   * block's own controls, which is where a press cannot reach. A press on the
   * page itself does the same; that half is handled on the frame below.
   */
  useEffect(() => {
    if (!selected) return;

    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setDragging(null);
        setSelected(null);
      }
    };

    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selected]);

  /** Presses a block: the first time chooses it, the second lets it go. */
  const choose = useCallback((id: WidgetId | null) => {
    setSelected((current) => (current === id ? null : id));
  }, []);

  // A reload or a closed tab with unsaved changes should not slip past silently.
  useEffect(() => {
    if (!dirty) return;
    const guard = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', guard);
    return () => window.removeEventListener('beforeunload', guard);
  }, [dirty]);

  const reorder = useCallback((from: WidgetId, to: WidgetId) => {
    setSaved(false);
    setCurrent((list) => {
      const fromIndex = list.indexOf(from);
      const toIndex = list.indexOf(to);
      if (fromIndex < 0 || toIndex < 0 || fromIndex === toIndex) return list;
      // Lift the block out, then drop it where the target sat, so it takes the
      // target's place exactly â€” including when the list also holds markers
      // that are not drawn.
      const next = [...list];
      next.splice(fromIndex, 1);
      next.splice(toIndex, 0, from);
      return next;
    });
  }, []);

  /** Sends a block to one end of the list. */
  const moveTo = useCallback((id: WidgetId, edge: 'top' | 'bottom') => {
    setSaved(false);
    setCurrent((list) => {
      if (!list.includes(id)) return list;
      const rest = list.filter((entry) => entry !== id);
      return edge === 'top' ? [id, ...rest] : [...rest, id];
    });
  }, []);

  const resize = useCallback((id: WidgetId, size: WidgetSize) => {
    setSaved(false);
    setSizes((current) => {
      const next = { ...current };
      // `small` is the natural size, so it is stored as "no override".
      if (size === 'small') delete next[id];
      else next[id] = size;
      return next;
    });
  }, []);

  async function save() {
    setBusy(true);
    setError('');
    const result = await saveDashboardAction({ order: current, progressStyle: style, sizes });
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setSaved(true);
    router.push('/plan');
    router.refresh();
  }

  async function reset() {
    setBusy(true);
    setError('');
    await resetDashboardAction();
    setBusy(false);
    setSaved(true);
    router.refresh();
  }

  function close() {
    if (dirty && !saved) {
      const leave = window.confirm('Close without saving your layout changes?');
      if (!leave) return;
    }
    // Put back what was stored, then leave edit mode.
    setCurrent(order);
    setStyle(progressStyle);
    setSizes(initialSizes);
    setSelected(null);
    setDragging(null);
    router.push('/plan');
  }

  const api: EditApi = {
    order: current,
    style,
    sizes,
    onReorder: reorder,
    onMoveTo: moveTo,
    onResize: resize,
    onRemove: (id) => {
      setSaved(false);
      // A block that is no longer on the page cannot stay chosen.
      setSelected((chosen) => (chosen === id ? null : chosen));
      setCurrent((list) => removeWidget(list, id));
    },
    onStyle: (next) => {
      setSaved(false);
      setStyle(next);
    },
    onSave: save,
    onReset: reset,
    onClose: close,
    dirty,
    busy,
    saved,
    error,
    selected,
    onSelect: choose,
    dragging,
    onDragStart: startDrag
  };

  const hidden = hiddenWidgets(current);

  // The "tile row" marker is not a block any more: the tiles themselves are
  // draggable. It stays in the list only so older layouts keep working.
  const addable = hidden.filter((widget) => widget.id !== 'overview');

  /*
   * The frame around the blocks. A press anywhere inside it is a press on the
   * page, not on a block, so the chosen block is let go — unless the press was
   * on the editing bar, which is used while arranging and must not release it.
   *
   * This is on the frame rather than on `window` because a release that finishes
   * a drag must never be read as a press on the page: putting a block down has
   * to stay a press of its own.
   */
  const letGoOffBlocks = (event: React.PointerEvent) => {
    if (!selected) return;
    const target = event.target as HTMLElement;
    if (target.closest('[data-widget]') || target.closest('.edit-bar')) return;
    setDragging(null);
    setSelected(null);
  };

  return (
    <EditProvider value={api}>
      <div className="editor-surface" onPointerDownCapture={letGoOffBlocks}>
        {children}
      </div>

      <div className="edit-bar" role="region" aria-label="Editing the page">
        <div className="edit-bar-inner">
          <div className="edit-bar-head">
            <strong>Editing this page</strong>
            <span className="small muted">
              {selected
                ? `moving â€œ${labelFor(selected)}â€ â€” drag it, or press it again to let go`
                : 'press a block to pick it up, then drag it. â¤¢ to resize, Ã— to remove'}
            </span>
          </div>

          {addable.length ? (
            <div className="edit-bar-row">
              <span className="small muted">Not shown:</span>
              <div className="chip-row">
                {addable.map((widget) => (
                  <button
                    key={widget.id}
                    className="chip chip-add"
                    type="button"
                    aria-label={`Add ${widget.label}`}
                    title={widget.hint}
                    onClick={() => {
                      setSaved(false);
                      setCurrent((list) => addWidget(list, widget.id));
                    }}
                  >
                    + {widget.label}
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          <div className="edit-bar-row">
            <span className="small muted">Percentages</span>
            <StyleSwitch style={style} onStyle={api.onStyle} />
            <div style={{ flex: 1 }} />
            {error ? <span className="small" style={{ color: 'var(--danger)' }}>{error}</span> : null}
            <button className="btn btn-sm btn-ghost" type="button" disabled={busy} onClick={api.onClose}>
              Close
            </button>
            <button className="btn btn-sm" type="button" disabled={busy} onClick={api.onReset}>
              Reset
            </button>
            <button className="btn btn-sm btn-primary" type="button" disabled={busy} onClick={api.onSave}>
              {busy ? 'Savingâ€¦' : saved ? 'Saved' : 'Save layout'}
            </button>
          </div>
        </div>
      </div>
    </EditProvider>
  );
}

/** Every widget id, for the editor's own bookkeeping. */
export const ALL_WIDGETS: WidgetId[] = WIDGETS.map((widget) => widget.id);

/** Exported for the tests, so they can exercise a single move. */
export { moveWidget };

