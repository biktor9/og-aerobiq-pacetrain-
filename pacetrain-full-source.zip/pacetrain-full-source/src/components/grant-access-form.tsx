'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { grantPlanAction } from '@/actions/billing';
import { PLANS, formatSek, type PlanId } from '@/domain/billing';

/**
 * Admin tool: switch a period on once the money has arrived (Swish, bank
 * transfer) or after a support chat. The amount is recorded so "paid so far"
 * stays honest.
 */
export function GrantAccessForm() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [plan, setPlan] = useState<PlanId>('quarter');
  const [amount, setAmount] = useState('');
  const [status, setStatus] = useState({ message: '', tone: 'good' as 'good' | 'bad' });
  const [busy, setBusy] = useState(false);

  const selected = PLANS.find((item) => item.id === plan) ?? PLANS[0];

  async function grant() {
    setBusy(true);
    const parsedAmount = amount.trim() ? Number(amount.replace(',', '.')) : null;
    const result = await grantPlanAction({
      email,
      plan,
      amountSek: parsedAmount !== null && Number.isFinite(parsedAmount) ? parsedAmount : null
    });
    setBusy(false);
    if (!result.ok) {
      setStatus({ message: result.error, tone: 'bad' });
      return;
    }
    setStatus({
      message: `Switched on ${selected.name} for ${email}${parsedAmount !== null ? ` · ${formatSek(parsedAmount)} recorded` : ''}.`,
      tone: 'good'
    });
    setEmail('');
    setAmount('');
    router.refresh();
  }

  return (
    <div className="stack" style={{ gap: 10 }}>
      <div className="field-row">
        <div className="field">
          <label htmlFor="grant-email">Athlete email</label>
          <input
            id="grant-email"
            className="input"
            type="email"
            value={email}
            placeholder="athlete@example.com"
            onChange={(event) => setEmail(event.target.value)}
          />
        </div>
        <div className="field">
          <label htmlFor="grant-plan">Period</label>
          <select id="grant-plan" className="select" value={plan} onChange={(event) => setPlan(event.target.value as PlanId)}>
            {PLANS.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name} · {formatSek(item.priceSek)}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="field">
        <label htmlFor="grant-amount">Amount received (kr)</label>
        <input
          id="grant-amount"
          className="input"
          type="number"
          min="0"
          step="1"
          value={amount}
          placeholder={String(selected.priceSek)}
          onChange={(event) => setAmount(event.target.value)}
        />
        <span className="field-hint">
          Leave empty to record the list price ({formatSek(selected.priceSek)}). Use 0 for a free grant.
        </span>
      </div>

      <button className="btn btn-sm" type="button" disabled={busy || !email.trim()} onClick={grant}>
        {busy ? 'Switching on…' : 'Grant access'}
      </button>
      {status.message ? <div className={`alert alert-${status.tone}`}>{status.message}</div> : null}
    </div>
  );
}

