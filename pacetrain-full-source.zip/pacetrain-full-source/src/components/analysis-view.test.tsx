﻿// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { AnalysisView } from '@/components/analysis-view';
import { buildIntervalReport } from '@/domain/interval-stats';
import { detectIntervals, normalizeDetectParams } from '@/domain/intervals';
import type { Activity } from '@/domain/types';
import { demoStream } from '@/lib/demo';

vi.mock('next/link', () => ({
  default: ({ children, href, ...rest }: { children: React.ReactNode; href: string }) => (
    <a href={href} {...rest}>
      {children}
    </a>
  )
}));

const activities: Activity[] = [
  {
    id: 'activity-threshold',
    externalId: 'demo-threshold',
    date: '2026-03-03',
    mode: 'run',
    name: 'Threshold 5Ã—8â€²',
    durationSec: 4320,
    distanceM: 13200,
    avgHr: 152,
    maxHr: 175,
    load: 92,
    source: 'demo',
    linkedSessionId: null
  },
  {
    id: 'activity-long',
    externalId: 'demo-long',
    date: '2026-03-01',
    mode: 'run',
    name: 'Long easy run',
    durationSec: 5400,
    distanceM: 15600,
    avgHr: 138,
    maxHr: 149,
    load: 74,
    source: 'demo',
    linkedSessionId: null
  }
];

function payload(seed = 'demo-threshold') {
  const workout = demoStream(seed);
  const result = detectIntervals(workout.time, workout.watts, normalizeDetectParams({ metric: 'power' }));
  return {
    result,
    series: { time: workout.time, values: workout.watts, unit: 'W', label: 'Power' },
    summary: 'Five efforts around 300 W, very even pacing.',
    report: buildIntervalReport(result.work, workout)
  };
}

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe('AnalysisView', () => {
  it('explains how to get data when nothing has been imported', () => {
    render(<AnalysisView activities={[]} initialActivityId={null} />);
    expect(screen.getByText('No activities yet.')).toBeInTheDocument();
  });

  it('lists the imported activities and preselects the first', () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, json: async () => payload() }));
    render(<AnalysisView activities={activities} initialActivityId={null} />);

    const picker = screen.getByLabelText('Activity') as HTMLSelectElement;
    expect(picker.value).toBe('activity-threshold');
    expect(screen.getByRole('option', { name: /Long easy run/ })).toBeInTheDocument();
  });

  it('reads the activity on its own and shows the intervals, stats and chart', async () => {
    const body = payload();
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, json: async () => body });
    vi.stubGlobal('fetch', fetchMock);

    render(<AnalysisView activities={activities} initialActivityId={null} />);

    expect(await screen.findByText(/Five efforts around 300 W, very even pacing/)).toBeInTheDocument();
    expect(screen.getByText('Reps')).toBeInTheDocument();
    expect(screen.getByText('efforts found')).toBeInTheDocument();
    expect(screen.getByRole('img', { name: /power over the session/i })).toBeInTheDocument();
    expect(screen.getByRole('table')).toBeInTheDocument();
    expect(screen.getByText('total')).toBeInTheDocument();

    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toBe('/api/analysis');
    expect(JSON.parse((init as RequestInit).body as string)).toEqual({ activityId: 'activity-threshold' });
  });

  it('compares a written session without asking the server again', async () => {
    const body = payload();
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, json: async () => body });
    vi.stubGlobal('fetch', fetchMock);

    render(<AnalysisView activities={activities} initialActivityId={null} />);
    await screen.findByText(/Five efforts around 300 W, very even pacing/);

    await userEvent.type(screen.getByLabelText('Session as planned'), "2x8' threshold");

    expect(await screen.findByText('Planned vs actual')).toBeInTheDocument();
    expect(screen.getAllByText(/planned$/).length).toBeGreaterThan(0);
    // One request for the activity; typing is parsed in the browser.
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('asks for the new activity when the picker changes', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce({ ok: true, json: async () => payload() })
      .mockResolvedValueOnce({ ok: true, json: async () => payload('demo-long') });
    vi.stubGlobal('fetch', fetchMock);

    render(<AnalysisView activities={activities} initialActivityId={null} />);
    await screen.findByText(/Five efforts around 300 W, very even pacing/);

    await userEvent.selectOptions(screen.getByLabelText('Activity'), 'activity-long');

    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(2));
    expect(JSON.parse((fetchMock.mock.calls[1][1] as RequestInit).body as string)).toEqual({
      activityId: 'activity-long'
    });
  });

  it('asks the AI to read a session and says which parser answered', async () => {
    const body = payload();
    const fetchMock = vi.fn().mockImplementation(async (url: string) => {
      if (url === '/api/intervals/parse') {
        return {
          ok: true,
          json: async () => ({ source: 'ai', parsed: { blocks: [{ kind: 'work', minutes: 12, zone: 4 }] } })
        };
      }
      return { ok: true, json: async () => body };
    });
    vi.stubGlobal('fetch', fetchMock);

    render(<AnalysisView activities={activities} initialActivityId={null} aiConfigured />);
    await screen.findByText(/Five efforts around 300 W, very even pacing/);

    await userEvent.type(screen.getByLabelText('Session as planned'), "1x12' threshold");
    await userEvent.click(screen.getByRole('button', { name: 'Ask the AI to read it' }));

    expect(await screen.findByText(/Read with AI/)).toBeInTheDocument();
    const call = fetchMock.mock.calls.find(([url]) => url === '/api/intervals/parse');
    expect(JSON.parse((call?.[1] as RequestInit).body as string)).toEqual({ text: "1x12' threshold" });
  });

  it('says why the AI could not read the session', async () => {
    const body = payload();
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation(async (url: string) => {
        if (url === '/api/intervals/parse') {
          return {
            ok: false,
            status: 402,
            json: async () => ({ error: 'Your plan has ended. Renew on the pricing page to keep training.' })
          };
        }
        return { ok: true, json: async () => body };
      })
    );

    render(<AnalysisView activities={activities} initialActivityId={null} aiConfigured />);
    await screen.findByText(/Five efforts around 300 W, very even pacing/);

    await userEvent.type(screen.getByLabelText('Session as planned'), "1x12' threshold");
    await userEvent.click(screen.getByRole('button', { name: 'Ask the AI to read it' }));

    expect(await screen.findByText(/Your plan has ended/)).toBeInTheDocument();
  });

  it('is honest when no AI key is configured', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, json: async () => payload() }));

    render(<AnalysisView activities={activities} initialActivityId={null} />);
    await screen.findByText(/Five efforts around 300 W, very even pacing/);

    expect(screen.getByText(/No AI key configured/)).toBeInTheDocument();
  });

  it('says so when the stream cannot be read', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: false,
        json: async () => ({ error: 'This activity has no time stream, so intervals cannot be detected.' })
      })
    );

    render(<AnalysisView activities={activities} initialActivityId={null} />);
    expect(
      await screen.findByText('This activity has no time stream, so intervals cannot be detected.')
    ).toBeInTheDocument();
    expect(screen.getByText('no result')).toBeInTheDocument();
  });
});

describe('AnalysisView with the watch’s laps', () => {
  function lapPayload() {
    const base = payload();
    return {
      ...base,
      fromLaps: true,
      laps: [
        { index: 1, kind: 'work' as const, startSec: 0, durationSec: 240, avg: 300, max: 300, label: '800m' },
        { index: 2, kind: 'recover' as const, startSec: 240, durationSec: 120, avg: 420, max: 420, label: '2:00' },
        { index: 3, kind: 'work' as const, startSec: 360, durationSec: 240, avg: 302, max: 302, label: '800m' }
      ]
    };
  }

  it('shows the laps it was given, and says it used them', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, json: async () => lapPayload() }));

    render(<AnalysisView activities={activities} initialActivityId={null} />);

    expect(await screen.findByText('Laps from the watch')).toBeInTheDocument();
    expect(screen.getByText(/from the watch’s laps/)).toBeInTheDocument();
    expect(screen.getByText('2 of 3 used as intervals')).toBeInTheDocument();
    expect(screen.getAllByRole('checkbox')).toHaveLength(3);
    expect(screen.getAllByText('800m')).toHaveLength(2);
  });

  it('leaves a lap out when it is unticked', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce({ ok: true, json: async () => lapPayload() })
      .mockResolvedValueOnce({ ok: true, json: async () => lapPayload() });
    vi.stubGlobal('fetch', fetchMock);

    render(<AnalysisView activities={activities} initialActivityId={null} />);
    await screen.findByText('Laps from the watch');

    // The first rep goes: the request carries only the laps still ticked.
    await userEvent.click(screen.getAllByRole('checkbox')[0]);

    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(2));
    expect(JSON.parse((fetchMock.mock.calls[1][1] as RequestInit).body as string)).toEqual({
      activityId: 'activity-threshold',
      laps: [3]
    });
  });

  it('can read the stream instead of the laps', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce({ ok: true, json: async () => lapPayload() })
      .mockResolvedValueOnce({ ok: true, json: async () => payload() });
    vi.stubGlobal('fetch', fetchMock);

    render(<AnalysisView activities={activities} initialActivityId={null} />);
    await screen.findByText('Laps from the watch');

    await userEvent.click(screen.getByRole('button', { name: 'Read the stream instead' }));

    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(2));
    expect(JSON.parse((fetchMock.mock.calls[1][1] as RequestInit).body as string)).toEqual({
      activityId: 'activity-threshold',
      ignoreLaps: true
    });
  });
});

