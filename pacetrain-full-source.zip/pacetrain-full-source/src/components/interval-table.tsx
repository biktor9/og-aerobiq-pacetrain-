'use client';

import { formatSpan, type IntervalReport } from '@/domain/interval-stats';
import { formatPace } from '@/domain/pace';
import { fmtClock } from '@/domain/week';

/**
 * One line per work interval: how long it lasted, how far it went, how fast it
 * was, what the heart did and how much it climbed. The deltas are against the
 * other reps of the same length — the comparison that actually matters.
 */

function km(meters: number | null): string {
  return meters === null ? '—' : `${(meters / 1000).toFixed(2)} km`;
}

function climb(gainM: number | null, lossM: number | null): string {
  const parts: string[] = [];
  if (gainM) parts.push(`↑${gainM}`);
  if (lossM) parts.push(`↓${lossM}`);
  return parts.length ? `${parts.join(' ')} m` : gainM === null && lossM === null ? '—' : '0 m';
}

function signedPace(seconds: number): string {
  const rounded = Math.round(seconds);
  if (!rounded) return '0″';
  const magnitude = Math.abs(rounded);
  return `${rounded > 0 ? '+' : '−'}${magnitude >= 60 ? fmtClock(magnitude) : `${magnitude}″`}`;
}

export function IntervalTable({
  report,
  plannedSeconds
}: {
  report: IntervalReport;
  /**
   * Work blocks from the session the athlete described, in seconds, in order.
   * When present every rep gets its own target and the difference to it.
   */
  plannedSeconds?: number[] | null;
}) {
  if (!report.rows.length) {
    return <div className="empty">No work intervals were found in this activity.</div>;
  }

  const totals = report.totals;
  const hasPlan = Boolean(plannedSeconds?.length);
  const plannedTotal = hasPlan ? (plannedSeconds ?? []).reduce((sum, value) => sum + value, 0) : 0;
  const totalDelta = hasPlan ? (
    <span className="badge">{signedPace(totals.timeSec - plannedTotal)}</span>
  ) : null;

  return (
    <div className="stack" style={{ gap: 10 }}>
      <div className="row-wrap" style={{ gap: 6 }}>
        {report.groups.map((group, index) => (
          <span key={`${group.label}-${index}`} className="badge">
            {group.count} × {group.label}
            {group.avgPaceSecPerKm ? ` · ${formatPace(group.avgPaceSecPerKm)}` : ''}
          </span>
        ))}
        <span className="badge badge-accent">work {formatSpan(totals.timeSec)}</span>
      </div>

      <div className="scroll-y">
        <table className="seg-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Set</th>
              <th>Time</th>
              {hasPlan ? <th>Plan</th> : null}
              {hasPlan ? <th>Δ plan</th> : null}
              <th>Distance</th>
              <th>Pace</th>
              <th>Avg HR</th>
              <th>Max HR</th>
              <th>Climb</th>
              <th>vs set</th>
            </tr>
          </thead>
          <tbody>
            {report.rows.map((row) => {
              const plan = plannedSeconds?.[row.index - 1];
              return (
                <tr key={row.index}>
                  <td>{row.index}</td>
                  <td>
                    {row.sameLengthCount > 1 ? (
                      <span className="badge">{row.sameLengthLabel}</span>
                    ) : (
                      <span className="faint">—</span>
                    )}
                  </td>
                  <td className="mono">{fmtClock(row.durationSec)}</td>
                  {hasPlan ? (
                    <td className="mono">
                      {plan === undefined ? <span className="faint">—</span> : fmtClock(plan)}
                    </td>
                  ) : null}
                  {hasPlan ? (
                    <td>
                      {plan === undefined ? (
                        <span className="faint">—</span>
                      ) : (
                        <span className="badge">{signedPace(row.durationSec - plan)}</span>
                      )}
                    </td>
                  ) : null}
                  <td>{km(row.distanceM)}</td>
                <td>{row.paceSecPerKm ? formatPace(row.paceSecPerKm) : '—'}</td>
                <td>{row.avgHr ?? '—'}</td>
                <td>{row.maxHr ?? '—'}</td>
                <td>{climb(row.gainM, row.lossM)}</td>
                <td>
                  {row.deltaVsSameLengthPaceSec === null || row.sameLengthCount < 2 ? (
                    <span className="faint">—</span>
                  ) : (
                    <span
                      className={`badge ${row.deltaVsSameLengthPaceSec <= 0 ? 'badge-good' : 'badge-warn'}`}
                    >
                      {signedPace(row.deltaVsSameLengthPaceSec)}
                    </span>
                  )}
                </td>
              </tr>
              );
            })}
          </tbody>
          <tfoot>
            <tr>
              <td />
              <td className="small muted">total</td>
              <td className="mono">{fmtClock(totals.timeSec)}</td>
              {hasPlan ? <td className="mono">{fmtClock(plannedTotal)}</td> : null}
              {hasPlan ? <td>{totalDelta}</td> : null}
              <td>{km(totals.distanceM)}</td>
              <td>{totals.paceSecPerKm ? formatPace(totals.paceSecPerKm) : '—'}</td>
              <td>{totals.avgHr ?? '—'}</td>
              <td>{totals.maxHr ?? '—'}</td>
              <td>{climb(totals.gainM, totals.lossM)}</td>
              <td />
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}
