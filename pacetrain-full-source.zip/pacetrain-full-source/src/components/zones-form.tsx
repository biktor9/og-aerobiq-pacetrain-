'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { saveZonesAction } from '@/actions/settings';
import { zoneLabels, type ZoneBounds } from '@/domain/hr-zones';
import { MODES, type ModeId, zone } from '@/domain/types';

/**
 * The athlete's own heart-rate zones.
 *
 * Typing the beats where each zone ends replaces the app's guess of "a share of
 * maximum heart rate": from then on every imported session is placed against
 * these numbers. The sport tick-boxes decide which disciplines count towards the
 * weekly zone bar — a strength session's high heart rate is not aerobic work, so
 * leaving it out is often what makes the bar mean something.
 */
export function ZonesForm({
  bounds,
  maxHr,
  modes,
  sports
}: {
  bounds: ZoneBounds;
  /** The stored maximum, or null when the activities decide it. */
  maxHr: number | null;
  /** The sports counted, or null for all of them. */
  modes: ModeId[] | null;
  /** The sports that actually have a heart rate in the imported activities. */
  sports: { mode: ModeId; activities: number; minutes: number }[];
}) {
  const router = useRouter();
  const [values, setValues] = useState<string[]>(bounds.map((value) => String(value)));
  const [maxDraft, setMaxDraft] = useState(maxHr ? String(maxHr) : '');
  const [chosen, setChosen] = useState<ModeId[]>(modes ?? []);
  const [status, setStatus] = useState({ message: '', tone: 'good' as 'good' | 'bad' });
  const [busy, setBusy] = useState(false);

  const numbers = values.map((value) => Number(value) || 0) as ZoneBounds;
  const valid = numbers.every((value, index) => value > 0 && (index === 0 || value > numbers[index - 1]));
  const preview = zoneLabels(valid ? numbers : bounds);

  const toggleSport = (mode: ModeId) => {
    // The chips may only show the sports with a heart rate, but the choice is
    // about every sport: unticking one means "all the others", including the
    // sports not on screen.
    const all = MODES.map((entry) => entry.id);
    setChosen((current) => {
      const from = current.length ? current : all;
      const next = from.includes(mode)
        ? from.filter((id) => id !== mode)
        : all.filter((id) => from.includes(id) || id === mode);
      // Every sport counted is stored as "no choice", never as a list of seven.
      return next.length === all.length ? [] : next;
    });
  };

  async function save() {
    setBusy(true);
    setStatus({ message: '', tone: 'good' });
    const result = await saveZonesAction({
      bounds: numbers,
      maxHr: maxDraft.trim() ? Number(maxDraft) : null,
      // Every sport ticked is stored as "all of them", so a new sport counts too.
      modes: chosen.length === MODES.length ? [] : chosen
    });
    setBusy(false);
    if (!result.ok) {
      setStatus({ message: result.error, tone: 'bad' });
      return;
    }
    setStatus({ message: 'Zones saved — the plan page uses them from now on.', tone: 'good' });
    router.refresh();
  }

  return (
    <div className="stack" style={{ gap: 12 }}>
      <p className="small muted" style={{ margin: 0 }}>
        Where each zone ends, in bpm. Z5 is everything above the last number. Leave these alone and the app uses fixed
        shares of your maximum heart rate instead.
      </p>

      <div className="field-row" style={{ alignItems: 'flex-start' }}>
        {[1, 2, 3, 4].map((id) => (
          <div className="field" key={id}>
            <label htmlFor={`zone-${id}`}>{zone(id).label} ends at</label>
            <input
              id={`zone-${id}`}
              className="input"
              type="number"
              min={60}
              max={230}
              value={values[id - 1]}
              onChange={(event) =>
                setValues((current) => current.map((value, index) => (index === id - 1 ? event.target.value : value)))
              }
            />
            <span className="field-hint">{zone(id).name}</span>
          </div>
        ))}
        <div className="field">
          <label htmlFor="zone-max">Max HR</label>
          <input
            id="zone-max"
            className="input"
            type="number"
            min={120}
            max={230}
            placeholder="from activities"
            value={maxDraft}
            onChange={(event) => setMaxDraft(event.target.value)}
          />
          <span className="field-hint">optional</span>
        </div>
      </div>

      <div className="zone-legend">
        {preview.map((entry) => (
          <span key={entry.id} className="row" style={{ gap: 5 }}>
            <span className="dot" style={{ background: zone(entry.id).color }} />
            {entry.label} · {entry.range}
          </span>
        ))}
      </div>

      <div className="field">
        <label>Sports counted towards the week&apos;s zones</label>
        <div className="row-wrap" style={{ gap: 6 }}>
          {(sports.length ? sports : MODES.map((mode) => ({ mode: mode.id, activities: 0, minutes: 0 }))).map(
            (sport) => {
              const info = MODES.find((mode) => mode.id === sport.mode);
              if (!info) return null;
              // Nothing ticked means "all sports", so show them all as on.
              const active = chosen.length === 0 || chosen.includes(sport.mode);
              return (
                <button
                  key={sport.mode}
                  type="button"
                  className="mode-chip"
                  aria-pressed={active}
                  onClick={() => toggleSport(sport.mode)}
                  style={active ? { borderColor: info.color, color: info.color } : undefined}
                >
                  <span className="mode-swatch" style={{ background: info.color }} />
                  {info.label}
                  {sport.activities ? <span className="faint"> · {sport.minutes}′</span> : null}
                </button>
              );
            }
          )}
        </div>
        <span className="field-hint">
          {chosen.length === 0
            ? 'every sport counts — untick one to leave it out'
            : `${chosen.length} sport${chosen.length === 1 ? '' : 's'} counted; tick all to count every sport`}
        </span>
      </div>

      <div className="row-wrap" style={{ gap: 8 }}>
        <button className="btn btn-primary" type="button" disabled={busy || !valid} onClick={save}>
          {busy ? 'Saving…' : 'Save zones'}
        </button>
        {!valid ? (
          <span className="small" style={{ color: 'var(--bad)' }}>
            each zone must end above the previous one
          </span>
        ) : null}
        {status.message ? (
          <span className="small" style={{ color: status.tone === 'bad' ? 'var(--bad)' : 'var(--good)' }}>
            {status.message}
          </span>
        ) : null}
      </div>
    </div>
  );
}
