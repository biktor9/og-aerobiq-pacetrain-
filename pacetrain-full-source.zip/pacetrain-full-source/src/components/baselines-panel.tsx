'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { saveBaselinesAction } from '@/actions/wellness';
import { BASELINE_FIELDS, type BaselineView } from '@/domain/baselines';

/**
 * The numbers the recovery score measures each morning against. Left empty,
 * every one of them is the rolling 14-day average of what the athlete logged;
 * typed in, it is the athlete's own word instead. HRV, resting heart rate and
 * sleep are here, and so is the maximum heart rate that the zone bar needs.
 *
 * Clearing a field brings the average back — nothing is lost by typing a number.
 */
export function BaselinesPanel({
  baselines,
  maxHr,
  observedMaxHr
}: {
  baselines: BaselineView[];
  /** The max heart rate stored, or null when the activities decide it. */
  maxHr: number | null;
  /** What the activities say, used as a placeholder and as the default. */
  observedMaxHr: number;
}) {
  const router = useRouter();
  const [draft, setDraft] = useState<Record<string, string>>(() =>
    Object.fromEntries(
      baselines.map((view) => [view.key, view.manual && view.value !== null ? String(view.value) : ''])
    )
  );
  const [maxDraft, setMaxDraft] = useState(maxHr ? String(maxHr) : '');
  const [status, setStatus] = useState({ message: '', tone: 'good' as 'good' | 'bad' });
  const [busy, setBusy] = useState(false);

  function numberOrNull(value: string): number | null {
    if (!value.trim()) return null;
    const parsed = Number(value.replace(',', '.'));
    return Number.isFinite(parsed) ? parsed : null;
  }

  async function save() {
    setBusy(true);
    setStatus({ message: '', tone: 'good' });
    const result = await saveBaselinesAction({
      hrvMs: numberOrNull(draft.hrvMs ?? ''),
      restingHr: numberOrNull(draft.restingHr ?? ''),
      sleepHours: numberOrNull(draft.sleepHours ?? ''),
      maxHr: numberOrNull(maxDraft)
    });
    setBusy(false);
    if (!result.ok) {
      setStatus({ message: result.error, tone: 'bad' });
      return;
    }
    setStatus({ message: 'Baselines saved — the next score uses them.', tone: 'good' });
    router.refresh();
  }

  return (
    <div className="card">
      <div className="card-head">
        <h3>Your baselines</h3>
        <span className="small muted">the numbers a morning is measured against</span>
      </div>

      <p className="small muted" style={{ marginBottom: 10 }}>
        Leave a field empty and the rolling 14-day average is used. Type a number to overrule it — useful when the
        watch reads high, when the first weeks of data are thin, or when you simply know better.
      </p>

      <div className="field-row">
        {baselines.map((view) => {
          const field = BASELINE_FIELDS.find((item) => item.key === view.key);
          return (
            <div className="field" key={view.key}>
              <label htmlFor={`baseline-${view.key}`}>{view.label}</label>
              <div className="row" style={{ gap: 6 }}>
                <input
                  id={`baseline-${view.key}`}
                  className="input"
                  type="number"
                  step={field?.step ?? 1}
                  min={field?.min}
                  max={field?.max}
                  placeholder={
                    view.value !== null && !view.manual
                      ? `${view.value} (${view.days} days)`
                      : `automatic`
                  }
                  value={draft[view.key] ?? ''}
                  onChange={(event) => setDraft((current) => ({ ...current, [view.key]: event.target.value }))}
                />
                <span className="small muted">{view.unit}</span>
              </div>
              <span className="field-hint">{field?.hint}</span>
              <span className="small" style={{ color: view.manual ? 'var(--good)' : 'var(--faint)' }}>
                {view.manual
                  ? `using ${view.value} ${view.unit} — yours`
                  : view.value !== null
                    ? `averaging ${view.value} ${view.unit}`
                    : 'nothing to average yet'}
              </span>
            </div>
          );
        })}
      </div>

      <div className="field" style={{ marginTop: 10 }}>
        <label htmlFor="max-hr">Max heart rate</label>
        <div className="row" style={{ gap: 6 }}>
          <input
            id="max-hr"
            className="input"
            style={{ maxWidth: 120 }}
            type="number"
            min={120}
            max={230}
            placeholder={`${observedMaxHr}`}
            value={maxDraft}
            onChange={(event) => setMaxDraft(event.target.value)}
          />
          <span className="small muted">bpm</span>
        </div>
        <span className="field-hint">
          Used by the heart-rate zones on the plan page. Empty means the highest peak in your imported activities
          ({observedMaxHr} bpm).
        </span>
      </div>

      <div className="row" style={{ gap: 8, marginTop: 10 }}>
        <button className="btn btn-primary" type="button" disabled={busy} onClick={save}>
          {busy ? 'Saving…' : 'Save baselines'}
        </button>
        <button
          className="btn btn-ghost"
          type="button"
          disabled={busy}
          onClick={() => {
            setDraft(Object.fromEntries(baselines.map((view) => [view.key, ''])));
            setMaxDraft('');
          }}
        >
          Use the averages
        </button>
        {status.message ? (
          <span className="small" style={{ color: status.tone === 'bad' ? 'var(--bad)' : 'var(--good)' }}>
            {status.message}
          </span>
        ) : null}
      </div>
    </div>
  );
}
