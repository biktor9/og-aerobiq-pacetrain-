'use client';

import { usePathname } from 'next/navigation';
import { useState } from 'react';
import { savePageNoteAction } from '@/actions/settings';
import { BETA_LABEL, BETA_TEXT, NOTE_MAX_LENGTH, pageKeyForPath, showNote, type PageKey } from '@/domain/page-notes';

/**
 * The strip along the top of every tab: the beta banner, and under it the note
 * an admin has written for this tab. Everyone sees the note in red; only an
 * admin gets the pen, and each tab keeps its own text.
 */
export function PageBanner({
  isAdmin,
  notes
}: {
  isAdmin: boolean;
  /** What each tab currently says, so no request is needed to start editing. */
  notes: Partial<Record<PageKey, string>>;
}) {
  const pathname = usePathname();
  const page = pageKeyForPath(pathname ?? '');
  // A page that is not one of the tabs (an activity, say) still carries the
  // beta banner, but there is no note to show.
  const body = page ? (notes[page] ?? '') : '';
  const [draft, setDraft] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function save() {
    if (!page || draft === null) return;
    setSaving(true);
    setError('');
    // The page is re-rendered from the database once this returns, so the
    // viewer's own note is stored here and the text boxes close.
    const result = await savePageNoteAction({ page, body: draft });
    setSaving(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setDraft(null);
  }

  return (
    <section className="page-banner" aria-label="About this site">
      <p className="beta-line">
        <span className="beta-tag">{BETA_LABEL}</span>
        {BETA_TEXT}
      </p>

      {page ? (
        <div className="note-box">
          {draft === null ? (
            <>
              {showNote(body) ? (
                <p className="note-text">{body}</p>
              ) : isAdmin ? (
                <p className="note-empty">No note on this tab yet.</p>
              ) : null}
              {isAdmin ? (
                <button className="note-edit" type="button" onClick={() => setDraft(body)}>
                  {showNote(body) ? 'Edit note' : 'Write a note'}
                </button>
              ) : null}
            </>
          ) : (
            <div className="note-form">
              <label className="note-label" htmlFor="page-note">
                Note on this tab — everyone who opens it reads this
              </label>
              <textarea
                id="page-note"
                className="note-input"
                value={draft}
                maxLength={NOTE_MAX_LENGTH}
                rows={4}
                onChange={(event) => setDraft(event.target.value)}
                placeholder="What is new: fixes, changes, things to look at…"
              />
              <div className="note-actions">
                <span className="small muted">
                  {draft.length}/{NOTE_MAX_LENGTH}
                </span>
                {error ? <span className="small note-error">{error}</span> : null}
                <div style={{ flex: 1 }} />
                <button className="btn btn-sm btn-ghost" type="button" disabled={saving} onClick={() => setDraft(null)}>
                  Cancel
                </button>
                <button className="btn btn-sm btn-primary" type="button" disabled={saving} onClick={save}>
                  {saving ? 'Saving…' : 'Save note'}
                </button>
              </div>
            </div>
          )}
        </div>
      ) : null}
    </section>
  );
}
