// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render } from '@testing-library/react';
import { PlanWidgets, type PlanData } from '@/components/plan-widgets';
import { layoutRows, type WidgetId } from '@/domain/dashboard';
import { emptyZoneMinutes } from '@/domain/hr-zones';
import { ramp } from '@/domain/load';
import { DEFAULT_PACE_SEC_PER_KM } from '@/domain/pace';
import { buildWeekStrip } from '@/domain/week-summary';

// The editor saves through a server action and refreshes the route; neither is
// what these tests are about, so both are stood in for.
vi.mock('next/navigation', () => ({
  useRouter: () => ({ refresh: vi.fn(), push: vi.fn() })
}));

vi.mock('@/actions/settings', () => ({
  saveDashboardAction: vi.fn(async () => ({ ok: true, data: undefined })),
  resetDashboardAction: vi.fn(async () => ({ ok: true, data: undefined }))
}));

/**
 * The editor draws whatever `layoutRows` returns, and so does the saved page.
 * Pinning the rows here is what keeps the two identical: the editor cannot
 * fall back to a list without breaking these.
 */
function rows(order: WidgetId[], sizes = {}) {
  return layoutRows(order, sizes).map((row) => ({ kind: row.kind, ids: row.ids }));
}

// Two tiles, then a card, then two more tiles: the shape an athlete arranged.
const ORDER: WidgetId[] = ['stat-running', 'stat-time', 'mix', 'stat-load', 'stat-planned'];

/** An empty week, which is all the stat tiles need to draw. */
function planData(order: WidgetId[] = ['stat-running', 'stat-time']): PlanData {
  const weeks = buildWeekStrip({
    monday: new Date(2026, 9, 26),
    weeks: 2,
    activities: [],
    sessions: [],
    today: new Date(2026, 9, 28)
  });
  return {
    order,
    progressStyle: 'ring',
    sizes: {},
    current: weeks[0],
    nextWeek: weeks[1],
    weeks,
    weekKeyValue: weeks[0].key,
    mondayISO: weeks[0].monday,
    sickDays: [],
    paceNote: '',
    load: 0,
    rampInfo: ramp(0, 0),
    sessions: [],
    weekActivities: [],
    paces: DEFAULT_PACE_SEC_PER_KM,
    mix: { slices: [], totalMinutes: 0, source: 'none' },
    zones: { zones: emptyZoneMinutes(), totalMinutes: 0, withoutHr: 0 },
    zoneBounds: {} as PlanData['zoneBounds'],
    zoneModes: null,
    heat: {
      routes: [],
      area: null,
      period: 'week',
      missing: 0,
      totals: { sessions: 0, km: 0 },
      loaded: 0
    },
    avgPaceSecPerKm: null,
    previousLoad: 0,
    loadBars: [],
    loadPeak: 0,
    outstanding: [],
    recovery: { hasData: false, score: 0, summary: '', label: '' }
  };
}

afterEach(cleanup);

describe('the rows the plan page is drawn in', () => {
  it('groups runs of tiles into rows and gives a full-width card its own', () => {
    expect(rows(ORDER)).toEqual([
      { kind: 'tiles', ids: ['stat-running', 'stat-time'] },
      { kind: 'cards', ids: ['mix'] },
      { kind: 'tiles', ids: ['stat-load', 'stat-planned'] }
    ]);
  });

  it('keeps true order: a card between tiles breaks the run in two', () => {
    const shapes = rows(ORDER).map((row) => row.kind);
    expect(shapes).toEqual(['tiles', 'cards', 'tiles']);
  });

  it('never puts a single tile alone in a row when another tile is beside it', () => {
    const [first] = rows(ORDER);
    expect(first.ids).toHaveLength(2);
  });

  it('ignores the old tile-row marker, which draws nothing', () => {
    expect(rows(['overview', 'stat-running', 'stat-time'])).toEqual([
      { kind: 'tiles', ids: ['stat-running', 'stat-time'] }
    ]);
  });

  it('half-width cards share a row, full-width cards do not', () => {
    expect(rows(['mix', 'zones'])).toEqual([
      { kind: 'cards', ids: ['mix'] },
      { kind: 'cards', ids: ['zones'] }
    ]);
    expect(rows(['mix', 'zones'], { mix: 'wide', zones: 'wide' })).toEqual([
      { kind: 'cards', ids: ['mix', 'zones'] }
    ]);
  });
});

describe('a tile on the saved page', () => {
  /**
   * The tile carries no border of its own, and the `.stat` inside it carries
   * none either, so the saved page shows words rather than a grid of boxes.
   * The stylesheet keys the edges off exactly this shape — one box, and only
   * for the editor — so the nesting is asserted here.
   */
  it('has one box layer: the tile, with the block nested inside it', () => {
    const { container } = render(<PlanWidgets data={planData()} />);

    const tile = container.querySelector('.flow-tile > .stat.is-tile-sliver');
    expect(tile).not.toBeNull();
    // The block itself is the inner `.stat`, which the stylesheet strips bare.
    expect(tile?.querySelector('.stat[data-widget="stat-running"]')).not.toBeNull();
    // Nothing between the tile and its contents that could draw a second edge.
    expect(tile?.querySelector('.slot')).toBeNull();
  });

  it('adds the editor frame, and only the editor frame, when editing', () => {
    const { container } = render(<PlanWidgets data={planData()} editing />);

    const slot = container.querySelector('.flow-tile > .slot[data-editing="true"]');
    expect(slot).not.toBeNull();
    // The tile lives inside the slot's body, which is the box the stylesheet
    // draws for the editor.
    expect(slot?.querySelector('.slot-body > .stat.is-tile-sliver')).not.toBeNull();
  });
});
