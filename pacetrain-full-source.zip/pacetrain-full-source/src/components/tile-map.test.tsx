// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { TileMap } from '@/components/tile-map';
import { zoomForRadius } from '@/domain/geo';

/** jsdom has no layout engine, so the map is told when it was resized. */
class ResizeObserverStub {
  observe() {}
  unobserve() {}
  disconnect() {}
}

beforeEach(() => {
  vi.stubGlobal('ResizeObserver', ResizeObserverStub);
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

const CENTRE: [number, number] = [59.335, 18.065];
const LINE = {
  id: 'run-1',
  points: [
    [59.33, 18.06],
    [59.34, 18.07]
  ] as [number, number][]
};

describe('TileMap', () => {
  it('covers the view with satellite tiles at the zoom the area needs', () => {
    const { container } = render(<TileMap lines={[LINE]} centre={CENTRE} radiusKm={2} height={300} />);
    const tiles = [...container.querySelectorAll('img.map-tile')];

    expect(tiles.length).toBeGreaterThan(0);
    const expected = zoomForRadius(2, 240, 300);
    for (const tile of tiles) {
      expect(tile.getAttribute('src')).toContain('/World_Imagery/MapServer/tile/');
      expect(tile.getAttribute('src')).toContain(`/tile/${expected}/`);
    }
    expect(screen.getByText(/Imagery © Esri/)).toBeInTheDocument();
  });

  it('draws the trace as a line with start and finish', () => {
    const { container } = render(<TileMap lines={[LINE]} centre={CENTRE} radiusKm={2} height={300} />);

    const line = container.querySelector('polyline');
    expect(line?.getAttribute('points')?.split(' ')).toHaveLength(2);
    // Green at the start, red at the finish.
    expect(container.querySelectorAll('circle')).toHaveLength(2);
  });

  it('leaves the markers off for a heat map', () => {
    const { container } = render(
      <TileMap lines={[LINE]} centre={CENTRE} radiusKm={2} height={300} markers={false} blend />
    );

    expect(container.querySelectorAll('circle')).toHaveLength(0);
    expect(container.querySelector('polyline')).not.toBeNull();
  });

  it('zooms in over the same centre', () => {
    const { container } = render(<TileMap lines={[LINE]} centre={CENTRE} radiusKm={2} height={300} />);
    const before = container.querySelector('img.map-tile')?.getAttribute('src');

    fireEvent.click(screen.getByRole('button', { name: 'Zoom in' }));

    const after = container.querySelector('img.map-tile')?.getAttribute('src');
    expect(after).not.toBe(before);
    expect(after).toContain(`/tile/${zoomForRadius(2, 240, 300) + 1}/`);
  });

  it('reports where it has been dragged to', () => {
    const onViewChange = vi.fn();
    const { container } = render(
      <TileMap lines={[LINE]} centre={CENTRE} radiusKm={2} height={300} onViewChange={onViewChange} />
    );

    const map = container.querySelector('.tile-map') as HTMLElement;
    fireEvent.pointerDown(map, { clientX: 100, clientY: 100, pointerId: 1 });
    fireEvent.pointerMove(map, { clientX: 60, clientY: 100, pointerId: 1 });

    expect(onViewChange).toHaveBeenCalled();
    const [centre] = onViewChange.mock.calls[0] as [[number, number], number];
    // Dragging west moves the centre east.
    expect(centre[1]).toBeGreaterThan(CENTRE[1]);
  });

  it('does not pan when it is not interactive', () => {
    const onViewChange = vi.fn();
    const { container } = render(
      <TileMap lines={[LINE]} centre={CENTRE} radiusKm={2} height={300} interactive={false} onViewChange={onViewChange} />
    );

    const map = container.querySelector('.tile-map') as HTMLElement;
    fireEvent.pointerDown(map, { clientX: 100, clientY: 100, pointerId: 1 });
    fireEvent.pointerMove(map, { clientX: 60, clientY: 100, pointerId: 1 });

    expect(onViewChange).not.toHaveBeenCalled();
    expect(screen.queryByRole('button', { name: 'Zoom in' })).not.toBeInTheDocument();
  });
});
