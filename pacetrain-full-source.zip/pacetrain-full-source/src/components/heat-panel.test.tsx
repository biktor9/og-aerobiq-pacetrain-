// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { HeatPanel } from '@/components/heat-panel';

const mocks = vi.hoisted(() => ({
  setHeatPeriodAction: vi.fn(),
  setHeatAreaAction: vi.fn(),
  loadRoutesAction: vi.fn(),
  refresh: vi.fn()
}));

vi.mock('@/actions/heat', () => ({
  setHeatPeriodAction: mocks.setHeatPeriodAction,
  setHeatAreaAction: mocks.setHeatAreaAction,
  loadRoutesAction: mocks.loadRoutesAction
}));

vi.mock('next/navigation', () => ({
  useRouter: () => ({ refresh: mocks.refresh, push: vi.fn() })
}));

class ResizeObserverStub {
  observe() {}
  unobserve() {}
  disconnect() {}
}

const AREA = { lat: 59.33, lng: 18.06, radiusKm: 15, label: 'Stockholm' };

const ROUTES = [
  {
    id: 'a',
    date: '2026-10-20',
    name: 'Easy 8',
    points: [
      [59.33, 18.06],
      [59.34, 18.07]
    ] as [number, number][]
  },
  {
    id: 'b',
    date: '2026-10-21',
    name: 'Tempo',
    points: [
      [59.335, 18.06],
      [59.345, 18.07]
    ] as [number, number][]
  }
];

function renderPanel(overrides: Partial<Parameters<typeof HeatPanel>[0]> = {}) {
  return render(
    <HeatPanel
      routes={ROUTES}
      area={AREA}
      period="week"
      missing={5}
      totals={{ sessions: 2, km: 12.4 }}
      loaded={2}
      {...overrides}
    />
  );
}

beforeEach(() => {
  vi.stubGlobal('ResizeObserver', ResizeObserverStub);
  for (const mock of Object.values(mocks)) mock.mockReset();
  mocks.setHeatPeriodAction.mockResolvedValue({ ok: true });
  mocks.setHeatAreaAction.mockResolvedValue({ ok: true });
  mocks.loadRoutesAction.mockResolvedValue({ ok: true, data: { loaded: 5, remaining: 0 } });
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe('HeatPanel', () => {
  it('says how much is on the map', () => {
    renderPanel();
    expect(screen.getByText('2 sessions · 12.4 km in Stockholm this week')).toBeInTheDocument();
  });

  it('switches the window and asks the server to remember it', async () => {
    renderPanel();

    await userEvent.click(screen.getByRole('button', { name: 'month' }));

    expect(mocks.setHeatPeriodAction).toHaveBeenCalledWith('month');
    expect(mocks.refresh).toHaveBeenCalled();
  });

  it('reads the missing traces a batch at a time', async () => {
    renderPanel();

    await userEvent.click(screen.getByRole('button', { name: 'Read 5 traces' }));

    expect(mocks.loadRoutesAction).toHaveBeenCalled();
    expect(await screen.findByText(/Read 5 traces — the map is complete/)).toBeInTheDocument();
  });

  it('saves the radius and the name the athlete gave it', async () => {
    renderPanel();

    await userEvent.click(screen.getByRole('button', { name: 'Larger area' }));
    expect(screen.getByText('20 km')).toBeInTheDocument();
    // Once something differs, the button offers to keep the view.
    expect(screen.queryByRole('button', { name: 'Save area' })).not.toBeInTheDocument();

    const name = screen.getByLabelText('Area name');
    await userEvent.clear(name);
    await userEvent.type(name, 'Stockholm north');
    await userEvent.click(screen.getByRole('button', { name: 'Use this view' }));

    expect(mocks.setHeatAreaAction).toHaveBeenCalledWith({
      lat: 59.33,
      lng: 18.06,
      radiusKm: 20,
      label: 'Stockholm north'
    });
  });

  it('explains an empty map instead of drawing one', () => {
    renderPanel({ area: null, routes: [], loaded: 0 });

    expect(screen.getByText('No traces yet.')).toBeInTheDocument();
    expect(screen.queryByText(/Imagery © Esri/)).not.toBeInTheDocument();
  });

  it('says when none of the loaded traces are in the area', () => {
    renderPanel({ routes: [], loaded: 7 });
    expect(screen.getByText(/7 traces loaded, but none of them come within 15 km of Stockholm/)).toBeInTheDocument();
  });
});
