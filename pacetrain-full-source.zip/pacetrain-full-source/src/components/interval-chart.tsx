'use client';

/**
 * A deliberately small SVG chart. Streams are decimated on the server, so this
 * only has to draw a polyline and shade the work intervals.
 */

export interface ChartSegment {
  startSec: number;
  endSec: number;
  kind: 'work' | 'recover';
}

export function IntervalChart({
  time,
  values,
  unit,
  segments,
  invert = false,
  label,
  footer = 'shaded = work'
}: {
  time: number[];
  values: (number | null)[];
  unit: string;
  segments: ChartSegment[];
  invert?: boolean;
  label?: string;
  footer?: string;
}) {
  const width = 1000;
  const height = 260;
  const starts = time.length ? time[0] : 0;
  const ends = time.length ? time[time.length - 1] : starts + 1;
  const span = Math.max(1, ends - starts);

  const present = values.filter((value): value is number => value !== null && Number.isFinite(value));
  if (!present.length) {
    return <div className="empty">No values to chart for this metric.</div>;
  }

  const min = Math.min(...present);
  const max = Math.max(...present);
  const range = max - min || 1;

  const xFor = (seconds: number) => ((seconds - starts) / span) * width;
  const yFor = (value: number) => {
    const ratio = (value - min) / range;
    return height - (invert ? 1 - ratio : ratio) * height;
  };

  // A new sub-path starts wherever the stream has a gap.
  let path = '';
  let penDown = false;
  for (let index = 0; index < values.length; index++) {
    const value = values[index];
    if (value === null || !Number.isFinite(value)) {
      penDown = false;
      continue;
    }
    const x = xFor(time[index] ?? starts);
    const y = yFor(value);
    path += `${penDown ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)} `;
    penDown = true;
  }

  return (
    <div className="chart-wrap">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="chart-svg"
        preserveAspectRatio="none"
        role="img"
        aria-label={`${label ?? unit} over the session`}
      >
        {[0.25, 0.5, 0.75].map((ratio) => (
          <line
            key={ratio}
            x1={0}
            x2={width}
            y1={height * ratio}
            y2={height * ratio}
            stroke="currentColor"
            strokeOpacity={0.08}
            vectorEffect="non-scaling-stroke"
          />
        ))}

        {segments
          .filter((segment) => segment.kind === 'work')
          .map((segment, index) => {
            const left = Math.max(0, xFor(segment.startSec));
            const right = Math.min(width, xFor(segment.endSec));
            return (
              <rect
                key={index}
                x={left}
                y={0}
                width={Math.max(1, right - left)}
                height={height}
                fill="#e2703a"
                fillOpacity={0.14}
              />
            );
          })}

        <path d={path} fill="none" stroke="#1f6feb" strokeWidth={1.6} vectorEffect="non-scaling-stroke" />
      </svg>

      <div className="row small faint" style={{ justifyContent: 'space-between' }}>
        <span>
          {Math.ceil(max)} {unit}
        </span>
        <span>
          avg {Math.round(present.reduce((sum, value) => sum + value, 0) / present.length)} {unit}
          {footer ? ` · ${footer}` : ''}
        </span>
        <span>
          {Math.ceil(min)} {unit}
        </span>
      </div>
    </div>
  );
}
