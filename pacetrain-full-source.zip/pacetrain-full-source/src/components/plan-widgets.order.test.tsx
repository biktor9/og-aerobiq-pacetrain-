// @vitest-environment jsdom
import { afterEach, describe, expect, it } from 'vitest';
import { cleanup, render } from '@testing-library/react';
import { WidgetOrderProbe } from '@/components/plan-widget-order-probe';

afterEach(cleanup);

function drawn(): (string | null)[] {
  return Array.from(document.querySelectorAll('[data-drawn]')).map((node) => node.getAttribute('data-drawn'));
}

describe('the block order on the page', () => {
  it('draws the blocks in exactly the order it was given', () => {
    // The reported bug: a saved layout kept the cards in order but re-sorted
    // the tiles into a fixed row. Nothing may be re-sorted now.
    const order = ['stat-time', 'mix', 'stat-running', 'zones', 'stat-load'];
    render(<WidgetOrderProbe order={order} />);

    expect(drawn()).toEqual(order);
  });

  it('keeps a tile between two cards when that is where it was put', () => {
    render(<WidgetOrderProbe order={['stat-running', 'mix', 'stat-time']} />);
    expect(drawn()).toEqual(['stat-running', 'mix', 'stat-time']);
  });

  it('draws nothing for the old tile-row marker', () => {
    render(<WidgetOrderProbe order={['overview', 'stat-running']} />);
    expect(drawn()).toEqual(['stat-running']);
  });
});
