﻿'use client';

import { useEffect, useState } from 'react';
import { deleteSessionAction, saveSessionAction } from '@/actions/sessions';
import { NumberStepper } from '@/components/number-stepper';
import {
  DEFAULT_PACE_SEC_PER_KM,
  WORK_PACE_SHARE,
  formatPace,
  impliedPaceSecPerKm,
  isDistanceSport,
  kmForMinutes,
  minutesForKm,
  paceMismatchPct,
  planningPace,
  type PaceTable
} from '@/domain/pace';
import { describeSession, edgeMinutes, isOpenInterval, sessionBlocks, sessionDuration, sessionTitle } from '@/domain/plan';
import { MODES, ZONES, type Activity, type ModeId, type SessionInput, zone, zoneName } from '@/domain/types';

const KINDS: { id: SessionInput['kind']; label: string }[] = [
  { id: 'steady', label: 'Steady' },
  { id: 'intervals', label: 'Intervals' }
];

const BLOCK_LABELS: Record<string, string> = {
  warmup: 'Warm-up',
  work: 'Work',
  recover: 'Recovery',
  cooldown: 'Cool-down'
};

function minutesLabel(value: number): string {
  return Number.isInteger(value) ? String(value) : value.toFixed(1);
}

/** `0.8`, `1`, `1.25` — a distance without trailing zeros. */
function kmTextValue(km: number): string {
  return Number.isInteger(km) ? String(km) : String(Math.round(km * 100) / 100);
}

export function SessionSheet({
  initial,
  paces,
  activities,
  onClose,
  onSaved
}: {
  initial: SessionInput & { id?: string; linkedActivityId?: string | null };
  /** Median pace per running discipline, in seconds per km. */
  paces?: PaceTable;
  /** Activities imported on this session's day, for linking the actual. */
  activities?: Activity[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [draft, setDraft] = useState<SessionInput>(initial);
  const [linked, setLinked] = useState<string | null>(initial.linkedActivityId ?? null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  /** Kilometres are only ever entered by hand, so they start from what was typed. */
  const [kmDraft, setKmDraft] = useState<string | null>(initial.targetKm != null ? String(initial.targetKm) : null);

  const patch = (changes: Partial<SessionInput>) => setDraft((current) => ({ ...current, ...changes }));

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const blocks = sessionBlocks(draft);
  const total = sessionDuration(draft);
  const paceTable = paces ?? DEFAULT_PACE_SEC_PER_KM;
  const pace = planningPace(draft.mode, paceTable);

  // Minutes and kilometres are independent: both are saved, and a pair that
  // disagrees with the athlete's usual pace is a warning rather than a
  // correction. Nothing silently overwrites the other field.
  const showDistance = isDistanceSport(draft.mode) && draft.kind !== 'strength' && !draft.structure?.length;
  const km = draft.targetKm ?? kmForMinutes(draft.minutes, draft.mode, paceTable);
  const implied = impliedPaceSecPerKm(draft.minutes, km);
  const mismatch = showDistance ? paceMismatchPct(draft.minutes, km, pace) : null;
  const preview = showDistance ? { ...draft, targetKm: km } : draft;

  // An interval session may be left at "reps not chosen yet": a zone, a total
  // time and optionally a distance, with the reps filled in later.
  const openInterval = isOpenInterval(draft);
  const decided = draft.kind === 'intervals' && !openInterval;
  // A rep of a kilometre or less is planned as a distance (8×800 m), anything
  // longer as a time (4×8′), which is how the two are actually run.
  const distanceInterval = decided && Boolean(draft.targetReps);
  const repKm = draft.targetReps ?? null;
  /** Which of the warm-up and cool-down the athlete wrote in kilometres. */
  const edgesInKm = {
    warmup: draft.warmupKm != null && draft.warmupKm > 0,
    cooldown: draft.cooldownKm != null && draft.cooldownKm > 0
  };
  /** The session length warm-up and cool-down add around the reps, in minutes. */
  const edgesMin = edgeMinutes(draft, pace).warmup + edgeMinutes(draft, pace).cooldown;

  function setReps(value: number | null) {
    if (value === null) {
      // Back to "not decided": the work numbers go, the plan keeps its time.
      patch({ reps: null, workMin: null, targetReps: null });
      return;
    }
    patch({ reps: value });
  }

  function setWorkMin(value: number | null) {
    patch(value === null ? { workMin: null } : { workMin: value, targetReps: null });
  }

  /** Working pace, which is not the athlete's easy pace: a rep is run harder. */
  const repPace = Math.round(pace * WORK_PACE_SHARE);

  function setRepKm(value: number | null) {
    if (value === null) {
      patch({ targetReps: null });
      return;
    }
    // Kilometres per rep decide the work length, so the two never disagree.
    patch({ targetReps: value, workMin: minutesForKm(value, repPace) });
  }

  /**
   * The easy kilometres around the reps: the warm-up and cool-down exactly as
   * written when they are in km, and otherwise converted from their minutes at
   * the athlete's easy pace.
   */
  const edgeKm =
    (draft.warmupKm && draft.warmupKm > 0 ? draft.warmupKm : kmForMinutes(draft.warmupMin, draft.mode, paceTable)) +
    (draft.cooldownKm && draft.cooldownKm > 0 ? draft.cooldownKm : kmForMinutes(draft.cooldownMin, draft.mode, paceTable));
  /**
   * What the session adds up to at the athlete's own paces: the reps at working
   * pace plus the warm-up, the jogs between them and the cool-down at easy
   * pace. It is only a suggestion — the athlete can type their own total, and an
   * empty field means "use this".
   */
  const suggestedKm = (() => {
    const reps = draft.reps ?? 0;
    const workMin = draft.workMin ?? 0;
    const recoverMin = draft.recoverMin ?? 0;
    if (!reps || !workMin) return null;
    const workKm = (reps * workMin * 60) / repPace;
    const recoverKm = (Math.max(0, reps - 1) * recoverMin * 60) / pace;
    const total = workKm + recoverKm + edgeKm;
    return total > 0 ? Math.round(total * 2) / 2 : null;
  })();
  /** What the athlete typed, if anything. Empty means "use the estimate". */
  const [totalKmDraft, setTotalKmDraft] = useState<string>(
    initial.kind === 'intervals' && initial.reps ? String(initial.targetKm ?? '') : ''
  );
  const typedTotalKm = (() => {
    const parsed = Number(totalKmDraft.replace(',', '.'));
    return Number.isFinite(parsed) && parsed > 0 ? Math.round(parsed * 10) / 10 : null;
  })();
  /** The kilometres the interval session will be saved with. */
  const intervalTotalKm = typedTotalKm ?? suggestedKm;
  /** The kilometres typed for an open interval session, as a number. */
  const typedKm = (() => {
    const parsed = Number((kmDraft ?? '').replace(',', '.'));
    return Number.isFinite(parsed) && parsed > 0 ? Math.round(parsed * 10) / 10 : null;
  })();
  const totalKm = decided
    ? draft.targetKm ?? (repKm && draft.reps ? Math.round((repKm * draft.reps + edgeKm) * 10) / 10 : null)
    : typedKm;
  const workPace = repKm ? impliedPaceSecPerKm(minutesForKm(repKm, repPace), repKm) : null;

  /** Back to "reps not decided", keeping the zone, the time and the kilometres. */
  function clearInterval() {
    patch({ reps: null, workMin: null, targetReps: null });
  }

  function chooseMode(mode: ModeId) {
    if (mode === draft.mode) return;
    // Switching discipline re-derives the estimate at that sport's pace; a
    // bicycle at running kilometres is never what someone meant.
    patch({
      mode,
      kind: mode === 'strength' ? 'strength' : draft.kind === 'strength' ? 'steady' : draft.kind,
      structure: mode === 'strength' ? null : draft.structure,
      targetKm: null
    });
  }

  function chooseKind(kind: SessionInput['kind']) {
    if (kind === draft.kind) return;
    // The numbers no longer describe the session once a structure is dropped.
    patch({ kind, structure: null, targetKm: kind === 'steady' ? (draft.targetKm ?? null) : null });
  }

  function chooseZone(zoneId: number) {
    if (zoneId === draft.zone) return;
    patch({ zone: zoneId, structure: null });
  }

  async function save() {
    setBusy(true);
    setError('');
    const isInterval = draft.kind === 'intervals';
    // Every session saves a definite distance: a number or null. `undefined`
    // is dropped by the database layer, so a field left at undefined would keep
    // whatever the row held before — or, for a new row, fall back to a default.
    // An open interval session keeps the kilometres typed for it; one with reps
    // keeps the total the athlete typed, or the estimate the plan adds up to.
    const targetKm = isInterval
      ? (decided ? (typedTotalKm ?? suggestedKm ?? null) : (typedKm ?? null))
      : showDistance
        ? km
        : (draft.targetKm ?? null);
    const result = await saveSessionAction({
      ...draft,
      targetKm,
      id: initial.id,
      // A skipped session is not fulfilled by any activity, so the link goes
      // with it — otherwise it would keep pairing as done.
      linkedActivityId: draft.status === 'skipped' ? null : linked
    });
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    onSaved();
  }

  async function remove() {
    if (!initial.id) return;
    setBusy(true);
    await deleteSessionAction(initial.id);
    setBusy(false);
    onSaved();
  }

  return (
    <div className="sheet-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <aside className="sheet" role="dialog" aria-modal="true" aria-label="Session">
        <div className="sheet-head">
          <div>
            <h2>{initial.id ? 'Edit session' : 'New session'}</h2>
            <p className="small muted">{draft.date}</p>
          </div>
          <button type="button" className="btn btn-ghost btn-icon" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>

        <div className="sheet-body">
          <div className="field">
            {/* Moving a session without dragging: phones and keyboards end up here. */}
            <label htmlFor="day">Day</label>
            <input
              id="day"
              className="input"
              type="date"
              value={draft.date}
              onChange={(event) => {
                if (event.target.value) patch({ date: event.target.value });
              }}
            />
          </div>
          <div className="field">
            <label>Discipline</label>
            <div className="mode-picker" role="group" aria-label="Discipline">
              {MODES.map((option) => {
                const active = draft.mode === option.id;
                return (
                  <button
                    key={option.id}
                    type="button"
                    className="mode-chip"
                    aria-pressed={active}
                    onClick={() => chooseMode(option.id)}
                    style={active ? { borderColor: option.color, color: option.color } : undefined}
                  >
                    <span className="mode-swatch" style={{ background: option.color }} />
                    {option.label}
                  </button>
                );
              })}
            </div>
          </div>

          {draft.mode !== 'strength' ? (
            <div className="field">
              <label>Type</label>
              <div className="segmented">
                {KINDS.map((kind) => (
                  <button
                    key={kind.id}
                    type="button"
                    aria-pressed={draft.kind === kind.id}
                    onClick={() => chooseKind(kind.id)}
                  >
                    {kind.label}
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          <div className="field">
            <label htmlFor="title">Title</label>
            <input
              id="title"
              className="input"
              value={draft.title}
              maxLength={80}
              placeholder={draft.kind === 'intervals' ? 'Threshold 4×8′' : 'Easy endurance'}
              onChange={(event) => patch({ title: event.target.value })}
            />
          </div>

          <div className="field">
            <label>Zone / effort</label>
            <div className="segmented">
              {ZONES.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  aria-pressed={draft.zone === option.id}
                  onClick={() => chooseZone(option.id)}
                  title={option.name}
                >
                  {option.id}
                </button>
              ))}
            </div>
            <span className="field-hint">
              {zoneName(draft.mode, draft.zone)} —{' '}
              {draft.mode === 'strength' ? `effort ${draft.zone}` : zone(draft.zone).short}
            </span>
          </div>

          {draft.structure && draft.structure.length ? (
            <div className="field">
              <div className="spread">
                <label>Session as written</label>
                <span className="small muted">{Math.round(total)}′ total</span>
              </div>
              <ul className="block-list">
                {draft.structure.map((block, index) => (
                  <li key={`${block.kind}-${index}`}>
                    <span className="dot" style={{ background: zone(block.zone).color }} />
                    <span>{BLOCK_LABELS[block.kind] ?? 'Work'}</span>
                    <span className="spacer" />
                    <span className="mono">{minutesLabel(block.minutes)}′</span>
                    <span className="small muted block-effort">{zoneName(draft.mode, block.zone)}</span>
                  </li>
                ))}
              </ul>
              <div className="row-wrap">
                <button className="btn btn-sm btn-ghost" type="button" onClick={() => patch({ structure: null })}>
                  Clear structure
                </button>
                <span className="field-hint">Parsed from your words. Clear it to edit the numbers instead.</span>
              </div>
            </div>
          ) : draft.kind === 'intervals' ? (
            <>
              {/* "Not chosen yet": a zone, a total time and optionally the
                  kilometres, with the reps to be decided nearer the session. */}
              {openInterval ? (
                <div className="field">
                  <div className="spread">
                    <label>Reps</label>
                    <label htmlFor="reps-open" className="row small muted" style={{ gap: 6, fontWeight: 400 }}>
                      <input
                        id="reps-open"
                        type="checkbox"
                        checked
                        onChange={() =>
                          patch({
                            reps: draft.reps ?? 4,
                            workMin: draft.workMin ?? 8,
                            recoverMin: draft.recoverMin ?? 2
                          })
                        }
                      />
                      Not chosen yet
                    </label>
                  </div>
                  <span className="field-hint">
                    Plan the zone, the time and optionally the kilometres now; the reps can wait until you know them.
                    The session is saved as one block in Z{draft.zone}.
                  </span>
                  <div className="field-row" style={{ marginTop: 8 }}>
                    <div className="field">
                      <label htmlFor="open-minutes">Duration (min)</label>
                      <NumberStepper
                        value={draft.minutes}
                        min={5}
                        max={600}
                        step={5}
                        onChange={(minutes) => patch({ minutes })}
                      />
                    </div>
                    <div className="field">
                      <label htmlFor="open-km">Distance (km)</label>
                      <NumberStepper
                        value={typedKm ?? kmForMinutes(draft.minutes, draft.mode, paceTable)}
                        min={1}
                        max={300}
                        step={1}
                        onChange={(targetKm) => setKmDraft(String(targetKm))}
                      />
                    </div>
                  </div>
                  <span className="field-hint">
                    {typedKm ? `${typedKm} km entered` : 'distance is optional'} · it feeds the week&apos;s km and the
                    planned running total
                  </span>
                </div>
              ) : null}

              {decided ? (
                <>
                  <div className="field">
                    <div className="spread">
                      <label>Reps</label>
                      <label htmlFor="reps-open" className="row small muted" style={{ gap: 6, fontWeight: 400 }}>
                        <input
                          id="reps-open"
                          type="checkbox"
                          checked={false}
                          onChange={() => patch({ reps: null, workMin: null, targetReps: null })}
                        />
                        Not chosen yet
                      </label>
                    </div>
                  </div>
                  <div className="field-row">
                    <div className="field">
                      <label>Reps</label>
                      <NumberStepper value={draft.reps ?? 4} min={1} max={40} onChange={setReps} />
                    </div>
                    <div className="field">
                      <label>Recovery (min)</label>
                      <NumberStepper
                        value={draft.recoverMin ?? 0}
                        min={0}
                        max={60}
                        step={0.5}
                        onChange={(recoverMin) => patch({ recoverMin })}
                      />
                    </div>
                  </div>

                  <div className="field">
                    <div className="spread">
                      <label>Work per rep</label>
                      <div className="segmented" role="group" aria-label="Rep unit">
                        <button type="button" aria-pressed={!distanceInterval} onClick={() => setRepKm(null)}>
                          Time
                        </button>
                        <button
                          type="button"
                          aria-pressed={distanceInterval}
                          onClick={() => setRepKm(repKm ?? 1)}
                        >
                          km
                        </button>
                      </div>
                    </div>
                    {distanceInterval ? (
                      <NumberStepper
                        value={repKm ?? 1}
                        min={0.1}
                        max={20}
                        step={0.1}
                        onChange={(value) => setRepKm(value)}
                      />
                    ) : (
                      <NumberStepper
                        value={draft.workMin ?? 8}
                        min={0.5}
                        max={120}
                        step={0.5}
                        onChange={setWorkMin}
                      />
                    )}
                    <span className="field-hint">
                      {distanceInterval
                        ? `${draft.reps ?? 0} × ${kmTextValue(repKm ?? 0)} km ≈ ${formatPace(workPace ?? repPace)} a rep`
                        : 'Time per rep. Switch to km for 400 m, 800 m and 1 km reps.'}
                    </span>
                  </div>

                  <div className="field">
                    <label htmlFor="total-km">Total distance (km)</label>
                    <div className="row" style={{ gap: 6 }}>
                      <input
                        id="total-km"
                        className="input"
                        type="number"
                        min={0}
                        max={300}
                        step={0.1}
                        placeholder={suggestedKm ? `${suggestedKm}` : 'optional'}
                        value={totalKmDraft}
                        onChange={(event) => setTotalKmDraft(event.target.value)}
                      />
                      {suggestedKm ? (
                        <button
                          className="btn btn-sm"
                          type="button"
                          onClick={() => setTotalKmDraft('')}
                          title={`Use the estimate from the plan: ${suggestedKm} km`}
                        >
                          use {suggestedKm}
                        </button>
                      ) : null}
                    </div>
                    <span className="field-hint">
                      the whole session, warm-up and cool-down included —{' '}
                      {suggestedKm ? `the plan adds up to about ${suggestedKm} km` : 'optional'}
                    </span>
                  </div>
                </>
              ) : null}

              <div className="field-row">
                <div className="field">
                  <div className="spread">
                    <label htmlFor="warmup-km">Warm-up{edgesInKm.warmup ? ' (km)' : ' (min)'}</label>
                    <div className="segmented" role="group" aria-label="Warm-up unit">
                      <button
                        type="button"
                        aria-pressed={!edgesInKm.warmup}
                        onClick={() => patch({ warmupKm: null })}
                      >
                        Time
                      </button>
                      <button
                        type="button"
                        aria-pressed={edgesInKm.warmup}
                        onClick={() =>
                          patch({
                            warmupKm: draft.warmupKm ?? Math.round((draft.warmupMin / Math.max(1, pace / 60)) * 10) / 10
                          })
                        }
                      >
                        km
                      </button>
                    </div>
                  </div>
                  {edgesInKm.warmup ? (
                    <NumberStepper
                      value={draft.warmupKm ?? 0}
                      min={0}
                      max={30}
                      step={0.5}
                      onChange={(warmupKm) => patch({ warmupKm })}
                    />
                  ) : (
                    <NumberStepper
                      value={draft.warmupMin}
                      min={0}
                      max={120}
                      onChange={(warmupMin) => patch({ warmupMin })}
                    />
                  )}
                </div>
                <div className="field">
                  <div className="spread">
                    <label htmlFor="cooldown-km">Cool-down{edgesInKm.cooldown ? ' (km)' : ' (min)'}</label>
                    <div className="segmented" role="group" aria-label="Cool-down unit">
                      <button
                        type="button"
                        aria-pressed={!edgesInKm.cooldown}
                        onClick={() => patch({ cooldownKm: null })}
                      >
                        Time
                      </button>
                      <button
                        type="button"
                        aria-pressed={edgesInKm.cooldown}
                        onClick={() =>
                          patch({
                            cooldownKm:
                              draft.cooldownKm ?? Math.round((draft.cooldownMin / Math.max(1, pace / 60)) * 10) / 10
                          })
                        }
                      >
                        km
                      </button>
                    </div>
                  </div>
                  {edgesInKm.cooldown ? (
                    <NumberStepper
                      value={draft.cooldownKm ?? 0}
                      min={0}
                      max={30}
                      step={0.5}
                      onChange={(cooldownKm) => patch({ cooldownKm })}
                    />
                  ) : (
                    <NumberStepper
                      value={draft.cooldownMin}
                      min={0}
                      max={120}
                      onChange={(cooldownMin) => patch({ cooldownMin })}
                    />
                  )}
                </div>
              </div>
              <span className="field-hint">
                Kilometres are turned into minutes at your easy pace ({formatPace(pace)}), so the block, the total and the
                week&apos;s kilometres all stay in step.
              </span>
            </>
          ) : showDistance ? (
            <>
              <div className="field-row">
                <div className="field">
                  <label>Duration (min)</label>
                  <NumberStepper
                    value={draft.minutes}
                    min={5}
                    max={600}
                    step={5}
                    onChange={(minutes) => patch({ minutes })}
                  />
                </div>
                <div className="field">
                  <label>Distance (km)</label>
                  <NumberStepper value={km} min={1} max={300} step={1} onChange={(targetKm) => patch({ targetKm })} />
                </div>
              </div>
              <span className="field-hint">
                {implied ? `≈ ${formatPace(implied)} implied` : ''} · your usual {formatPace(pace)} · both are saved
              </span>
              {mismatch !== null && mismatch > 10 ? (
                <div className="alert alert-warn" role="status">
                  Time and distance disagree by {Math.round(mismatch)}%. Both are saved as written — adjust either one
                  to line them up.
                </div>
              ) : null}
            </>
          ) : (
            <div className="field">
              <label>Duration (min)</label>
              <NumberStepper
                value={draft.minutes}
                min={5}
                max={600}
                step={5}
                onChange={(minutes) => patch({ minutes })}
              />
            </div>
          )}

          <div className="field">
            <label htmlFor="notes">Notes</label>
            <textarea
              id="notes"
              className="textarea"
              value={draft.notes}
              maxLength={400}
              placeholder="Keep it controlled, last rep strong."
              onChange={(event) => patch({ notes: event.target.value })}
            />
          </div>

          <div className="field">
            <label>Status</label>
            <div className="segmented">
              {(['planned', 'done', 'skipped'] as const).map((status) => (
                <button
                  key={status}
                  type="button"
                  aria-pressed={draft.status === status}
                  onClick={() => patch({ status })}
                >
                  {status === 'planned' ? 'Planned' : status === 'done' ? 'Done' : 'Skipped'}
                </button>
              ))}
            </div>
          </div>

          {activities && activities.length ? (
            <div className="field">
              <label htmlFor="linked-activity">Completed by</label>
              <select
                id="linked-activity"
                className="select"
                value={linked ?? ''}
                onChange={(event) => {
                  const value = event.target.value || null;
                  setLinked(value);
                  // Linking an imported activity is proof the session happened.
                  if (value) patch({ status: 'done' });
                }}
              >
                <option value="">Match by day and discipline</option>
                {activities.map((activity) => (
                  <option key={activity.id} value={activity.id}>
                    {activity.name || 'Activity'} · {Math.round(activity.durationSec / 60)}′
                    {activity.distanceM ? ` · ${(activity.distanceM / 1000).toFixed(1)} km` : ''}
                  </option>
                ))}
              </select>
              <span className="field-hint">
                Pick the activity that fulfilled this session, or leave it to the automatic match.
              </span>
            </div>
          ) : null}

          <div className="preview">
            <div className="spread">
              <strong>{sessionTitle(preview)}</strong>
              <span>
                {showDistance ? `${minutesLabel(km)} km · ` : ''}
                {Math.round(total)}′
              </span>
            </div>
            <div>{describeSession(preview)}</div>
            <div className="timeline">
              {blocks.map((block, index) => (
                <span
                  key={index}
                  className="timeline-seg"
                  style={{
                    flexGrow: Math.max(block.minutes, 2),
                    background: zone(block.zone).color,
                    opacity: block.kind === 'warmup' || block.kind === 'cooldown' ? 0.5 : 1
                  }}
                  title={`${block.kind} ${block.minutes}′ Z${block.zone}`}
                />
              ))}
            </div>
          </div>

          {error ? <div className="alert alert-error">{error}</div> : null}
        </div>

        <div className="sheet-foot">
          <button className="btn btn-primary" type="button" onClick={save} disabled={busy}>
            {busy ? 'Saving…' : 'Save session'}
          </button>
          <button className="btn" type="button" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <div style={{ flex: 1 }} />
          {initial.id ? (
            <button className="btn btn-danger" type="button" onClick={remove} disabled={busy}>
              Delete
            </button>
          ) : null}
        </div>
      </aside>
    </div>
  );
}
