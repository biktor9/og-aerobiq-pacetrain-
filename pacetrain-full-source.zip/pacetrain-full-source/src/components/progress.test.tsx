// @vitest-environment jsdom
import { afterEach, describe, expect, it } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import { Progress, ProgressBar, ProgressRing } from '@/components/progress';

afterEach(cleanup);

describe('ProgressRing', () => {
  it('draws a circle for the track and one for the fill', () => {
    const { container } = render(<ProgressRing percent={50} label="50%" />);

    // Two circles: the grey track and the coloured arc.
    expect(container.querySelectorAll('circle')).toHaveLength(2);
    expect(screen.getByText('50%')).toBeInTheDocument();
  });

  it('fills half the circumference at 50%', () => {
    const { container } = render(<ProgressRing percent={50} label="50%" size={100} />);
    const fill = container.querySelectorAll('circle')[1];
    const stroke = Number(fill.getAttribute('stroke-width'));
    const radius = (100 - stroke) / 2;
    const circumference = 2 * Math.PI * radius;
    const dash = Number(fill.getAttribute('stroke-dasharray')?.split(' ')[0]);

    expect(dash).toBeCloseTo(circumference / 2, 1);
  });

  it('draws no arc at zero and a full circle at a hundred', () => {
    const none = render(<ProgressRing percent={0} label="0%" />);
    expect(none.container.querySelectorAll('circle')).toHaveLength(1);
    cleanup();

    const full = render(<ProgressRing percent={100} label="100%" size={100} />);
    const fill = full.container.querySelectorAll('circle')[1];
    const dash = Number(fill.getAttribute('stroke-dasharray')?.split(' ')[0]);
    const gap = Number(fill.getAttribute('stroke-dasharray')?.split(' ')[1]);
    expect(gap).toBe(0);
    expect(dash).toBeGreaterThan(0);
  });

  it('clamps a percentage that makes no sense', () => {
    const { container } = render(<ProgressRing percent={238} label="238%" />);
    expect(container.querySelector('svg')?.getAttribute('aria-label')).toBe('100%');
    expect(screen.getByText('238%')).toBeInTheDocument();
  });

  it('describes itself for a screen reader, including the note', () => {
    render(<ProgressRing percent={62} label="62%" note="5h of 8h due" />);
    expect(screen.getByRole('img').getAttribute('aria-label')).toBe('62%, 5h of 8h due');
    expect(screen.getByText('5h of 8h due')).toBeInTheDocument();
  });
});

describe('Progress', () => {
  it('shows a ring when rings were chosen', () => {
    const { container } = render(<Progress percent={40} label="40%" style="ring" />);
    expect(container.querySelector('svg.ring')).not.toBeNull();
  });

  it('shows a filling bar when bars were chosen', () => {
    const { container } = render(<Progress percent={40} label="40%" style="bar" />);
    expect(container.querySelector('svg.ring')).toBeNull();
    expect(container.querySelector('.meter-fill')).not.toBeNull();
  });
});

describe('ProgressBar', () => {
  it('sets the fill width to the percentage', () => {
    const { container } = render(<ProgressBar percent={73} />);
    expect((container.querySelector('.meter-fill') as HTMLElement).style.width).toBe('73%');
  });
});
