'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { clearWeekAction, copyPreviousWeekAction, loadDemoAction, moveSessionAction } from '@/actions/sessions';
import { SessionSheet } from '@/components/session-sheet';
import { activitiesByDate } from '@/domain/activity';
import { sessionLoad } from '@/domain/load';
import { DEFAULT_PACE_SEC_PER_KM, type PaceTable } from '@/domain/pace';
import { pairByDate } from '@/domain/plan-match';
import { initialSession, sessionTitle, sortSessions } from '@/domain/plan';
import { type Activity, type Session, type SessionInput, mode, zone } from '@/domain/types';
import { dayLabel, fmtClock, isToday, parseISODate, toISODate, weekDays } from '@/domain/week';

interface Editing {
  date: string;
  session?: Session;
}

function kmText(km: number): string {
  return Number.isInteger(km) ? String(km) : km.toFixed(1);
}

export function WeekBoard({
  sessions,
  activities,
  paces,
  mondayISO,
  weekKey
}: {
  sessions: Session[];
  /** Imported activities for this week, shown under each day as what actually happened. */
  activities?: Activity[];
  paces?: PaceTable;
  mondayISO: string;
  weekKey: string;
}) {
  const router = useRouter();
  const [editing, setEditing] = useState<Editing | null>(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  /** The session under the cursor while dragging, and the day it hovers over. */
  const [dragging, setDragging] = useState<Session | null>(null);
  const [dropDate, setDropDate] = useState<string | null>(null);

  const sorted = sortSessions(sessions);
  const days = weekDays(parseISODate(mondayISO));
  const actuals = activitiesByDate(activities ?? []);
  // Which imported activity belongs to which session, solved once for the week.
  const pairings = pairByDate(sorted, activities ?? []);

  const refresh = () => {
    setEditing(null);
    router.refresh();
  };

  async function run(action: () => Promise<{ ok: boolean; error?: string }>, success: string) {
    setBusy(true);
    setError('');
    setNotice('');
    const result = await action();
    setBusy(false);
    if (!result.ok) {
      setError(result.error ?? 'That did not work.');
      return;
    }
    setNotice(success);
    router.refresh();
  }

  const emptyInitial = (date: string): SessionInput => initialSession(date, 'run');

  /** Dropped on another day: keep the session, change the date. */
  async function moveTo(session: Session, iso: string) {
    setDragging(null);
    setDropDate(null);
    if (session.date === iso) return;

    setBusy(true);
    setError('');
    setNotice('');
    const result = await moveSessionAction(session.id, iso);
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setNotice(`Moved “${sessionTitle(session)}” to ${dayLabel(parseISODate(iso))}.`);
    router.refresh();
  }

  return (
    <div className="stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div className="row" style={{ gap: 6 }}>
          <button
            className="btn btn-sm"
            type="button"
            disabled={busy}
            onClick={() => run(() => copyPreviousWeekAction(weekKey), 'Copied last week into this week.')}
          >
            Copy last week
          </button>
          <button
            className="btn btn-sm"
            type="button"
            disabled={busy}
            onClick={() => run(() => loadDemoAction(weekKey), 'Sample week loaded, with four demo activities.')}
          >
            Load sample week
          </button>
        </div>
        <button
          className="btn btn-sm btn-ghost"
          type="button"
          disabled={busy || sessions.length === 0}
          onClick={() => {
            if (!window.confirm('Remove every session in this week?')) return;
            void run(() => clearWeekAction(weekKey), 'Week cleared.');
          }}
        >
          Clear week
        </button>
      </div>

      {error ? <div className="alert alert-error">{error}</div> : null}
      {notice ? <div className="alert alert-good">{notice}</div> : null}

      {sessions.length === 0 ? (
        <div className="alert">
          <strong>Nothing planned yet.</strong>
          <p className="small" style={{ marginTop: 4 }}>
            Add a session to any day, or load the sample week to see how a balanced seven days looks. The coach reads
            whatever you put here.
          </p>
        </div>
      ) : null}

      <div className="week-grid">
        {days.map((day) => {
          const iso = toISODate(day);
          const daySessions = sorted.filter((session) => session.date === iso);
          const dayActivities = actuals[iso] ?? [];
          const pairing = pairings.get(iso);
          const paired = new Map((pairing?.pairs ?? []).map((item) => [item.session.id, item]));
          const leftovers = pairing?.leftoverActivities ?? dayActivities;
          const load = daySessions.reduce((total, session) => total + sessionLoad(session), 0);

          return (
            <section
              key={iso}
              className={`day-col ${isToday(day) ? 'is-today' : ''} ${daySessions.length ? '' : 'is-empty'} ${
                dropDate === iso ? 'is-drop' : ''
              }`}
              // Any day can receive a session, empty or not: plans move.
              onDragOver={(event) => {
                if (!dragging) return;
                event.preventDefault();
                event.dataTransfer.dropEffect = 'move';
                if (dropDate !== iso) setDropDate(iso);
              }}
              onDragLeave={(event) => {
                const next = event.relatedTarget as Node | null;
                if (next && event.currentTarget.contains(next)) return;
                setDropDate((current) => (current === iso ? null : current));
              }}
              onDrop={(event) => {
                event.preventDefault();
                if (dragging) void moveTo(dragging, iso);
              }}
            >
              <header className="day-head">
                <span className="day-name">{dayLabel(day).split(' ')[0]}</span>
                <span className="day-date">{day.getDate()}</span>
              </header>
              <div className="day-load">{load ? `load ${load}` : '—'}</div>

              <div className="day-body">
                {daySessions.map((session) => {
                  const match = paired.get(session.id);
                  return (
                    <div key={session.id} className="session-block">
                      <div
                        className={`session-card ${dragging?.id === session.id ? 'is-dragging' : ''}`}
                        data-status={match ? 'done' : session.status}
                        role="button"
                        tabIndex={0}
                        draggable={!busy}
                        title="Drag it to another day, or click to edit"
                        onDragStart={(event) => {
                          setDragging(session);
                          event.dataTransfer.effectAllowed = 'move';
                          // Some browsers need a payload before they start a drag.
                          event.dataTransfer.setData('text/plain', session.id);
                        }}
                        onDragEnd={() => {
                          setDragging(null);
                          setDropDate(null);
                        }}
                        onClick={() => setEditing({ date: session.date, session })}
                        onKeyDown={(event) => {
                          if (event.key === 'Enter' || event.key === ' ') {
                            event.preventDefault();
                            setEditing({ date: session.date, session });
                          }
                        }}
                      >
                        <span className="session-accent" style={{ background: mode(session.mode).color }} />
                        <span className="session-title">{sessionTitle(session)}</span>
                        <span className="session-meta">
                          {session.targetKm ? `${kmText(session.targetKm)} km · ` : ''}
                          {session.kind === 'intervals' && !session.structure?.length
                            ? session.reps && session.workMin
                              ? `${session.reps}×${session.targetReps ? `${kmText(session.targetReps)}km` : `${session.workMin}′`}`
                              : `${Math.round(session.durationMin)}′ · reps open`
                            : `${Math.round(session.durationMin)}′`}{' '}
                          · Z{session.zone}
                          {match ? ' · done' : session.status === 'skipped' ? ' · skipped' : ''}
                        </span>
                      </div>

                      {match ? (
                        <Link
                          className="session-actual"
                          href={`/activities/${match.activity.id}`}
                          title={`${match.activity.name || 'Activity'} — open the details`}
                        >
                          <span className="dot" style={{ background: mode(match.activity.mode).color }} />
                          {match.activity.distanceM ? `${(match.activity.distanceM / 1000).toFixed(1)} km · ` : ''}
                          {Math.round(match.activity.durationSec / 60)}′
                          {match.activity.avgHr ? ` · ${match.activity.avgHr} bpm` : ''}
                          <span className="faint">{match.manual ? ' · linked' : ' · matched'}</span>
                        </Link>
                      ) : null}
                    </div>
                  );
                })}

                {leftovers.map((activity) => (
                  <Link
                    key={activity.id}
                    className="day-actual"
                    href={`/activities/${activity.id}`}
                    title={`${activity.name || 'Activity'} — open details`}
                  >
                    <span className="dot" style={{ background: mode(activity.mode).color }} />
                    {activity.distanceM ? `${(activity.distanceM / 1000).toFixed(1)} km` : fmtClock(activity.durationSec)}
                    {activity.distanceM ? ` · ${Math.round(activity.durationSec / 60)}′` : ''}
                  </Link>
                ))}

                <button className="add-session" type="button" onClick={() => setEditing({ date: iso })}>
                  + Add
                </button>
              </div>
            </section>
          );
        })}
      </div>

      <p className="small faint">
        Drag a session to another day if plans change, or click it to edit it or link the imported activity that
        fulfilled it. Zone colours: {[1, 2, 3, 4, 5].map((id) => `Z${id} ${zone(id).name}`).join(' · ')}.
      </p>

      {editing ? (
        <SessionSheet
          initial={editing.session ?? emptyInitial(editing.date)}
          paces={paces ?? DEFAULT_PACE_SEC_PER_KM}
          activities={actuals[editing.date] ?? []}
          onClose={() => setEditing(null)}
          onSaved={refresh}
        />
      ) : null}
    </div>
  );
}
