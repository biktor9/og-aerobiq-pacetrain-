'use server';

import { eq } from 'drizzle-orm';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { db, schema } from '@/db';
import { activatePlan, trialAlreadyUsed } from '@/lib/billing-server';
import { requireAdmin } from '@/lib/session';

/**
 * Periods are sold by hand. The athlete emails the developer, pays directly
 * (Swish, bank transfer), and an admin switches the period on here. There is no
 * checkout, no provider and no card data anywhere on the site.
 */

export type ActionResult<T = undefined> = { ok: true; data: T } | { ok: false; error: string };

const planSchema = z.enum(['trial', 'quarter', 'halfYear', 'year']);

function refresh(): void {
  revalidatePath('/', 'layout');
  revalidatePath('/pricing');
  revalidatePath('/billing');
}

const grantSchema = z.object({
  email: z.string().email(),
  plan: planSchema,
  /** What actually arrived. Empty means the plan's list price. */
  amountSek: z.number().min(0).max(10_000).nullish()
});

/** An admin records a payment and starts the period. */
export async function grantPlanAction(input: unknown): Promise<ActionResult> {
  const admin = await requireAdmin();
  const parsed = grantSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: 'Give an email address and a period.' };

  const email = parsed.data.email.trim().toLowerCase();
  const [target] = await db
    .select({ id: schema.user.id, name: schema.user.name })
    .from(schema.user)
    .where(eq(schema.user.email, email))
    .limit(1);

  if (!target) return { ok: false, error: `No account with ${email}.` };

  if (parsed.data.plan === 'trial' && (await trialAlreadyUsed(target.id))) {
    return { ok: false, error: `${email} has already used the test period. Give them 3, 6 or 12 months instead.` };
  }

  await activatePlan(target.id, {
    plan: parsed.data.plan,
    source: 'grant',
    amountSek: parsed.data.amountSek ?? undefined,
    note: `Switched on by ${admin.email ?? 'an admin'}`
  });
  refresh();
  return { ok: true, data: undefined };
}

