'use server';

import { and, eq } from 'drizzle-orm';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { db, schema } from '@/db';
import { randomId } from '@/lib/crypto';
import { requireUser } from '@/lib/session';

/**
 * Illness, logged so the plan and the coach know about it. One row per period:
 * "sore throat and a fever, 22–25 October, rough". No streaks, no guilt.
 */

export type ActionResult<T = undefined> = { ok: true; data: T } | { ok: false; error: string };

const iso = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);

const sickSchema = z.object({
  id: z.string().min(1).optional(),
  dateFrom: iso,
  dateTo: iso,
  symptoms: z.string().trim().min(1, 'Write the symptoms so the coach knows what to work around.').max(200),
  severity: z.number().int().min(1).max(3),
  notes: z.string().max(300).default('')
});

function refresh(): void {
  revalidatePath('/recovery');
  revalidatePath('/plan');
  revalidatePath('/progress');
  revalidatePath('/coach');
}

export async function saveSickNoteAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const user = await requireUser();
  const parsed = sickSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'That illness note does not look right.' };
  }

  // Dates given backwards are still a period.
  const from = parsed.data.dateFrom <= parsed.data.dateTo ? parsed.data.dateFrom : parsed.data.dateTo;
  const to = parsed.data.dateFrom <= parsed.data.dateTo ? parsed.data.dateTo : parsed.data.dateFrom;
  const now = new Date();
  const values = {
    dateFrom: from,
    dateTo: to,
    symptoms: parsed.data.symptoms,
    severity: parsed.data.severity,
    notes: parsed.data.notes,
    updatedAt: now
  };

  if (parsed.data.id) {
    await db
      .update(schema.sickNotes)
      .set(values)
      .where(and(eq(schema.sickNotes.id, parsed.data.id), eq(schema.sickNotes.userId, user.id)));
    refresh();
    return { ok: true, data: { id: parsed.data.id } };
  }

  const id = randomId();
  await db.insert(schema.sickNotes).values({ id, userId: user.id, ...values, createdAt: now });
  refresh();
  return { ok: true, data: { id } };
}

export async function deleteSickNoteAction(id: string): Promise<ActionResult> {
  const user = await requireUser();
  await db.delete(schema.sickNotes).where(and(eq(schema.sickNotes.id, id), eq(schema.sickNotes.userId, user.id)));
  refresh();
  return { ok: true, data: undefined };
}
