'use server';

import { and, eq } from 'drizzle-orm';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { db, schema } from '@/db';
import { MODE_ID_VALUES } from '@/domain/types';
import { randomId } from '@/lib/crypto';
import { requireUser } from '@/lib/session';

/** Races and goals: the dates the plan is arranged around. */

export type ActionResult<T = undefined> = { ok: true; data: T } | { ok: false; error: string };

const eventSchema = z.object({
  id: z.string().min(1).optional(),
  name: z.string().trim().min(1, 'Give the race a name.').max(80),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  mode: z.enum(MODE_ID_VALUES),
  priority: z.enum(['A', 'B', 'C']),
  distanceKm: z.number().min(0).max(1000).nullish(),
  targetTimeSec: z.number().int().min(0).max(360_000).nullish(),
  notes: z.string().max(300).default('')
});

function refresh(): void {
  revalidatePath('/progress');
  revalidatePath('/plan');
}

export async function saveEventAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const user = await requireUser();
  const parsed = eventSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? 'That race does not look right.' };

  const values = {
    name: parsed.data.name,
    date: parsed.data.date,
    mode: parsed.data.mode,
    priority: parsed.data.priority,
    distanceKm: parsed.data.distanceKm ?? null,
    targetTimeSec: parsed.data.targetTimeSec ?? null,
    notes: parsed.data.notes,
    updatedAt: new Date()
  };

  if (parsed.data.id) {
    await db
      .update(schema.events)
      .set(values)
      .where(and(eq(schema.events.id, parsed.data.id), eq(schema.events.userId, user.id)));
    refresh();
    return { ok: true, data: { id: parsed.data.id } };
  }

  const id = randomId();
  await db.insert(schema.events).values({ id, userId: user.id, ...values, createdAt: new Date() });
  refresh();
  return { ok: true, data: { id } };
}

export async function deleteEventAction(id: string): Promise<ActionResult> {
  const user = await requireUser();
  await db.delete(schema.events).where(and(eq(schema.events.id, id), eq(schema.events.userId, user.id)));
  refresh();
  return { ok: true, data: undefined };
}
