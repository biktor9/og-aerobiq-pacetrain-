'use server';

import { revalidatePath } from 'next/cache';
import { startOfWeek, toISODate } from '@/domain/week';
import { importActivitiesBetween, type ImportResult } from '@/lib/icu-sync';
import { requireUser } from '@/lib/session';

/**
 * Small, targeted imports: one day or the week so far, straight from the
 * activities screen. Both are idempotent, so pressing them twice is harmless.
 */

export type ActionResult<T = undefined> = { ok: true; data: T } | { ok: false; error: string };

function refresh(): void {
  revalidatePath('/activities');
  revalidatePath('/plan');
  revalidatePath('/progress');
  revalidatePath('/analysis');
  revalidatePath('/settings');
}

async function run(fromISO: string, toISO: string): Promise<ActionResult<ImportResult>> {
  const user = await requireUser();
  try {
    const result = await importActivitiesBetween(user.id, fromISO, toISO);
    refresh();
    return { ok: true, data: result };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : 'The import failed.' };
  }
}

export async function importTodayAction(): Promise<ActionResult<ImportResult>> {
  const today = toISODate(new Date());
  return run(today, today);
}

export async function importThisWeekAction(): Promise<ActionResult<ImportResult>> {
  const now = new Date();
  return run(toISODate(startOfWeek(now)), toISODate(now));
}

export async function importRangeAction(fromISO: string, toISO: string): Promise<ActionResult<ImportResult>> {
  return run(fromISO, toISO);
}
