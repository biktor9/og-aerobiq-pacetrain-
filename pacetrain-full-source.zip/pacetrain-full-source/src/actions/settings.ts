'use server';

import { eq } from 'drizzle-orm';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { z } from 'zod';
import { db, schema } from '@/db';
import { parseDashboard, parseSizes, serializeDashboard, serializeSizes } from '@/domain/dashboard';
import { serializeZoneBounds, serializeZoneModes, type ZoneBounds } from '@/domain/hr-zones';
import { isPageKey, NOTE_MAX_LENGTH, normalizeNote, pageInfo, PAGES } from '@/domain/page-notes';
import { MODE_ID_VALUES, type ModeId } from '@/domain/types';
import { encryptSecret, secretLast4 } from '@/lib/crypto';
import { getIcuCredentials, getSettings } from '@/lib/data';
import { testConnection } from '@/lib/icu';
import { importActivities, type ImportResult } from '@/lib/icu-sync';
import { isAdmin, requireUser } from '@/lib/session';

export type ActionResult<T = undefined> = { ok: true; data: T } | { ok: false; error: string };

const profileSchema = z.object({
  goalText: z.string().max(300),
  eventDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .or(z.literal(''))
    .transform((value) => (value ? value : null)),
  weeklyMinutesTarget: z.number().int().min(0).max(3000),
  weeklyLoadTarget: z.number().int().min(0).max(2000),
  primaryMode: z.enum(MODE_ID_VALUES),
  coachTone: z.enum(['direct', 'supportive', 'analytical', 'concise']),
  athleteNotes: z.string().max(1000)
});

export async function saveProfileAction(input: unknown): Promise<ActionResult> {
  const user = await requireUser();
  const parsed = profileSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Those settings are not valid.' };
  }

  await getSettings(user.id);
  await db
    .update(schema.userSettings)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(schema.userSettings.userId, user.id));

  revalidatePath('/settings');
  revalidatePath('/coach');
  return { ok: true, data: undefined };
}

/** The athlete's own heart-rate zones and which sports count towards them. */
const zonesSchema = z.object({
  /** The tops of Z1 … Z4, in bpm, rising. */
  bounds: z.array(z.number().int().min(60).max(230)).length(4),
  maxHr: z.number().int().min(120).max(230).nullish(),
  /** Null or empty means every sport counts. */
  modes: z.array(z.enum(MODE_ID_VALUES)).nullish()
});

export async function saveZonesAction(input: unknown): Promise<ActionResult> {
  const user = await requireUser();
  const parsed = zonesSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: 'Those zone boundaries do not look right.' };

  const bounds = parsed.data.bounds;
  for (let index = 1; index < bounds.length; index++) {
    if (bounds[index] <= bounds[index - 1]) {
      return { ok: false, error: 'Each zone has to end above the one before it.' };
    }
  }

  await getSettings(user.id);
  await db
    .update(schema.userSettings)
    .set({
      hrZoneBounds: serializeZoneBounds(bounds as ZoneBounds),
      hrZoneModes: serializeZoneModes((parsed.data.modes ?? []) as ModeId[]),
      maxHr: parsed.data.maxHr ?? null,
      updatedAt: new Date()
    })
    .where(eq(schema.userSettings.userId, user.id));

  revalidatePath('/settings');
  revalidatePath('/plan');
  return { ok: true, data: undefined };
}

/** The plan page's layout, how percentages are drawn, and how big things are. */
const dashboardSchema = z.object({
  order: z.array(z.string()).max(64),
  progressStyle: z.enum(['bar', 'ring']).optional(),
  sizes: z.record(z.string(), z.enum(['small', 'wide', 'large'])).optional()
});

export async function saveDashboardAction(input: unknown): Promise<ActionResult> {
  const user = await requireUser();
  const parsed = dashboardSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: 'That layout does not look right.' };

  // Anything unknown is dropped, duplicates go, and the rest keeps its order.
  const dashboard = parseDashboard(JSON.stringify(parsed.data.order));
  const sizes = parseSizes(JSON.stringify(parsed.data.sizes ?? {}));

  await getSettings(user.id);
  await db
    .update(schema.userSettings)
    .set({
      dashboardJson: serializeDashboard(dashboard),
      dashboardSizes: serializeSizes(sizes),
      ...(parsed.data.progressStyle ? { progressStyle: parsed.data.progressStyle } : {}),
      updatedAt: new Date()
    })
    .where(eq(schema.userSettings.userId, user.id));

  revalidatePath('/plan');
  revalidatePath('/settings');
  return { ok: true, data: undefined };
}

/** Puts every widget back, in the catalogue's order, at its natural size. */
export async function resetDashboardAction(): Promise<ActionResult> {
  const user = await requireUser();
  await getSettings(user.id);
  await db
    .update(schema.userSettings)
    .set({ dashboardJson: null, dashboardSizes: null, updatedAt: new Date() })
    .where(eq(schema.userSettings.userId, user.id));

  revalidatePath('/plan');
  return { ok: true, data: undefined };
}

export async function saveOwnKeyAction(apiKey: string): Promise<ActionResult> {
  const user = await requireUser();
  const key = apiKey.trim();
  if (key.length < 20 || !key.startsWith('sk-')) {
    return { ok: false, error: 'That does not look like a DeepSeek key (they start with sk-).' };
  }

  await getSettings(user.id);
  await db
    .update(schema.userSettings)
    .set({ deepseekKeyEnc: encryptSecret(key), updatedAt: new Date() })
    .where(eq(schema.userSettings.userId, user.id));

  revalidatePath('/settings');
  revalidatePath('/coach');
  return { ok: true, data: undefined };
}

export async function clearOwnKeyAction(): Promise<ActionResult> {
  const user = await requireUser();
  await db
    .update(schema.userSettings)
    .set({ deepseekKeyEnc: null, updatedAt: new Date() })
    .where(eq(schema.userSettings.userId, user.id));
  revalidatePath('/settings');
  revalidatePath('/coach');
  return { ok: true, data: undefined };
}

const icuSchema = z.object({
  athleteId: z.string().trim().min(1, 'Athlete ID is required.').max(40),
  apiKey: z.string().trim().min(10, 'The API key looks too short.').max(120)
});

/** Tests the credentials before storing them, so a typo fails loudly. */
export async function connectIcuAction(input: unknown): Promise<ActionResult<{ name: string }>> {
  const user = await requireUser();
  const parsed = icuSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Check the athlete ID and key.' };
  }

  const { athleteId, apiKey } = parsed.data;
  let name: string;
  try {
    const info = await testConnection({ athleteId, apiKey });
    name = info.name;
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : 'Could not reach intervals.icu.' };
  }

  const existing = await getIcuCredentials(user.id);
  const now = new Date();
  if (existing) {
    await db
      .update(schema.icuCredentials)
      .set({
        athleteId,
        apiKeyEnc: encryptSecret(apiKey),
        keyLast4: secretLast4(apiKey),
        status: 'ok',
        lastError: null,
        updatedAt: now
      })
      .where(eq(schema.icuCredentials.userId, user.id));
  } else {
    await db.insert(schema.icuCredentials).values({
      userId: user.id,
      athleteId,
      apiKeyEnc: encryptSecret(apiKey),
      keyLast4: secretLast4(apiKey),
      status: 'ok',
      createdAt: now,
      updatedAt: now
    });
  }

  revalidatePath('/settings');
  revalidatePath('/analysis');
  return { ok: true, data: { name } };
}

export async function disconnectIcuAction(): Promise<ActionResult> {
  const user = await requireUser();
  await db.delete(schema.icuCredentials).where(eq(schema.icuCredentials.userId, user.id));
  revalidatePath('/settings');
  revalidatePath('/analysis');
  return { ok: true, data: undefined };
}

export async function syncIcuAction(days = 30): Promise<ActionResult<ImportResult>> {
  const user = await requireUser();
  const window = Math.min(365, Math.max(1, Math.round(days)));
  try {
    const result = await importActivities(user.id, window);
    revalidatePath('/settings');
    revalidatePath('/analysis');
    revalidatePath('/plan');
    return { ok: true, data: result };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : 'The import failed.' };
  }
}

export async function deleteAccountAction(): Promise<ActionResult> {
  const user = await requireUser();
  await db.delete(schema.user).where(eq(schema.user.id, user.id));
  redirect('/');
}

/**
 * Writes the note on one tab. Only an admin may do it, and the note is shared:
 * one box per tab, seen by everyone who opens that tab. Writing an empty note
 * clears it, which is how an update is taken down again.
 */
const noteSchema = z.object({
  page: z.string(),
  body: z.string().max(NOTE_MAX_LENGTH * 2)
});

export async function savePageNoteAction(input: unknown): Promise<ActionResult<{ body: string }>> {
  const user = await requireUser();
  // Checked here rather than in the page, because this is the boundary that has
  // to hold: a note is public, and only an admin may put words in front of
  // everyone else.
  if (!isAdmin(user)) return { ok: false, error: 'Only an admin can write these notes.' };

  const parsed = noteSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: 'That note could not be saved.' };
  if (!isPageKey(parsed.data.page)) return { ok: false, error: 'Unknown tab.' };

  const body = normalizeNote(parsed.data.body);
  if (body.length > NOTE_MAX_LENGTH) {
    return { ok: false, error: `Notes are limited to ${NOTE_MAX_LENGTH} characters.` };
  }

  const page = pageInfo(parsed.data.page);
  const now = new Date();
  await db
    .insert(schema.pageNotes)
    .values({ page: page.key, body, updatedBy: user.id, updatedAt: now })
    .onConflictDoUpdate({
      target: schema.pageNotes.page,
      set: { body, updatedBy: user.id, updatedAt: now }
    });

  // The note is drawn by the app shell, so every tab that shows it is refreshed.
  for (const entry of PAGES) revalidatePath(entry.path);
  revalidatePath('/', 'layout');
  return { ok: true, data: { body } };
}
