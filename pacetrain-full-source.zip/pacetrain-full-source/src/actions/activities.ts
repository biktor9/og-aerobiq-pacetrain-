'use server';

import { and, eq } from 'drizzle-orm';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { db, schema } from '@/db';
import { MODE_ID_VALUES } from '@/domain/types';
import { getActivity, setActivityRemoved, updateActivity } from '@/lib/data';
import { requireUser } from '@/lib/session';

/**
 * Corrections to imported activities.
 *
 * Imports are not always right: a watch uploads the same run twice, a session
 * is filed under the wrong sport, the distance includes a warm-up lap. These
 * actions let the athlete fix the local copy. Deleting is a soft delete, so the
 * next sync cannot quietly bring the activity back.
 */

export type ActionResult<T = undefined> = { ok: true; data: T } | { ok: false; error: string };

const updateSchema = z.object({
  id: z.string().min(1),
  name: z.string().trim().max(80).default(''),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  mode: z.enum(MODE_ID_VALUES),
  durationSec: z.number().int().min(0).max(86_400),
  distanceM: z.number().min(0).max(1_000_000),
  avgHr: z.number().int().min(30).max(260).nullish(),
  maxHr: z.number().int().min(30).max(260).nullish(),
  load: z.number().min(0).max(2000).nullish(),
  rpe: z.number().int().min(1).max(10).nullish(),
  feel: z.number().int().min(1).max(5).nullish(),
  notes: z.string().max(500).default('')
});

function refresh(id?: string): void {
  revalidatePath('/activities');
  revalidatePath('/plan');
  revalidatePath('/progress');
  revalidatePath('/analysis');
  if (id) revalidatePath(`/activities/${id}`);
}

export async function updateActivityAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const user = await requireUser();
  const parsed = updateSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? 'That activity does not look right.' };

  const existing = await getActivity(user.id, parsed.data.id);
  if (!existing) return { ok: false, error: 'That activity is no longer here.' };

  await updateActivity(user.id, parsed.data.id, {
    name: parsed.data.name,
    date: parsed.data.date,
    mode: parsed.data.mode,
    durationSec: parsed.data.durationSec,
    distanceM: parsed.data.distanceM,
    avgHr: parsed.data.avgHr ?? null,
    maxHr: parsed.data.maxHr ?? null,
    load: parsed.data.load ?? null,
    rpe: parsed.data.rpe ?? null,
    feel: parsed.data.feel ?? null,
    notes: parsed.data.notes
  });

  refresh(parsed.data.id);
  return { ok: true, data: { id: parsed.data.id } };
}

export async function deleteActivityAction(id: string): Promise<ActionResult> {
  const user = await requireUser();
  const existing = await getActivity(user.id, id);
  if (!existing) return { ok: false, error: 'That activity is already gone.' };

  await setActivityRemoved(user.id, id, true);
  // A planned session pointing at a deleted activity would keep saying "done"
  // with nothing behind it, so the link goes too.
  await db
    .update(schema.plannedSessions)
    .set({ linkedActivityId: null, updatedAt: new Date() })
    .where(and(eq(schema.plannedSessions.userId, user.id), eq(schema.plannedSessions.linkedActivityId, id)));

  refresh(id);
  return { ok: true, data: undefined };
}

export async function restoreActivityAction(id: string): Promise<ActionResult> {
  const user = await requireUser();
  await setActivityRemoved(user.id, id, false);
  refresh(id);
  return { ok: true, data: undefined };
}
