'use server';

import { and, eq } from 'drizzle-orm';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { db, schema } from '@/db';
import { normalizeSession } from '@/domain/plan';
import { MODE_ID_VALUES } from '@/domain/types';
import { addDays, mondayOfWeekKey, parseISODate, toISODate } from '@/domain/week';
import { randomId } from '@/lib/crypto';
import { getSessionById, weekSessions } from '@/lib/data';
import { demoActivities, demoStream, demoSessions } from '@/lib/demo';
import { routePoints } from '@/lib/icu';
import { ROUTE_POINTS, serialiseRoute } from '@/domain/route-json';
import { requireUser } from '@/lib/session';

export type ActionResult<T = undefined> = { ok: true; data: T } | { ok: false; error: string };

const blockSchema = z.object({
  kind: z.enum(['warmup', 'work', 'recover', 'cooldown']),
  minutes: z.number().min(0.5).max(600),
  zone: z.number().int().min(1).max(5)
});

const sessionSchema = z.object({
  id: z.string().min(1).optional(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  mode: z.enum(MODE_ID_VALUES),
  kind: z.enum(['steady', 'intervals', 'strength']),
  title: z.string().max(80),
  zone: z.number().int().min(1).max(5),
  minutes: z.number().min(5).max(600),
  targetKm: z.number().min(0).max(300).nullish(),
  /** Null while an interval session has no reps yet. */
  reps: z.number().int().min(1).max(40).nullish(),
  workMin: z.number().min(0.5).max(120).nullish(),
  recoverMin: z.number().min(0).max(60).nullish(),
  warmupMin: z.number().min(0).max(120),
  cooldownMin: z.number().min(0).max(120),
  /** Warm-up and cool-down written in kilometres instead of minutes. */
  warmupKm: z.number().min(0).max(30).nullish(),
  cooldownKm: z.number().min(0).max(30).nullish(),
  /** Kilometres per rep: 0.8 for 8×800 m. */
  targetReps: z.number().min(0).max(20).nullish(),
  notes: z.string().max(400),
  status: z.enum(['planned', 'done', 'skipped']),
  structure: z.array(blockSchema).max(80).nullish(),
  /** The imported activity that fulfilled this session, when one was chosen. */
  linkedActivityId: z.string().min(1).nullish()
});

/** Columns for a session row, with the block list folded into one JSON column. */
function toColumns(session: ReturnType<typeof normalizeSession>) {
  const { structure, ...columns } = session;
  // A column set to `undefined` is silently skipped by the query builder, so a
  // field the form did not mention would keep its old value. Every field is
  // either a value or null by the time it gets here; this makes that explicit.
  const values: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(columns)) values[key] = value === undefined ? null : value;
  return {
    ...values,
    structureJson: structure && structure.length ? JSON.stringify(structure) : null
  } as typeof columns & { structureJson: string | null };
}

function firstIssue(error: z.ZodError): string {
  return error.issues[0]?.message ?? 'That session does not look right.';
}

function refresh(): void {
  revalidatePath('/plan');
  revalidatePath('/coach');
}

export async function saveSessionAction(input: unknown): Promise<ActionResult<{ id: string }>> {
  const user = await requireUser();
  const parsed = sessionSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };

  const session = normalizeSession(parsed.data);
  const columns = toColumns(session);
  const now = new Date();

  if (parsed.data.id) {
    const existing = await getSessionById(user.id, parsed.data.id);
    if (!existing) return { ok: false, error: 'That session no longer exists.' };

    await db
      .update(schema.plannedSessions)
      .set({ ...columns, linkedActivityId: parsed.data.linkedActivityId ?? null, updatedAt: now })
      .where(and(eq(schema.plannedSessions.id, parsed.data.id), eq(schema.plannedSessions.userId, user.id)));
    refresh();
    return { ok: true, data: { id: parsed.data.id } };
  }

  const id = randomId();
  await db.insert(schema.plannedSessions).values({
    id,
    userId: user.id,
    ...columns,
    linkedActivityId: parsed.data.linkedActivityId ?? null,
    createdAt: now,
    updatedAt: now
  });
  refresh();
  return { ok: true, data: { id } };
}

export async function deleteSessionAction(id: string): Promise<ActionResult> {
  const user = await requireUser();
  await db
    .delete(schema.plannedSessions)
    .where(and(eq(schema.plannedSessions.id, id), eq(schema.plannedSessions.userId, user.id)));
  refresh();
  return { ok: true, data: undefined };
}

export async function setSessionStatusAction(
  id: string,
  status: 'planned' | 'done' | 'skipped'
): Promise<ActionResult> {
  const user = await requireUser();
  const parsed = z.enum(['planned', 'done', 'skipped']).safeParse(status);
  if (!parsed.success) return { ok: false, error: 'Unknown status.' };

  await db
    .update(schema.plannedSessions)
    .set({ status: parsed.data, updatedAt: new Date() })
    .where(and(eq(schema.plannedSessions.id, id), eq(schema.plannedSessions.userId, user.id)));
  refresh();
  return { ok: true, data: undefined };
}

/**
 * Moves one session to another day and leaves everything else about it alone.
 * Changing your mind about Tuesday is a drag, not a delete and re-enter.
 */
export async function moveSessionAction(id: string, date: string): Promise<ActionResult<{ date: string }>> {
  const user = await requireUser();
  if (!z.string().regex(/^\d{4}-\d{2}-\d{2}$/).safeParse(date).success) {
    return { ok: false, error: 'That is not a day I can move it to.' };
  }

  const existing = await getSessionById(user.id, id);
  if (!existing) return { ok: false, error: 'That session no longer exists.' };
  if (existing.date === date) return { ok: true, data: { date } };

  await db
    .update(schema.plannedSessions)
    .set({ date, updatedAt: new Date() })
    .where(and(eq(schema.plannedSessions.id, id), eq(schema.plannedSessions.userId, user.id)));
  refresh();
  revalidatePath('/activities');
  return { ok: true, data: { date } };
}

async function deleteWeek(userId: string, monday: Date): Promise<void> {
  for (let day = 0; day < 7; day++) {
    await db
      .delete(schema.plannedSessions)
      .where(
        and(
          eq(schema.plannedSessions.userId, userId),
          eq(schema.plannedSessions.date, toISODate(addDays(monday, day)))
        )
      );
  }
}

/** Copies last week's sessions into the next week, replacing what is there. */
export async function copyPreviousWeekAction(targetKey: string): Promise<ActionResult<{ count: number }>> {
  const user = await requireUser();
  const targetMonday = mondayOfWeekKey(targetKey);
  const sourceMonday = addDays(targetMonday, -7);
  const source = await weekSessions(user.id, sourceMonday);
  if (!source.length) return { ok: false, error: 'Last week has nothing to copy.' };

  await deleteWeek(user.id, targetMonday);

  const now = new Date();
  for (const session of source) {
    await db.insert(schema.plannedSessions).values({
      id: randomId(),
      userId: user.id,
      date: toISODate(addDays(parseISODate(session.date), 7)),
      mode: session.mode,
      kind: session.kind,
      title: session.title,
      zone: session.zone,
      minutes: session.minutes,
      targetKm: session.targetKm ?? null,
      reps: session.reps,
      workMin: session.workMin,
      recoverMin: session.recoverMin,
      warmupMin: session.warmupMin,
      cooldownMin: session.cooldownMin,
      warmupKm: session.warmupKm ?? null,
      cooldownKm: session.cooldownKm ?? null,
      targetReps: session.targetReps ?? null,
      notes: session.notes,
      status: 'planned',
      structureJson: session.structure && session.structure.length ? JSON.stringify(session.structure) : null,
      linkedActivityId: null,
      createdAt: now,
      updatedAt: now
    });
  }

  refresh();
  return { ok: true, data: { count: source.length } };
}

/** Fills a week with the sample plan and imports four demo activities. */
export async function loadDemoAction(weekKey: string): Promise<ActionResult<{ sessions: number; activities: number }>> {
  const user = await requireUser();
  const monday = mondayOfWeekKey(weekKey);
  const existing = await weekSessions(user.id, monday);
  if (existing.length) {
    return { ok: false, error: 'This week already has sessions. Clear it first if you want the sample plan.' };
  }

  const now = new Date();
  const sessions = demoSessions(toISODate(monday));
  for (const session of sessions) {
    const normalized = normalizeSession(session);
    await db.insert(schema.plannedSessions).values({
      id: randomId(),
      userId: user.id,
      ...toColumns(normalized),
      linkedActivityId: null,
      createdAt: now,
      updatedAt: now
    });
  }

  const activities = demoActivities();
  for (const activity of activities) {
    const date = new Date(now);
    date.setDate(date.getDate() - activity.daysAgo);
    await db
      .insert(schema.activities)
      .values({
        id: randomId(),
        userId: user.id,
        externalId: activity.externalId,
        source: 'demo',
        date: toISODate(date),
        mode: activity.mode,
        name: activity.name,
        durationSec: activity.durationSec,
        distanceM: activity.distanceM,
        avgHr: activity.avgHr,
        maxHr: activity.maxHr,
        load: activity.load,
        // The sample runs carry a GPS trace, so the heat map has something to
        // draw before a single real activity has been imported.
        routeJson: serialiseRoute(routePoints(demoStream(activity.externalId), ROUTE_POINTS)),
        createdAt: now
      })
      .onConflictDoNothing();
  }

  refresh();
  revalidatePath('/analysis');
  return { ok: true, data: { sessions: sessions.length, activities: activities.length } };
}

/** Removes every session in a week. */
export async function clearWeekAction(weekKey: string): Promise<ActionResult<{ count: number }>> {
  const user = await requireUser();
  const monday = mondayOfWeekKey(weekKey);
  const existing = await weekSessions(user.id, monday);
  await deleteWeek(user.id, monday);
  refresh();
  return { ok: true, data: { count: existing.length } };
}
