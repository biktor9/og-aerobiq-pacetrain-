'use server';

import { and, eq } from 'drizzle-orm';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { db, schema } from '@/db';
import { randomId } from '@/lib/crypto';
import { getSettings } from '@/lib/data';
import { requireUser } from '@/lib/session';

/**
 * One wellness entry per day. Saving the same date twice updates it, because
 * athletes correct yesterday far more often than they add a second entry.
 */

export type ActionResult<T = undefined> = { ok: true; data: T } | { ok: false; error: string };

const wellnessSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  sleepHours: z.number().min(0).max(24).nullish(),
  sleepQuality: z.number().int().min(1).max(5).nullish(),
  hrvMs: z.number().int().min(5).max(300).nullish(),
  restingHr: z.number().int().min(25).max(150).nullish(),
  weightKg: z.number().min(25).max(250).nullish(),
  soreness: z.number().int().min(1).max(5).nullish(),
  mood: z.number().int().min(1).max(5).nullish(),
  stress: z.number().int().min(1).max(5).nullish(),
  feeling: z.enum(['better', 'as-expected', 'worse']).nullish(),
  notes: z.string().max(400).default('')
});

function refresh(): void {
  revalidatePath('/progress');
  revalidatePath('/plan');
}

export async function saveWellnessAction(input: unknown): Promise<ActionResult<{ date: string }>> {
  const user = await requireUser();
  const parsed = wellnessSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? 'That entry does not look right.' };

  const { date, notes } = parsed.data;
  const values = {
    sleepHours: parsed.data.sleepHours ?? null,
    sleepQuality: parsed.data.sleepQuality ?? null,
    hrvMs: parsed.data.hrvMs ?? null,
    restingHr: parsed.data.restingHr ?? null,
    weightKg: parsed.data.weightKg ?? null,
    soreness: parsed.data.soreness ?? null,
    mood: parsed.data.mood ?? null,
    stress: parsed.data.stress ?? null,
    feeling: parsed.data.feeling ?? null,
    notes,
    updatedAt: new Date()
  };

  const [existing] = await db
    .select({ id: schema.wellness.id })
    .from(schema.wellness)
    .where(and(eq(schema.wellness.userId, user.id), eq(schema.wellness.date, date)))
    .limit(1);

  if (existing) {
    await db.update(schema.wellness).set(values).where(eq(schema.wellness.id, existing.id));
  } else {
    const now = new Date();
    await db.insert(schema.wellness).values({ id: randomId(), userId: user.id, date, ...values, createdAt: now });
  }

  refresh();
  return { ok: true, data: { date } };
}

export async function deleteWellnessAction(date: string): Promise<ActionResult> {
  const user = await requireUser();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return { ok: false, error: 'Pick a day first.' };

  await db.delete(schema.wellness).where(and(eq(schema.wellness.userId, user.id), eq(schema.wellness.date, date)));
  refresh();
  return { ok: true, data: undefined };
}

/** Guards: a baseline is a number in a sane range, or nothing at all. */
const baselineSchema = z.object({
  hrvMs: z.number().int().min(5).max(300).nullish(),
  restingHr: z.number().int().min(25).max(150).nullish(),
  sleepHours: z.number().min(3).max(12).nullish(),
  maxHr: z.number().int().min(120).max(230).nullish()
});

/**
 * The athlete's own baseline numbers. Saved once and used every morning, until
 * they are cleared — clearing a value brings back the rolling 14-day average.
 */
export async function saveBaselinesAction(input: unknown): Promise<ActionResult> {
  const user = await requireUser();
  const parsed = baselineSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? 'Those baseline numbers do not look right.' };
  }

  await getSettings(user.id);
  await db
    .update(schema.userSettings)
    .set({
      baselineHrvMs: parsed.data.hrvMs === null ? null : Math.round(parsed.data.hrvMs ?? 0) || null,
      baselineRestingHr: parsed.data.restingHr === null ? null : Math.round(parsed.data.restingHr ?? 0) || null,
      baselineSleepHours: parsed.data.sleepHours ?? null,
      maxHr: parsed.data.maxHr ?? null,
      updatedAt: new Date()
    })
    .where(eq(schema.userSettings.userId, user.id));

  revalidatePath('/recovery');
  revalidatePath('/plan');
  return { ok: true, data: undefined };
}
