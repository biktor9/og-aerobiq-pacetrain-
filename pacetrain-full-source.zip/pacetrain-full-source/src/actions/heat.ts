'use server';

import { eq } from 'drizzle-orm';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { db, schema } from '@/db';
import { isHeatPeriod } from '@/domain/heat';
import { fetchMissingRoutes } from '@/lib/routes';
import { requireUser } from '@/lib/session';

/**
 * The heat map's own little settings: which patch of the world, how wide, what it
 * is called, and how far back. They live in user_settings, so the map opens on
 * the same place tomorrow.
 */

export type HeatResult = { ok: true } | { ok: false; error: string };

const areaSchema = z.object({
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  radiusKm: z.number().min(1).max(80),
  label: z.string().max(60)
});

function refresh(): void {
  revalidatePath('/plan');
}

export async function setHeatAreaAction(input: unknown): Promise<HeatResult> {
  const user = await requireUser();
  const parsed = areaSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: 'That area does not look right.' };

  await db
    .update(schema.userSettings)
    .set({
      heatLat: Math.round(parsed.data.lat * 1e5) / 1e5,
      heatLng: Math.round(parsed.data.lng * 1e5) / 1e5,
      heatRadiusKm: Math.round(parsed.data.radiusKm),
      heatLabel: parsed.data.label.trim().slice(0, 60),
      updatedAt: new Date()
    })
    .where(eq(schema.userSettings.userId, user.id));
  refresh();
  return { ok: true };
}

export async function setHeatPeriodAction(period: string): Promise<HeatResult> {
  const user = await requireUser();
  if (!isHeatPeriod(period)) return { ok: false, error: 'Pick this week, this month or this year.' };

  await db
    .update(schema.userSettings)
    .set({ heatPeriod: period, updatedAt: new Date() })
    .where(eq(schema.userSettings.userId, user.id));
  refresh();
  return { ok: true };
}

/** Reads the GPS traces the map is still missing, a dozen at a time. */
export async function loadRoutesAction(): Promise<{ ok: true; data: { loaded: number; remaining: number } } | { ok: false; error: string }> {
  const user = await requireUser();
  try {
    const result = await fetchMissingRoutes(user.id);
    refresh();
    return { ok: true, data: result };
  } catch {
    return { ok: false, error: 'intervals.icu did not answer. Try again in a moment.' };
  }
}
