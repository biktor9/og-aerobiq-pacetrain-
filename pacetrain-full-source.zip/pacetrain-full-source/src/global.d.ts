// Ambient declarations for assets imported for their side effects.
declare module '*.css';
declare module '*.svg';
