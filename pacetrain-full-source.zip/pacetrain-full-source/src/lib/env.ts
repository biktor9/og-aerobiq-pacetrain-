/**
 * Environment access. Everything is read through functions so tests can change
 * `process.env` without re-importing the module.
 */

function str(key: string, fallback = ''): string {
  const value = process.env[key];
  return value === undefined || value === null ? fallback : value.trim();
}

function num(key: string, fallback: number): number {
  const parsed = Number(str(key));
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : fallback;
}

export const APP_NAME = 'PaceTrain';

export interface AppConfig {
  baseUrl: string;
  isProd: boolean;
  allowSignup: boolean;
  adminEmails: string[];
  encryptionKey: string;
  deepseek: {
    apiKey: string;
    baseUrl: string;
    model: string;
    dailyTokenBudget: number;
    maxTokens: number;
    temperature: number;
  };
  email: {
    transport: 'console' | 'resend';
    resendApiKey: string;
    from: string;
  };
  paywall: {
    /** Off makes every page free again — useful while setting things up. */
    enabled: boolean;
    /** Where "contact developer to buy" points. Empty hides the address. */
    contactEmail: string;
  };
}

export function appConfig(): AppConfig {
  const transport = str('EMAIL_TRANSPORT', 'console').toLowerCase();
  const adminEmails = str('ADMIN_EMAILS')
    .split(',')
    .map((email) => email.trim().toLowerCase())
    .filter(Boolean);
  const emailFrom = str('EMAIL_FROM', 'PaceTrain <no-reply@pacetrain.local>');
  const fromAddress = /<([^>]+)>/.exec(emailFrom)?.[1]?.trim() ?? emailFrom.trim();

  // Who to email to buy a period: explicit setting first, then the owner's
  // admin address, then the From address if it is a real one.
  const contactEmail =
    str('CONTACT_EMAIL') || adminEmails[0] || (fromAddress && !fromAddress.endsWith('.local') ? fromAddress : '');

  return {
    baseUrl: str('BETTER_AUTH_URL', 'http://localhost:3000').replace(/\/+$/, ''),
    isProd: process.env.NODE_ENV === 'production',
    allowSignup: str('ALLOW_SIGNUP', 'true').toLowerCase() !== 'false',
    adminEmails,
    encryptionKey: str('ENCRYPTION_KEY'),
    deepseek: {
      apiKey: str('DEEPSEEK_API_KEY'),
      baseUrl: str('DEEPSEEK_BASE_URL', 'https://api.deepseek.com').replace(/\/+$/, ''),
      model: str('DEEPSEEK_MODEL', 'deepseek-chat'),
      dailyTokenBudget: num('DAILY_TOKEN_BUDGET', 1_500_000),
      maxTokens: Math.min(2000, Math.max(200, num('DEEPSEEK_MAX_TOKENS', 700))),
      temperature: 0.4
    },
    email: {
      transport: transport === 'resend' ? 'resend' : 'console',
      resendApiKey: str('RESEND_API_KEY'),
      from: emailFrom
    },
    paywall: {
      enabled: str('PAYWALL_ENABLED', 'true').toLowerCase() !== 'false',
      contactEmail
    }
  };
}

/** True when the shared key is configured, i.e. the AI coach can answer. */
export function hasSharedKey(): boolean {
  return appConfig().deepseek.apiKey.length > 0;
}
