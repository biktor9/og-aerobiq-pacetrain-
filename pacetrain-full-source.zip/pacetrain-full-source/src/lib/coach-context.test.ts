import { describe, expect, it } from 'vitest';
import { weekStats } from '@/domain/load';
import { toSession } from '@/domain/plan';
import type { Activity, DetectionResult, SessionInput } from '@/domain/types';
import {
  type CoachInput,
  buildCoachMessages,
  buildContextBlock,
  buildSystemPrompt,
  offlineAnswer,
  truncate
} from './coach-context';

function sessionInput(date: string, overrides: Partial<SessionInput> = {}): SessionInput {
  return {
    date,
    mode: 'run',
    kind: 'steady',
    title: '',
    zone: 2,
    minutes: 60,
    reps: 4,
    workMin: 8,
    recoverMin: 2,
    warmupMin: 15,
    cooldownMin: 10,
    notes: '',
    status: 'planned',
    ...overrides
  };
}

const sessions = [
  toSession({ ...sessionInput('2026-10-19'), id: 's1', linkedActivityId: null }),
  toSession({
    ...sessionInput('2026-10-21', { kind: 'intervals', zone: 4, title: 'Threshold' }),
    id: 's2',
    linkedActivityId: null
  }),
  toSession({ ...sessionInput('2026-10-24', { minutes: 90, status: 'done' }), id: 's3', linkedActivityId: null })
];

const activities: Activity[] = [
  {
    id: 'a1',
    externalId: 'i1',
    date: '2026-10-21',
    mode: 'run',
    name: 'Threshold 4x8',
    durationSec: 3780,
    distanceM: 12400,
    avgHr: 152,
    maxHr: 173,
    load: 88,
    source: 'intervals.icu',
    linkedSessionId: null
  }
];

const detection: DetectionResult = {
  metric: 'power',
  metricLabel: 'Power',
  unit: 'W',
  threshold: 312,
  reps: 4,
  segments: [],
  work: [],
  recover: [],
  durationSec: 2400,
  workTimeSec: 1920,
  recoverTimeSec: 360,
  avgWorkSec: 480,
  avgRecoverSec: 120,
  consistency: 3.2,
  driftPct: -4.1
};

function makeInput(overrides: Partial<CoachInput> = {}): CoachInput {
  const list = overrides.sessions ?? sessions;
  return {
    userName: 'Ada',
    settings: {
      goalText: 'sub-3 marathon',
      eventDate: '2027-04-11',
      weeklyMinutesTarget: 360,
      weeklyLoadTarget: 240,
      primaryMode: 'run',
      coachTone: 'direct',
      athleteNotes: 'works shifts, mornings are easier'
    },
    weekKey: '2026-W43',
    weekRange: '19–25 Oct 2026',
    sessions: list,
    stats: weekStats(list),
    previousLoad: 120,
    activities,
    latestAnalysis: { activityName: 'Threshold 4x8', result: detection, summary: '4 × 8′ efforts around 312 W.' },
    ...overrides
  };
}

describe('truncate', () => {
  it('keeps short text and cuts long text with an ellipsis', () => {
    expect(truncate('abc', 10)).toBe('abc');
    expect(truncate('a'.repeat(20), 10)).toBe(`${'a'.repeat(9)}…`);
  });
});

describe('buildContextBlock', () => {
  it('includes the athlete, the week and the imported training', () => {
    const context = buildContextBlock(makeInput());
    expect(context).toContain('ATHLETE');
    expect(context).toContain('goal: sub-3 marathon');
    expect(context).toContain('CURRENT WEEK 2026-W43');
    expect(context).toContain('totals: 3 sessions');
    expect(context).toContain('[done]');
    expect(context).toContain('RECENT ACTIVITIES');
    expect(context).toContain('Threshold 4x8');
    expect(context).toContain('avg HR 152');
    expect(context).toContain('LATEST INTERVAL ANALYSIS');
    expect(context).toContain('consistency 3.2%');
  });

  it('reports an empty week and no activities honestly', () => {
    const context = buildContextBlock(makeInput({ sessions: [], stats: weekStats([]), activities: [] }));
    expect(context).toContain('nothing planned yet');
    expect(context).toContain('none imported yet');
  });

  it('hands the coach fitness, recovery, the athlete\'s own words and the next race', () => {
    const context = buildContextBlock(
      makeInput({
        fitness: { ctl: 54.4, atl: 61.2, tsb: -6.8, label: 'Neutral' },
        recovery: {
          score: 41,
          label: 'Take it easy',
          summary: 'Something is off. Keep it easy, or move the quality session to tomorrow.',
          sick: false,
          signals: ['Overnight HRV 44 ms (−19% against your 14-day normal of 54 ms)', 'Sleep 5.2 h']
        },
        recoveryNote: 'more tired than it says, hectic week at work',
        nextRace: { name: 'Autumn half', days: 24, phase: 'peak' }
      })
    );

    expect(context).toContain('FORM, RECOVERY AND READINESS');
    expect(context).toContain('fitness 54, fatigue 61, form -7 (Neutral)');
    expect(context).toContain('recovery 41/100 (Take it easy)');
    expect(context).toContain('Overnight HRV 44 ms');
    expect(context).toContain('the athlete\'s own words this morning');
    expect(context).toContain('hectic week at work');
    expect(context).toContain('next race: Autumn half in 24 days, peak phase');
  });

  it('tells the coach when the athlete is sick', () => {
    const context = buildContextBlock(
      makeInput({
        recovery: { score: 18, label: 'Rest', summary: 'You are sick.', sick: true, signals: [] },
        illness: { from: '2026-10-22', to: '2026-10-25', symptoms: 'Sore throat, fever 38.2', severity: 2 }
      })
    );

    expect(context).toContain('SICK 2026-10-22 → 2026-10-25 (rough): Sore throat, fever 38.2');
  });

  it('leaves the section out when nothing is logged', () => {
    expect(buildContextBlock(makeInput())).not.toContain('FORM, RECOVERY AND READINESS');
  });

  it('caps the context size even with a huge athlete note', () => {
    const input = makeInput();
    input.settings.athleteNotes = 'x'.repeat(20_000);
    expect(buildContextBlock(input).length).toBeLessThanOrEqual(6000);
  });
});

describe('buildSystemPrompt', () => {
  it('sets the role, the tone and the guardrails', () => {
    const prompt = buildSystemPrompt(makeInput(), 'ATHLETE\nname: Ada');
    expect(prompt).toContain('PaceTrain');
    expect(prompt).toContain('Be direct and specific');
    expect(prompt).toContain('Never diagnose injuries');
    expect(prompt).toContain('ATHLETE\nname: Ada');
  });

  it('switches tone', () => {
    const input = makeInput();
    input.settings.coachTone = 'analytical';
    expect(buildSystemPrompt(input, '')).toContain('Be analytical');
  });
});

describe('buildCoachMessages', () => {
  it('puts the system prompt first, history in the middle and the question last', () => {
    const messages = buildCoachMessages(
      makeInput(),
      [
        { role: 'user', content: 'How was my week?' },
        { role: 'assistant', content: 'Solid, three sessions.' }
      ],
      'What should I do tomorrow?'
    );
    expect(messages[0].role).toBe('system');
    expect(messages).toHaveLength(4);
    expect(messages.at(-1)).toEqual({ role: 'user', content: 'What should I do tomorrow?' });
  });

  it('keeps only the last eight history messages', () => {
    const history = Array.from({ length: 20 }, (_, i) => ({
      role: (i % 2 === 0 ? 'user' : 'assistant') as 'user' | 'assistant',
      content: `message ${i}`
    }));
    const messages = buildCoachMessages(makeInput(), history, 'next?');
    expect(messages).toHaveLength(10);
    expect(messages[1].content).toBe('message 12');
  });

  it('drops empty history and caps the question', () => {
    const messages = buildCoachMessages(makeInput(), [{ role: 'user', content: '   ' }], 'q'.repeat(5000));
    expect(messages).toHaveLength(2);
    expect(messages.at(-1)?.content.length).toBe(1500);
  });
});

describe('offlineAnswer', () => {
  it('summarises the week and suggests something concrete', () => {
    const answer = offlineAnswer(makeInput(), 'What should I do next?');
    expect(answer).toContain('This week');
    expect(answer).toContain('Next session');
    expect(answer).toContain('built-in rule engine');
  });

  it('mentions the interval analysis when asked about intervals', () => {
    expect(offlineAnswer(makeInput(), 'How were my reps?')).toContain('Latest interval analysis');
  });

  it('says so when there is nothing planned', () => {
    const answer = offlineAnswer(makeInput({ sessions: [], stats: weekStats([]), previousLoad: 0 }), 'Plan my week');
    expect(answer).toContain('nothing is planned yet');
  });

  it('flags a big load jump', () => {
    const answer = offlineAnswer(makeInput({ previousLoad: 50 }), 'How is my load?');
    expect(answer).toContain('load jumped');
  });
});
