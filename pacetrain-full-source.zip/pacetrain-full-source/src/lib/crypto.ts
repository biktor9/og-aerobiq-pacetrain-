import crypto from 'node:crypto';
import { appConfig } from './env';

/**
 * Small helpers for secrets that must be stored at rest: intervals.icu API keys
 * and personal DeepSeek keys. AES-256-GCM with a random IV per value, so the
 * same key never produces the same ciphertext twice.
 */

const VERSION = 'v1';

function keyBuffer(): Buffer {
  const raw = appConfig().encryptionKey;
  if (!raw) {
    throw new Error('ENCRYPTION_KEY is not set. Generate one with `openssl rand -base64 32`.');
  }
  const buf = raw.length === 64 && /^[0-9a-f]+$/i.test(raw) ? Buffer.from(raw, 'hex') : Buffer.from(raw, 'base64');
  if (buf.length !== 32) {
    throw new Error('ENCRYPTION_KEY must decode to exactly 32 bytes (base64 or hex).');
  }
  return buf;
}

export function encryptSecret(plaintext: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', keyBuffer(), iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  return [VERSION, iv.toString('base64'), cipher.getAuthTag().toString('base64'), ciphertext.toString('base64')].join(
    ':'
  );
}

export function decryptSecret(payload: string): string {
  const parts = payload.split(':');
  if (parts.length !== 4 || parts[0] !== VERSION) {
    throw new Error('Encrypted value is not in the expected format.');
  }
  const [, iv, tag, data] = parts;
  const decipher = crypto.createDecipheriv('aes-256-gcm', keyBuffer(), Buffer.from(iv, 'base64'));
  decipher.setAuthTag(Buffer.from(tag, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(data, 'base64')), decipher.final()]).toString('utf8');
}

export function secretLast4(secret: string): string {
  return secret.slice(-4);
}

export function randomId(bytes = 16): string {
  return crypto.randomBytes(bytes).toString('base64url');
}

export function sha256(value: string): string {
  return crypto.createHash('sha256').update(value).digest('hex');
}

/** Never log a secret: `sk-…a1b2`. */
export function maskSecret(secret: string): string {
  if (!secret) return '';
  if (secret.length <= 8) return '••••';
  return `${secret.slice(0, 3)}…${secret.slice(-4)}`;
}
