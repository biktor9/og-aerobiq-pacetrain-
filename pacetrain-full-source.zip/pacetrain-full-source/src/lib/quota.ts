/**
 * Quota rules for the shared DeepSeek key. Pure functions: the caller reads the
 * counters from SQLite and this decides what to answer with.
 */

export interface QuotaLimits {
  perHour: number;
  perDay: number;
}

export interface QuotaInput {
  /** Whole days since the account was created. */
  accountAgeDays: number;
  /** The user pasted their own DeepSeek key: their cost, no limits. */
  hasOwnKey: boolean;
  requestsLastHour: number;
  requestsToday: number;
  globalTokensToday: number;
  dailyTokenBudget: number;
}

export type QuotaReason = 'ok' | 'own-key' | 'hourly' | 'daily' | 'budget';

export interface QuotaDecision {
  allowed: boolean;
  reason: QuotaReason;
  message: string;
  limits: QuotaLimits;
  remainingHour: number;
  remainingDay: number;
  unlimited: boolean;
}

export const NEW_ACCOUNT_LIMITS: QuotaLimits = { perHour: 10, perDay: 30 };
export const ACTIVE_ACCOUNT_LIMITS: QuotaLimits = { perHour: 25, perDay: 100 };
export const NEW_ACCOUNT_DAYS = 7;

export function quotaLimits(input: Pick<QuotaInput, 'accountAgeDays' | 'hasOwnKey'>): QuotaLimits {
  if (input.hasOwnKey) return { perHour: Number.POSITIVE_INFINITY, perDay: Number.POSITIVE_INFINITY };
  return input.accountAgeDays >= NEW_ACCOUNT_DAYS ? ACTIVE_ACCOUNT_LIMITS : NEW_ACCOUNT_LIMITS;
}

export function decideQuota(input: QuotaInput): QuotaDecision {
  const limits = quotaLimits(input);
  const unlimited = !Number.isFinite(limits.perDay);

  if (input.hasOwnKey) {
    return {
      allowed: true,
      reason: 'own-key',
      message: 'Using your own DeepSeek key — no shared-key limits apply.',
      limits,
      remainingHour: Number.POSITIVE_INFINITY,
      remainingDay: Number.POSITIVE_INFINITY,
      unlimited
    };
  }

  const remainingHour = Math.max(0, limits.perHour - input.requestsLastHour);
  const remainingDay = Math.max(0, limits.perDay - input.requestsToday);

  if (input.dailyTokenBudget > 0 && input.globalTokensToday >= input.dailyTokenBudget) {
    return {
      allowed: false,
      reason: 'budget',
      message:
        'The shared AI budget for today is used up. It resets at 00:00 UTC — or add your own DeepSeek key in Settings to keep going.',
      limits,
      remainingHour,
      remainingDay,
      unlimited
    };
  }

  if (remainingHour <= 0) {
    return {
      allowed: false,
      reason: 'hourly',
      message: `You have used all ${limits.perHour} coach messages for this hour. Try again in a few minutes, or add your own key in Settings.`,
      limits,
      remainingHour: 0,
      remainingDay,
      unlimited
    };
  }

  if (remainingDay <= 0) {
    return {
      allowed: false,
      reason: 'daily',
      message: `You have used all ${limits.perDay} coach messages for today. The limit resets at 00:00 UTC, or add your own key in Settings.`,
      limits,
      remainingHour,
      remainingDay: 0,
      unlimited
    };
  }

  return {
    allowed: true,
    reason: 'ok',
    message: '',
    limits,
    remainingHour,
    remainingDay,
    unlimited
  };
}

/** Rough token estimate: ~4 characters per token, the usual English ratio. */
export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

export function dollarsForTokens(tokens: number): string {
  // deepseek-chat list price is small enough that showing cents is enough.
  return `$${(tokens * 0.0000005).toFixed(4)}`;
}

export function utcDay(date = new Date()): string {
  return date.toISOString().slice(0, 10);
}

/** Whole days between two instants, used for the "new account" window. */
export function daysBetween(from: Date, to = new Date()): number {
  return Math.max(0, Math.floor((to.getTime() - from.getTime()) / 86_400_000));
}
