import { drizzleAdapter } from '@better-auth/drizzle-adapter';
import { betterAuth } from 'better-auth';
import { nextCookies } from 'better-auth/next-js';
import { db, schema } from '@/db';
import { resetPasswordMail, sendMail } from './email';
import { appConfig } from './env';

const config = appConfig();

function authSecret(): string {
  const secret = process.env.BETTER_AUTH_SECRET?.trim();
  if (secret) return secret;
  if (process.env.NODE_ENV === 'production') {
    throw new Error('BETTER_AUTH_SECRET is required in production. Generate one with `openssl rand -hex 32`.');
  }
  return 'pacetrain-insecure-development-secret';
}

export const auth = betterAuth({
  appName: 'PaceTrain',
  secret: authSecret(),
  baseURL: config.baseUrl,
  trustedOrigins: [config.baseUrl],
  telemetry: { enabled: false },

  database: drizzleAdapter(db, {
    provider: 'sqlite',
    schema
  }),

  emailAndPassword: {
    enabled: true,
    // The address is confirmed by the athlete inside the sign-up form ("is this
    // really your address?"), so no mail round-trip stands between sign-up and
    // the first session. Password reset still goes out by mail.
    minPasswordLength: 8,
    maxPasswordLength: 128,
    autoSignIn: true,
    disableSignUp: !config.allowSignup,
    revokeSessionsOnPasswordReset: true,
    sendResetPassword: async ({ user, url }) => {
      try {
        await sendMail(resetPasswordMail(user.email, user.name ?? '', url));
      } catch (error) {
        // Never leak delivery problems to the caller: the response is the same
        // whether or not the address exists.
        console.error('[auth] could not send reset mail:', error);
      }
    }
  },

  session: {
    expiresIn: 60 * 60 * 24 * 30, // 30 days
    updateAge: 60 * 60 * 24, // refresh the expiry once a day
    cookieCache: { enabled: true, maxAge: 5 * 60 }
  },

  user: {
    additionalFields: {
      role: {
        type: 'string',
        required: false,
        defaultValue: 'user',
        input: false
      }
    }
  },

  rateLimit: {
    enabled: true,
    window: 60,
    max: 30,
    customRules: {
      '/sign-in/email': { window: 15 * 60, max: 10 },
      '/sign-up/email': { window: 60 * 60, max: 5 },
      '/request-password-reset': { window: 60 * 60, max: 5 }
    }
  },

  databaseHooks: {
    user: {
      create: {
        before: async (user) => {
          const email = String(user.email ?? '').toLowerCase();
          const role = config.adminEmails.includes(email) ? 'admin' : 'user';
          return { data: { ...user, role } };
        },
        after: async (user) => {
          // Every account gets a settings row, so the planner never has to
          // deal with a missing profile.
          await db
            .insert(schema.userSettings)
            .values({ userId: user.id, createdAt: new Date(), updatedAt: new Date() })
            .onConflictDoNothing();
        }
      }
    }
  },

  plugins: [nextCookies()]
});

export type Auth = typeof auth;
