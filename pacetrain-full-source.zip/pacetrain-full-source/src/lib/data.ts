import { and, desc, eq, gte, lte, sql } from 'drizzle-orm';
import { db, schema } from '@/db';
import {
  isPlanId,
  isSubscriptionSource,
  type SubscriptionRecord
} from '@/domain/billing';
import { isPriority, type RaceEvent } from '@/domain/events';
import { isPageKey, type PageKey } from '@/domain/page-notes';
import { normalizeMode, type Activity, type ModeId, type Session, type SessionKind, type SessionStatus } from '@/domain/types';
import { isFeeling, type WellnessEntry } from '@/domain/wellness';
import type { SickNote } from '@/domain/recovery';
import { sessionLoad } from '@/domain/load';
import { parseStructureJson, toSession } from '@/domain/plan';
import { addDays, startOfWeek, toISODate } from '@/domain/week';

type SessionRow = typeof schema.plannedSessions.$inferSelect;
type ActivityRow = typeof schema.activities.$inferSelect;
type SettingsRow = typeof schema.userSettings.$inferSelect;
type IcuRow = typeof schema.icuCredentials.$inferSelect;

export function rowToSession(row: SessionRow): Session {
  return toSession({
    id: row.id,
    date: row.date,
    mode: row.mode as ModeId,
    kind: row.kind as SessionKind,
    title: row.title,
    zone: row.zone,
    minutes: row.minutes,
    targetKm: row.targetKm,
    reps: row.reps,
    workMin: row.workMin,
    recoverMin: row.recoverMin,
    warmupMin: row.warmupMin,
    cooldownMin: row.cooldownMin,
    warmupKm: row.warmupKm,
    cooldownKm: row.cooldownKm,
    targetReps: row.targetReps,
    notes: row.notes,
    status: row.status as SessionStatus,
    structure: parseStructureJson(row.structureJson),
    linkedActivityId: row.linkedActivityId
  });
}

/** `"600,1800,900,0,0"` → `[600, 1800, 900, 0, 0]`, or null when nothing is stored. */
export function parseZoneTimes(value: string | null | undefined): number[] | null {
  if (!value) return null;
  const parts = value
    .split(',')
    .map((part) => Number(part))
    .filter((part) => Number.isFinite(part) && part >= 0);
  return parts.length ? parts.slice(0, 5) : null;
}

export function rowToActivity(row: ActivityRow): Activity {
  return {
    id: row.id,
    externalId: row.externalId,
    date: row.date,
    mode: row.mode as ModeId,
    name: row.name,
    durationSec: row.durationSec,
    distanceM: row.distanceM,
    avgHr: row.avgHr,
    maxHr: row.maxHr,
    load: row.load,
    avgSpeedMs: row.avgSpeedMs ?? null,
    hrZoneSec: parseZoneTimes(row.hrZoneTimes),
    source: row.source as Activity['source'],
    linkedSessionId: null,
    rpe: row.rpe,
    feel: row.feel,
    notes: row.notes,
    removed: row.removed
  };
}

export async function listSessionsBetween(userId: string, from: string, to: string): Promise<Session[]> {
  const rows = await db
    .select()
    .from(schema.plannedSessions)
    .where(
      and(
        eq(schema.plannedSessions.userId, userId),
        gte(schema.plannedSessions.date, from),
        lte(schema.plannedSessions.date, to)
      )
    )
    .orderBy(schema.plannedSessions.date, schema.plannedSessions.createdAt);
  return rows.map(rowToSession);
}

export async function weekSessions(userId: string, monday: Date): Promise<Session[]> {
  return listSessionsBetween(userId, toISODate(monday), toISODate(addDays(monday, 6)));
}

export async function previousWeekLoad(userId: string, monday: Date): Promise<number> {
  const previous = await listSessionsBetween(userId, toISODate(addDays(monday, -7)), toISODate(addDays(monday, -1)));
  return previous.reduce((total, session) => total + sessionLoad(session), 0);
}

export async function getSessionById(userId: string, id: string): Promise<Session | null> {
  const [row] = await db
    .select()
    .from(schema.plannedSessions)
    .where(and(eq(schema.plannedSessions.userId, userId), eq(schema.plannedSessions.id, id)))
    .limit(1);
  return row ? rowToSession(row) : null;
}

export async function countSessions(userId: string): Promise<number> {
  const [row] = await db
    .select({ count: sql<number>`count(*)` })
    .from(schema.plannedSessions)
    .where(eq(schema.plannedSessions.userId, userId));
  return Number(row?.count ?? 0);
}

export async function listActivities(userId: string, limit = 60): Promise<Activity[]> {
  const rows = await db
    .select()
    .from(schema.activities)
    .where(and(eq(schema.activities.userId, userId), eq(schema.activities.removed, false)))
    .orderBy(desc(schema.activities.date), desc(schema.activities.createdAt))
    .limit(limit);
  return rows.map(rowToActivity);
}

export async function activitiesSince(userId: string, fromISO: string): Promise<Activity[]> {
  const rows = await db
    .select()
    .from(schema.activities)
    .where(
      and(
        eq(schema.activities.userId, userId),
        eq(schema.activities.removed, false),
        gte(schema.activities.date, fromISO)
      )
    )
    .orderBy(desc(schema.activities.date))
    .limit(40);
  return rows.map(rowToActivity);
}

/** Activities whose date falls inside `from`–`to`, newest first. */
export async function activitiesBetween(
  userId: string,
  fromISO: string,
  toISO: string,
  limit = 500
): Promise<Activity[]> {
  const rows = await db
    .select()
    .from(schema.activities)
    .where(
      and(
        eq(schema.activities.userId, userId),
        eq(schema.activities.removed, false),
        gte(schema.activities.date, fromISO),
        lte(schema.activities.date, toISO)
      )
    )
    .orderBy(desc(schema.activities.date), desc(schema.activities.durationSec))
    .limit(limit);
  return rows.map(rowToActivity);
}

export async function countActivities(userId: string): Promise<number> {
  const [row] = await db
    .select({ count: sql<number>`count(*)` })
    .from(schema.activities)
    .where(and(eq(schema.activities.userId, userId), eq(schema.activities.removed, false)));
  return Number(row?.count ?? 0);
}

export async function getActivity(userId: string, id: string): Promise<Activity | null> {
  const [row] = await db
    .select()
    .from(schema.activities)
    .where(
      and(eq(schema.activities.userId, userId), eq(schema.activities.id, id), eq(schema.activities.removed, false))
    )
    .limit(1);
  return row ? rowToActivity(row) : null;
}

/** Fields the athlete may correct on an imported activity. */
export interface ActivityUpdate {
  name?: string;
  date?: string;
  mode?: ModeId;
  durationSec?: number;
  distanceM?: number;
  avgHr?: number | null;
  maxHr?: number | null;
  load?: number | null;
  rpe?: number | null;
  feel?: number | null;
  notes?: string;
}

/**
 * Local corrections to an imported activity. The ICU import only inserts new
 * rows (`onConflictDoNothing`), so an edit here survives the next sync.
 */
export async function updateActivity(userId: string, id: string, patch: ActivityUpdate): Promise<void> {
  await db
    .update(schema.activities)
    .set(patch)
    .where(and(eq(schema.activities.userId, userId), eq(schema.activities.id, id)));
}

/** Soft delete, so a re-import cannot bring a removed activity back. */
export async function setActivityRemoved(userId: string, id: string, removed: boolean): Promise<void> {
  await db
    .update(schema.activities)
    .set({ removed })
    .where(and(eq(schema.activities.userId, userId), eq(schema.activities.id, id)));
}

export async function getSettings(userId: string): Promise<SettingsRow> {
  const [existing] = await db
    .select()
    .from(schema.userSettings)
    .where(eq(schema.userSettings.userId, userId))
    .limit(1);
  if (existing) return existing;

  const now = new Date();
  await db
    .insert(schema.userSettings)
    .values({ userId, createdAt: now, updatedAt: now })
    .onConflictDoNothing();
  const [created] = await db
    .select()
    .from(schema.userSettings)
    .where(eq(schema.userSettings.userId, userId))
    .limit(1);
  return created;
}

export async function getIcuCredentials(userId: string): Promise<IcuRow | null> {
  const [row] = await db
    .select()
    .from(schema.icuCredentials)
    .where(eq(schema.icuCredentials.userId, userId))
    .limit(1);
  return row ?? null;
}

export interface CachedAnalysis {
  id: string;
  activityId: string;
  paramsJson: string;
  summary: string;
  reps: number;
  result: DetectionResultLike;
  createdAt: Date;
}

type DetectionResultLike = import('@/domain/types').DetectionResult;

function rowToAnalysis(row: typeof schema.analyses.$inferSelect): CachedAnalysis {
  return {
    id: row.id,
    activityId: row.activityId,
    paramsJson: row.paramsJson,
    summary: row.summary,
    reps: row.reps,
    result: JSON.parse(row.resultJson) as DetectionResultLike,
    createdAt: row.createdAt
  };
}

export async function latestAnalyses(userId: string, limit = 10): Promise<CachedAnalysis[]> {
  const rows = await db
    .select()
    .from(schema.analyses)
    .where(eq(schema.analyses.userId, userId))
    .orderBy(desc(schema.analyses.createdAt))
    .limit(limit);
  return rows.map(rowToAnalysis);
}

export async function latestAnalysisFor(userId: string, activityId: string): Promise<CachedAnalysis | null> {
  const [row] = await db
    .select()
    .from(schema.analyses)
    .where(and(eq(schema.analyses.userId, userId), eq(schema.analyses.activityId, activityId)))
    .orderBy(desc(schema.analyses.createdAt))
    .limit(1);
  return row ? rowToAnalysis(row) : null;
}

export async function chatHistory(
  userId: string,
  limit = 20
): Promise<{ role: 'user' | 'assistant'; content: string }[]> {
  const rows = await db
    .select({ role: schema.chatMessages.role, content: schema.chatMessages.content })
    .from(schema.chatMessages)
    .where(eq(schema.chatMessages.userId, userId))
    .orderBy(desc(schema.chatMessages.createdAt))
    .limit(limit);
  return rows
    .reverse()
    .filter((row) => row.role === 'user' || row.role === 'assistant')
    .map((row) => ({ role: row.role as 'user' | 'assistant', content: row.content }));
}

export function currentWeekStart(): Date {
  return startOfWeek(new Date());
}

type WellnessRow = typeof schema.wellness.$inferSelect;
type EventRow = typeof schema.events.$inferSelect;

function rowToWellness(row: WellnessRow): WellnessEntry {
  return {
    date: row.date,
    sleepHours: row.sleepHours,
    sleepQuality: row.sleepQuality,
    hrvMs: row.hrvMs,
    restingHr: row.restingHr,
    weightKg: row.weightKg,
    soreness: row.soreness,
    mood: row.mood,
    stress: row.stress,
    feeling: isFeeling(row.feeling) ? row.feeling : null,
    notes: row.notes
  };
}

type SickRow = typeof schema.sickNotes.$inferSelect;

function rowToSickNote(row: SickRow): SickNote {
  return {
    id: row.id,
    dateFrom: row.dateFrom,
    dateTo: row.dateTo,
    symptoms: row.symptoms,
    severity: row.severity,
    notes: row.notes
  };
}

/** Illnesses, newest first. */
export async function listSickNotes(userId: string, limit = 20): Promise<SickNote[]> {
  const rows = await db
    .select()
    .from(schema.sickNotes)
    .where(eq(schema.sickNotes.userId, userId))
    .orderBy(desc(schema.sickNotes.dateFrom))
    .limit(limit);
  return rows.map(rowToSickNote);
}

/** Illnesses that overlap a window — used by the calendar and the recovery page. */
export async function sickNotesCovering(userId: string, fromISO: string, toISO: string): Promise<SickNote[]> {
  const rows = await db
    .select()
    .from(schema.sickNotes)
    .where(
      and(
        eq(schema.sickNotes.userId, userId),
        lte(schema.sickNotes.dateFrom, toISO),
        gte(schema.sickNotes.dateTo, fromISO)
      )
    )
    .orderBy(desc(schema.sickNotes.dateFrom));
  return rows.map(rowToSickNote);
}

function rowToEvent(row: EventRow): RaceEvent {
  return {
    id: row.id,
    name: row.name,
    date: row.date,
    mode: normalizeMode(row.mode),
    priority: isPriority(row.priority) ? row.priority : 'A',
    distanceKm: row.distanceKm,
    targetTimeSec: row.targetTimeSec,
    notes: row.notes
  };
}

/** Wellness entries between two dates, oldest first. */
export async function wellnessBetween(userId: string, fromISO: string, toISO: string): Promise<WellnessEntry[]> {
  const rows = await db
    .select()
    .from(schema.wellness)
    .where(and(eq(schema.wellness.userId, userId), gte(schema.wellness.date, fromISO), lte(schema.wellness.date, toISO)))
    .orderBy(schema.wellness.date);
  return rows.map(rowToWellness);
}

/** The last `days` days of wellness, oldest first. */
export async function recentWellness(userId: string, days = 60): Promise<WellnessEntry[]> {
  const today = new Date();
  return wellnessBetween(userId, toISODate(addDays(today, -(days - 1))), toISODate(today));
}

export async function listEvents(userId: string): Promise<RaceEvent[]> {
  const rows = await db
    .select()
    .from(schema.events)
    .where(eq(schema.events.userId, userId))
    .orderBy(schema.events.date);
  return rows.map(rowToEvent);
}

/** Races from today onwards, soonest first. */
export async function upcomingEvents(userId: string, limit = 5): Promise<RaceEvent[]> {
  const rows = await db
    .select()
    .from(schema.events)
    .where(and(eq(schema.events.userId, userId), gte(schema.events.date, toISODate(new Date()))))
    .orderBy(schema.events.date)
    .limit(limit);
  return rows.map(rowToEvent);
}

type SubscriptionRow = typeof schema.subscriptions.$inferSelect;

function rowToSubscription(row: SubscriptionRow): SubscriptionRecord {
  return {
    id: row.id,
    plan: isPlanId(row.plan) ? row.plan : 'halfYear',
    status: row.status === 'canceled' ? 'canceled' : 'active',
    source: isSubscriptionSource(row.source) ? row.source : 'manual',
    amountSek: row.amountSek,
    reference: row.reference,
    note: row.note,
    startedAt: row.startedAt.toISOString(),
    expiresAt: row.expiresAt.toISOString()
  };
}

/** Every purchase and grant, newest first. */
export async function subscriptionHistory(userId: string, limit = 20): Promise<SubscriptionRecord[]> {
  const rows = await db
    .select()
    .from(schema.subscriptions)
    .where(eq(schema.subscriptions.userId, userId))
    .orderBy(desc(schema.subscriptions.createdAt))
    .limit(limit);
  return rows.map(rowToSubscription);
}

/** The period that ends last — the one access is decided by. */
export async function currentSubscription(userId: string): Promise<SubscriptionRecord | null> {
  const [row] = await db
    .select()
    .from(schema.subscriptions)
    .where(eq(schema.subscriptions.userId, userId))
    .orderBy(desc(schema.subscriptions.expiresAt))
    .limit(1);
  return row ? rowToSubscription(row) : null;
}

/**
 * The notes admins have pinned to the tabs, keyed by page. A single read for the
 * whole app shell, so every tab gets its own note without its own query.
 */
export async function pageNotes(): Promise<Partial<Record<PageKey, string>>> {
  const rows = await db.select().from(schema.pageNotes);
  const notes: Partial<Record<PageKey, string>> = {};
  for (const row of rows) {
    if (isPageKey(row.page)) notes[row.page] = row.body;
  }
  return notes;
}

/** One tab's note, or null when nobody has written one. */
export async function pageNote(page: PageKey): Promise<string | null> {
  const [row] = await db
    .select()
    .from(schema.pageNotes)
    .where(eq(schema.pageNotes.page, page))
    .limit(1);
  return row?.body ?? null;
}


