import { afterEach, describe, expect, it, vi } from 'vitest';
import { describeDeepSeekError, parseDeepSeekChunk, sseData, streamDeepSeek } from './deepseek';

function streamOf(chunks: string[]): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();
  return new ReadableStream({
    start(controller) {
      for (const chunk of chunks) controller.enqueue(encoder.encode(chunk));
      controller.close();
    }
  });
}

async function collect(stream: ReadableStream<Uint8Array>): Promise<string[]> {
  const out: string[] = [];
  for await (const payload of sseData(stream)) out.push(payload);
  return out;
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('sseData', () => {
  it('splits events on blank lines', async () => {
    expect(await collect(streamOf(['data: one\n\ndata: two\n\n']))).toEqual(['one', 'two']);
  });

  it('reassembles events split across network chunks', async () => {
    expect(await collect(streamOf(['data: {"a"', ':1}\n', '\ndata: two\n\n']))).toEqual(['{"a":1}', 'two']);
  });

  it('handles CRLF framing', async () => {
    expect(await collect(streamOf(['data: one\r\n\r\ndata: two\r\n\r\n']))).toEqual(['one', 'two']);
  });

  it('ignores comments, other fields and empty data lines', async () => {
    expect(await collect(streamOf([': keep-alive\n\nevent: ping\n\ndata: \n\ndata: real\n\n']))).toEqual(['real']);
  });

  it('flushes a final event that has no trailing blank line', async () => {
    expect(await collect(streamOf(['data: last']))).toEqual(['last']);
  });
});

describe('parseDeepSeekChunk', () => {
  it('reads streamed content deltas', () => {
    const chunk = parseDeepSeekChunk('{"choices":[{"delta":{"content":"Hello"}}]}');
    expect(chunk.text).toBe('Hello');
    expect(chunk.done).toBe(false);
  });

  it('reads the finish marker', () => {
    expect(parseDeepSeekChunk('[DONE]').done).toBe(true);
  });

  it('reads usage from the final frame', () => {
    const chunk = parseDeepSeekChunk('{"choices":[],"usage":{"prompt_tokens":120,"completion_tokens":45}}');
    expect(chunk).toMatchObject({ promptTokens: 120, completionTokens: 45 });
  });

  it('ignores malformed frames instead of throwing', () => {
    expect(parseDeepSeekChunk('not json')).toMatchObject({ text: '', done: false });
  });

  it('tolerates a null content delta', () => {
    expect(parseDeepSeekChunk('{"choices":[{"delta":{"content":null}}]}').text).toBe('');
  });
});

describe('describeDeepSeekError', () => {
  it('explains the common failures', () => {
    expect(describeDeepSeekError(401, '')).toMatch(/API key/);
    expect(describeDeepSeekError(402, '')).toMatch(/credit/);
    expect(describeDeepSeekError(429, '')).toMatch(/rate limiting/);
    expect(describeDeepSeekError(500, '')).toMatch(/server error/);
    expect(describeDeepSeekError(418, 'teapot')).toContain('teapot');
  });
});

describe('streamDeepSeek', () => {
  async function run(options: { messages: { role: 'user' | 'system'; content: string }[] }) {
    const events = [];
    for await (const event of streamDeepSeek({
      apiKey: 'test-key',
      baseUrl: 'https://api.deepseek.com',
      model: 'deepseek-chat',
      messages: options.messages
    })) {
      events.push(event);
    }
    return events;
  }

  it('yields deltas, then a usage summary', async () => {
    const fetchMock = vi.fn(
      async () =>
        new Response(
          streamOf([
            'data: {"choices":[{"delta":{"content":"Run "}}]}\n\n',
            'data: {"choices":[{"delta":{"content":"4x8."}}]}\n\n',
            'data: {"choices":[],"usage":{"prompt_tokens":50,"completion_tokens":7}}\n\n',
            'data: [DONE]\n\n'
          ]),
          { status: 200 }
        )
    );
    vi.stubGlobal('fetch', fetchMock);

    const events = await run({ messages: [{ role: 'user', content: 'hi' }] });
    const text = events
      .filter((event) => event.type === 'delta')
      .map((event) => (event as { text: string }).text)
      .join('');

    expect(text).toBe('Run 4x8.');
    expect(events.at(-1)).toEqual({ type: 'done', usage: { promptTokens: 50, completionTokens: 7 } });

    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe('https://api.deepseek.com/chat/completions');
    expect((init.headers as Record<string, string>).Authorization).toBe('Bearer test-key');
    const body = JSON.parse(String(init.body));
    expect(body).toMatchObject({ model: 'deepseek-chat', stream: true, max_tokens: 700 });
  });

  it('estimates usage when the provider sends none', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(streamOf(['data: {"choices":[{"delta":{"content":"abcd"}}]}\n\ndata: [DONE]\n\n'])))
    );
    const events = await run({ messages: [{ role: 'system', content: 'aaaaaaaa' }] });
    const done = events.at(-1) as { usage: { promptTokens: number; completionTokens: number } };
    expect(done.usage.promptTokens).toBe(2);
    expect(done.usage.completionTokens).toBe(1);
  });

  it('turns an HTTP failure into a readable error event', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('insufficient balance', { status: 402 })));
    const events = await run({ messages: [] });
    expect(events).toHaveLength(1);
    expect(events[0].type).toBe('error');
  });

  it('survives a network failure', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => {
        throw new Error('ECONNRESET');
      })
    );
    const events = await run({ messages: [] });
    expect(events[0]).toMatchObject({ type: 'error' });
    expect((events[0] as { message: string }).message).toContain('Could not reach DeepSeek');
  });
});
