import { type DetectionResult, type MetricId, type ModeId } from '@/domain/types';
import { isLatLng, simplifyRoute, type LatLng } from '@/domain/geo';

/**
 * Minimal intervals.icu client. Credentials are only ever used on the server:
 * they are decrypted per request and never sent to the browser.
 */

export const ICU_BASE = 'https://intervals.icu/api/v1';

export interface IcuConfig {
  athleteId: string;
  apiKey: string;
}

export class IcuError extends Error {
  constructor(
    message: string,
    readonly status: number
  ) {
    super(message);
    this.name = 'IcuError';
  }
}

function authHeader(apiKey: string): string {
  return `Basic ${Buffer.from(`API_KEY:${apiKey}`).toString('base64')}`;
}

async function icuFetch<T>(path: string, config: IcuConfig, signal?: AbortSignal): Promise<T> {
  const response = await fetch(`${ICU_BASE}${path}`, {
    headers: {
      Authorization: authHeader(config.apiKey),
      Accept: 'application/json'
    },
    cache: 'no-store',
    signal
  });

  if (response.status === 401 || response.status === 403) {
    throw new IcuError('intervals.icu rejected the API key or athlete ID.', response.status);
  }
  if (response.status === 404) {
    throw new IcuError('intervals.icu could not find that athlete or activity.', 404);
  }
  if (!response.ok) {
    throw new IcuError(`intervals.icu responded ${response.status}.`, response.status);
  }
  return (await response.json()) as T;
}

export interface IcuActivityRaw {
  id: string;
  start_date_local?: string;
  start_date?: string;
  type?: string;
  name?: string;
  /** `COROS`, `STRAVA`, `GARMIN`, … */
  source?: string;
  moving_time?: number;
  elapsed_time?: number;
  distance?: number;
  /** intervals.icu's own moving-speed average, in m/s. */
  average_speed?: number;
  average_heartrate?: number | null;
  max_heartrate?: number | null;
  icu_training_load?: number | null;
  /**
   * Seconds in each heart-rate zone, Z1 … Z5, when intervals.icu has computed
   * them. Much better than estimating from the average, so it is preferred.
   */
  hr_zone_times?: number[] | null;
  /** Seconds in each power zone, Z1 … Z5 (and up). Unused, but harmless. */
  power_zone_times?: number[] | null;
  /** Set by intervals.icu when it will not hand the activity over. */
  _note?: string;
}

/** An activity intervals.icu lists but refuses to serve, usually because of Strava. */
export interface UnavailableActivity {
  externalId: string;
  date: string;
  source: string;
  note: string;
}

/**
 * Strava activities reach intervals.icu but may not be served over its API, so
 * the list contains a stub: an id, a start time, `source: "STRAVA"` and a note,
 * with no sport, name, time or distance. Importing one used to create a 0 s /
 * 0 m activity out of thin air.
 */
export function isUnavailableActivity(raw: IcuActivityRaw): boolean {
  if (raw._note && /not available/i.test(raw._note)) return true;
  return (
    raw.type === undefined &&
    !raw.name &&
    raw.moving_time === undefined &&
    raw.elapsed_time === undefined &&
    raw.distance === undefined
  );
}

export interface ActivityFetch {
  activities: ActivityDraft[];
  /** The stubs that were left out, so the athlete can be told why. */
  unavailable: UnavailableActivity[];
}

export interface ActivityDraft {
  externalId: string;
  date: string;
  mode: ModeId;
  name: string;
  durationSec: number;
  distanceM: number;
  avgHr: number | null;
  maxHr: number | null;
  load: number | null;
  /** intervals.icu's average moving speed in m/s, which is what its pace shows. */
  avgSpeedMs: number | null;
  /** Seconds in heart-rate zones Z1 … Z5 when the platform computed them. */
  hrZoneSec: number[] | null;
}

/**
 * intervals.icu reports the sport in the Strava-style `type` field. The rules
 * are ordered from the most specific to the most generic so that, for example,
 * mountain biking never lands in the road-bike bucket.
 */
export function mapActivityType(type: string | undefined): ModeId {
  const t = (type ?? '').toLowerCase().replace(/[^a-z]/g, '');
  if (!t) return 'run';

  if (/mtb|mountainbike|emountainbike/.test(t)) return 'mtb';
  if (/orient/.test(t)) return 'orienteering';
  if (/trail|hike|fell/.test(t)) return 'trail';
  if (/rollerski|skateski|skierg|nordicski|crosscountryski|backcountryski|alpineski|snowboard|biathlon|ski|iceskate|inlineskate/.test(t))
    return 'ski';
  if (/ride|bike|cycling|gravel|ebike|virtualride|indoorcycling|trainer|velomobile|handcycle/.test(t)) return 'bike';
  if (/weight|strength|gym|workout|crossfit|core|yoga|mobility|pilates|climb/.test(t)) return 'strength';
  if (/run|jog|walk|treadmill/.test(t)) return 'run';
  return 'run';
}

/** A lap as intervals.icu records it, when the activity has any. */
export interface IcuIntervalRaw {
  /** Seconds from the start of the activity. */
  start_index?: number;
  /** Seconds in the lap, moving time. */
  moving_time?: number;
  elapsed_time?: number;
  distance?: number;
  average_heartrate?: number | null;
  max_heartrate?: number | null;
  average_watts?: number | null;
  max_watts?: number | null;
  zone?: number | null;
  type?: string;
  label?: string | null;
  /** True when intervals.icu worked the interval out itself rather than the device. */
  automatic?: boolean;
}

/** Laps as the athlete pressed them, or null when the activity has none. */
export async function fetchLaps(
  config: IcuConfig,
  activityId: string,
  signal?: AbortSignal
): Promise<IcuIntervalRaw[] | null> {
  try {
    const raw = await icuFetch<IcuIntervalRaw[]>(
      `/activity/${encodeURIComponent(activityId)}/intervals`,
      config,
      signal
    );
    return Array.isArray(raw) ? raw : null;
  } catch {
    // No laps (or no permission for them) is not an error: the stream still works.
    return null;
  }
}

/** Zone seconds as intervals.icu sends them, trimmed to the five zones we show. */
function zoneTimes(raw: number[] | null | undefined): number[] | null {
  if (!Array.isArray(raw) || !raw.length) return null;
  const seconds = raw.slice(0, 5).map((value) => (Number.isFinite(value) && value > 0 ? Math.round(value) : 0));
  return seconds.some((value) => value > 0) ? seconds : null;
}

export function mapActivity(raw: IcuActivityRaw): ActivityDraft {
  const stamp = raw.start_date_local ?? raw.start_date ?? '';
  return {
    externalId: String(raw.id),
    date: stamp.slice(0, 10),
    mode: mapActivityType(raw.type),
    name: (raw.name ?? '').slice(0, 120),
    durationSec: Math.round(raw.moving_time ?? raw.elapsed_time ?? 0),
    distanceM: Math.round(raw.distance ?? 0),
    avgHr: raw.average_heartrate ? Math.round(raw.average_heartrate) : null,
    maxHr: raw.max_heartrate ? Math.round(raw.max_heartrate) : null,
    load: raw.icu_training_load ?? null,
    avgSpeedMs:
      typeof raw.average_speed === 'number' && raw.average_speed > 0
        ? Math.round(raw.average_speed * 1000) / 1000
        : null,
    hrZoneSec: zoneTimes(raw.hr_zone_times)
  };
}

export async function fetchActivitiesDetailed(
  config: IcuConfig,
  oldest: string,
  newest: string,
  signal?: AbortSignal
): Promise<ActivityFetch> {
  const params = new URLSearchParams({ oldest, newest });
  const raw = await icuFetch<IcuActivityRaw[]>(
    `/athlete/${encodeURIComponent(config.athleteId)}/activities?${params.toString()}`,
    config,
    signal
  );

  const dated = raw.filter((activity) => activity.id && (activity.start_date_local ?? activity.start_date));
  const activities = dated
    .filter((activity) => !isUnavailableActivity(activity))
    .map(mapActivity)
    .sort((a, b) => (a.date < b.date ? 1 : -1));

  const unavailable = dated.filter(isUnavailableActivity).map((activity) => ({
    externalId: String(activity.id),
    date: (activity.start_date_local ?? activity.start_date ?? '').slice(0, 10),
    source: activity.source ?? 'unknown',
    note: activity._note ?? ''
  }));

  return { activities, unavailable };
}

export async function fetchActivities(
  config: IcuConfig,
  oldest: string,
  newest: string,
  signal?: AbortSignal
): Promise<ActivityDraft[]> {
  const { activities } = await fetchActivitiesDetailed(config, oldest, newest, signal);
  return activities;
}

export interface IcuStream {
  type: string;
  /** Numbers for most streams; `latlng` carries `[lat, lng]` pairs. */
  data?: unknown[];
  /** Longitudes, when intervals.icu splits a two-part stream like `latlng`. */
  data2?: unknown[];
}

export interface IcuStreams {
  time: number[];
  watts?: (number | null)[];
  heartrate?: (number | null)[];
  velocity?: (number | null)[];
  /** Cumulative metres, when the activity recorded them. */
  distance?: (number | null)[];
  /** Metres above sea level. Some sports only report `fixed_altitude`. */
  altitude?: (number | null)[];
  /** GPS trace, one entry per sample: `[lat, lng]`, or null without a fix. */
  latlng?: (LatLng | null)[];
}

/** The numbers in a stream, whatever the payload held. Missing stays missing. */
function numeric(values: unknown[] | undefined): (number | null)[] | undefined {
  if (!values?.length) return undefined;
  return values.map((value) => {
    if (typeof value === 'number') return Number.isFinite(value) ? value : null;
    // A gap in the recording is not a measurement of zero: turning null into 0
    // invents a dip in altitude and a stop at 0 m/s.
    if (typeof value === 'string' && value.trim() !== '') {
      const parsed = Number(value);
      return Number.isFinite(parsed) ? parsed : null;
    }
    return null;
  });
}

function asNumber(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function latLngAt(entry: unknown): LatLng | null {
  if (!Array.isArray(entry) || entry.length < 2) return null;
  const lat = asNumber(entry[0]);
  const lng = asNumber(entry[1]);
  if (lat === null || lng === null) return null;
  const pair: LatLng = [lat, lng];
  return isLatLng(pair) ? pair : null;
}

/**
 * The route stream. intervals.icu keeps the two coordinates in separate arrays —
 * `data` holds latitudes and `data2` longitudes — and some exports send `[lat, lng]`
 * pairs outright, so both shapes are read. A stream with only one coordinate is
 * ignored on purpose: pairing a latitude with the next latitude draws a route in
 * the wrong country, which is worse than drawing nothing.
 */
function routeStream(stream: IcuStream | undefined): { aligned?: (LatLng | null)[] } {
  const data = stream?.data;
  if (!data?.length) return {};

  if (data.some((value) => Array.isArray(value))) return { aligned: data.map(latLngAt) };

  const lngs = stream?.data2;
  if (!lngs?.length) return {};

  const length = Math.max(data.length, lngs.length);
  return {
    aligned: Array.from({ length }, (_, index) => {
      const lat = asNumber(data[index]);
      const lng = asNumber(lngs[index]);
      if (lat === null || lng === null) return null;
      const pair: LatLng = [lat, lng];
      return isLatLng(pair) ? pair : null;
    })
  };
}

/** Below this a sample is standing still, not moving slowly. */
const STOPPED_SPEED = 0.1;

function isNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value);
}

/**
 * Was the athlete standing still at this sample? A paused watch keeps the clock
 * running, so the raw `time` axis contains minutes of standing about — and every
 * split, best effort and detected interval would count them. intervals.icu sends
 * a `moving` flag; without it a near-zero speed or distance change marks a stop.
 */
function isStoppedAt(
  index: number,
  {
    moving,
    velocity,
    distance
  }: {
    moving?: (number | null)[] | null;
    velocity?: (number | null)[] | null;
    distance?: (number | null)[] | null;
  }
): boolean {
  if (moving?.length) {
    const flag = moving[index];
    return flag !== null && flag !== undefined && Number(flag) === 0;
  }
  if (velocity?.length) {
    const speed = velocity[index];
    if (isNumber(speed)) return speed < STOPPED_SPEED;
  }
  if (distance?.length && index > 0) {
    const now = distance[index];
    const before = distance[index - 1];
    if (isNumber(now) && isNumber(before)) return now - before < 0.2;
  }
  return false;
}

export function normaliseStreams(raw: IcuStream[]): IcuStreams {
  const streamByType = new Map(raw.map((stream) => [stream.type, stream]));
  const byType = new Map(raw.map((stream) => [stream.type, stream.data ?? []]));
  const time = (numeric(byType.get('time')) ?? []).map((value) => value ?? 0);
  const moving = numeric(byType.get('moving'));
  const velocity = numeric(byType.get('velocity_smooth')) ?? numeric(byType.get('velocity'));
  const distance = numeric(byType.get('distance'));
  const route = routeStream(streamByType.get('latlng'));

  const streams: IcuStreams = {
    time,
    watts: numeric(byType.get('watts')) ?? numeric(byType.get('power')),
    heartrate: numeric(byType.get('heartrate')),
    velocity,
    distance,
    altitude: numeric(byType.get('altitude')) ?? numeric(byType.get('fixed_altitude')),
    latlng: route.aligned
  };

  if (time.length < 2) return streams;

  // Rebuild the clock without the pauses: ten minutes at a red light must not
  // turn a 40 minute run into a 50 minute one, or a 5:00/km into 6:15/km.
  const kept: number[] = [];
  const keptTime: number[] = [];
  let clock = 0;

  for (let index = 0; index < time.length; index++) {
    const paused = index > 0 && isStoppedAt(index, { moving, velocity, distance });
    if (index > 0 && !paused) clock += Math.max(0, time[index] - time[index - 1]);
    if (index === 0 || !paused) {
      kept.push(index);
      keptTime.push(clock);
    }
  }

  // Nothing moved, or there is no pause data at all: leave the activity alone.
  if (kept.length < 2) return streams;

  const pick = (values: (number | null)[] | null | undefined) =>
    values && values.length ? kept.map((index) => values[index] ?? null) : undefined;

  return {
    time: keptTime,
    watts: pick(streams.watts),
    heartrate: pick(streams.heartrate),
    velocity: pick(streams.velocity),
    distance: pick(streams.distance),
    altitude: pick(streams.altitude),
    latlng: route.aligned ? kept.map((index) => route.aligned?.[index] ?? null) : undefined
  };
}

/** The GPS trace as a thinned list of points, ready for a map. */
export function routePoints(streams: IcuStreams, maxPoints = 150): LatLng[] {
  const points = streams.latlng?.filter((point): point is LatLng => point !== null) ?? [];
  return simplifyRoute(points, maxPoints);
}

export async function fetchStreams(
  config: IcuConfig,
  activityId: string,
  signal?: AbortSignal
): Promise<IcuStreams> {
  const raw = await icuFetch<IcuStream[]>(`/activity/${encodeURIComponent(activityId)}/streams`, config, signal);
  return normaliseStreams(Array.isArray(raw) ? raw : []);
}

/** The raw samples for a metric, or null when the activity lacks that stream. */
export function streamsForMetric(streams: IcuStreams, metric: MetricId): (number | null)[] | null {
  switch (metric) {
    case 'power':
      return streams.watts?.length ? streams.watts : null;
    case 'hr':
      return streams.heartrate?.length ? streams.heartrate : null;
    case 'speed':
    case 'pace': {
      if (!streams.velocity?.length) return null;
      // intervals.icu gives velocity in m/s; km/h reads better in the UI.
      return streams.velocity.map((value) => (value === null ? null : value * 3.6));
    }
    default:
      return null;
  }
}

export function metricAvailability(streams: IcuStreams): MetricId[] {
  const available: MetricId[] = [];
  if (streams.watts?.length) available.push('power');
  if (streams.heartrate?.length) available.push('hr');
  if (streams.velocity?.length) available.push('speed');
  return available;
}

/**
 * Speed-based detection converted to pace, so runners can read their intervals
 * in min/km without a second implementation of the detector.
 */
export function toPaceResult(result: DetectionResult): DetectionResult {
  // Detection runs on km/h (see streamsForMetric), so pace in seconds per km is
  // 3600 / speed.
  const toPace = (speed: number) => (speed > 0.1 ? Math.round(3600 / speed) : 0);
  const convert = (segment: DetectionResult['segments'][number]) => ({
    ...segment,
    avg: toPace(segment.avg),
    max: toPace(segment.max),
    min: toPace(segment.min)
  });
  return {
    ...result,
    metric: 'pace',
    metricLabel: 'Pace',
    unit: '/km',
    threshold: toPace(result.threshold),
    segments: result.segments.map(convert),
    work: result.work.map(convert),
    recover: result.recover.map(convert)
  };
}

export async function testConnection(config: IcuConfig): Promise<{ name: string; athleteId: string }> {
  const athlete = await icuFetch<{ id?: string; name?: string; athlete_id?: string }>(
    `/athlete/${encodeURIComponent(config.athleteId)}`,
    config
  );
  return {
    name: athlete.name ?? 'intervals.icu athlete',
    athleteId: String(athlete.id ?? athlete.athlete_id ?? config.athleteId)
  };
}
