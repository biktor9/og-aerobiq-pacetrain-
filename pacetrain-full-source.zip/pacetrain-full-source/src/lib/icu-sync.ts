import { and, eq } from 'drizzle-orm';
import { db, schema } from '@/db';
import { addDays, parseISODate, toISODate } from '@/domain/week';
import { decryptSecret, randomId } from './crypto';
import { getIcuCredentials } from './data';
import { fetchActivitiesDetailed } from './icu';

export interface ImportResult {
  scanned: number;
  imported: number;
  /** Records intervals.icu listed but would not serve, usually Strava activities. */
  unavailable: number;
  /** The inclusive window that was asked for. */
  from: string;
  to: string;
}

/** A year at a time is plenty; a wider window is a mistake, not a request. */
const MAX_SPAN_DAYS = 400;

function isISODate(value: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(value);
}

/**
 * Pulls activities from intervals.icu for a window of days. Runs are
 * idempotent: the unique index on (user, source, external id) means pressing
 * "import today" twice imports nothing the second time.
 */
export async function importActivitiesBetween(
  userId: string,
  fromISO: string,
  toISO: string
): Promise<ImportResult> {
  if (!isISODate(fromISO) || !isISODate(toISO)) throw new Error('Pick a valid date range.');

  // A range given backwards is still a range.
  let from = fromISO <= toISO ? fromISO : toISO;
  const to = fromISO <= toISO ? toISO : fromISO;

  const span = Math.round((parseISODate(to).getTime() - parseISODate(from).getTime()) / 86_400_000);
  if (span > MAX_SPAN_DAYS) from = toISODate(addDays(parseISODate(to), -(MAX_SPAN_DAYS - 1)));

  const credentials = await getIcuCredentials(userId);
  if (!credentials) throw new Error('Connect intervals.icu in Settings first.');

  const apiKey = decryptSecret(credentials.apiKeyEnc);
  const now = new Date();

  let activities;
  let unavailable;
  try {
    const fetched = await fetchActivitiesDetailed({ athleteId: credentials.athleteId, apiKey }, from, to);
    activities = fetched.activities;
    unavailable = fetched.unavailable;
  } catch (error) {
    await db
      .update(schema.icuCredentials)
      .set({
        status: 'error',
        lastError: error instanceof Error ? error.message : 'Unknown error',
        updatedAt: now
      })
      .where(eq(schema.icuCredentials.userId, userId));
    throw error;
  }

  let imported = 0;
  // An earlier import may have stored one of these stubs as a 0 s / 0 m
  // activity. A run the API will not hand over is not a real workout, so the
  // empty copy is removed rather than left in the calendar.
  for (const stub of unavailable) {
    await db
      .delete(schema.activities)
      .where(
        and(
          eq(schema.activities.userId, userId),
          eq(schema.activities.source, 'intervals.icu'),
          eq(schema.activities.externalId, stub.externalId)
        )
      );
  }

  for (const activity of activities) {
    const values = {
      date: activity.date,
      mode: activity.mode,
      durationSec: activity.durationSec,
      distanceM: activity.distanceM,
      avgHr: activity.avgHr,
      maxHr: activity.maxHr,
      load: activity.load,
      avgSpeedMs: activity.avgSpeedMs,
      hrZoneTimes: activity.hrZoneSec?.length ? activity.hrZoneSec.join(',') : null
    };

    const inserted = await db
      .insert(schema.activities)
      .values({
        id: randomId(),
        userId,
        externalId: activity.externalId,
        source: 'intervals.icu',
        name: activity.name,
        ...values,
        createdAt: now
      })
      .onConflictDoNothing()
      .returning({ id: schema.activities.id });

    if (inserted.length) {
      imported += 1;
      continue;
    }

    // Already imported: refresh the numbers intervals.icu owns, so a fixed
    // average speed or a corrected distance reaches activities from before the
    // import learned about it. The athlete's own fields are left alone.
    await db
      .update(schema.activities)
      .set(values)
      .where(
        and(
          eq(schema.activities.userId, userId),
          eq(schema.activities.source, 'intervals.icu'),
          eq(schema.activities.externalId, activity.externalId)
        )
      );
  }

  await db
    .update(schema.icuCredentials)
    .set({ status: 'ok', lastError: null, lastSyncAt: now, updatedAt: now })
    .where(eq(schema.icuCredentials.userId, userId));

  return { scanned: activities.length, imported, unavailable: unavailable.length, from, to };
}

/** The last `days` days, inclusive of today. */
export async function importActivities(userId: string, days = 30): Promise<ImportResult> {
  const now = new Date();
  const window = Math.min(365, Math.max(1, Math.round(days)));
  return importActivitiesBetween(userId, toISODate(addDays(now, -(window - 1))), toISODate(now));
}

