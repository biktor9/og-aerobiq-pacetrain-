import type { IcuIntervalRaw, IcuStreams } from './icu';

/**
 * Streams are large and both the activity page and the interval analyser want
 * them. A short-lived, per-user cache means opening an activity and then asking
 * for its intervals does not hit intervals.icu twice. Everything is dropped
 * after five minutes, and the cache never leaves the server process.
 */

const TTL_MS = 5 * 60 * 1000;
const MAX_ENTRIES = 50;

interface Entry {
  streams: IcuStreams;
  storedAt: number;
}

interface LapEntry {
  laps: IcuIntervalRaw[] | null;
  storedAt: number;
}

const entries = new Map<string, Entry>();
/** Laps get their own map, so a missing lap list is cached too. */
const lapEntries = new Map<string, LapEntry>();

function keyFor(userId: string, externalId: string): string {
  return `${userId}:${externalId}`;
}

function prune(now: number) {
  for (const [key, entry] of entries) {
    if (now - entry.storedAt > TTL_MS) entries.delete(key);
  }
  // Map keeps insertion order, so the oldest keys go first.
  while (entries.size > MAX_ENTRIES) {
    const oldest = entries.keys().next();
    if (oldest.done) break;
    entries.delete(oldest.value);
  }
}

export function cachedStreams(userId: string, externalId: string): IcuStreams | null {
  const entry = entries.get(keyFor(userId, externalId));
  if (!entry) return null;
  if (Date.now() - entry.storedAt > TTL_MS) {
    entries.delete(keyFor(userId, externalId));
    return null;
  }
  return entry.streams;
}

export function rememberStreams(userId: string, externalId: string, streams: IcuStreams): void {
  const now = Date.now();
  entries.set(keyFor(userId, externalId), { streams, storedAt: now });
  prune(now);
}

/** Returns the cached streams, or loads them once and remembers the result. */
export async function withStreamCache(
  userId: string,
  externalId: string,
  load: () => Promise<IcuStreams>
): Promise<IcuStreams> {
  const hit = cachedStreams(userId, externalId);
  if (hit) return hit;
  const streams = await load();
  rememberStreams(userId, externalId, streams);
  return streams;
}

/** Only used by tests, and by nothing in the app. */
export function clearStreamCache(): void {
  entries.clear();
  lapEntries.clear();
}

/** The cached lap list, or null when it has not been read yet. */
export function cachedLaps(userId: string, externalId: string): IcuIntervalRaw[] | null {
  const key = keyFor(userId, externalId);
  const entry = lapEntries.get(key);
  if (!entry) return null;
  if (Date.now() - entry.storedAt > TTL_MS) {
    lapEntries.delete(key);
    return null;
  }
  return entry.laps;
}

/** Remembers a lap list — including "this activity has none" — for five minutes. */
export function rememberLaps(userId: string, externalId: string, laps: IcuIntervalRaw[] | null): void {
  const now = Date.now();
  for (const [key, entry] of lapEntries) {
    if (now - entry.storedAt > TTL_MS) lapEntries.delete(key);
  }
  lapEntries.set(keyFor(userId, externalId), { laps, storedAt: now });
  while (lapEntries.size > MAX_ENTRIES) {
    const oldest = lapEntries.keys().next();
    if (oldest.done) break;
    lapEntries.delete(oldest.value);
  }
}
