import { describe, expect, it, vi } from 'vitest';
import { initialSession, toSession } from '@/domain/plan';
import type { Activity, Session } from '@/domain/types';
import { activityDetail } from '@/lib/activity-detail';

const mocks = vi.hoisted(() => ({
  getActivity: vi.fn(),
  listSessionsBetween: vi.fn()
}));

vi.mock('@/lib/data', () => ({
  getActivity: mocks.getActivity,
  listSessionsBetween: mocks.listSessionsBetween
}));

function activity(overrides: Partial<Activity> = {}): Activity {
  return {
    id: 'activity-1',
    externalId: 'demo-threshold',
    date: '2026-10-20',
    mode: 'run',
    name: 'Threshold 4×8′',
    durationSec: 3480,
    distanceM: 11800,
    avgHr: 152,
    maxHr: 175,
    load: 92,
    source: 'demo',
    linkedSessionId: null,
    ...overrides
  };
}

function planned(date: string, mode: Activity['mode'], id: string): Session {
  return toSession({ ...initialSession(date, mode), id, linkedActivityId: null });
}

describe('activityDetail', () => {
  it('returns nothing for an activity that is not the user’s', async () => {
    mocks.getActivity.mockResolvedValue(null);
    mocks.listSessionsBetween.mockResolvedValue([]);

    await expect(activityDetail('user-1', 'missing')).resolves.toBeNull();
  });

  it('builds kilometre splits and charts from the demo stream', async () => {
    mocks.getActivity.mockResolvedValue(activity());
    mocks.listSessionsBetween.mockResolvedValue([]);

    const detail = await activityDetail('user-1', 'activity-1');
    expect(detail).not.toBeNull();
    expect(detail?.splits?.rows.length).toBeGreaterThan(5);
    expect(detail?.splits?.rows[0].paceSecPerKm).toBeGreaterThan(120);
    expect(detail?.splits?.rows[0].avgHr).toBeGreaterThan(100);
    expect(detail?.charts.pace?.unit).toBe('/km');
    expect(detail?.charts.pace?.invert).toBe(true);
    expect(detail?.charts.hr?.unit).toBe('bpm');
    expect(detail?.note).toBe('');
  });

  it('pairs the activity with the session planned that day in the same discipline', async () => {
    mocks.getActivity.mockResolvedValue(activity());
    mocks.listSessionsBetween.mockResolvedValue([
      planned('2026-10-20', 'bike', 'bike-1'),
      planned('2026-10-20', 'run', 'run-1')
    ]);

    const detail = await activityDetail('user-1', 'activity-1');
    expect(detail?.planned?.id).toBe('run-1');
    expect(mocks.listSessionsBetween).toHaveBeenCalledWith('user-1', '2026-10-20', '2026-10-20');
  });

  it('leaves an unmatched day alone rather than guessing', async () => {
    mocks.getActivity.mockResolvedValue(activity());
    mocks.listSessionsBetween.mockResolvedValue([
      planned('2026-10-20', 'bike', 'bike-1'),
      planned('2026-10-20', 'ski', 'ski-1')
    ]);

    const detail = await activityDetail('user-1', 'activity-1');
    expect(detail?.planned).toBeNull();
  });

  it('says why a hand-added activity has no splits', async () => {
    mocks.getActivity.mockResolvedValue(activity({ source: 'manual', externalId: 'manual-1' }));
    mocks.listSessionsBetween.mockResolvedValue([]);

    const detail = await activityDetail('user-1', 'activity-1');
    expect(detail?.splits).toBeNull();
    expect(detail?.charts.pace).toBeNull();
    expect(detail?.note).toMatch(/Added by hand/);
  });

  it('says so when the streams cannot be read', async () => {
    mocks.getActivity.mockResolvedValue(activity({ source: 'intervals.icu', externalId: 'i123' }));
    mocks.listSessionsBetween.mockResolvedValue([]);

    const detail = await activityDetail('user-1', 'activity-1');
    expect(detail?.splits).toBeNull();
    expect(detail?.note).toMatch(/Streams are unavailable/);
  });
});
