import { db, schema } from '@/db';
import {
  accessFor,
  periodEnd,
  planById,
  trialUsed,
  type Access,
  type PlanId,
  type SubscriptionRecord,
  type SubscriptionSource
} from '@/domain/billing';
import { randomId } from './crypto';
import { currentSubscription, subscriptionHistory } from './data';

/**
 * Server-side billing rules: who gets in, and how a paid period is recorded.
 * The arithmetic (dates, extension, trial-once) lives in `domain/billing.ts`;
 * this file only touches the database.
 */

export async function accessForUser(userId: string): Promise<Access> {
  return accessFor(await currentSubscription(userId));
}

export async function trialAlreadyUsed(userId: string): Promise<boolean> {
  return trialUsed(await subscriptionHistory(userId, 50));
}

export interface ActivationOptions {
  plan: PlanId;
  source: SubscriptionSource;
  amountSek?: number;
  reference?: string;
  note?: string;
}

/** Records a paid (or granted) period and returns it. */
export async function activatePlan(userId: string, options: ActivationOptions): Promise<SubscriptionRecord> {
  const plan = planById(options.plan);
  if (!plan) throw new Error(`Unknown plan: ${options.plan}`);

  const current = await currentSubscription(userId);
  const now = new Date();
  const currentEnd = current ? new Date(current.expiresAt) : null;
  const startsAt = currentEnd && currentEnd.getTime() > now.getTime() ? currentEnd : now;
  const expiresAt = periodEnd(plan, { subscription: current, now });

  const record: SubscriptionRecord = {
    id: randomId(),
    plan: plan.id,
    status: 'active',
    source: options.source,
    amountSek: options.amountSek ?? plan.priceSek,
    reference: options.reference ?? '',
    note: options.note ?? '',
    startedAt: startsAt.toISOString(),
    expiresAt: expiresAt.toISOString()
  };

  await db.insert(schema.subscriptions).values({
    id: record.id,
    userId,
    plan: record.plan,
    status: record.status,
    source: record.source,
    amountSek: record.amountSek,
    reference: record.reference,
    note: record.note,
    startedAt: new Date(record.startedAt),
    expiresAt: new Date(record.expiresAt),
    createdAt: now,
    updatedAt: now
  });

  return record;
}



