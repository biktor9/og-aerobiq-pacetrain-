import { db, schema } from '@/db';
import { randomId } from './crypto';
import { appConfig } from './env';

export interface Mail {
  to: string;
  subject: string;
  text: string;
  /** The actionable URL, stored separately so the dev mailbox can link it. */
  link?: string;
}

function htmlFor(mail: Mail): string {
  const escaped = mail.text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/\n/g, '<br />');
  const button = mail.link
    ? `<p style="margin:24px 0"><a href="${mail.link}" style="background:#1f6feb;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none;font-weight:600">Open PaceTrain</a></p>
       <p style="color:#667;font-size:13px;word-break:break-all">${mail.link}</p>`
    : '';
  return `<div style="font-family:system-ui,-apple-system,Segoe UI,sans-serif;max-width:520px;margin:0 auto;padding:24px;color:#1a1f2b">
    <h2 style="margin:0 0 16px">${mail.subject}</h2>
    <p style="line-height:1.6">${escaped}</p>
    ${button}
    <p style="color:#889;font-size:12px;margin-top:32px">PaceTrain — plan the week, review the reps.</p>
  </div>`;
}

/**
 * Sends mail through Resend when configured, otherwise prints it to the server
 * log and stores it in the development mailbox (/dev/mailbox).
 */
export async function sendMail(mail: Mail): Promise<void> {
  const config = appConfig();

  if (config.email.transport === 'resend' && config.email.resendApiKey) {
    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${config.email.resendApiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: config.email.from,
          to: [mail.to],
          subject: mail.subject,
          text: mail.text,
          html: htmlFor(mail)
        })
      });
      if (!response.ok) {
        throw new Error(`Resend responded ${response.status}: ${await response.text()}`);
      }
      return;
    } catch (error) {
      console.error('[email] delivery through Resend failed:', error);
      // Fall through to the console transport so local work is never blocked.
    }
  }

  console.info(`\n──── EMAIL ────\nto: ${mail.to}\nsubject: ${mail.subject}\n${mail.text}\n───────────────\n`);

  if (!config.isProd) {
    await db.insert(schema.devMail).values({
      id: randomId(),
      to: mail.to,
      subject: mail.subject,
      body: mail.text,
      link: mail.link ?? '',
      createdAt: new Date()
    });
  }
}

export function resetPasswordMail(email: string, name: string, url: string): Mail {
  return {
    to: email,
    subject: 'Reset your PaceTrain password',
    text: `Hi ${name || 'there'},

someone asked to reset the password for this address. Choose a new password with the link below — it expires in one hour.

If this was not you, no action is needed.`,
    link: url
  };
}

