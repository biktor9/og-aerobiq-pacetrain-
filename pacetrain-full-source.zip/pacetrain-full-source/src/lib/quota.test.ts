import { describe, expect, it } from 'vitest';
import { daysBetween, decideQuota, estimateTokens, quotaLimits, utcDay } from './quota';

const base = {
  accountAgeDays: 30,
  hasOwnKey: false,
  requestsLastHour: 0,
  requestsToday: 0,
  globalTokensToday: 0,
  dailyTokenBudget: 1_500_000
};

describe('quotaLimits', () => {
  it('treats the first week as a trial period', () => {
    expect(quotaLimits({ accountAgeDays: 0, hasOwnKey: false })).toEqual({
      perHour: 10,
      perDay: 30
    });
    expect(quotaLimits({ accountAgeDays: 6, hasOwnKey: false })).toEqual({
      perHour: 10,
      perDay: 30
    });
  });

  it('raises limits after a week', () => {
    expect(quotaLimits({ accountAgeDays: 7, hasOwnKey: false })).toEqual({
      perHour: 25,
      perDay: 100
    });
  });

  it('removes limits for users with their own key', () => {
    const limits = quotaLimits({ accountAgeDays: 0, hasOwnKey: true });
    expect(limits.perDay).toBe(Number.POSITIVE_INFINITY);
  });
});

describe('decideQuota', () => {
  it('allows an account under the limits', () => {
    const decision = decideQuota(base);
    expect(decision.allowed).toBe(true);
    expect(decision.reason).toBe('ok');
    expect(decision.remainingHour).toBe(25);
    expect(decision.remainingDay).toBe(100);
  });

  it('applies the trial limits to a fresh account', () => {
    const decision = decideQuota({ ...base, accountAgeDays: 0, requestsLastHour: 9 });
    expect(decision.allowed).toBe(true);
    expect(decision.remainingHour).toBe(1);
  });

  it('blocks when the hourly window is used up', () => {
    const decision = decideQuota({ ...base, requestsLastHour: 25 });
    expect(decision).toMatchObject({ allowed: false, reason: 'hourly', remainingHour: 0 });
  });

  it('blocks when the daily window is used up', () => {
    const decision = decideQuota({ ...base, requestsToday: 100 });
    expect(decision).toMatchObject({ allowed: false, reason: 'daily' });
  });

  it('prefers the hourly message when both are exhausted', () => {
    const decision = decideQuota({ ...base, requestsLastHour: 40, requestsToday: 200 });
    expect(decision.reason).toBe('hourly');
  });

  it('applies the stricter new-account limits', () => {
    const decision = decideQuota({ ...base, accountAgeDays: 2, requestsLastHour: 10 });
    expect(decision.reason).toBe('hourly');
    expect(decision.limits).toEqual({ perHour: 10, perDay: 30 });
  });

  it('stops everyone when the shared daily budget is gone', () => {
    const decision = decideQuota({ ...base, globalTokensToday: 1_500_000 });
    expect(decision).toMatchObject({ allowed: false, reason: 'budget' });
    expect(decision.message).toContain('00:00 UTC');
  });

  it('ignores the budget for a user on their own key', () => {
    const decision = decideQuota({
      ...base,
      hasOwnKey: true,
      globalTokensToday: 99_000_000,
      requestsToday: 5000
    });
    expect(decision).toMatchObject({ allowed: true, reason: 'own-key', unlimited: true });
  });

  it('treats a zero budget as unlimited', () => {
    const decision = decideQuota({ ...base, dailyTokenBudget: 0, globalTokensToday: 50_000_000 });
    expect(decision.allowed).toBe(true);
  });
});

describe('helpers', () => {
  it('estimates tokens from characters', () => {
    expect(estimateTokens('')).toBe(0);
    expect(estimateTokens('abcd')).toBe(1);
    expect(estimateTokens('a'.repeat(400))).toBe(100);
  });

  it('formats the UTC day', () => {
    expect(utcDay(new Date('2026-10-23T23:59:59Z'))).toBe('2026-10-23');
    expect(utcDay(new Date('2026-10-24T00:00:01Z'))).toBe('2026-10-24');
  });

  it('counts whole days between timestamps', () => {
    const now = new Date('2026-10-23T12:00:00Z');
    expect(daysBetween(new Date('2026-10-23T08:00:00Z'), now)).toBe(0);
    expect(daysBetween(new Date('2026-10-16T12:00:00Z'), now)).toBe(7);
    expect(daysBetween(new Date('2026-11-01T12:00:00Z'), now)).toBe(0);
  });
});
