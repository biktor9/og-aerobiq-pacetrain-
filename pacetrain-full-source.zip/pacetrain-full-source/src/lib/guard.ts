import { accessForUser } from './billing-server';
import { appConfig } from './env';
import { isAdmin } from './session';

/**
 * The paywall, for code that is not a page layout.
 *
 * API routes live outside `(app)`, so they have to ask this themselves — and
 * the AI routes especially, because an unpaid account should not be able to
 * spend the shared DeepSeek budget.
 */

export interface GuardUser {
  id: string;
  role?: string | null;
  email?: string | null;
}

export async function blockedByPaywall(user: GuardUser): Promise<boolean> {
  if (!appConfig().paywall.enabled) return false;
  if (isAdmin(user)) return false;
  const access = await accessForUser(user.id);
  return !access.active;
}

export function paywallResponse(): Response {
  return Response.json(
    {
      error: 'Your plan has ended. Renew on the pricing page to keep training.',
      reason: 'paywall',
      pricing: '/pricing'
    },
    { status: 402 }
  );
}
