import { bestEfforts, RIDE_EFFORTS, RUN_EFFORTS, type BestEffort } from '@/domain/best-efforts';
import {
  buildSplits,
  lapsFromIcu,
  splitsFromLaps,
  type SplitsReport,
  type SplitTotals
} from '@/domain/splits';
import { isDistanceMode } from '@/domain/pace';
import { isRunningMode } from '@/domain/activity';
import type { Activity, ModeId, Session } from '@/domain/types';
import { activityLaps, activityStreams } from './activity-streams';
import { getActivity, listSessionsBetween } from './data';
import { routePoints, type IcuStreams } from './icu';
import type { LatLng } from '@/domain/geo';

/**
 * Everything the activity page shows: the summary it was opened with, the
 * kilometre splits, the decimated pace and heart-rate series, and the session
 * that was planned for the same day. Server-only.
 */

export interface DetailChart {
  time: number[];
  values: (number | null)[];
  unit: string;
  label: string;
  /** True when a lower number is better, as with pace. */
  invert: boolean;
}

export interface ActivityDetail {
  activity: Activity;
  splits: SplitsReport | null;
  charts: { pace: DetailChart | null; hr: DetailChart | null };
  /** Fastest window over 400 m, 1 km, 5 km … for this activity. */
  efforts: BestEffort[];
  /** The GPS trace, thinned for the map. Empty for a treadmill or a manual entry. */
  route: LatLng[];
  planned: Session | null;
  /** Why there are no splits, written for the athlete. Empty when there are. */
  note: string;
}

/**
 * Which totals the splits are matched to. intervals.icu's own pace comes from
 * `average_speed`, measured over its moving time from the stream rather than over
 * the device's `moving_time` (a COROS watch auto-pauses more eagerly). Matching
 * that keeps our kilometre paces identical to the ones in intervals.icu.
 */
function splitTotals(activity: Activity): SplitTotals {
  if (activity.avgSpeedMs && activity.avgSpeedMs > 0 && activity.distanceM > 0) {
    return { distanceM: activity.distanceM, durationSec: activity.distanceM / activity.avgSpeedMs };
  }
  return { distanceM: activity.distanceM, durationSec: activity.durationSec };
}

/** Keeps charts under ~720 points without changing the shape. */
function decimate(time: number[], values: (number | null)[], maxPoints = 720) {
  const stride = Math.max(1, Math.ceil(time.length / maxPoints));
  if (stride === 1) return { time, values };
  return {
    time: time.filter((_, index) => index % stride === 0),
    values: values.filter((_, index) => index % stride === 0)
  };
}

function chartsFor(streams: IcuStreams, mode: ModeId): ActivityDetail['charts'] {
  let pace: DetailChart | null = null;
  const speed = streams.velocity;
  if (speed?.length) {
    const distanceMode = isDistanceMode(mode);
    const values = speed.map((value) => {
      if (value === null || !Number.isFinite(value) || value <= 0.2) return null;
      // Pace in seconds per km; everything else reads as km/h.
      return distanceMode ? Math.round(3600 / value) : Math.round(value * 36) / 10;
    });
    const sampled = decimate(streams.time, values);
    pace = {
      time: sampled.time,
      values: sampled.values,
      unit: distanceMode ? '/km' : 'km/h',
      label: distanceMode ? 'Pace' : 'Speed',
      invert: distanceMode
    };
  }

  let hr: DetailChart | null = null;
  if (streams.heartrate?.length) {
    const sampled = decimate(streams.time, streams.heartrate);
    hr = { time: sampled.time, values: sampled.values, unit: 'bpm', label: 'Heart rate', invert: false };
  }

  return { pace, hr };
}

/**
 * The session planned for the same day, preferring the same discipline. The
 * planner has never written `linkedActivityId`, so date plus discipline is what
 * pairs a session with the run that got done.
 */
async function plannedSessionFor(userId: string, activity: Activity): Promise<Session | null> {
  const sessions = await listSessionsBetween(userId, activity.date, activity.date);
  if (!sessions.length) return null;

  const sameMode = sessions.filter((session) => session.mode === activity.mode);
  if (sameMode.length) return sameMode.find((session) => session.status === 'done') ?? sameMode[0];
  return sessions.length === 1 ? sessions[0] : null;
}

/**
 * The kilometre splits, and where they came from. The watch's own laps are used
 * when intervals.icu has them and they cover the whole session, because those
 * are the split times the platform itself shows; only without usable laps is
 * the table cut from the trace.
 */
export async function activityDetail(userId: string, activityId: string): Promise<ActivityDetail | null> {
  const activity = await getActivity(userId, activityId);
  if (!activity) return null;

  const [planned, streams, laps] = await Promise.all([
    plannedSessionFor(userId, activity),
    activityStreams(userId, activity).catch(() => null),
    activityLaps(userId, activity).catch(() => null)
  ]);

  // Laps only describe a run the athlete lapped; a ride's lap button is not a
  // kilometre split, so cycling keeps reading kilometres off the trace.
  const fromLaps =
    isDistanceMode(activity.mode) && laps?.length ? lapsFromIcu(laps, { movingTimeSec: activity.durationSec }) : null;
  const lapSplits = fromLaps && fromLaps.laps.length ? splitsFromLaps(fromLaps.laps) : null;
  const splits: SplitsReport | null = lapSplits?.rows.length
    ? lapSplits
    : streams
      ? buildSplits(streams, 1000, splitTotals(activity))
      : null;
  const charts = streams ? chartsFor(streams, activity.mode) : { pace: null, hr: null };
  const efforts = streams
    ? bestEfforts(streams, isRunningMode(activity.mode) ? RUN_EFFORTS : RIDE_EFFORTS)
    : [];
  const route = streams ? routePoints(streams) : [];

  let note = '';
  if (!streams) {
    note =
      activity.source === 'manual'
        ? 'Added by hand — there are no streams, so no splits or charts.'
        : 'Streams are unavailable for this activity. Reconnect intervals.icu in Settings and try again.';
  } else if (splits && !splits.rows.length) {
    note = 'No distance was recorded, so there are no kilometre splits.';
  } else if (!splits?.rows.length) {
    note = 'This activity is too short to split by the kilometre.';
  }

  return { activity, splits, charts, planned, efforts, route, note };
}
