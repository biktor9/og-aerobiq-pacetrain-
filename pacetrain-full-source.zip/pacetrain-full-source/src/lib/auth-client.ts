import { createAuthClient } from 'better-auth/react';

/**
 * Browser auth client. It talks to /api/auth on the same origin, so no URL
 * configuration is needed — and no secret ever reaches this side.
 */
export const authClient = createAuthClient();

export const { signIn, signUp, signOut, useSession, requestPasswordReset, resetPassword } = authClient;
