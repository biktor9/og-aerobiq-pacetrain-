import { decryptSecret } from './crypto';
import { getIcuCredentials } from './data';
import { demoStream } from './demo';
import { fetchLaps, fetchStreams, type IcuIntervalRaw, type IcuStreams } from './icu';
import { cachedLaps, rememberLaps, withStreamCache } from './stream-cache';

/**
 * Streams for one activity, from the sample generator or intervals.icu.
 *
 * The interval analyser and the activity page both need the same arrays, so
 * they come through here and share one short-lived cache.
 */

export class StreamError extends Error {
  constructor(
    message: string,
    readonly status = 409
  ) {
    super(message);
    this.name = 'StreamError';
  }
}

export interface StreamSource {
  externalId: string;
  source: 'intervals.icu' | 'demo' | 'manual';
}

export async function activityStreams(userId: string, activity: StreamSource): Promise<IcuStreams> {
  if (activity.source === 'demo') {
    const workout = demoStream(activity.externalId);
    return {
      time: workout.time,
      watts: workout.watts,
      heartrate: workout.heartrate,
      velocity: workout.velocity,
      distance: workout.distance,
      altitude: workout.altitude,
      latlng: workout.latlng
    };
  }

  if (activity.source === 'manual') {
    throw new StreamError('This activity was added by hand, so it has no streams to read.');
  }

  return withStreamCache(userId, activity.externalId, async () => {
    const credentials = await getIcuCredentials(userId);
    if (!credentials) {
      throw new StreamError('Reconnect intervals.icu in Settings to read this activity.');
    }
    const apiKey = decryptSecret(credentials.apiKeyEnc);
    return fetchStreams({ athleteId: credentials.athleteId, apiKey }, activity.externalId);
  });
}

/**
 * The laps the watch recorded, if intervals.icu has any. Null is a real answer —
 * the activity was never lapped — and a demo activity has no laps either.
 */
export async function activityLaps(userId: string, activity: StreamSource): Promise<IcuIntervalRaw[] | null> {
  if (activity.source !== 'intervals.icu') return null;

  const hit = cachedLaps(userId, activity.externalId);
  if (hit !== null) return hit;

  const credentials = await getIcuCredentials(userId);
  if (!credentials) return null;
  const apiKey = decryptSecret(credentials.apiKeyEnc);
  const laps = await fetchLaps({ athleteId: credentials.athleteId, apiKey }, activity.externalId);
  rememberLaps(userId, activity.externalId, laps);
  return laps;
}
