import { normalizeStructure } from '@/domain/plan';
import type { Block } from '@/domain/types';

/**
 * Optional AI path for the "describe your session" box. DeepSeek reads unusual
 * phrasings better than the local parser, but its output is only ever accepted
 * after `normalizeStructure` has vetted it, and any failure falls back to the
 * local parser.
 */

export interface AiIntervalConfig {
  apiKey: string;
  baseUrl: string;
  model: string;
  signal?: AbortSignal;
}

export interface AiIntervalResult {
  blocks: Block[];
  promptTokens: number;
  completionTokens: number;
}

export const INTERVAL_SYSTEM_PROMPT = [
  'You turn a coach’s session description into JSON for a training planner.',
  'Reply with JSON only, no prose and no code fences:',
  '{"blocks":[{"kind":"warmup|work|recover|cooldown","minutes":number,"zone":1|2|3|4|5}]}',
  'Rules:',
  '- minutes are minutes of work, decimals allowed (90 seconds = 1.5).',
  '- when reps are given by distance and a pace, work out the rep time (1km @ 4:30/km = 4.5 minutes).',
  '- zone 1 is recovery, 2 aerobic, 3 tempo, 4 threshold, 5 VO2max/max.',
  '- open with a warmup block and close with a cooldown block when the text says so.',
  '- do not repeat the recovery after the final rep of a set.',
  '- never invent durations that are not in the text; if there are no durations, return {"blocks":[]}.'
].join('\n');

/** Models like to wrap JSON in fences or add a sentence; find the object. */
export function extractJsonObject(text: string): unknown {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start < 0 || end <= start) return null;
  try {
    return JSON.parse(text.slice(start, end + 1));
  } catch {
    return null;
  }
}

export async function parseIntervalsWithAi(
  text: string,
  config: AiIntervalConfig
): Promise<AiIntervalResult | null> {
  let response: Response;
  try {
    response = await fetch(`${config.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${config.apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: config.model,
        messages: [
          { role: 'system', content: INTERVAL_SYSTEM_PROMPT },
          { role: 'user', content: text }
        ],
        response_format: { type: 'json_object' },
        temperature: 0,
        max_tokens: 900
      }),
      signal: config.signal
    });
  } catch (error) {
    console.error('[intervals] could not reach DeepSeek:', error);
    return null;
  }

  if (!response.ok) {
    console.error('[intervals] DeepSeek returned', response.status);
    return null;
  }

  const payload = (await response.json().catch(() => null)) as {
    choices?: { message?: { content?: string | null } }[];
    usage?: { prompt_tokens?: number; completion_tokens?: number } | null;
  } | null;

  const content = payload?.choices?.[0]?.message?.content ?? '';
  const json = extractJsonObject(content) as { blocks?: unknown } | null;
  const blocks = normalizeStructure(json?.blocks);
  if (!blocks) return null;

  return {
    blocks,
    promptTokens: payload?.usage?.prompt_tokens ?? 0,
    completionTokens: payload?.usage?.completion_tokens ?? 0
  };
}
