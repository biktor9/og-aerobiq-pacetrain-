import { afterEach, describe, expect, it, vi } from 'vitest';
import type { DetectionResult } from '@/domain/types';
import {
  fetchActivities,
  fetchActivitiesDetailed,
  isUnavailableActivity,
  mapActivity,
  mapActivityType,
  metricAvailability,
  normaliseStreams,
  routePoints,
  streamsForMetric,
  testConnection,
  toPaceResult
} from './icu';

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('mapActivityType', () => {
  it('maps intervals.icu sport types onto PaceTrain modes', () => {
    expect(mapActivityType('Run')).toBe('run');
    expect(mapActivityType('VirtualRun')).toBe('run');
    expect(mapActivityType('TrailRun')).toBe('trail');
    expect(mapActivityType('Hike')).toBe('trail');
    expect(mapActivityType('Orienteering')).toBe('orienteering');
    expect(mapActivityType('NordicSki')).toBe('ski');
    expect(mapActivityType('RollerSki')).toBe('ski');
    expect(mapActivityType('Ride')).toBe('bike');
    expect(mapActivityType('GravelRide')).toBe('bike');
    expect(mapActivityType('MountainBikeRide')).toBe('mtb');
    expect(mapActivityType('EBikeRide')).toBe('bike');
    expect(mapActivityType('WeightTraining')).toBe('strength');
    expect(mapActivityType(undefined)).toBe('run');
    expect(mapActivityType('SomethingNew')).toBe('run');
  });

  it('prefers the more specific discipline', () => {
    expect(mapActivityType('EMountainBikeRide')).toBe('mtb');
    expect(mapActivityType('TrailRunning')).toBe('trail');
    expect(mapActivityType('RollerSkiInterval')).toBe('ski');
    expect(mapActivityType('VirtualRide')).toBe('bike');
    // A hobby that is not a bike or a ski still has to land somewhere sane.
    expect(mapActivityType('Skateboard')).toBe('run');
  });
});

describe('mapActivity', () => {
  it('normalises the fields we store', () => {
    const draft = mapActivity({
      id: 'i123',
      start_date_local: '2026-10-21T06:15:00',
      type: 'Run',
      name: 'Threshold 4x8',
      moving_time: 3780.4,
      distance: 12400.7,
      average_speed: 3.334,
      average_heartrate: 152.4,
      max_heartrate: 173.6,
      icu_training_load: 88,
      hr_zone_times: [900, 1800, 600, 300, 0]
    });
    expect(draft).toEqual({
      externalId: 'i123',
      date: '2026-10-21',
      mode: 'run',
      name: 'Threshold 4x8',
      durationSec: 3780,
      distanceM: 12401,
      avgHr: 152,
      maxHr: 174,
      load: 88,
      avgSpeedMs: 3.334,
      hrZoneSec: [900, 1800, 600, 300, 0]
    });
  });

  it('copes with missing optional fields', () => {
    const draft = mapActivity({ id: 'x', start_date: '2026-01-01T00:00:00Z' });
    expect(draft).toMatchObject({
      date: '2026-01-01',
      name: '',
      durationSec: 0,
      distanceM: 0,
      avgHr: null,
      load: null,
      avgSpeedMs: null,
      hrZoneSec: null
    });
  });
});

describe('normaliseStreams', () => {
  it('picks the streams we care about and aliases power', () => {
    const streams = normaliseStreams([
      { type: 'time', data: [0, 1, 2] },
      { type: 'power', data: [100, 200, 300] },
      { type: 'heartrate', data: [120, 130, 140] },
      { type: 'velocity_smooth', data: [3, 4, 5] }
    ]);
    expect(streams.time).toEqual([0, 1, 2]);
    expect(streams.watts).toEqual([100, 200, 300]);
    expect(streams.heartrate).toEqual([120, 130, 140]);
    expect(streams.velocity).toEqual([3, 4, 5]);
  });

  it('tolerates a missing time stream', () => {
    expect(normaliseStreams([{ type: 'watts', data: [1] }]).time).toEqual([]);
  });

  it('keeps distance and altitude, including fixed_altitude', () => {
    const streams = normaliseStreams([
      { type: 'time', data: [0, 1] },
      { type: 'distance', data: [0, 3.5] },
      { type: 'fixed_altitude', data: [42, 43] }
    ]);

    expect(streams.distance).toEqual([0, 3.5]);
    expect(streams.altitude).toEqual([42, 43]);
  });

  it('drops paused time using the moving flag', () => {
    const streams = normaliseStreams([
      { type: 'time', data: [0, 1, 2, 3, 4, 5] },
      // Standing still from second 2 to second 4, then moving again.
      { type: 'moving', data: [1, 1, 0, 0, 0, 1] },
      { type: 'distance', data: [0, 3, 3, 3, 3, 6] },
      { type: 'velocity_smooth', data: [3, 3, 0, 0, 0, 3] }
    ]);

    // Two moving seconds, not five: 6 m in 2 s is 3 m/s, not 1.2.
    expect(streams.time).toEqual([0, 1, 2]);
    expect(streams.distance).toEqual([0, 3, 6]);
    expect(streams.velocity).toEqual([3, 3, 3]);
  });

  it('spots a stop from speed when the activity has no moving flag', () => {
    const streams = normaliseStreams([
      { type: 'time', data: [0, 1, 2, 3, 4] },
      { type: 'velocity_smooth', data: [3, 3, 0, 0, 3] },
      { type: 'distance', data: [0, 3, 3, 3, 6] }
    ]);

    expect(streams.time).toEqual([0, 1, 2]);
    expect(streams.velocity).toEqual([3, 3, 3]);
  });

  it('leaves a steady activity exactly as it was', () => {
    const raw = [
      { type: 'time', data: [0, 1, 2] },
      { type: 'velocity_smooth', data: [3, 3, 3] },
      { type: 'distance', data: [0, 3, 6] }
    ];
    const streams = normaliseStreams(raw);
    expect(streams.time).toEqual([0, 1, 2]);
  });

  it('falls back to the raw streams when everything looks stopped', () => {
    const streams = normaliseStreams([
      { type: 'time', data: [0, 1, 2] },
      { type: 'velocity_smooth', data: [0, 0, 0] }
    ]);
    expect(streams.time).toEqual([0, 1, 2]);
  });

  it('keeps a gap as a gap instead of inventing a zero reading', () => {
    const streams = normaliseStreams([
      { type: 'time', data: [0, 1, 2, 3] },
      { type: 'altitude', data: [173, null, 173, 174] },
      { type: 'velocity_smooth', data: [3, 3, null, 3] }
    ]);

    // A null here used to become 0 m, which showed up as 800 m of climbing.
    expect(streams.altitude).toEqual([173, null, 173, 174]);
    expect(streams.velocity).toEqual([3, 3, null, 3]);
  });

  it('pairs latitudes with longitudes from data2', () => {
    const streams = normaliseStreams([
      { type: 'time', data: [0, 1, 2] },
      {
        type: 'latlng',
        data: [60.6183, 60.6182, 60.6181],
        data2: [15.6346, 15.6347, 15.6348]
      }
    ]);

    expect(routePoints(streams)).toEqual([
      [60.6183, 15.6346],
      [60.6182, 15.6347],
      [60.6181, 15.6348]
    ]);
  });

  it('draws nothing rather than a wrong place when only one coordinate exists', () => {
    const streams = normaliseStreams([
      { type: 'time', data: [0, 1, 2] },
      { type: 'latlng', data: [60.6183, 60.6182, 60.6181] }
    ]);

    expect(routePoints(streams)).toEqual([]);
  });

  it('carries the GPS trace, thinned for a map', () => {
    const streams = normaliseStreams([
      { type: 'time', data: [0, 1, 2] },
      {
        type: 'latlng',
        data: [
          [59.33, 18.06],
          [59.331, 18.061],
          [59.332, 18.062]
        ]
      }
    ]);

    expect(streams.latlng).toHaveLength(3);
    expect(routePoints(streams)).toEqual([
      [59.33, 18.06],
      [59.331, 18.061],
      [59.332, 18.062]
    ]);
  });

  it('drops the points recorded while paused', () => {
    const streams = normaliseStreams([
      { type: 'time', data: [0, 1, 2, 3] },
      { type: 'moving', data: [1, 1, 0, 1] },
      {
        type: 'latlng',
        data: [
          [59.33, 18.06],
          [59.331, 18.061],
          [59.331, 18.061],
          [59.332, 18.062]
        ]
      }
    ]);

    expect(routePoints(streams)).toEqual([
      [59.33, 18.06],
      [59.331, 18.061],
      [59.332, 18.062]
    ]);
  });

});

describe('streamsForMetric', () => {
  const streams = normaliseStreams([
    { type: 'time', data: [0, 1] },
    { type: 'watts', data: [200, 250] },
    { type: 'velocity_smooth', data: [10 / 3, 4] }
  ]);

  it('returns the requested stream', () => {
    expect(streamsForMetric(streams, 'power')).toEqual([200, 250]);
    expect(streamsForMetric(streams, 'hr')).toBeNull();
  });

  it('converts m/s to km/h for speed and pace', () => {
    const kmh = streamsForMetric(streams, 'speed');
    expect(kmh?.[0]).toBeCloseTo(12, 5);
    expect(streamsForMetric(streams, 'pace')?.[0]).toBeCloseTo(12, 5);
  });

  it('lists which metrics an activity supports', () => {
    expect(metricAvailability(streams)).toEqual(['power', 'speed']);
  });
});

describe('toPaceResult', () => {
  it('turns km/h into min/km', () => {
    const result: DetectionResult = {
      metric: 'speed',
      metricLabel: 'Speed',
      unit: 'km/h',
      threshold: 12,
      reps: 1,
      segments: [
        { index: 1, kind: 'work', startSec: 0, endSec: 240, durationSec: 240, avg: 12, max: 14.4, min: 10 }
      ],
      work: [{ index: 1, kind: 'work', startSec: 0, endSec: 240, durationSec: 240, avg: 12, max: 14.4, min: 10 }],
      recover: [],
      durationSec: 240,
      workTimeSec: 240,
      recoverTimeSec: 0,
      avgWorkSec: 240,
      avgRecoverSec: 0,
      consistency: 0,
      driftPct: 0
    };
    const pace = toPaceResult(result);
    expect(pace.metric).toBe('pace');
    expect(pace.unit).toBe('/km');
    expect(pace.threshold).toBe(300);
    expect(pace.work[0]).toMatchObject({ avg: 300, max: 250, min: 360 });
  });
});

describe('Strava placeholders', () => {
  const stub = {
    id: '20716204652',
    source: 'STRAVA',
    start_date_local: '2026-10-24T18:18:35',
    _note: 'STRAVA activities are not available via the API'
  };

  it('recognises a record with no sport, name, time or distance', () => {
    expect(isUnavailableActivity(stub)).toBe(true);
    expect(isUnavailableActivity({ id: 'i199562853', type: 'TrailRun', moving_time: 3224 })).toBe(false);
    // A real activity with a note attached is still a real activity.
    expect(isUnavailableActivity({ id: 'i1', type: 'Run', moving_time: 60, _note: 'felt good' })).toBe(false);
  });

  it('leaves the stub out of the import and says so', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        new Response(
          JSON.stringify([
            stub,
            {
              id: 'i199562853',
              start_date_local: '2026-10-20T16:06:00',
              type: 'TrailRun',
              name: 'Afternoon Trail Run',
              moving_time: 3224,
              distance: 10049.62
            }
          ]),
          { status: 200, headers: { 'content-type': 'application/json' } }
        )
      )
    );

    const fetched = await fetchActivitiesDetailed({ athleteId: 'i1', apiKey: 'k' }, '2026-10-19', '2026-10-25');

    expect(fetched.activities).toHaveLength(1);
    expect(fetched.activities[0]).toMatchObject({
      externalId: 'i199562853',
      mode: 'trail',
      durationSec: 3224,
      distanceM: 10050
    });
    expect(fetched.unavailable).toEqual([
      {
        externalId: '20716204652',
        date: '2026-10-24',
        source: 'STRAVA',
        note: 'STRAVA activities are not available via the API'
      }
    ]);
  });

  it('never turns a stub into a zero-length activity', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        new Response(JSON.stringify([stub]), { status: 200, headers: { 'content-type': 'application/json' } })
      )
    );

    expect(await fetchActivities({ athleteId: 'i1', apiKey: 'k' }, '2026-10-24', '2026-10-24')).toEqual([]);
  });
});

describe('HTTP calls', () => {
  it('authenticates with API_KEY as the basic-auth username', async () => {
    const fetchMock = vi.fn(async () =>
      new Response(JSON.stringify({ id: 'i42', name: 'Ada' }), {
        status: 200,
        headers: { 'content-type': 'application/json' }
      })
    );
    vi.stubGlobal('fetch', fetchMock);

    const info = await testConnection({ athleteId: 'i42', apiKey: 'secret-key' });
    expect(info).toEqual({ name: 'Ada', athleteId: 'i42' });

    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe('https://intervals.icu/api/v1/athlete/i42');
    expect((init.headers as Record<string, string>).Authorization).toBe(
      `Basic ${Buffer.from('API_KEY:secret-key').toString('base64')}`
    );
  });

  it('requests a date window and sorts newest first', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        new Response(
          JSON.stringify([
            { id: '1', start_date_local: '2026-10-01T08:00:00', type: 'Run' },
            { id: '2', start_date_local: '2026-10-20T08:00:00', type: 'Ride' }
          ]),
          { status: 200, headers: { 'content-type': 'application/json' } }
        )
      )
    );

    const activities = await fetchActivities({ athleteId: 'i1', apiKey: 'k' }, '2026-09-01', '2026-10-23');
    expect(activities.map((a) => a.date)).toEqual(['2026-10-20', '2026-10-01']);
  });

  it('explains an auth failure', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('nope', { status: 401 })));
    await expect(testConnection({ athleteId: 'i1', apiKey: 'bad' })).rejects.toThrow(/rejected the API key/);
  });
});
