import { beforeEach, describe, expect, it } from 'vitest';
import { decryptSecret, encryptSecret, maskSecret, secretLast4, sha256 } from './crypto';

const KEY = 'MDEyMzQ1Njc4OWFiY2RlZjAxMjM0NTY3ODlhYmNkZWY=';

beforeEach(() => {
  process.env.ENCRYPTION_KEY = KEY;
});

describe('encryptSecret / decryptSecret', () => {
  it('round-trips a value', () => {
    const secret = 'icu_abcdef1234567890';
    const encrypted = encryptSecret(secret);
    expect(encrypted).not.toContain(secret);
    expect(encrypted.startsWith('v1:')).toBe(true);
    expect(decryptSecret(encrypted)).toBe(secret);
  });

  it('produces a different ciphertext every time', () => {
    expect(encryptSecret('same-value')).not.toBe(encryptSecret('same-value'));
  });

  it('handles unicode and empty strings', () => {
    expect(decryptSecret(encryptSecret('clé-🔑-secret'))).toBe('clé-🔑-secret');
    expect(decryptSecret(encryptSecret(''))).toBe('');
  });

  it('rejects a tampered ciphertext', () => {
    const encrypted = encryptSecret('icu_abcdef1234567890');
    const parts = encrypted.split(':');
    const data = Buffer.from(parts[3], 'base64');
    data[0] = data[0] ^ 0xff;
    parts[3] = data.toString('base64');
    expect(() => decryptSecret(parts.join(':'))).toThrow();
  });

  it('rejects a tampered auth tag', () => {
    const parts = encryptSecret('icu_abcdef1234567890').split(':');
    parts[2] = Buffer.alloc(16, 7).toString('base64');
    expect(() => decryptSecret(parts.join(':'))).toThrow();
  });

  it('rejects malformed payloads', () => {
    expect(() => decryptSecret('not-encrypted')).toThrow(/format/);
    expect(() => decryptSecret('v2:a:b:c')).toThrow(/format/);
  });

  it('fails loudly when the key is missing or the wrong length', () => {
    delete process.env.ENCRYPTION_KEY;
    expect(() => encryptSecret('x')).toThrow(/ENCRYPTION_KEY is not set/);
    process.env.ENCRYPTION_KEY = Buffer.alloc(16).toString('base64');
    expect(() => encryptSecret('x')).toThrow(/32 bytes/);
  });
});

describe('secret helpers', () => {
  it('keeps only the last four characters', () => {
    expect(secretLast4('icu_abcdef1234567890')).toBe('7890');
  });

  it('masks a key for display', () => {
    expect(maskSecret('sk-1234567890abcdef')).toBe('sk-…cdef');
    expect(maskSecret('short')).toBe('••••');
    expect(maskSecret('')).toBe('');
  });

  it('hashes deterministically', () => {
    expect(sha256('abc')).toBe(sha256('abc'));
    expect(sha256('abc')).toHaveLength(64);
    expect(sha256('abc')).not.toBe(sha256('abd'));
  });
});
