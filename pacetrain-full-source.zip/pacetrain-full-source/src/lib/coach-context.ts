import { type ChatMessage } from './deepseek';
import { runningTotals } from '@/domain/activity';
import { type WeekStats } from '@/domain/load';
import { formatPace } from '@/domain/pace';
import { describeSession, sessionTitle } from '@/domain/plan';
import { fmtClock, fmtDuration, fmtKm, parseISODate, weekdayLabel } from '@/domain/week';
import { type Activity, type DetectionResult, type Session } from '@/domain/types';

export interface CoachSettings {
  goalText: string;
  eventDate: string | null;
  weeklyMinutesTarget: number;
  weeklyLoadTarget: number;
  primaryMode: string;
  coachTone: string;
  athleteNotes: string;
}

export interface CoachInput {
  userName: string;
  settings: CoachSettings;
  weekKey: string;
  weekRange: string;
  sessions: Session[];
  stats: WeekStats;
  previousLoad: number;
  activities: Activity[];
  latestAnalysis: { activityName: string; result: DetectionResult; summary: string } | null;
  /** Fitness, fatigue and form, when the athlete has enough history. */
  fitness?: { ctl: number; atl: number; tsb: number; label: string } | null;
  /** This morning's recovery score, with the signals behind it. */
  recovery?: { score: number; label: string; summary: string; sick: boolean; signals: string[] } | null;
  /** What the athlete wrote this morning — their own correction to the numbers. */
  recoveryNote?: string | null;
  /** An illness period covering today, if any. */
  illness?: { from: string; to: string; symptoms: string; severity: number } | null;
  /** The next race, so the coach can plan around a deadline. */
  nextRace?: { name: string; days: number; phase: string } | null;
}

const MAX_CONTEXT_CHARS = 6000;

export function truncate(text: string, max: number): string {
  if (text.length <= max) return text;
  return `${text.slice(0, Math.max(0, max - 1)).trimEnd()}…`;
}

function activityLine(activity: Activity): string {
  const bits = [
    activity.date,
    activity.mode,
    activity.name || 'session',
    fmtClock(activity.durationSec),
    activity.distanceM ? fmtKm(activity.distanceM) : '',
    activity.avgHr ? `avg HR ${activity.avgHr}` : '',
    activity.load ? `load ${Math.round(activity.load)}` : ''
  ].filter(Boolean);
  return `- ${bits.join(' · ')}`;
}

function sessionLine(session: Session): string {
  const status = session.status === 'done' ? ' [done]' : session.status === 'skipped' ? ' [skipped]' : '';
  return `- ${weekdayLabel(parseISODate(session.date))} ${parseISODate(session.date).getDate()}: ${sessionTitle(session)} — ${describeSession(session)}${status}`;
}

/** The athlete, their week and their recent training as compact text. */
export function buildContextBlock(input: CoachInput): string {
  const { settings, stats } = input;
  const sections: string[] = [];

  const profile = [
    `name: ${input.userName || 'athlete'}`,
    settings.goalText ? `goal: ${settings.goalText}` : '',
    settings.eventDate ? `target event: ${settings.eventDate}` : '',
    `weekly target: ${settings.weeklyMinutesTarget} min / ${settings.weeklyLoadTarget} load`,
    `primary mode: ${settings.primaryMode}`,
    settings.athleteNotes ? `notes: ${truncate(settings.athleteNotes, 400)}` : ''
  ].filter(Boolean);
  sections.push(`ATHLETE\n${profile.join('\n')}`);

  const days = stats.byDay;
  const weekLines = input.sessions.length
    ? input.sessions.map(sessionLine).join('\n')
    : '- nothing planned yet';
  const restDays = 7 - Object.keys(days).length;
  sections.push(
    `CURRENT WEEK ${input.weekKey} (${input.weekRange})\n${weekLines}\n` +
      `totals: ${stats.count} sessions, ${Math.round(stats.minutes)} min, ${stats.runningKm} km running, load ${stats.load}, ` +
      `${stats.hardCount} hard, ${stats.doneCount} done, ${stats.skippedCount} skipped, ${restDays} empty days\n` +
      `previous week load: ${input.previousLoad}` +
      (stats.load > 0 && input.previousLoad > 0
        ? ` (${stats.load >= input.previousLoad ? '+' : ''}${Math.round(((stats.load - input.previousLoad) / input.previousLoad) * 100)}%)`
        : '')
  );

  const recent = input.activities.slice(0, 14);
  const running = runningTotals(input.activities);
  const runningLine = running.count
    ? `${running.km.toFixed(1)} km running in ${running.count} sessions${running.avgPaceSecPerKm ? ` at ${formatPace(running.avgPaceSecPerKm)}` : ''}`
    : 'nothing running imported yet';
  sections.push(
    `RECENT ACTIVITIES (imported, newest first)\n${recent.length ? recent.map(activityLine).join('\n') : '- none imported yet'}\n` +
      `running total: ${runningLine}`
  );

  if (input.fitness || input.recovery || input.illness || input.nextRace) {
    const lines: string[] = [];
    if (input.fitness) {
      lines.push(
        `- fitness ${Math.round(input.fitness.ctl)}, fatigue ${Math.round(input.fitness.atl)}, ` +
          `form ${Math.round(input.fitness.tsb)} (${input.fitness.label})`
      );
    }
    if (input.recovery) {
      lines.push(`- recovery ${input.recovery.score}/100 (${input.recovery.label}): ${input.recovery.summary}`);
      if (input.recovery.signals.length) lines.push(`  ${input.recovery.signals.slice(0, 5).join(' · ')}`);
    }
    if (input.recoveryNote) {
      lines.push(`- the athlete's own words this morning: "${truncate(input.recoveryNote, 200)}"`);
    }
    if (input.illness) {
      const severity = ['mild', 'rough', 'bad'][Math.min(3, Math.max(1, input.illness.severity)) - 1];
      lines.push(`- SICK ${input.illness.from} → ${input.illness.to} (${severity}): ${input.illness.symptoms}`);
    }
    if (input.nextRace) {
      lines.push(`- next race: ${input.nextRace.name} in ${input.nextRace.days} days, ${input.nextRace.phase} phase`);
    }
    sections.push(`FORM, RECOVERY AND READINESS\n${lines.join('\n')}`);
  }

  if (input.latestAnalysis) {
    const { result, summary, activityName } = input.latestAnalysis;
    sections.push(
      `LATEST INTERVAL ANALYSIS (${activityName})\n` +
        `- ${result.reps} reps, ${result.metricLabel} threshold ${Math.round(result.threshold)} ${result.unit}, ` +
        `avg work ${Math.round(result.avgWorkSec)}s, avg recovery ${Math.round(result.avgRecoverSec)}s\n` +
        `- consistency ${result.consistency}%, drift ${result.driftPct}%\n- ${summary}`
    );
  }

  const block = sections.join('\n\n');
  return truncate(block, MAX_CONTEXT_CHARS);
}

const TONES: Record<string, string> = {
  direct: 'Be direct and specific. Short sentences, no filler.',
  supportive: 'Be warm and encouraging, but still specific and honest.',
  analytical: 'Be analytical: cite the numbers, explain the reasoning, keep it structured.',
  concise: 'Be extremely brief: at most three short bullet points.'
};

export function buildSystemPrompt(input: CoachInput, contextBlock: string): string {
  const tone = TONES[input.settings.coachTone] ?? TONES.direct;
  return [
    'You are PaceTrain, an endurance coach embedded in a training planner.',
    tone,
    'Rules:',
    '- Use only the athlete data below. If something is missing, say so instead of inventing it.',
    '- Answer the question that was asked, in the language it was asked in.',
    '- Give at most one concrete next session (mode, duration, zone or reps) when it helps.',
    '- Never diagnose injuries or medical conditions; suggest a professional instead.',
    '- Keep answers under 220 words. Plain text with simple markdown lists is fine.',
    '- You are not a generic chatbot: no apologies, no restating the question, no "as an AI".',
    '',
    'ATHLETE DATA',
    contextBlock
  ].join('\n');
}

export interface HistoryMessage {
  role: 'user' | 'assistant';
  content: string;
}

/** System prompt + recent conversation + the new question. */
export function buildCoachMessages(
  input: CoachInput,
  history: HistoryMessage[],
  question: string
): ChatMessage[] {
  const contextBlock = buildContextBlock(input);
  const trimmedHistory = history
    .slice(-8)
    .filter((message) => message.content.trim().length > 0)
    .map((message) => ({ role: message.role, content: truncate(message.content, 1200) }) as ChatMessage);

  return [
    { role: 'system', content: buildSystemPrompt(input, contextBlock) },
    ...trimmedHistory,
    { role: 'user', content: truncate(question.trim(), 1500) }
  ];
}

/**
 * Deterministic answers used when no shared key is configured (or when the
 * model cannot be reached). It reads the same data the AI would see, so the
 * coach tab is never a dead end.
 */
export function offlineAnswer(input: CoachInput, question: string): string {
  const { stats } = input;
  const q = question.toLowerCase();
  const lines: string[] = [];

  const rampPct =
    input.previousLoad > 0 ? Math.round(((stats.load - input.previousLoad) / input.previousLoad) * 100) : null;

  lines.push(
    `**This week (${input.weekRange})** — ${stats.count} sessions, ${fmtDuration(stats.minutes)}, load ${stats.load}` +
      (rampPct === null ? ' (first tracked week)' : `, ${rampPct >= 0 ? '+' : ''}${rampPct}% vs last week`) +
      `, ${stats.hardCount} hard, ${stats.doneCount} done.`
  );

  if (q.includes('interval') || q.includes('rep') || q.includes('analys')) {
    if (input.latestAnalysis) {
      lines.push(`**Latest interval analysis** (${input.latestAnalysis.activityName}): ${input.latestAnalysis.summary}`);
    } else {
      lines.push('No interval analysis yet — pick an activity in the Analysis tab and run the detector.');
    }
  }

  const hardStreak = longestHardStreak(input.sessions);
  const flags: string[] = [];
  if (rampPct !== null && rampPct > 25) {
    flags.push(`load jumped ${rampPct}% week over week; hold volume flat next week and keep one quality session.`);
  }
  if (rampPct !== null && rampPct < -30) {
    flags.push('volume dropped sharply — fine after a race or illness, otherwise add one easy session back.');
  }
  if (stats.hardCount >= 3) flags.push('three or more hard sessions in one week; two is usually enough.');
  if (stats.count > 0 && Object.keys(stats.byDay).length >= 7) {
    flags.push('no rest day this week — take one, ideally after the long session.');
  }
  if (hardStreak >= 2) flags.push('hard sessions on back-to-back days; separate them with an easy day.');
  if (stats.count > 0 && stats.minutes < input.settings.weeklyMinutesTarget * 0.7) {
    flags.push(`volume is below 70% of your ${input.settings.weeklyMinutesTarget} min target.`);
  }
  if (stats.count === 0) flags.push('nothing is planned yet — add two easy sessions and one quality session to start.');

  if (flags.length) lines.push(`**Watch** — ${flags.join(' ')}`);

  const lastHard = [...input.sessions]
    .filter((session) => session.zone >= 4 && session.status !== 'skipped')
    .sort((a, b) => (a.date < b.date ? -1 : 1))
    .at(-1);
  const daysSinceHard = lastHard ? daysSince(lastHard.date) : null;
  const hasLong = input.sessions.some((session) => session.durationMin >= 75);

  let next: string;
  if (daysSinceHard !== null && daysSinceHard <= 1) {
    next = 'easy 45–60 min in Z1–Z2, nose breathing only';
  } else if (!hasLong && stats.count > 0) {
    next = 'long easy session, 75–90 min in Z2, steady effort';
  } else if (stats.hardCount < 2) {
    next = 'quality session: 4 × 8 min at Z4 with 2 min float, 15 min warm-up and 10 min cool-down';
  } else {
    next = 'easy 40–50 min in Z1, or a full rest day if anything feels tight';
  }
  lines.push(`**Next session** — ${next}.`);

  lines.push(
    '_AI answers are offline right now, so this is the built-in rule engine. Add `DEEPSEEK_API_KEY` on the server (or your own key in Settings) for conversational coaching._'
  );

  return lines.join('\n\n');
}

function longestHardStreak(sessions: Session[]): number {
  const dates = [...new Set(sessions.filter((s) => s.zone >= 4 && s.status !== 'skipped').map((s) => s.date))].sort();
  let best = 0;
  let streak = 0;
  let previous: number | null = null;
  for (const date of dates) {
    const time = parseISODate(date).getTime();
    streak = previous !== null && time - previous === 86_400_000 ? streak + 1 : 1;
    best = Math.max(best, streak);
    previous = time;
  }
  return best;
}

function daysSince(date: string): number {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  return Math.round((today - parseISODate(date).getTime()) / 86_400_000);
}
