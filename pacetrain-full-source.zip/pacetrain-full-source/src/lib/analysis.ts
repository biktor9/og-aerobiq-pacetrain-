import { db, schema } from '@/db';
import { compareToIntent, type IntentComparison } from '@/domain/compare';
import { buildIntervalReport, type IntervalReport } from '@/domain/interval-stats';
import {
  detectionFromLaps,
  detectIntervals,
  normalizeDetectParams,
  reportFromLaps,
  summariseDetection,
  type DetectParams,
  type LoggedLap
} from '@/domain/intervals';
import { isDistanceMode } from '@/domain/pace';
import { METRICS, type Block, type DetectionResult, type MetricId } from '@/domain/types';
import { activityLaps, activityStreams, StreamError } from './activity-streams';
import { randomId } from './crypto';
import { getActivity } from './data';
import { metricAvailability, streamsForMetric, toPaceResult, type IcuIntervalRaw, type IcuStreams } from './icu';

export class AnalysisError extends Error {
  constructor(
    message: string,
    readonly status = 400
  ) {
    super(message);
    this.name = 'AnalysisError';
  }
}

export interface AnalyseOptions extends Partial<DetectParams> {
  metric?: MetricId;
  /** The session as the athlete described it, for a planned-vs-actual comparison. */
  intent?: Block[] | null;
  /**
   * The laps the athlete wants analysed, 1-based in recording order. Empty means
   * "all of them"; a lap dropped from the list on the page is left out here.
   */
  laps?: number[];
  /** True when the athlete un-ticked "use the laps" and wants the stream read. */
  ignoreLaps?: boolean;
}

export interface ChartSeries {
  time: number[];
  values: (number | null)[];
  unit: string;
  label: string;
}

/** A lap, both as the analysis page lists it and as the detection used it. */
export interface LapRow {
  /** 1-based, in recording order. */
  index: number;
  kind: 'work' | 'recover';
  startSec: number;
  durationSec: number;
  /** In the detected metric's unit: `/km` for a run, `W`, `bpm`. */
  avg: number;
  max: number;
  /** `800m`, `16′`, `90″` … */
  label: string;
}

export interface AnalyseResult {
  result: DetectionResult;
  series: ChartSeries;
  available: MetricId[];
  source: 'demo' | 'intervals.icu' | 'manual';
  summary: string;
  params: DetectParams;
  /** Per-rep pace, heart rate, distance and elevation for the work intervals. */
  report: IntervalReport;
  /** Planned vs actual, from the athlete's own words. Null without an intent. */
  comparison: IntentComparison | null;
  /** True when the intervals came from the watch's own laps. */
  fromLaps: boolean;
  /** Every lap intervals.icu has, so the page can offer them for unticking. */
  laps: LapRow[];
}

/** Distance that belongs above the metric switch, so a rep can be labelled `800m`. */
function metresOf(lap: IcuIntervalRaw): number {
  const value = Number(lap.distance);
  return Number.isFinite(value) && value > 0 ? value : 0;
}

/** `800m`, `1 km`, `2.5 km` — how a lap distance reads in a table. */
function distanceLabel(metres: number): string {
  if (metres < 950) return `${Math.round(metres / 10) * 10} m`;
  const km = metres / 1000;
  return `${Number.isInteger(km) ? km : km.toFixed(1)} km`;
}

/**
 * The watch's laps, in the unit the detector speaks. A lap carries its own
 * distance, time and heart rate, so a run's laps read as pace in seconds per km
 * and a ride's or a ski's as km/h — the same numbers intervals.icu shows.
 */
export function lapsToLogged(raw: IcuIntervalRaw[], { metric }: { metric: MetricId }): LoggedLap[] {
  const laps: LoggedLap[] = [];
  let cursor = 0;

  for (const lap of raw) {
    const duration = Number(lap.moving_time ?? lap.elapsed_time ?? 0);
    if (!(duration > 0.5)) continue;
    const start = Number.isFinite(lap.start_index) ? Number(lap.start_index) : cursor;
    cursor = start + duration;
    const distance = metresOf(lap);
    const speed = distance > 0 ? distance / duration : 0;
    const averagePace = distance >= 50 ? duration / (distance / 1000) : 0;

    // The recorded metrics, converted to what the detector ran on.
    const values: Record<MetricId, number> = {
      power: Number(lap.average_watts) || 0,
      hr: Number(lap.average_heartrate) || 0,
      speed: Math.round(speed * 36) / 10,
      pace: averagePace > 0 ? Math.round(averagePace) : 0
    };
    const avg = values[metric];
    if (!(avg > 0)) continue;

    const label = distance >= 50 ? distanceLabel(distance) : `${Math.round(duration)} s`;
    laps.push({
      index: laps.length + 1,
      startSec: Math.round(start),
      durationSec: Math.round(duration),
      avg,
      max: avg,
      min: avg,
      name: label
    });
  }

  return laps;
}

/** The laps a page lists, in the same unit as the detection. */
function lapRows(laps: LoggedLap[], result: DetectionResult): LapRow[] {
  return laps.map((lap) => ({
    index: lap.index,
    kind: result.segments.find((segment) => segment.index === lap.index)?.kind ?? 'recover',
    startSec: lap.startSec,
    durationSec: lap.durationSec,
    avg: lap.avg,
    max: lap.max,
    label: lap.name ?? `${Math.round(lap.durationSec)} s`
  }));
}

/** Keeps charts under ~900 points without changing the shape. */
export function decimate(time: number[], values: (number | null)[], maxPoints = 900) {
  const stride = Math.max(1, Math.ceil(time.length / maxPoints));
  if (stride === 1) return { time, values };
  return {
    time: time.filter((_, index) => index % stride === 0),
    values: values.filter((_, index) => index % stride === 0)
  };
}

/**
 * Fetches the streams for one activity, runs the interval detector and caches
 * the result. The raw stream never leaves the server except decimated for the
 * chart.
 */
export async function analyseActivity(
  userId: string,
  activityId: string,
  options: AnalyseOptions = {}
): Promise<AnalyseResult> {
  const activity = await getActivity(userId, activityId);
  if (!activity) throw new AnalysisError('That activity does not exist.', 404);

  let streams: IcuStreams;
  try {
    streams = await activityStreams(userId, activity);
  } catch (error) {
    if (error instanceof StreamError) throw new AnalysisError(error.message, error.status);
    throw error;
  }

  const available = metricAvailability(streams);

  // Runners read pace; everything else reads power first, then heart rate.
  const preferred: MetricId = isDistanceMode(activity.mode)
    ? available.includes('speed')
      ? 'pace'
      : available.includes('hr')
        ? 'hr'
        : 'power'
    : available.includes('power')
      ? 'power'
      : available.includes('hr')
        ? 'hr'
        : 'speed';
  const requested: MetricId = options.metric ?? preferred;

  // Pace is detected on speed and converted afterwards; the two share a stream.
  const streamMetric: MetricId = requested === 'pace' ? 'speed' : requested;
  const values = streamsForMetric(streams, streamMetric);
  if (!values) {
    const labels = available.map((id) => METRICS.find((m) => m.id === id)?.label ?? id);
    throw new AnalysisError(
      labels.length
        ? `This activity has no ${requested} stream. Available: ${labels.join(', ')}.`
        : 'This activity has no usable streams (power, heart rate or speed).'
    );
  }
  if (!streams.time.length) {
    throw new AnalysisError('This activity has no time stream, so intervals cannot be detected.');
  }

  const params = normalizeDetectParams({
    ...options,
    metric: streamMetric,
    // A pace threshold is entered in seconds per km; the detector needs km/h.
    threshold: requested === 'pace' && Number(options.threshold) > 0 ? 3600 / Number(options.threshold) : options.threshold
  });

  // The watch's own laps come first. They are what intervals.icu shows and what
  // the athlete pressed, so they beat anything read out of the stream. The page
  // can untick laps (they are left out here) or ask for the stream instead.
  let logged: LoggedLap[] = [];
  if (!options.ignoreLaps) {
    const rawLaps = await activityLaps(userId, activity).catch(() => null);
    if (rawLaps?.length) {
      logged = lapsToLogged(rawLaps, { metric: requested });
      const keep = options.laps?.length ? new Set(options.laps) : null;
      if (keep) logged = logged.filter((lap) => keep.has(lap.index)).map((lap, index) => ({ ...lap, index: index + 1 }));
    }
  }
  const fromLaps = logged.length >= 2;

  // Laps are already in the metric the page reads; the stream runs on km/h and
  // is converted to pace afterwards, which is the one place the two differ.
  let result: DetectionResult;
  if (fromLaps) {
    result = detectionFromLaps(logged, requested);
  } else {
    result = detectIntervals(streams.time, values, params);
    if (requested === 'pace') result = toPaceResult(result);
  }

  // Every rep gets pace, heart rate, distance and climbing — not just the metric
  // the detector ran on.
  const report = buildIntervalReport(result.work, streams);

  const summary = summariseDetection(result);
  const meta = METRICS.find((m) => m.id === requested) ?? METRICS[0];

  await db.insert(schema.analyses).values({
    id: randomId(),
    userId,
    activityId,
    paramsJson: JSON.stringify({ ...params, metric: requested, source: fromLaps ? 'laps' : 'stream', laps: options.laps ?? null }),
    summary,
    reps: result.reps,
    resultJson: JSON.stringify(result),
    createdAt: new Date()
  });

  const decimated = decimate(streams.time, values);
  const chartValues =
    requested === 'pace'
      ? decimated.values.map((value) => (value && value > 0.1 ? Math.round(3600 / value) : null))
      : decimated.values;

  return {
    result,
    series: {
      time: decimated.time,
      values: chartValues,
      unit: requested === 'pace' ? '/km' : meta.unit,
      label: meta.label
    },
    available,
    source: activity.source,
    summary,
    params,
    report,
    comparison: compareToIntent(result, options.intent ?? null),
    fromLaps,
    laps: fromLaps ? lapRows(logged, result) : []
  };
}
