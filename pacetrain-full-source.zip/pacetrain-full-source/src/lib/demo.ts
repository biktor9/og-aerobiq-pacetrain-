import type { LatLng } from '@/domain/geo';
import type { ModeId, SessionInput } from '@/domain/types';

/**
 * Deterministic sample data. It lets a new account see the planner, the
 * analysis chart and the coach without connecting intervals.icu first.
 * Everything is generated from a seed, so the same demo always looks the same.
 */

function mulberry32(seed: number) {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = Math.imul(state ^ (state >>> 15), 1 | state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashString(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i++) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

export interface DemoWorkout {
  time: number[];
  watts: number[];
  heartrate: number[];
  velocity: number[];
  /** Cumulative metres, alongside `time`. */
  distance: number[];
  /** Metres above sea level, alongside `time`. */
  altitude: number[];
  /** A plausible GPS trace, alongside `time`, so the map has something to draw. */
  latlng: LatLng[];
  label: string;
}

/**
 * A threshold interval session: warm-up, N reps with float recovery, cool-down.
 * Watts are synthetic but the shape matches a real 4×8' set closely enough for
 * the detector to be exercised end to end.
 */
export function demoStream(seed: string): DemoWorkout {
  const random = mulberry32(hashString(seed) || 1);
  const reps = 3 + Math.floor(random() * 3); // 3–5
  const workSec = [180, 240, 300, 360, 480][Math.floor(random() * 5)];
  const recoverSec = 90 + Math.floor(random() * 3) * 30;
  const warmupSec = 600;
  const cooldownSec = 480;

  const time: number[] = [];
  const watts: number[] = [];
  const heartrate: number[] = [];
  const velocity: number[] = [];
  const altitude: number[] = [];

  let t = 0;
  const push = (seconds: number, power: number, hr: number) => {
    for (let i = 0; i < seconds; i++) {
      const noise = (random() - 0.5) * 18;
      const wobble = Math.sin((t / 37) * Math.PI) * 6;
      const w = Math.max(60, Math.round(power + noise + wobble));
      time.push(t);
      watts.push(w);
      heartrate.push(Math.round(hr + (random() - 0.5) * 4));
      // ~3.3 m/s at 300 W, roughly 4:30/km.
      velocity.push(Math.round((1.9 + w / 190) * 100) / 100);
      // A gentle rolling course, so elevation and km splits have something to show.
      altitude.push(Math.round((46 + Math.sin(t / 260) * 16 + Math.sin(t / 41) * 3) * 10) / 10);
      t += 1;
    }
  };

  // Warm-up: easy, then a few short pickups.
  push(warmupSec, 165, 128);
  for (let pickup = 0; pickup < 3; pickup++) {
    push(20, 280, 145);
    push(60, 150, 132);
  }

  for (let rep = 0; rep < reps; rep++) {
    // Fade a little rep by rep, the way a real set does.
    const fade = 1 - rep * 0.025;
    push(workSec, 305 * fade, 160 + rep * 4);
    if (rep < reps - 1) push(recoverSec, 145, 138);
  }

  push(cooldownSec, 150, 124);

  const distance: number[] = [];
  let metres = 0;
  for (let i = 0; i < time.length; i++) {
    if (i > 0) metres += velocity[i - 1] * (time[i] - time[i - 1]);
    distance.push(Math.round(metres * 10) / 10);
  }

  return {
    time,
    watts,
    heartrate,
    velocity,
    distance,
    altitude,
    latlng: routeFor(distance, random),
    label: `${reps} × ${Math.round(workSec / 60)}′ threshold`
  };
}

/**
 * A winding path through the distance stream, so the demo runs have a shape on
 * the map. Each seed starts somewhere slightly different around Stockholm and
 * drifts, the way a city run does.
 */
function routeFor(distance: number[], random: () => number): LatLng[] {
  const latlng: LatLng[] = [];
  let lat = 59.3293 + (random() - 0.5) * 0.03;
  let lng = 18.0686 + (random() - 0.5) * 0.04;
  let heading = random() * Math.PI * 2;

  const round = (value: number) => Math.round(value * 1e5) / 1e5;
  for (let i = 0; i < distance.length; i++) {
    if (i > 0) {
      const step = Math.max(0, distance[i] - distance[i - 1]);
      heading += (random() - 0.5) * 0.03;
      lat += (step * Math.cos(heading)) / 111320;
      lng += (step * Math.sin(heading)) / (111320 * Math.cos((lat * Math.PI) / 180));
    }
    latlng.push([round(lat), round(lng)]);
  }
  return latlng;
}

export interface DemoActivitySeed {
  externalId: string;
  daysAgo: number;
  mode: ModeId;
  name: string;
  durationSec: number;
  distanceM: number;
  avgHr: number;
  maxHr: number;
  load: number;
}

export function demoActivities(): DemoActivitySeed[] {
  return [
    {
      externalId: 'demo-threshold',
      daysAgo: 2,
      mode: 'run',
      name: 'Threshold 4×8′',
      durationSec: 3480,
      distanceM: 11800,
      avgHr: 152,
      maxHr: 175,
      load: 92
    },
    {
      externalId: 'demo-long',
      daysAgo: 4,
      mode: 'run',
      name: 'Long easy run',
      durationSec: 5400,
      distanceM: 15600,
      avgHr: 138,
      maxHr: 149,
      load: 74
    },
    {
      externalId: 'demo-ski',
      daysAgo: 6,
      mode: 'ski',
      name: 'Roller ski technique',
      durationSec: 4200,
      distanceM: 18200,
      avgHr: 141,
      maxHr: 160,
      load: 68
    },
    {
      externalId: 'demo-easy',
      daysAgo: 8,
      mode: 'run',
      name: 'Easy shakeout',
      durationSec: 2400,
      distanceM: 6800,
      avgHr: 131,
      maxHr: 142,
      load: 32
    },
    {
      externalId: 'demo-mtb',
      daysAgo: 10,
      mode: 'mtb',
      name: 'MTB trail ride',
      durationSec: 4860,
      distanceM: 21400,
      avgHr: 147,
      maxHr: 172,
      load: 86
    },
    {
      externalId: 'demo-orienteering',
      daysAgo: 12,
      mode: 'orienteering',
      name: 'Orienteering training',
      durationSec: 4320,
      distanceM: 8400,
      avgHr: 158,
      maxHr: 181,
      load: 94
    }
  ];
}

/** A week of sensible training anchored on the given Monday. */
export function demoSessions(mondayISO: string): SessionInput[] {
  // Stay in UTC: parsing "YYYY-MM-DDT00:00:00" as local time and formatting it
  // back with toISOString() shifts the whole week west of Greenwich by a day.
  const base = new Date(`${mondayISO}T00:00:00Z`);
  const dateAt = (offset: number) => {
    const date = new Date(base);
    date.setUTCDate(date.getUTCDate() + offset);
    return date.toISOString().slice(0, 10);
  };

  const make = (dayOffset: number, overrides: Partial<SessionInput>): SessionInput => ({
    date: dateAt(dayOffset),
    mode: 'run',
    kind: 'steady',
    title: '',
    zone: 2,
    minutes: 60,
    reps: 4,
    workMin: 8,
    recoverMin: 2,
    warmupMin: 15,
    cooldownMin: 10,
    notes: '',
    status: 'planned',
    ...overrides
  });

  return [
    make(0, { minutes: 45, targetKm: 8, zone: 1, title: 'Recovery jog', notes: 'Nose breathing only.' }),
    make(1, { kind: 'intervals', zone: 4, title: 'Threshold 4×8′', notes: 'Even pacing, controlled breathing.' }),
    make(2, { minutes: 50, zone: 1, mode: 'ski', title: 'Technique', notes: 'Focus on the glide phase.' }),
    make(3, { minutes: 60, targetKm: 11, zone: 2, title: 'Easy endurance' }),
    make(4, { minutes: 40, zone: 1, mode: 'strength', kind: 'strength', title: 'Core & hips' }),
    make(5, { minutes: 90, targetKm: 16, zone: 2, mode: 'trail', title: 'Long run', notes: 'Last 15 minutes steady.' }),
    make(6, { minutes: 30, targetKm: 5, zone: 1, mode: 'orienteering', title: 'Optional shakeout' })
  ];
}
