import { and, desc, eq, gte, isNotNull, isNull, sql } from 'drizzle-orm';
import { db, schema } from '@/db';
import type { LatLng } from '@/domain/geo';
import type { HeatRoute } from '@/domain/heat';
import { parseRoute, ROUTE_POINTS, serialiseRoute } from '@/domain/route-json';
import { activityStreams, type StreamSource } from './activity-streams';
import { routePoints } from './icu';

/**
 * Stored GPS traces.
 *
 * A heat map needs every run at once, and fetching a stream per activity on each
 * page load would hammer intervals.icu, so each trace is thinned once and kept in
 * the activity row — see domain/route-json for the shape.
 */

export { parseRoute, ROUTE_POINTS, serialiseRoute };

/** Every stored trace from `fromISO` onwards, newest first. */
export async function storedRoutes(userId: string, fromISO: string): Promise<HeatRoute[]> {
  const rows = await db
    .select({
      id: schema.activities.id,
      date: schema.activities.date,
      name: schema.activities.name,
      routeJson: schema.activities.routeJson
    })
    .from(schema.activities)
    .where(
      and(
        eq(schema.activities.userId, userId),
        eq(schema.activities.removed, false),
        gte(schema.activities.date, fromISO),
        isNotNull(schema.activities.routeJson)
      )
    )
    .orderBy(desc(schema.activities.date));

  const routes: HeatRoute[] = [];
  for (const row of rows) {
    const points = parseRoute(row.routeJson);
    if (points.length > 1) routes.push({ id: row.id, date: row.date, name: row.name, points });
  }
  return routes;
}

/** How many activities in the window still have to be read before the map is complete. */
export async function missingRoutes(userId: string, fromISO: string): Promise<number> {
  const [row] = await db
    .select({ count: sql<number>`count(*)` })
    .from(schema.activities)
    .where(
      and(
        eq(schema.activities.userId, userId),
        eq(schema.activities.removed, false),
        gte(schema.activities.date, fromISO),
        isNull(schema.activities.routeJson)
      )
    );
  return Number(row?.count ?? 0);
}

/**
 * Reads the traces of the newest activities that have none yet, a few at a time
 * so a single press stays quick. An activity whose streams cannot be read is
 * stored as an empty route instead of being tried again and again.
 */
export async function fetchMissingRoutes(
  userId: string,
  limit = 12
): Promise<{ loaded: number; remaining: number }> {
  const rows = await db
    .select({
      id: schema.activities.id,
      externalId: schema.activities.externalId,
      source: schema.activities.source
    })
    .from(schema.activities)
    .where(
      and(
        eq(schema.activities.userId, userId),
        eq(schema.activities.removed, false),
        isNull(schema.activities.routeJson)
      )
    )
    .orderBy(desc(schema.activities.date))
    .limit(Math.max(1, Math.min(40, limit)));

  let loaded = 0;
  for (const row of rows) {
    let points: LatLng[] = [];
    try {
      const streams = await activityStreams(userId, {
        externalId: row.externalId,
        source: row.source as StreamSource['source']
      });
      points = routePoints(streams, ROUTE_POINTS);
    } catch {
      points = [];
    }
    await db
      .update(schema.activities)
      .set({ routeJson: serialiseRoute(points) })
      .where(and(eq(schema.activities.id, row.id), eq(schema.activities.userId, userId)));
    loaded += 1;
  }

  const [remaining] = await db
    .select({ count: sql<number>`count(*)` })
    .from(schema.activities)
    .where(
      and(
        eq(schema.activities.userId, userId),
        eq(schema.activities.removed, false),
        isNull(schema.activities.routeJson)
      )
    );
  return { loaded, remaining: Number(remaining?.count ?? 0) };
}
