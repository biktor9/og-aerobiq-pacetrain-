import { estimateTokens } from './quota';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface DeepSeekOptions {
  apiKey: string;
  baseUrl: string;
  model: string;
  messages: ChatMessage[];
  maxTokens?: number;
  temperature?: number;
  signal?: AbortSignal;
}

export type StreamEvent =
  | { type: 'delta'; text: string }
  | { type: 'done'; usage: { promptTokens: number; completionTokens: number } }
  | { type: 'error'; message: string };

/**
 * Yields the `data:` payloads of a server-sent-events stream. Kept separate
 * from the HTTP call so the framing logic can be tested without a network.
 */
export async function* sseData(stream: ReadableStream<Uint8Array>): AsyncGenerator<string> {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, '\n');
      let boundary = buffer.indexOf('\n\n');
      while (boundary >= 0) {
        const block = buffer.slice(0, boundary);
        buffer = buffer.slice(boundary + 2);
        yield* payloads(block);
        boundary = buffer.indexOf('\n\n');
      }
    }
    buffer += decoder.decode().replace(/\r\n/g, '\n');
    if (buffer.trim()) yield* payloads(buffer);
  } finally {
    reader.releaseLock();
  }
}

function* payloads(block: string): Generator<string> {
  for (const line of block.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed.startsWith('data:')) continue;
    const payload = trimmed.slice(5).trim();
    if (payload) yield payload;
  }
}

export interface ParsedChunk {
  text: string;
  promptTokens: number;
  completionTokens: number;
  done: boolean;
}

export function parseDeepSeekChunk(payload: string): ParsedChunk {
  if (payload === '[DONE]') {
    return { text: '', promptTokens: 0, completionTokens: 0, done: true };
  }
  try {
    const json = JSON.parse(payload) as {
      choices?: { delta?: { content?: string | null }; message?: { content?: string | null } }[];
      usage?: { prompt_tokens?: number; completion_tokens?: number } | null;
    };
    const choice = json.choices?.[0];
    const text = choice?.delta?.content ?? choice?.message?.content ?? '';
    return {
      text,
      promptTokens: json.usage?.prompt_tokens ?? 0,
      completionTokens: json.usage?.completion_tokens ?? 0,
      done: false
    };
  } catch {
    // A malformed frame should not kill the stream; the next one may be fine.
    return { text: '', promptTokens: 0, completionTokens: 0, done: false };
  }
}

export function describeDeepSeekError(status: number, body: string): string {
  const detail = body.slice(0, 300);
  switch (status) {
    case 401:
    case 403:
      return 'DeepSeek rejected the API key. Check DEEPSEEK_API_KEY (or the key saved in Settings).';
    case 402:
      return 'The DeepSeek account is out of credit. Top it up or use your own key in Settings.';
    case 429:
      return 'DeepSeek is rate limiting us right now. Give it a minute and try again.';
    case 400:
      return `DeepSeek rejected the request: ${detail}`;
    default:
      if (status >= 500) return 'DeepSeek had a server error. Trying again usually works.';
      return `DeepSeek request failed (${status}). ${detail}`.trim();
  }
}

/**
 * Streams a chat completion. Nothing here touches the browser: the API key is
 * only ever read on the server.
 */
export async function* streamDeepSeek(options: DeepSeekOptions): AsyncGenerator<StreamEvent> {
  const body = {
    model: options.model,
    messages: options.messages,
    stream: true,
    max_tokens: options.maxTokens ?? 700,
    temperature: options.temperature ?? 0.4,
    stream_options: { include_usage: true }
  };

  let response: Response;
  try {
    response = await fetch(`${options.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${options.apiKey}`,
        'Content-Type': 'application/json',
        Accept: 'text/event-stream'
      },
      body: JSON.stringify(body),
      signal: options.signal
    });
  } catch (error) {
    yield {
      type: 'error',
      message:
        error instanceof Error && error.name === 'AbortError'
          ? 'The answer was cancelled.'
          : 'Could not reach DeepSeek. Check the connection and try again.'
    };
    return;
  }

  if (!response.ok) {
    const text = await response.text().catch(() => '');
    yield { type: 'error', message: describeDeepSeekError(response.status, text) };
    return;
  }
  if (!response.body) {
    yield { type: 'error', message: 'DeepSeek returned an empty response.' };
    return;
  }

  let promptTokens = 0;
  let completionTokens = 0;
  let received = '';

  for await (const payload of sseData(response.body)) {
    const chunk = parseDeepSeekChunk(payload);
    if (chunk.promptTokens) promptTokens = chunk.promptTokens;
    if (chunk.completionTokens) completionTokens = chunk.completionTokens;
    if (chunk.text) {
      received += chunk.text;
      yield { type: 'delta', text: chunk.text };
    }
    if (chunk.done) break;
  }

  yield {
    type: 'done',
    usage: {
      promptTokens: promptTokens || estimateTokens(options.messages.map((m) => m.content).join('\n')),
      completionTokens: completionTokens || estimateTokens(received)
    }
  };
}
