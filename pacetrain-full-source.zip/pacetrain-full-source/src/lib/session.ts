import { headers } from 'next/headers';
import { redirect } from 'next/navigation';
import { auth } from './auth';
import { appConfig } from './env';

export type SessionUser = {
  id: string;
  name: string;
  email: string;
  image?: string | null;
  role?: string | null;
  createdAt: Date;
};

export async function getSession() {
  return auth.api.getSession({ headers: await headers() });
}

/** Redirects to /sign-in when there is no session. */
export async function requireUser(): Promise<SessionUser> {
  const session = await getSession();
  if (!session?.user) redirect('/sign-in');
  return session.user as SessionUser;
}

export async function requireAdmin(): Promise<SessionUser> {
  const user = await requireUser();
  if (!isAdmin(user)) redirect('/plan');
  return user;
}

/**
 * The database role, or an address listed in ADMIN_EMAILS. The env list is also
 * applied at sign-up, but checking it here means the owner can promote an
 * existing account (including one created before the paywall) by editing
 * `.env.local` and restarting — no SQL required.
 */
export function isAdmin(user: { role?: string | null; email?: string | null } | null | undefined): boolean {
  if (!user) return false;
  if (user.role === 'admin') return true;
  const email = (user.email ?? '').trim().toLowerCase();
  return email.length > 0 && appConfig().adminEmails.includes(email);
}
