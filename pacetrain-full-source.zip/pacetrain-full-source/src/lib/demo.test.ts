import { describe, expect, it } from 'vitest';
import { detectIntervals, normalizeDetectParams } from '@/domain/intervals';
import { demoSessions, demoStream, demoActivities } from './demo';

const repsFromLabel = (label: string) => Number(label.split(' ')[0]);

describe('demoStream', () => {
  it('is deterministic for the same seed', () => {
    const first = demoStream('demo-threshold');
    const second = demoStream('demo-threshold');
    expect(second.watts).toEqual(first.watts);
    expect(second.heartrate).toEqual(first.heartrate);
    expect(second.velocity).toEqual(first.velocity);
  });

  it('differs between seeds', () => {
    expect(demoStream('demo-threshold').watts).not.toEqual(demoStream('demo-long').watts);
  });

  it('keeps every stream aligned with the time axis', () => {
    const workout = demoStream('demo-threshold');
    expect(workout.watts).toHaveLength(workout.time.length);
    expect(workout.heartrate).toHaveLength(workout.time.length);
    expect(workout.velocity).toHaveLength(workout.time.length);
    expect(workout.time[0]).toBe(0);
    expect(workout.time[1] - workout.time[0]).toBe(1);
  });

  it('contains only usable positive values', () => {
    const { watts, heartrate, velocity } = demoStream('demo-threshold');
    for (const series of [watts, heartrate, velocity]) {
      expect(series.every((value) => Number.isFinite(value) && value > 0)).toBe(true);
    }
  });

  it('draws a GPS trace alongside the other streams', () => {
    const workout = demoStream('demo-threshold');

    expect(workout.latlng).toHaveLength(workout.time.length);
    // Somewhere around Stockholm: a real coordinate, not a zero without a fix.
    for (const [lat, lng] of workout.latlng) {
      expect(lat).toBeGreaterThan(59);
      expect(lat).toBeLessThan(60);
      expect(lng).toBeGreaterThan(17);
      expect(lng).toBeLessThan(19);
    }
    // It moves: the first and last points are a few kilometres apart.
    const first = workout.latlng[0];
    const last = workout.latlng[workout.latlng.length - 1];
    expect(Math.abs(last[0] - first[0]) + Math.abs(last[1] - first[1])).toBeGreaterThan(0.001);
  });
});

describe('demo data versus the interval detector', () => {
  it.each(['demo-threshold', 'sample-a', 'sample-b'])('finds every rep in %s', (seed) => {
    const workout = demoStream(seed);
    const expected = repsFromLabel(workout.label);
    const result = detectIntervals(workout.time, workout.watts, normalizeDetectParams({ metric: 'power' }));

    expect(result.reps).toBe(expected);
    expect(result.work).toHaveLength(expected);
    expect(result.threshold).toBeGreaterThan(0);
    expect(result.workTimeSec).toBeGreaterThan(0);
    expect(result.consistency).toBeGreaterThanOrEqual(0);
    expect(Number.isFinite(result.consistency)).toBe(true);
  });

  it('finds the same number of reps through the velocity stream', () => {
    const workout = demoStream('demo-threshold');
    const expected = repsFromLabel(workout.label);
    // The app converts intervals.icu's m/s into km/h before detection.
    const speed = workout.velocity.map((value) => value * 3.6);
    const result = detectIntervals(workout.time, speed, normalizeDetectParams({ metric: 'speed' }));

    expect(result.reps).toBe(expected);
    expect(result.metric).toBe('speed');
  });
});

describe('demoActivities', () => {
  it('returns distinct activities with plausible numbers', () => {
    const activities = demoActivities();
    expect(activities).toHaveLength(6);
    expect(new Set(activities.map((activity) => activity.externalId)).size).toBe(activities.length);
    expect(activities.map((activity) => activity.mode)).toEqual(
      expect.arrayContaining(['run', 'ski', 'mtb', 'orienteering'])
    );

    for (const activity of activities) {
      expect(activity.durationSec).toBeGreaterThan(0);
      expect(activity.distanceM).toBeGreaterThan(0);
      expect(activity.maxHr).toBeGreaterThanOrEqual(activity.avgHr);
      expect(activity.load).toBeGreaterThan(0);
    }
  });
});

describe('demoSessions', () => {
  it('plans one week starting on the given Monday', () => {
    const sessions = demoSessions('2026-03-02');
    expect(sessions).toHaveLength(7);
    expect(sessions[0].date).toBe('2026-03-02');
    expect(sessions[6].date).toBe('2026-03-08');
    expect(new Set(sessions.map((session) => session.date)).size).toBe(7);
  });

  it('mixes modes and keeps the hard work bounded', () => {
    const sessions = demoSessions('2026-03-02');
    const hard = sessions.filter((session) => session.zone >= 4);
    expect(hard).toHaveLength(1);
    expect(sessions.some((session) => session.mode === 'ski')).toBe(true);
    expect(sessions.some((session) => session.mode === 'trail')).toBe(true);
    expect(sessions.some((session) => session.mode === 'orienteering')).toBe(true);
    expect(sessions.some((session) => session.kind === 'strength')).toBe(true);
    expect(sessions.every((session) => session.status === 'planned')).toBe(true);
  });
});
