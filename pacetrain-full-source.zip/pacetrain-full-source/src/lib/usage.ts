import { and, eq, gte, sql } from 'drizzle-orm';
import { db, schema } from '@/db';
import { type QuotaDecision, daysBetween, decideQuota, utcDay } from './quota';

export interface UsageSnapshot {
  day: string;
  requestsToday: number;
  byokToday: number;
  requestsLastHour: number;
  globalTokensToday: number;
  promptTokensToday: number;
  completionTokensToday: number;
}

export async function usageSnapshot(userId: string, now = new Date()): Promise<UsageSnapshot> {
  const day = utcDay(now);
  const hourAgo = new Date(now.getTime() - 60 * 60 * 1000);

  const [today] = await db
    .select()
    .from(schema.usageDaily)
    .where(and(eq(schema.usageDaily.userId, userId), eq(schema.usageDaily.day, day)))
    .limit(1);

  const [hourly] = await db
    .select({ count: sql<number>`count(*)` })
    .from(schema.chatMessages)
    .where(
      and(
        eq(schema.chatMessages.userId, userId),
        eq(schema.chatMessages.role, 'user'),
        gte(schema.chatMessages.createdAt, hourAgo)
      )
    );

  const [global] = await db
    .select({
      prompt: sql<number>`coalesce(sum(${schema.usageDaily.promptTokens}), 0)`,
      completion: sql<number>`coalesce(sum(${schema.usageDaily.completionTokens}), 0)`
    })
    .from(schema.usageDaily)
    .where(eq(schema.usageDaily.day, day));

  return {
    day,
    requestsToday: today?.requests ?? 0,
    byokToday: today?.byokRequests ?? 0,
    requestsLastHour: Number(hourly?.count ?? 0),
    globalTokensToday: Number(global?.prompt ?? 0) + Number(global?.completion ?? 0),
    promptTokensToday: today?.promptTokens ?? 0,
    completionTokensToday: today?.completionTokens ?? 0
  };
}

export interface RecordUsageInput {
  userId: string;
  promptTokens: number;
  completionTokens: number;
  /** True when the request used the user's own key (not counted against quotas). */
  byok?: boolean;
  now?: Date;
}

export async function recordUsage(input: RecordUsageInput): Promise<void> {
  const day = utcDay(input.now ?? new Date());
  const now = input.now ?? new Date();
  const byok = input.byok ? 1 : 0;

  await db
    .insert(schema.usageDaily)
    .values({
      userId: input.userId,
      day,
      requests: byok ? 0 : 1,
      byokRequests: byok,
      promptTokens: input.promptTokens,
      completionTokens: input.completionTokens,
      updatedAt: now
    })
    .onConflictDoUpdate({
      target: [schema.usageDaily.userId, schema.usageDaily.day],
      set: {
        requests: sql`${schema.usageDaily.requests} + ${byok ? 0 : 1}`,
        byokRequests: sql`${schema.usageDaily.byokRequests} + ${byok}`,
        promptTokens: sql`${schema.usageDaily.promptTokens} + ${input.promptTokens}`,
        completionTokens: sql`${schema.usageDaily.completionTokens} + ${input.completionTokens}`,
        updatedAt: now
      }
    });
}

export interface QuotaSubject {
  id: string;
  createdAt: Date;
}

/**
 * Reads the counters and applies the rules. `hasOwnKey` comes from the stored
 * (encrypted) personal key, never from the request body.
 */
export async function checkQuota(
  user: QuotaSubject,
  options: { hasOwnKey: boolean; dailyTokenBudget: number; now?: Date }
): Promise<{ decision: QuotaDecision; usage: UsageSnapshot }> {
  const now = options.now ?? new Date();
  const usage = await usageSnapshot(user.id, now);
  const decision = decideQuota({
    accountAgeDays: daysBetween(user.createdAt, now),
    hasOwnKey: options.hasOwnKey,
    requestsLastHour: usage.requestsLastHour,
    requestsToday: usage.requestsToday,
    globalTokensToday: usage.globalTokensToday,
    dailyTokenBudget: options.dailyTokenBudget
  });
  return { decision, usage };
}

export interface AdminUsageRow {
  userId: string;
  email: string;
  name: string;
  role: string;
  requestsToday: number;
  tokensToday: number;
  requests7d: number;
  tokens7d: number;
  messages: number;
}

/** Aggregated usage for the admin dashboard. */
export async function adminUsage(now = new Date()): Promise<AdminUsageRow[]> {
  const day = utcDay(now);
  const weekAgo = utcDay(new Date(now.getTime() - 6 * 86_400_000));

  const users = await db
    .select({
      id: schema.user.id,
      email: schema.user.email,
      name: schema.user.name,
      role: schema.user.role
    })
    .from(schema.user)
    .orderBy(schema.user.createdAt);

  const daily = await db.select().from(schema.usageDaily).where(gte(schema.usageDaily.day, weekAgo));
  const messages = await db
    .select({ userId: schema.chatMessages.userId, count: sql<number>`count(*)` })
    .from(schema.chatMessages)
    .where(eq(schema.chatMessages.role, 'user'))
    .groupBy(schema.chatMessages.userId);

  return users.map((user) => {
    const rows = daily.filter((row) => row.userId === user.id);
    const today = rows.filter((row) => row.day === day);
    return {
      userId: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      requestsToday: today.reduce((sum, row) => sum + row.requests + row.byokRequests, 0),
      tokensToday: today.reduce((sum, row) => sum + row.promptTokens + row.completionTokens, 0),
      requests7d: rows.reduce((sum, row) => sum + row.requests + row.byokRequests, 0),
      tokens7d: rows.reduce((sum, row) => sum + row.promptTokens + row.completionTokens, 0),
      messages: Number(messages.find((m) => m.userId === user.id)?.count ?? 0)
    };
  });
}
