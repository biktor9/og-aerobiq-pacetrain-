import Database from 'better-sqlite3';
import { getCloudflareContext } from '@opennextjs/cloudflare';
import { drizzle as drizzleD1 } from 'drizzle-orm/d1';
import { drizzle as drizzleSqlite, type BetterSQLite3Database } from 'drizzle-orm/better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import * as schema from './schema';

/**
 * One schema, two runtimes.
 *
 * Locally the app talks to a SQLite file through better-sqlite3. On Cloudflare
 * Workers there is no filesystem and native modules cannot load, so the same
 * Drizzle schema is served by D1 (SQLite over a binding). Only the client
 * differs: every query in the app is awaited, which is exactly what D1 needs.
 *
 * `DATABASE_DRIVER=d1` (set in wrangler.jsonc) selects D1, and that branch is
 * the only one a Worker ever takes. better-sqlite3 is a native module, so it is
 * never *called* there — but note that the bundler does carry its JavaScript
 * along. At the time of writing that is ~1.8 MB gzipped in total, inside
 * Cloudflare's 3 MB free-tier limit, and nothing in the D1 path touches it. The
 * alternative — two separately built entry points — costs more than it saves.
 */

export type Database = BetterSQLite3Database<typeof schema>;

function usesD1(): boolean {
  return (process.env.DATABASE_DRIVER ?? '').toLowerCase() === 'd1';
}

function resolveDbFile(): string {
  const raw = process.env.DATABASE_URL?.trim() || './data/pacetrain.db';
  const withoutScheme = raw.startsWith('file:') ? raw.slice('file:'.length) : raw;
  return path.isAbsolute(withoutScheme) ? withoutScheme : path.join(process.cwd(), withoutScheme);
}

/** Where the file lives, or `d1` when the app is running on Workers. */
export const dbFile = usesD1() ? 'd1' : resolveDbFile();

function createSqliteClient(): Database {
  fs.mkdirSync(path.dirname(dbFile), { recursive: true });
  const sqlite = new Database(dbFile);
  sqlite.pragma('journal_mode = WAL');
  sqlite.pragma('foreign_keys = ON');
  sqlite.pragma('busy_timeout = 5000');
  return drizzleSqlite(sqlite, { schema });
}

function createD1Client(): Database {
  const { env } = getCloudflareContext();
  const binding = (env as Record<string, unknown>).DB;
  if (!binding) {
    throw new Error('The D1 binding `DB` is missing. Check `d1_databases` in wrangler.jsonc.');
  }
  // Same Drizzle surface, async underneath; the cast is only about the driver's
  // return type, never about the queries.
  return drizzleD1(binding as Parameters<typeof drizzleD1>[0], { schema }) as unknown as Database;
}

function createClient(): Database {
  return usesD1() ? createD1Client() : createSqliteClient();
}

// Reuse one connection across dev hot-reloads so SQLite is not reopened on
// every edit (and to avoid holding several write locks at once). On Workers the
// isolate keeps its own D1 binding, which costs nothing to hold.
const globalForDb = globalThis as typeof globalThis & { __pacetrainDb?: Database };

export const db: Database = globalForDb.__pacetrainDb ?? createClient();
globalForDb.__pacetrainDb = db;

export type { Database as DatabaseClient };
export { schema };

