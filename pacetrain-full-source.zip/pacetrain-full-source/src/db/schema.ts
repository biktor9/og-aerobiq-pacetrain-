import { index, integer, primaryKey, real, sqliteTable, text, uniqueIndex } from 'drizzle-orm/sqlite-core';

/**
 * Schema for PaceTrain.
 *
 * The first four tables are better-auth's own tables (drizzle sqlite adapter).
 * Field names are part of better-auth's contract — do not rename them.
 */

export const user = sqliteTable('user', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull().unique(),
  emailVerified: integer('email_verified', { mode: 'boolean' }).notNull().default(false),
  image: text('image'),
  role: text('role').notNull().default('user'),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull(),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull()
});

export const session = sqliteTable('session', {
  id: text('id').primaryKey(),
  expiresAt: integer('expires_at', { mode: 'timestamp' }).notNull(),
  token: text('token').notNull().unique(),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull(),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull(),
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),
  userId: text('user_id')
    .notNull()
    .references(() => user.id, { onDelete: 'cascade' })
});

export const account = sqliteTable('account', {
  id: text('id').primaryKey(),
  accountId: text('account_id').notNull(),
  providerId: text('provider_id').notNull(),
  userId: text('user_id')
    .notNull()
    .references(() => user.id, { onDelete: 'cascade' }),
  accessToken: text('access_token'),
  refreshToken: text('refresh_token'),
  idToken: text('id_token'),
  accessTokenExpiresAt: integer('access_token_expires_at', { mode: 'timestamp' }),
  refreshTokenExpiresAt: integer('refresh_token_expires_at', { mode: 'timestamp' }),
  scope: text('scope'),
  password: text('password'),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull(),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull()
});

export const verification = sqliteTable('verification', {
  id: text('id').primaryKey(),
  identifier: text('identifier').notNull(),
  value: text('value').notNull(),
  expiresAt: integer('expires_at', { mode: 'timestamp' }).notNull(),
  createdAt: integer('created_at', { mode: 'timestamp' }),
  updatedAt: integer('updated_at', { mode: 'timestamp' })
});

/** Per-user preferences and the (encrypted) personal DeepSeek key for BYOK. */
export const userSettings = sqliteTable('user_settings', {
  userId: text('user_id')
    .primaryKey()
    .references(() => user.id, { onDelete: 'cascade' }),
  goalText: text('goal_text').notNull().default(''),
  eventDate: text('event_date'),
  weeklyMinutesTarget: integer('weekly_minutes_target').notNull().default(360),
  weeklyLoadTarget: integer('weekly_load_target').notNull().default(240),
  primaryMode: text('primary_mode').notNull().default('run'),
  coachTone: text('coach_tone').notNull().default('direct'),
  athleteNotes: text('athlete_notes').notNull().default(''),
  deepseekKeyEnc: text('deepseek_key_enc'),
  /**
   * The heat map remembers where and how far back: the centre it was dragged to,
   * the radius around it, the name the athlete gave it, and the window.
   */
  heatLat: real('heat_lat'),
  heatLng: real('heat_lng'),
  heatRadiusKm: integer('heat_radius_km').notNull().default(15),
  heatLabel: text('heat_label').notNull().default(''),
  heatPeriod: text('heat_period').notNull().default('week'),
  /** A maximum heart rate that overrules the one recorded in activities. */
  maxHr: integer('max_hr'),
  /**
   * The athlete's own zone boundaries, as bpm, in one comma-separated column:
   * `110,133,152,168` are the tops of Z1 … Z4, and Z5 is everything above. Null
   * means the default shares of `max_hr` are used instead.
   */
  hrZoneBounds: text('hr_zone_bounds'),
  /** Which sports count towards the week's heart-rate zones. Null = all of them. */
  hrZoneModes: text('hr_zone_modes'),
  /**
   * The plan page's layout: a JSON array of widget ids in the order they are
   * shown. Null means every widget, in the catalogue's default order.
   */
  dashboardJson: text('dashboard_json'),
  /**
   * How big each widget is drawn: `{"stat-load":"wide","mix":"wide"}`. Null
   * means every widget at its natural size.
   */
  dashboardSizes: text('dashboard_sizes'),
  /** `bar` (a meter that fills) or `ring` (a circle that closes). */
  progressStyle: text('progress_style').notNull().default('ring'),
  /**
   * Baselines typed by the athlete: HRV in ms, resting heart rate in bpm and
   * sleep in hours. A set value replaces the rolling average of the last 14 days.
   */
  baselineHrvMs: integer('baseline_hrv_ms'),
  baselineRestingHr: integer('baseline_resting_hr'),
  baselineSleepHours: real('baseline_sleep_hours'),
  onboardedAt: integer('onboarded_at', { mode: 'timestamp' }),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull(),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull()
});

/**
 * The note an admin pins to the top of a tab. One row per tab, shared by
 * everyone: the text is written once by an admin and read by every visitor, so
 * it lives here rather than in `user_settings`.
 */
export const pageNotes = sqliteTable('page_notes', {
  /** The page key: `plan`, `recovery`, … (see `domain/page-notes`). */
  page: text('page').primaryKey(),
  /** What the admin wrote. Empty is allowed and draws nothing. */
  body: text('body').notNull().default(''),
  /** Who wrote it last, kept for the record; unset when written by seed. */
  updatedBy: text('updated_by'),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull()
});

/** intervals.icu credentials, encrypted at rest with AES-256-GCM. */
export const icuCredentials = sqliteTable('icu_credentials', {
  userId: text('user_id')
    .primaryKey()
    .references(() => user.id, { onDelete: 'cascade' }),
  athleteId: text('athlete_id').notNull(),
  apiKeyEnc: text('api_key_enc').notNull(),
  keyLast4: text('key_last4').notNull().default(''),
  status: text('status').notNull().default('untested'),
  lastError: text('last_error'),
  lastSyncAt: integer('last_sync_at', { mode: 'timestamp' }),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull(),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull()
});

export const plannedSessions = sqliteTable(
  'planned_sessions',
  {
    id: text('id').primaryKey(),
    userId: text('user_id')
      .notNull()
      .references(() => user.id, { onDelete: 'cascade' }),
    date: text('date').notNull(),
    mode: text('mode').notNull(),
    kind: text('kind').notNull(),
    title: text('title').notNull().default(''),
    zone: integer('zone').notNull().default(2),
    minutes: integer('minutes').notNull().default(60),
    /**
     * Null while an interval session is planned by zone and total time only —
     * the reps get decided nearer the session.
     */
    reps: integer('reps'),
    workMin: real('work_min'),
    recoverMin: real('recover_min'),
    warmupMin: real('warmup_min').notNull().default(15),
    cooldownMin: real('cooldown_min').notNull().default(10),
    /**
     * Warm-up and cool-down written in kilometres instead of minutes. When one
     * is set it wins, and the minutes are derived from it at the athlete's pace.
     */
    warmupKm: real('warmup_km'),
    cooldownKm: real('cooldown_km'),
    /** Distance the athlete committed to, in km. Minutes stay the load driver. */
    targetKm: real('target_km'),
    /** Kilometres per rep for an interval session (`8×800 m`). */
    targetReps: real('target_reps'),
    notes: text('notes').notNull().default(''),
    status: text('status').notNull().default('planned'),
    /** JSON block list parsed from free text; null means "use the numbers above". */
    structureJson: text('structure_json'),
    linkedActivityId: text('linked_activity_id'),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull(),
    updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull()
  },
  (table) => [index('planned_sessions_user_date_idx').on(table.userId, table.date)]
);

/** Activities imported from intervals.icu (or seeded demo data). */
export const activities = sqliteTable(
  'activities',
  {
    id: text('id').primaryKey(),
    userId: text('user_id')
      .notNull()
      .references(() => user.id, { onDelete: 'cascade' }),
    externalId: text('external_id').notNull(),
    source: text('source').notNull().default('intervals.icu'),
    date: text('date').notNull(),
    mode: text('mode').notNull(),
    name: text('name').notNull().default(''),
    durationSec: integer('duration_sec').notNull().default(0),
    distanceM: real('distance_m').notNull().default(0),
    avgHr: integer('avg_hr'),
    maxHr: integer('max_hr'),
    load: real('load'),
    /** intervals.icu's average moving speed in m/s — the pace it displays. */
    avgSpeedMs: real('avg_speed_ms'),
    /**
     * Seconds in heart-rate zones Z1 … Z5 as intervals.icu computed them, in one
     * comma-separated column. Null when the platform had no zones to give.
     */
    hrZoneTimes: text('hr_zone_times'),
    /** 1–10 perceived effort, when the athlete rated it. */
    rpe: integer('rpe'),
    /** 1–5 how it felt, when the athlete rated it. */
    feel: integer('feel'),
    notes: text('notes').notNull().default(''),
    /**
     * The GPS trace, thinned to ~150 points and rounded to a metre. `null` means
     * "never fetched", `[]` means "fetched, but the activity has no GPS".
     */
    routeJson: text('route_json'),
    /**
     * Soft delete. Kept so a re-import cannot resurrect an activity the athlete
     * removed, and so "undo" is just a flag away.
     */
    removed: integer('removed', { mode: 'boolean' }).notNull().default(false),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull()
  },
  (table) => [
    uniqueIndex('activities_user_source_external_idx').on(table.userId, table.source, table.externalId),
    index('activities_user_date_idx').on(table.userId, table.date)
  ]
);

/** Cached interval-detection runs, so the Analysis tab reopens instantly. */
export const analyses = sqliteTable(
  'analyses',
  {
    id: text('id').primaryKey(),
    userId: text('user_id')
      .notNull()
      .references(() => user.id, { onDelete: 'cascade' }),
    activityId: text('activity_id').notNull(),
    paramsJson: text('params_json').notNull(),
    summary: text('summary').notNull().default(''),
    reps: integer('reps').notNull().default(0),
    resultJson: text('result_json').notNull(),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull()
  },
  (table) => [index('analyses_user_activity_idx').on(table.userId, table.activityId)]
);

export const chatMessages = sqliteTable(
  'chat_messages',
  {
    id: text('id').primaryKey(),
    userId: text('user_id')
      .notNull()
      .references(() => user.id, { onDelete: 'cascade' }),
    role: text('role').notNull(),
    content: text('content').notNull(),
    tokensIn: integer('tokens_in').notNull().default(0),
    tokensOut: integer('tokens_out').notNull().default(0),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull()
  },
  (table) => [index('chat_messages_user_created_idx').on(table.userId, table.createdAt)]
);

/** One row per user per UTC day: the source of truth for quota decisions. */
export const usageDaily = sqliteTable(
  'usage_daily',
  {
    userId: text('user_id')
      .notNull()
      .references(() => user.id, { onDelete: 'cascade' }),
    day: text('day').notNull(),
    requests: integer('requests').notNull().default(0),
    byokRequests: integer('byok_requests').notNull().default(0),
    promptTokens: integer('prompt_tokens').notNull().default(0),
    completionTokens: integer('completion_tokens').notNull().default(0),
    updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull()
  },
  (table) => [primaryKey({ columns: [table.userId, table.day] })]
);

/**
 * One wellness entry per day: sleep, resting heart rate, weight and how the
 * athlete felt. This is the "am I ready today?" half of intervals.icu, kept to
 * the five inputs that actually change a training decision.
 */
export const wellness = sqliteTable(
  'wellness',
  {
    id: text('id').primaryKey(),
    userId: text('user_id')
      .notNull()
      .references(() => user.id, { onDelete: 'cascade' }),
    date: text('date').notNull(),
    sleepHours: real('sleep_hours'),
    restingHr: integer('resting_hr'),
    weightKg: real('weight_kg'),
    /** Overnight HRV in ms (rMSSD), straight from the watch. */
    hrvMs: integer('hrv_ms'),
    /** 1 = terrible … 5 = great */
    sleepQuality: integer('sleep_quality'),
    /** 1 = fresh … 5 = very sore */
    soreness: integer('soreness'),
    /** The athlete's own correction: `better` | `as-expected` | `worse`. */
    feeling: text('feeling'),
    /** 1 = drained … 5 = great */
    mood: integer('mood'),
    /** 1 = calm … 5 = very stressed */
    stress: integer('stress'),
    /** Free text: "more tired than it says", "hectic week at work". */
    notes: text('notes').notNull().default(''),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull(),
    updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull()
  },
  (table) => [uniqueIndex('wellness_user_date_idx').on(table.userId, table.date)]
);

/**
 * An illness the athlete wants the plan and the coach to know about. One row
 * per period; `date_to` may be the same day, or later once it has passed.
 */
export const sickNotes = sqliteTable(
  'sick_notes',
  {
    id: text('id').primaryKey(),
    userId: text('user_id')
      .notNull()
      .references(() => user.id, { onDelete: 'cascade' }),
    dateFrom: text('date_from').notNull(),
    dateTo: text('date_to').notNull(),
    /** "Sore throat, fever 38.2, blocked nose" */
    symptoms: text('symptoms').notNull().default(''),
    /** 1 = mild, 2 = rough, 3 = bad. */
    severity: integer('severity').notNull().default(2),
    notes: text('notes').notNull().default(''),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull(),
    updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull()
  },
  (table) => [index('sick_notes_user_from_idx').on(table.userId, table.dateFrom)]
);

/** A race or a goal: the date the rest of the plan is built around. */
export const events = sqliteTable(
  'events',
  {
    id: text('id').primaryKey(),
    userId: text('user_id')
      .notNull()
      .references(() => user.id, { onDelete: 'cascade' }),
    name: text('name').notNull(),
    date: text('date').notNull(),
    mode: text('mode').notNull().default('run'),
    /** A = main goal, B = important tune-up, C = training race. */
    priority: text('priority').notNull().default('A'),
    distanceKm: real('distance_km'),
    targetTimeSec: integer('target_time_sec'),
    notes: text('notes').notNull().default(''),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull(),
    updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull()
  },
  (table) => [index('events_user_date_idx').on(table.userId, table.date)]
);

/**
 * Prepaid access periods: one row per purchase or grant. The latest
 * `expires_at` wins, and paying early extends the end of the current period.
 */
export const subscriptions = sqliteTable(
  'subscriptions',
  {
    id: text('id').primaryKey(),
    userId: text('user_id')
      .notNull()
      .references(() => user.id, { onDelete: 'cascade' }),
    /** `trial` | `quarter` | `halfYear` | `year` */
    plan: text('plan').notNull(),
    status: text('status').notNull().default('active'),
    /** `manual` | `grant` | `demo` */
    source: text('source').notNull().default('manual'),
    amountSek: integer('amount_sek').notNull().default(0),
    /** Swish reference, receipt number or an admin note. */
    reference: text('reference').notNull().default(''),
    note: text('note').notNull().default(''),
    startedAt: integer('started_at', { mode: 'timestamp' }).notNull(),
    expiresAt: integer('expires_at', { mode: 'timestamp' }).notNull(),
    createdAt: integer('created_at', { mode: 'timestamp' }).notNull(),
    updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull()
  },
  (table) => [index('subscriptions_user_expires_idx').on(table.userId, table.expiresAt)]
);

/**
 * Development mailbox. When EMAIL_TRANSPORT=console every outgoing mail is
 * stored here so it can be opened at /dev/mailbox instead of being sent.
 */
export const devMail = sqliteTable('dev_mail', {
  id: text('id').primaryKey(),
  to: text('to').notNull(),
  subject: text('subject').notNull(),
  body: text('body').notNull(),
  link: text('link').notNull().default(''),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull()
});
