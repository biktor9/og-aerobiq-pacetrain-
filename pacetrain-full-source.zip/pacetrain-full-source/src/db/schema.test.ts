import fs from 'node:fs';
import path from 'node:path';

import Database from 'better-sqlite3';
import { getTableColumns, getTableName, is } from 'drizzle-orm';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import { SQLiteTable } from 'drizzle-orm/sqlite-core';
import { afterAll, describe, expect, it } from 'vitest';

import * as schema from './schema';

/**
 * Regression guard for the `no such column: "structure_json"` incident: a
 * column was added to `schema.ts` without a matching migration, so drizzle
 * happily selected it while SQLite rejected the query at runtime. These tests
 * replay `drizzle/*.sql` onto an in-memory database and check that the result
 * covers everything the schema declares.
 */

const drizzleDir = path.join(process.cwd(), 'drizzle');

type Journal = { entries: { tag: string }[] };

function migrationTags(): string[] {
  const raw = fs.readFileSync(path.join(drizzleDir, 'meta', '_journal.json'), 'utf8');
  return (JSON.parse(raw) as Journal).entries.map((entry) => entry.tag);
}

function migrateInMemory(): Database.Database {
  const sqlite = new Database(':memory:');
  for (const tag of migrationTags()) {
    const file = path.join(drizzleDir, `${tag}.sql`);
    if (!fs.existsSync(file)) {
      throw new Error(`drizzle/meta/_journal.json lists ${tag} but ${path.basename(file)} is missing`);
    }
    sqlite.exec(fs.readFileSync(file, 'utf8').replaceAll('--> statement-breakpoint', ''));
  }
  return sqlite;
}

function columnsOf(sqlite: Database.Database, table: string): string[] {
  const rows = sqlite.prepare(`PRAGMA table_info("${table}")`).all() as { name: string }[];
  return rows.map((row) => row.name);
}

const sqlite = migrateInMemory();
const tables: SQLiteTable[] = Object.values(schema).filter((value) => is(value, SQLiteTable));

afterAll(() => {
  sqlite.close();
});

describe('drizzle migrations', () => {
  it('finds the schema tables it is meant to cover', () => {
    expect(tables.length).toBeGreaterThanOrEqual(12);
  });

  it('creates every table declared in schema.ts', () => {
    for (const table of tables) {
      const tableName = getTableName(table);
      expect(columnsOf(sqlite, tableName), tableName).not.toHaveLength(0);
    }
  });

  it('adds every column that drizzle selects for each table', () => {
    for (const table of tables) {
      const tableName = getTableName(table);
      const projection = Object.values(getTableColumns(table))
        .map((column) => `"${column.name}"`)
        .join(', ');

      expect(
        () => sqlite.prepare(`select ${projection} from "${tableName}" limit 1`).all(),
        tableName
      ).not.toThrow();
    }
  });

  it('keeps the planned sessions readable through drizzle', () => {
    const db = drizzle(sqlite);
    expect(() => db.select().from(schema.plannedSessions).limit(1).all()).not.toThrow();
  });

  it('makes every nullable column nullable in the database too', () => {
    // A column that is optional in `schema.ts` but NOT NULL in SQLite rejects
    // the row at runtime: an interval session saved without reps failed with
    // `NOT NULL constraint failed: planned_sessions.reps` because the migration
    // never dropped the old constraint.
    for (const table of tables) {
      const tableName = getTableName(table);
      const declared = new Map(
        (sqlite.prepare(`PRAGMA table_info("${tableName}")`).all() as { name: string; notnull: number }[]).map(
          (row) => [row.name, row.notnull === 1]
        )
      );

      for (const column of Object.values(getTableColumns(table))) {
        const notNullInSchema = column.notNull;
        const notNullInDb = declared.get(column.name);
        expect(notNullInDb, `${tableName}.${column.name}`).toBe(notNullInSchema);
      }
    }
  });

  it('lets an interval session be stored without reps', () => {
    // The exact insert the planner makes for "reps not chosen yet".
    sqlite
      .prepare(`insert into user (id, name, email, email_verified, role, created_at, updated_at) values ('u-test', 'T', 't@example.com', 0, 'user', 1, 1)`)
      .run();
    expect(() =>
      sqlite
        .prepare(
          `insert into planned_sessions
             (id, user_id, date, mode, kind, title, zone, minutes, reps, work_min, recover_min, notes, status, created_at, updated_at)
           values ('t1', 'u-test', '2026-10-26', 'run', 'intervals', '', 4, 90, null, null, null, '', 'planned', 1, 1)`
        )
        .run()
    ).not.toThrow();
    sqlite.prepare(`delete from planned_sessions where id = 't1'`).run();
    sqlite.prepare(`delete from user where id = 'u-test'`).run();
  });
});
